
package talend_tac2_repo.audit_incremental_7_tables_3_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: Audit_incremental_7_tables_3 Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230612_1054-patch
 * @status 
 */
public class Audit_incremental_7_tables_3 implements TalendJob {
	static {System.setProperty("TalendJob.log", "Audit_incremental_7_tables_3.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(Audit_incremental_7_tables_3.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "Audit_incremental_7_tables_3";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_4U2qwNkuEe2cDNax3wxz5A", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				Audit_incremental_7_tables_3.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(Audit_incremental_7_tables_3.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_1_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_2_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_3_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_4_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_5_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_6_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_7_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	



public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public int audit_plan_id;

				public int getAudit_plan_id () {
					return this.audit_plan_id;
				}

				public Boolean audit_plan_idIsNullable(){
				    return false;
				}
				public Boolean audit_plan_idIsKey(){
				    return false;
				}
				public Integer audit_plan_idLength(){
				    return 10;
				}
				public Integer audit_plan_idPrecision(){
				    return 0;
				}
				public String audit_plan_idDefault(){
				
					return null;
				
				}
				public String audit_plan_idComment(){
				
				    return "";
				
				}
				public String audit_plan_idPattern(){
				
					return "";
				
				}
				public String audit_plan_idOriginalDbColumnName(){
				
					return "audit_plan_id";
				
				}

				
			    public Integer total_questions;

				public Integer getTotal_questions () {
					return this.total_questions;
				}

				public Boolean total_questionsIsNullable(){
				    return true;
				}
				public Boolean total_questionsIsKey(){
				    return false;
				}
				public Integer total_questionsLength(){
				    return 10;
				}
				public Integer total_questionsPrecision(){
				    return 0;
				}
				public String total_questionsDefault(){
				
					return null;
				
				}
				public String total_questionsComment(){
				
				    return "";
				
				}
				public String total_questionsPattern(){
				
					return "";
				
				}
				public String total_questionsOriginalDbColumnName(){
				
					return "total_questions";
				
				}

				
			    public Integer total_process;

				public Integer getTotal_process () {
					return this.total_process;
				}

				public Boolean total_processIsNullable(){
				    return true;
				}
				public Boolean total_processIsKey(){
				    return false;
				}
				public Integer total_processLength(){
				    return 10;
				}
				public Integer total_processPrecision(){
				    return 0;
				}
				public String total_processDefault(){
				
					return null;
				
				}
				public String total_processComment(){
				
				    return "";
				
				}
				public String total_processPattern(){
				
					return "";
				
				}
				public String total_processOriginalDbColumnName(){
				
					return "total_process";
				
				}

				
			    public Integer is_partial;

				public Integer getIs_partial () {
					return this.is_partial;
				}

				public Boolean is_partialIsNullable(){
				    return true;
				}
				public Boolean is_partialIsKey(){
				    return false;
				}
				public Integer is_partialLength(){
				    return 10;
				}
				public Integer is_partialPrecision(){
				    return 0;
				}
				public String is_partialDefault(){
				
					return null;
				
				}
				public String is_partialComment(){
				
				    return "";
				
				}
				public String is_partialPattern(){
				
					return "";
				
				}
				public String is_partialOriginalDbColumnName(){
				
					return "is_partial";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return true;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.id = this.id;
	            other.audit_plan_id = this.audit_plan_id;
	            other.total_questions = this.total_questions;
	            other.total_process = this.total_process;
	            other.is_partial = this.is_partial;
	            other.created_on = this.created_on;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.id = this.id;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
			        this.audit_plan_id = dis.readInt();
					
						this.total_questions = readInteger(dis);
					
						this.total_process = readInteger(dis);
					
						this.is_partial = readInteger(dis);
					
					this.created_on = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
			        this.audit_plan_id = dis.readInt();
					
						this.total_questions = readInteger(dis);
					
						this.total_process = readInteger(dis);
					
						this.is_partial = readInteger(dis);
					
					this.created_on = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// int
				
		            	dos.writeInt(this.audit_plan_id);
					
					// Integer
				
						writeInteger(this.total_questions,dos);
					
					// Integer
				
						writeInteger(this.total_process,dos);
					
					// Integer
				
						writeInteger(this.is_partial,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// int
				
		            	dos.writeInt(this.audit_plan_id);
					
					// Integer
				
						writeInteger(this.total_questions,dos);
					
					// Integer
				
						writeInteger(this.total_process,dos);
					
					// Integer
				
						writeInteger(this.is_partial,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",audit_plan_id="+String.valueOf(audit_plan_id));
		sb.append(",total_questions="+String.valueOf(total_questions));
		sb.append(",total_process="+String.valueOf(total_process));
		sb.append(",is_partial="+String.valueOf(is_partial));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				sb.append(audit_plan_id);
        			
        			sb.append("|");
        		
        				if(total_questions == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_questions);
            			}
            		
        			sb.append("|");
        		
        				if(total_process == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_process);
            			}
            		
        			sb.append("|");
        		
        				if(is_partial == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_partial);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", "2MP7z0_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_1", false);
		start_Hash.put("tAsyncOut_tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tAsyncOut_tDBOutput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_1", "tAsyncOut_tDBOutput_1", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_1 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_1 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_1 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_1=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_1 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_1", pool_tAsyncOut_tDBOutput_1);
	final Object[] lockWrite_tAsyncOut_tDBOutput_1 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_1", lockWrite_tAsyncOut_tDBOutput_1);
 



/**
 * [tAsyncOut_tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_details\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"audit_details\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT    `audit_details`.`id`,    `audit_details`.`audit_plan_id`,    `audit_details`.`total_questions`,    `audit_details`.`total_process`,    `audit_details`.`is_partial`,    `audit_details`.`created_on`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `audit_details`\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audit_plan_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("total_questions")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("total_process")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_partial")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"audit_details\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
		    calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();
				if(stmt_tDBInput_1 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_1).enableStreamingResults();
				}else if(stmt_tDBInput_1 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_1).enableStreamingResults();
				}

		    String dbquery_tDBInput_1 = "SELECT \n  `audit_details`.`id`, \n  `audit_details`.`audit_plan_id`, \n  `audit_details`.`total_questions`, \n  `audit_det"
+"ails`.`total_process`, \n  `audit_details`.`is_partial`, \n  `audit_details`.`created_on`,\n	DATE_SUB(CURRENT_TIMESTAMP, I"
+"NTERVAL 1 DAY) AS `as_on`\nFROM `audit_details`";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.id = 0;
							} else {
		                          
            row1.id = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.audit_plan_id = 0;
							} else {
		                          
            row1.audit_plan_id = rs_tDBInput_1.getInt(2);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.total_questions = null;
							} else {
		                          
            row1.total_questions = rs_tDBInput_1.getInt(3);
            if(rs_tDBInput_1.wasNull()){
                    row1.total_questions = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.total_process = null;
							} else {
		                          
            row1.total_process = rs_tDBInput_1.getInt(4);
            if(rs_tDBInput_1.wasNull()){
                    row1.total_process = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.is_partial = null;
							} else {
		                          
            row1.is_partial = rs_tDBInput_1.getInt(5);
            if(rs_tDBInput_1.wasNull()){
                    row1.is_partial = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.created_on = null;
							} else {
										
				if(rs_tDBInput_1.getString(6) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(6);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.created_on = rs_tDBInput_1.getTimestamp(6);
					} else {
						row1.created_on = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.as_on = null;
							} else {
										
				if(rs_tDBInput_1.getString(7) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(7);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.as_on = rs_tDBInput_1.getTimestamp(7);
					} else {
						row1.as_on = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					

 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_details\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_details\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tDBInput_1","\"audit_details\"","tMysqlInput","tAsyncOut_tDBOutput_1","tAsyncOut_tDBOutput_1","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_1=new Object[]{null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_1[0] = String.valueOf(row1.id); 
	row_tAsyncOut_tDBOutput_1[1] = String.valueOf(row1.audit_plan_id); 
	if(row1.total_questions != null){
		row_tAsyncOut_tDBOutput_1[2] = String.valueOf(row1.total_questions);                			    
	}
	if(row1.total_process != null){
		row_tAsyncOut_tDBOutput_1[3] = String.valueOf(row1.total_process);                			    
	}
	if(row1.is_partial != null){
		row_tAsyncOut_tDBOutput_1[4] = String.valueOf(row1.is_partial);                			    
	}
	if(row1.created_on != null){
		row_tAsyncOut_tDBOutput_1[5] = row1.created_on;                			    
	}
	if(row1.as_on != null){
		row_tAsyncOut_tDBOutput_1[6] = row1.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_1 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_1", buffers_tAsyncOut_tDBOutput_1);
		/*tAsyncIn_tDBOutput_7Process(globalMap);*/
		tAsyncIn_tDBOutput_1Process(globalMap);
		buffers_tAsyncOut_tDBOutput_1 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_1 = 0;
	}
	buffers_tAsyncOut_tDBOutput_1.add(row_tAsyncOut_tDBOutput_1);
	index_tAsyncOut_tDBOutput_1++;
 


	tos_count_tAsyncOut_tDBOutput_1++;

/**
 * [tAsyncOut_tDBOutput_1 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	

 



/**
 * [tAsyncOut_tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	

 



/**
 * [tAsyncOut_tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_details\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_details\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}

		   globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
		

	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	


	if (buffers_tAsyncOut_tDBOutput_1.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_1", buffers_tAsyncOut_tDBOutput_1);
	    tAsyncIn_tDBOutput_1Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_1.waitForEnd();
	pool_tAsyncOut_tDBOutput_1.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tDBInput_1","\"audit_details\"","tMysqlInput","tAsyncOut_tDBOutput_1","tAsyncOut_tDBOutput_1","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_1", true);
end_Hash.put("tAsyncOut_tDBOutput_1", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_details\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	

 



/**
 * [tAsyncOut_tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String division;

				public String getDivision () {
					return this.division;
				}

				public Boolean divisionIsNullable(){
				    return true;
				}
				public Boolean divisionIsKey(){
				    return false;
				}
				public Integer divisionLength(){
				    return 100;
				}
				public Integer divisionPrecision(){
				    return 0;
				}
				public String divisionDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String divisionComment(){
				
				    return "";
				
				}
				public String divisionPattern(){
				
					return "";
				
				}
				public String divisionOriginalDbColumnName(){
				
					return "division";
				
				}

				
			    public String area;

				public String getArea () {
					return this.area;
				}

				public Boolean areaIsNullable(){
				    return true;
				}
				public Boolean areaIsKey(){
				    return false;
				}
				public Integer areaLength(){
				    return 100;
				}
				public Integer areaPrecision(){
				    return 0;
				}
				public String areaDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String areaComment(){
				
				    return "";
				
				}
				public String areaPattern(){
				
					return "";
				
				}
				public String areaOriginalDbColumnName(){
				
					return "area";
				
				}

				
			    public int branch_id;

				public int getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return false;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 10;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return null;
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public String branch;

				public String getBranch () {
					return this.branch;
				}

				public Boolean branchIsNullable(){
				    return true;
				}
				public Boolean branchIsKey(){
				    return false;
				}
				public Integer branchLength(){
				    return 100;
				}
				public Integer branchPrecision(){
				    return 0;
				}
				public String branchDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branchComment(){
				
				    return "";
				
				}
				public String branchPattern(){
				
					return "";
				
				}
				public String branchOriginalDbColumnName(){
				
					return "branch";
				
				}

				
			    public Integer month_audit_cycle;

				public Integer getMonth_audit_cycle () {
					return this.month_audit_cycle;
				}

				public Boolean month_audit_cycleIsNullable(){
				    return true;
				}
				public Boolean month_audit_cycleIsKey(){
				    return false;
				}
				public Integer month_audit_cycleLength(){
				    return 10;
				}
				public Integer month_audit_cyclePrecision(){
				    return 0;
				}
				public String month_audit_cycleDefault(){
				
					return null;
				
				}
				public String month_audit_cycleComment(){
				
				    return "";
				
				}
				public String month_audit_cyclePattern(){
				
					return "";
				
				}
				public String month_audit_cycleOriginalDbColumnName(){
				
					return "month_audit_cycle";
				
				}

				
			    public Integer year;

				public Integer getYear () {
					return this.year;
				}

				public Boolean yearIsNullable(){
				    return true;
				}
				public Boolean yearIsKey(){
				    return false;
				}
				public Integer yearLength(){
				    return 10;
				}
				public Integer yearPrecision(){
				    return 0;
				}
				public String yearDefault(){
				
					return null;
				
				}
				public String yearComment(){
				
				    return "";
				
				}
				public String yearPattern(){
				
					return "";
				
				}
				public String yearOriginalDbColumnName(){
				
					return "year";
				
				}

				
			    public Integer audit_no;

				public Integer getAudit_no () {
					return this.audit_no;
				}

				public Boolean audit_noIsNullable(){
				    return true;
				}
				public Boolean audit_noIsKey(){
				    return false;
				}
				public Integer audit_noLength(){
				    return 10;
				}
				public Integer audit_noPrecision(){
				    return 0;
				}
				public String audit_noDefault(){
				
					return null;
				
				}
				public String audit_noComment(){
				
				    return "";
				
				}
				public String audit_noPattern(){
				
					return "";
				
				}
				public String audit_noOriginalDbColumnName(){
				
					return "audit_no";
				
				}

				
			    public java.util.Date audited_from_date;

				public java.util.Date getAudited_from_date () {
					return this.audited_from_date;
				}

				public Boolean audited_from_dateIsNullable(){
				    return true;
				}
				public Boolean audited_from_dateIsKey(){
				    return false;
				}
				public Integer audited_from_dateLength(){
				    return 13;
				}
				public Integer audited_from_datePrecision(){
				    return 0;
				}
				public String audited_from_dateDefault(){
				
					return null;
				
				}
				public String audited_from_dateComment(){
				
				    return "";
				
				}
				public String audited_from_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audited_from_dateOriginalDbColumnName(){
				
					return "audited_from_date";
				
				}

				
			    public java.util.Date audited_to_date;

				public java.util.Date getAudited_to_date () {
					return this.audited_to_date;
				}

				public Boolean audited_to_dateIsNullable(){
				    return true;
				}
				public Boolean audited_to_dateIsKey(){
				    return false;
				}
				public Integer audited_to_dateLength(){
				    return 13;
				}
				public Integer audited_to_datePrecision(){
				    return 0;
				}
				public String audited_to_dateDefault(){
				
					return null;
				
				}
				public String audited_to_dateComment(){
				
				    return "";
				
				}
				public String audited_to_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audited_to_dateOriginalDbColumnName(){
				
					return "audited_to_date";
				
				}

				
			    public int auditor_id;

				public int getAuditor_id () {
					return this.auditor_id;
				}

				public Boolean auditor_idIsNullable(){
				    return false;
				}
				public Boolean auditor_idIsKey(){
				    return false;
				}
				public Integer auditor_idLength(){
				    return 10;
				}
				public Integer auditor_idPrecision(){
				    return 0;
				}
				public String auditor_idDefault(){
				
					return null;
				
				}
				public String auditor_idComment(){
				
				    return "";
				
				}
				public String auditor_idPattern(){
				
					return "";
				
				}
				public String auditor_idOriginalDbColumnName(){
				
					return "auditor_id";
				
				}

				
			    public String auditor;

				public String getAuditor () {
					return this.auditor;
				}

				public Boolean auditorIsNullable(){
				    return true;
				}
				public Boolean auditorIsKey(){
				    return false;
				}
				public Integer auditorLength(){
				    return 145;
				}
				public Integer auditorPrecision(){
				    return 0;
				}
				public String auditorDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String auditorComment(){
				
				    return "";
				
				}
				public String auditorPattern(){
				
					return "";
				
				}
				public String auditorOriginalDbColumnName(){
				
					return "auditor";
				
				}

				
			    public int audit_plan_id;

				public int getAudit_plan_id () {
					return this.audit_plan_id;
				}

				public Boolean audit_plan_idIsNullable(){
				    return false;
				}
				public Boolean audit_plan_idIsKey(){
				    return false;
				}
				public Integer audit_plan_idLength(){
				    return 10;
				}
				public Integer audit_plan_idPrecision(){
				    return 0;
				}
				public String audit_plan_idDefault(){
				
					return null;
				
				}
				public String audit_plan_idComment(){
				
				    return "";
				
				}
				public String audit_plan_idPattern(){
				
					return "";
				
				}
				public String audit_plan_idOriginalDbColumnName(){
				
					return "audit_plan_id";
				
				}

				
			    public Integer noofcenter_attended_by_auditor;

				public Integer getNoofcenter_attended_by_auditor () {
					return this.noofcenter_attended_by_auditor;
				}

				public Boolean noofcenter_attended_by_auditorIsNullable(){
				    return true;
				}
				public Boolean noofcenter_attended_by_auditorIsKey(){
				    return false;
				}
				public Integer noofcenter_attended_by_auditorLength(){
				    return 10;
				}
				public Integer noofcenter_attended_by_auditorPrecision(){
				    return 0;
				}
				public String noofcenter_attended_by_auditorDefault(){
				
					return "0";
				
				}
				public String noofcenter_attended_by_auditorComment(){
				
				    return "";
				
				}
				public String noofcenter_attended_by_auditorPattern(){
				
					return "";
				
				}
				public String noofcenter_attended_by_auditorOriginalDbColumnName(){
				
					return "noofcenter_attended_by_auditor";
				
				}

				
			    public Integer no_of_luc_done_by_auditor;

				public Integer getNo_of_luc_done_by_auditor () {
					return this.no_of_luc_done_by_auditor;
				}

				public Boolean no_of_luc_done_by_auditorIsNullable(){
				    return true;
				}
				public Boolean no_of_luc_done_by_auditorIsKey(){
				    return false;
				}
				public Integer no_of_luc_done_by_auditorLength(){
				    return 10;
				}
				public Integer no_of_luc_done_by_auditorPrecision(){
				    return 0;
				}
				public String no_of_luc_done_by_auditorDefault(){
				
					return "0";
				
				}
				public String no_of_luc_done_by_auditorComment(){
				
				    return "";
				
				}
				public String no_of_luc_done_by_auditorPattern(){
				
					return "";
				
				}
				public String no_of_luc_done_by_auditorOriginalDbColumnName(){
				
					return "no_of_luc_done_by_auditor";
				
				}

				
			    public Integer no_of_cre;

				public Integer getNo_of_cre () {
					return this.no_of_cre;
				}

				public Boolean no_of_creIsNullable(){
				    return true;
				}
				public Boolean no_of_creIsKey(){
				    return false;
				}
				public Integer no_of_creLength(){
				    return 10;
				}
				public Integer no_of_crePrecision(){
				    return 0;
				}
				public String no_of_creDefault(){
				
					return "0";
				
				}
				public String no_of_creComment(){
				
				    return "";
				
				}
				public String no_of_crePattern(){
				
					return "";
				
				}
				public String no_of_creOriginalDbColumnName(){
				
					return "no_of_cre";
				
				}

				
			    public Integer total_no_of_center;

				public Integer getTotal_no_of_center () {
					return this.total_no_of_center;
				}

				public Boolean total_no_of_centerIsNullable(){
				    return true;
				}
				public Boolean total_no_of_centerIsKey(){
				    return false;
				}
				public Integer total_no_of_centerLength(){
				    return 10;
				}
				public Integer total_no_of_centerPrecision(){
				    return 0;
				}
				public String total_no_of_centerDefault(){
				
					return "0";
				
				}
				public String total_no_of_centerComment(){
				
				    return "";
				
				}
				public String total_no_of_centerPattern(){
				
					return "";
				
				}
				public String total_no_of_centerOriginalDbColumnName(){
				
					return "total_no_of_center";
				
				}

				
			    public Integer total_no_of_members;

				public Integer getTotal_no_of_members () {
					return this.total_no_of_members;
				}

				public Boolean total_no_of_membersIsNullable(){
				    return true;
				}
				public Boolean total_no_of_membersIsKey(){
				    return false;
				}
				public Integer total_no_of_membersLength(){
				    return 10;
				}
				public Integer total_no_of_membersPrecision(){
				    return 0;
				}
				public String total_no_of_membersDefault(){
				
					return "0";
				
				}
				public String total_no_of_membersComment(){
				
				    return "";
				
				}
				public String total_no_of_membersPattern(){
				
					return "";
				
				}
				public String total_no_of_membersOriginalDbColumnName(){
				
					return "total_no_of_members";
				
				}

				
			    public Integer total_luc;

				public Integer getTotal_luc () {
					return this.total_luc;
				}

				public Boolean total_lucIsNullable(){
				    return true;
				}
				public Boolean total_lucIsKey(){
				    return false;
				}
				public Integer total_lucLength(){
				    return 10;
				}
				public Integer total_lucPrecision(){
				    return 0;
				}
				public String total_lucDefault(){
				
					return "0";
				
				}
				public String total_lucComment(){
				
				    return "";
				
				}
				public String total_lucPattern(){
				
					return "";
				
				}
				public String total_lucOriginalDbColumnName(){
				
					return "total_luc";
				
				}

				
			    public Integer active_borrowers;

				public Integer getActive_borrowers () {
					return this.active_borrowers;
				}

				public Boolean active_borrowersIsNullable(){
				    return true;
				}
				public Boolean active_borrowersIsKey(){
				    return false;
				}
				public Integer active_borrowersLength(){
				    return 10;
				}
				public Integer active_borrowersPrecision(){
				    return 0;
				}
				public String active_borrowersDefault(){
				
					return "0";
				
				}
				public String active_borrowersComment(){
				
				    return "";
				
				}
				public String active_borrowersPattern(){
				
					return "";
				
				}
				public String active_borrowersOriginalDbColumnName(){
				
					return "active_borrowers";
				
				}

				
			    public Float principal_Os;

				public Float getPrincipal_Os () {
					return this.principal_Os;
				}

				public Boolean principal_OsIsNullable(){
				    return true;
				}
				public Boolean principal_OsIsKey(){
				    return false;
				}
				public Integer principal_OsLength(){
				    return 8;
				}
				public Integer principal_OsPrecision(){
				    return 8;
				}
				public String principal_OsDefault(){
				
					return "'0'::real";
				
				}
				public String principal_OsComment(){
				
				    return "";
				
				}
				public String principal_OsPattern(){
				
					return "";
				
				}
				public String principal_OsOriginalDbColumnName(){
				
					return "principal_Os";
				
				}

				
			    public Double percentage_of_center_coverage;

				public Double getPercentage_of_center_coverage () {
					return this.percentage_of_center_coverage;
				}

				public Boolean percentage_of_center_coverageIsNullable(){
				    return true;
				}
				public Boolean percentage_of_center_coverageIsKey(){
				    return false;
				}
				public Integer percentage_of_center_coverageLength(){
				    return 17;
				}
				public Integer percentage_of_center_coveragePrecision(){
				    return 17;
				}
				public String percentage_of_center_coverageDefault(){
				
					return "'0'::double precision";
				
				}
				public String percentage_of_center_coverageComment(){
				
				    return "";
				
				}
				public String percentage_of_center_coveragePattern(){
				
					return "";
				
				}
				public String percentage_of_center_coverageOriginalDbColumnName(){
				
					return "percentage_of_center_coverage";
				
				}

				
			    public Double percetage_of_luc_coverage;

				public Double getPercetage_of_luc_coverage () {
					return this.percetage_of_luc_coverage;
				}

				public Boolean percetage_of_luc_coverageIsNullable(){
				    return true;
				}
				public Boolean percetage_of_luc_coverageIsKey(){
				    return false;
				}
				public Integer percetage_of_luc_coverageLength(){
				    return 17;
				}
				public Integer percetage_of_luc_coveragePrecision(){
				    return 17;
				}
				public String percetage_of_luc_coverageDefault(){
				
					return "'0'::double precision";
				
				}
				public String percetage_of_luc_coverageComment(){
				
				    return "";
				
				}
				public String percetage_of_luc_coveragePattern(){
				
					return "";
				
				}
				public String percetage_of_luc_coverageOriginalDbColumnName(){
				
					return "percetage_of_luc_coverage";
				
				}

				
			    public String grade;

				public String getGrade () {
					return this.grade;
				}

				public Boolean gradeIsNullable(){
				    return true;
				}
				public Boolean gradeIsKey(){
				    return false;
				}
				public Integer gradeLength(){
				    return 45;
				}
				public Integer gradePrecision(){
				    return 0;
				}
				public String gradeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String gradeComment(){
				
				    return "";
				
				}
				public String gradePattern(){
				
					return "";
				
				}
				public String gradeOriginalDbColumnName(){
				
					return "grade";
				
				}

				
			    public String grade_risk;

				public String getGrade_risk () {
					return this.grade_risk;
				}

				public Boolean grade_riskIsNullable(){
				    return true;
				}
				public Boolean grade_riskIsKey(){
				    return false;
				}
				public Integer grade_riskLength(){
				    return 45;
				}
				public Integer grade_riskPrecision(){
				    return 0;
				}
				public String grade_riskDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String grade_riskComment(){
				
				    return "";
				
				}
				public String grade_riskPattern(){
				
					return "";
				
				}
				public String grade_riskOriginalDbColumnName(){
				
					return "grade_risk";
				
				}

				
			    public Double total_score;

				public Double getTotal_score () {
					return this.total_score;
				}

				public Boolean total_scoreIsNullable(){
				    return true;
				}
				public Boolean total_scoreIsKey(){
				    return false;
				}
				public Integer total_scoreLength(){
				    return 17;
				}
				public Integer total_scorePrecision(){
				    return 17;
				}
				public String total_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String total_scoreComment(){
				
				    return "";
				
				}
				public String total_scorePattern(){
				
					return "";
				
				}
				public String total_scoreOriginalDbColumnName(){
				
					return "total_score";
				
				}

				
			    public Double actual_score;

				public Double getActual_score () {
					return this.actual_score;
				}

				public Boolean actual_scoreIsNullable(){
				    return true;
				}
				public Boolean actual_scoreIsKey(){
				    return false;
				}
				public Integer actual_scoreLength(){
				    return 17;
				}
				public Integer actual_scorePrecision(){
				    return 17;
				}
				public String actual_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String actual_scoreComment(){
				
				    return "";
				
				}
				public String actual_scorePattern(){
				
					return "";
				
				}
				public String actual_scoreOriginalDbColumnName(){
				
					return "actual_score";
				
				}

				
			    public Double percetage_of_score;

				public Double getPercetage_of_score () {
					return this.percetage_of_score;
				}

				public Boolean percetage_of_scoreIsNullable(){
				    return true;
				}
				public Boolean percetage_of_scoreIsKey(){
				    return false;
				}
				public Integer percetage_of_scoreLength(){
				    return 17;
				}
				public Integer percetage_of_scorePrecision(){
				    return 17;
				}
				public String percetage_of_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String percetage_of_scoreComment(){
				
				    return "";
				
				}
				public String percetage_of_scorePattern(){
				
					return "";
				
				}
				public String percetage_of_scoreOriginalDbColumnName(){
				
					return "percetage_of_score";
				
				}

				
			    public Integer is_force_audit_update;

				public Integer getIs_force_audit_update () {
					return this.is_force_audit_update;
				}

				public Boolean is_force_audit_updateIsNullable(){
				    return true;
				}
				public Boolean is_force_audit_updateIsKey(){
				    return false;
				}
				public Integer is_force_audit_updateLength(){
				    return 10;
				}
				public Integer is_force_audit_updatePrecision(){
				    return 0;
				}
				public String is_force_audit_updateDefault(){
				
					return "0";
				
				}
				public String is_force_audit_updateComment(){
				
				    return "";
				
				}
				public String is_force_audit_updatePattern(){
				
					return "";
				
				}
				public String is_force_audit_updateOriginalDbColumnName(){
				
					return "is_force_audit_update";
				
				}

				
			    public String description;

				public String getDescription () {
					return this.description;
				}

				public Boolean descriptionIsNullable(){
				    return true;
				}
				public Boolean descriptionIsKey(){
				    return false;
				}
				public Integer descriptionLength(){
				    return 2147483647;
				}
				public Integer descriptionPrecision(){
				    return 0;
				}
				public String descriptionDefault(){
				
					return null;
				
				}
				public String descriptionComment(){
				
				    return "";
				
				}
				public String descriptionPattern(){
				
					return "";
				
				}
				public String descriptionOriginalDbColumnName(){
				
					return "description";
				
				}

				
			    public Integer force_audit_updated_by;

				public Integer getForce_audit_updated_by () {
					return this.force_audit_updated_by;
				}

				public Boolean force_audit_updated_byIsNullable(){
				    return true;
				}
				public Boolean force_audit_updated_byIsKey(){
				    return false;
				}
				public Integer force_audit_updated_byLength(){
				    return 10;
				}
				public Integer force_audit_updated_byPrecision(){
				    return 0;
				}
				public String force_audit_updated_byDefault(){
				
					return "0";
				
				}
				public String force_audit_updated_byComment(){
				
				    return "";
				
				}
				public String force_audit_updated_byPattern(){
				
					return "";
				
				}
				public String force_audit_updated_byOriginalDbColumnName(){
				
					return "force_audit_updated_by";
				
				}

				
			    public java.util.Date force_audit_updated_on;

				public java.util.Date getForce_audit_updated_on () {
					return this.force_audit_updated_on;
				}

				public Boolean force_audit_updated_onIsNullable(){
				    return true;
				}
				public Boolean force_audit_updated_onIsKey(){
				    return false;
				}
				public Integer force_audit_updated_onLength(){
				    return 13;
				}
				public Integer force_audit_updated_onPrecision(){
				    return 0;
				}
				public String force_audit_updated_onDefault(){
				
					return null;
				
				}
				public String force_audit_updated_onComment(){
				
				    return "";
				
				}
				public String force_audit_updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String force_audit_updated_onOriginalDbColumnName(){
				
					return "force_audit_updated_on";
				
				}

				
			    public Double risk_actual_score;

				public Double getRisk_actual_score () {
					return this.risk_actual_score;
				}

				public Boolean risk_actual_scoreIsNullable(){
				    return true;
				}
				public Boolean risk_actual_scoreIsKey(){
				    return false;
				}
				public Integer risk_actual_scoreLength(){
				    return 17;
				}
				public Integer risk_actual_scorePrecision(){
				    return 17;
				}
				public String risk_actual_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String risk_actual_scoreComment(){
				
				    return "";
				
				}
				public String risk_actual_scorePattern(){
				
					return "";
				
				}
				public String risk_actual_scoreOriginalDbColumnName(){
				
					return "risk_actual_score";
				
				}

				
			    public Double risk_total_score;

				public Double getRisk_total_score () {
					return this.risk_total_score;
				}

				public Boolean risk_total_scoreIsNullable(){
				    return true;
				}
				public Boolean risk_total_scoreIsKey(){
				    return false;
				}
				public Integer risk_total_scoreLength(){
				    return 17;
				}
				public Integer risk_total_scorePrecision(){
				    return 17;
				}
				public String risk_total_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String risk_total_scoreComment(){
				
				    return "";
				
				}
				public String risk_total_scorePattern(){
				
					return "";
				
				}
				public String risk_total_scoreOriginalDbColumnName(){
				
					return "risk_total_score";
				
				}

				
			    public Double critical_max_score;

				public Double getCritical_max_score () {
					return this.critical_max_score;
				}

				public Boolean critical_max_scoreIsNullable(){
				    return true;
				}
				public Boolean critical_max_scoreIsKey(){
				    return false;
				}
				public Integer critical_max_scoreLength(){
				    return 17;
				}
				public Integer critical_max_scorePrecision(){
				    return 17;
				}
				public String critical_max_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String critical_max_scoreComment(){
				
				    return "";
				
				}
				public String critical_max_scorePattern(){
				
					return "";
				
				}
				public String critical_max_scoreOriginalDbColumnName(){
				
					return "critical_max_score";
				
				}

				
			    public Double critical_obtain_score;

				public Double getCritical_obtain_score () {
					return this.critical_obtain_score;
				}

				public Boolean critical_obtain_scoreIsNullable(){
				    return true;
				}
				public Boolean critical_obtain_scoreIsKey(){
				    return false;
				}
				public Integer critical_obtain_scoreLength(){
				    return 17;
				}
				public Integer critical_obtain_scorePrecision(){
				    return 17;
				}
				public String critical_obtain_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String critical_obtain_scoreComment(){
				
				    return "";
				
				}
				public String critical_obtain_scorePattern(){
				
					return "";
				
				}
				public String critical_obtain_scoreOriginalDbColumnName(){
				
					return "critical_obtain_score";
				
				}

				
			    public Double high_max_score;

				public Double getHigh_max_score () {
					return this.high_max_score;
				}

				public Boolean high_max_scoreIsNullable(){
				    return true;
				}
				public Boolean high_max_scoreIsKey(){
				    return false;
				}
				public Integer high_max_scoreLength(){
				    return 17;
				}
				public Integer high_max_scorePrecision(){
				    return 17;
				}
				public String high_max_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String high_max_scoreComment(){
				
				    return "";
				
				}
				public String high_max_scorePattern(){
				
					return "";
				
				}
				public String high_max_scoreOriginalDbColumnName(){
				
					return "high_max_score";
				
				}

				
			    public Double high_obtain_score;

				public Double getHigh_obtain_score () {
					return this.high_obtain_score;
				}

				public Boolean high_obtain_scoreIsNullable(){
				    return true;
				}
				public Boolean high_obtain_scoreIsKey(){
				    return false;
				}
				public Integer high_obtain_scoreLength(){
				    return 17;
				}
				public Integer high_obtain_scorePrecision(){
				    return 17;
				}
				public String high_obtain_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String high_obtain_scoreComment(){
				
				    return "";
				
				}
				public String high_obtain_scorePattern(){
				
					return "";
				
				}
				public String high_obtain_scoreOriginalDbColumnName(){
				
					return "high_obtain_score";
				
				}

				
			    public Double medium_max_score;

				public Double getMedium_max_score () {
					return this.medium_max_score;
				}

				public Boolean medium_max_scoreIsNullable(){
				    return true;
				}
				public Boolean medium_max_scoreIsKey(){
				    return false;
				}
				public Integer medium_max_scoreLength(){
				    return 17;
				}
				public Integer medium_max_scorePrecision(){
				    return 17;
				}
				public String medium_max_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String medium_max_scoreComment(){
				
				    return "";
				
				}
				public String medium_max_scorePattern(){
				
					return "";
				
				}
				public String medium_max_scoreOriginalDbColumnName(){
				
					return "medium_max_score";
				
				}

				
			    public Double medium_obtain_score;

				public Double getMedium_obtain_score () {
					return this.medium_obtain_score;
				}

				public Boolean medium_obtain_scoreIsNullable(){
				    return true;
				}
				public Boolean medium_obtain_scoreIsKey(){
				    return false;
				}
				public Integer medium_obtain_scoreLength(){
				    return 17;
				}
				public Integer medium_obtain_scorePrecision(){
				    return 17;
				}
				public String medium_obtain_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String medium_obtain_scoreComment(){
				
				    return "";
				
				}
				public String medium_obtain_scorePattern(){
				
					return "";
				
				}
				public String medium_obtain_scoreOriginalDbColumnName(){
				
					return "medium_obtain_score";
				
				}

				
			    public Double low_max_score;

				public Double getLow_max_score () {
					return this.low_max_score;
				}

				public Boolean low_max_scoreIsNullable(){
				    return true;
				}
				public Boolean low_max_scoreIsKey(){
				    return false;
				}
				public Integer low_max_scoreLength(){
				    return 17;
				}
				public Integer low_max_scorePrecision(){
				    return 17;
				}
				public String low_max_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String low_max_scoreComment(){
				
				    return "";
				
				}
				public String low_max_scorePattern(){
				
					return "";
				
				}
				public String low_max_scoreOriginalDbColumnName(){
				
					return "low_max_score";
				
				}

				
			    public Double risk_percentage_score;

				public Double getRisk_percentage_score () {
					return this.risk_percentage_score;
				}

				public Boolean risk_percentage_scoreIsNullable(){
				    return true;
				}
				public Boolean risk_percentage_scoreIsKey(){
				    return false;
				}
				public Integer risk_percentage_scoreLength(){
				    return 17;
				}
				public Integer risk_percentage_scorePrecision(){
				    return 17;
				}
				public String risk_percentage_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String risk_percentage_scoreComment(){
				
				    return "";
				
				}
				public String risk_percentage_scorePattern(){
				
					return "";
				
				}
				public String risk_percentage_scoreOriginalDbColumnName(){
				
					return "risk_percentage_score";
				
				}

				
			    public Double low_obtain_score;

				public Double getLow_obtain_score () {
					return this.low_obtain_score;
				}

				public Boolean low_obtain_scoreIsNullable(){
				    return true;
				}
				public Boolean low_obtain_scoreIsKey(){
				    return false;
				}
				public Integer low_obtain_scoreLength(){
				    return 17;
				}
				public Integer low_obtain_scorePrecision(){
				    return 17;
				}
				public String low_obtain_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String low_obtain_scoreComment(){
				
				    return "";
				
				}
				public String low_obtain_scorePattern(){
				
					return "";
				
				}
				public String low_obtain_scoreOriginalDbColumnName(){
				
					return "low_obtain_score";
				
				}

				
			    public Integer bm_status;

				public Integer getBm_status () {
					return this.bm_status;
				}

				public Boolean bm_statusIsNullable(){
				    return true;
				}
				public Boolean bm_statusIsKey(){
				    return false;
				}
				public Integer bm_statusLength(){
				    return 10;
				}
				public Integer bm_statusPrecision(){
				    return 0;
				}
				public String bm_statusDefault(){
				
					return "0";
				
				}
				public String bm_statusComment(){
				
				    return "";
				
				}
				public String bm_statusPattern(){
				
					return "";
				
				}
				public String bm_statusOriginalDbColumnName(){
				
					return "bm_status";
				
				}

				
			    public Integer dam_status;

				public Integer getDam_status () {
					return this.dam_status;
				}

				public Boolean dam_statusIsNullable(){
				    return true;
				}
				public Boolean dam_statusIsKey(){
				    return false;
				}
				public Integer dam_statusLength(){
				    return 10;
				}
				public Integer dam_statusPrecision(){
				    return 0;
				}
				public String dam_statusDefault(){
				
					return "0";
				
				}
				public String dam_statusComment(){
				
				    return "";
				
				}
				public String dam_statusPattern(){
				
					return "";
				
				}
				public String dam_statusOriginalDbColumnName(){
				
					return "dam_status";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String branch_audit_details_id;

				public String getBranch_audit_details_id () {
					return this.branch_audit_details_id;
				}

				public Boolean branch_audit_details_idIsNullable(){
				    return true;
				}
				public Boolean branch_audit_details_idIsKey(){
				    return false;
				}
				public Integer branch_audit_details_idLength(){
				    return 32;
				}
				public Integer branch_audit_details_idPrecision(){
				    return 0;
				}
				public String branch_audit_details_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branch_audit_details_idComment(){
				
				    return "";
				
				}
				public String branch_audit_details_idPattern(){
				
					return "";
				
				}
				public String branch_audit_details_idOriginalDbColumnName(){
				
					return "branch_audit_details_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.id = this.id;
	            other.division = this.division;
	            other.area = this.area;
	            other.branch_id = this.branch_id;
	            other.branch = this.branch;
	            other.month_audit_cycle = this.month_audit_cycle;
	            other.year = this.year;
	            other.audit_no = this.audit_no;
	            other.audited_from_date = this.audited_from_date;
	            other.audited_to_date = this.audited_to_date;
	            other.auditor_id = this.auditor_id;
	            other.auditor = this.auditor;
	            other.audit_plan_id = this.audit_plan_id;
	            other.noofcenter_attended_by_auditor = this.noofcenter_attended_by_auditor;
	            other.no_of_luc_done_by_auditor = this.no_of_luc_done_by_auditor;
	            other.no_of_cre = this.no_of_cre;
	            other.total_no_of_center = this.total_no_of_center;
	            other.total_no_of_members = this.total_no_of_members;
	            other.total_luc = this.total_luc;
	            other.active_borrowers = this.active_borrowers;
	            other.principal_Os = this.principal_Os;
	            other.percentage_of_center_coverage = this.percentage_of_center_coverage;
	            other.percetage_of_luc_coverage = this.percetage_of_luc_coverage;
	            other.grade = this.grade;
	            other.grade_risk = this.grade_risk;
	            other.total_score = this.total_score;
	            other.actual_score = this.actual_score;
	            other.percetage_of_score = this.percetage_of_score;
	            other.is_force_audit_update = this.is_force_audit_update;
	            other.description = this.description;
	            other.force_audit_updated_by = this.force_audit_updated_by;
	            other.force_audit_updated_on = this.force_audit_updated_on;
	            other.risk_actual_score = this.risk_actual_score;
	            other.risk_total_score = this.risk_total_score;
	            other.critical_max_score = this.critical_max_score;
	            other.critical_obtain_score = this.critical_obtain_score;
	            other.high_max_score = this.high_max_score;
	            other.high_obtain_score = this.high_obtain_score;
	            other.medium_max_score = this.medium_max_score;
	            other.medium_obtain_score = this.medium_obtain_score;
	            other.low_max_score = this.low_max_score;
	            other.risk_percentage_score = this.risk_percentage_score;
	            other.low_obtain_score = this.low_obtain_score;
	            other.bm_status = this.bm_status;
	            other.dam_status = this.dam_status;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.branch_audit_details_id = this.branch_audit_details_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.division = readString(dis);
					
					this.area = readString(dis);
					
			        this.branch_id = dis.readInt();
					
					this.branch = readString(dis);
					
						this.month_audit_cycle = readInteger(dis);
					
						this.year = readInteger(dis);
					
						this.audit_no = readInteger(dis);
					
					this.audited_from_date = readDate(dis);
					
					this.audited_to_date = readDate(dis);
					
			        this.auditor_id = dis.readInt();
					
					this.auditor = readString(dis);
					
			        this.audit_plan_id = dis.readInt();
					
						this.noofcenter_attended_by_auditor = readInteger(dis);
					
						this.no_of_luc_done_by_auditor = readInteger(dis);
					
						this.no_of_cre = readInteger(dis);
					
						this.total_no_of_center = readInteger(dis);
					
						this.total_no_of_members = readInteger(dis);
					
						this.total_luc = readInteger(dis);
					
						this.active_borrowers = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.principal_Os = null;
           				} else {
           			    	this.principal_Os = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percentage_of_center_coverage = null;
           				} else {
           			    	this.percentage_of_center_coverage = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percetage_of_luc_coverage = null;
           				} else {
           			    	this.percetage_of_luc_coverage = dis.readDouble();
           				}
					
					this.grade = readString(dis);
					
					this.grade_risk = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_score = null;
           				} else {
           			    	this.total_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.actual_score = null;
           				} else {
           			    	this.actual_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percetage_of_score = null;
           				} else {
           			    	this.percetage_of_score = dis.readDouble();
           				}
					
						this.is_force_audit_update = readInteger(dis);
					
					this.description = readString(dis);
					
						this.force_audit_updated_by = readInteger(dis);
					
					this.force_audit_updated_on = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_actual_score = null;
           				} else {
           			    	this.risk_actual_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_total_score = null;
           				} else {
           			    	this.risk_total_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.critical_max_score = null;
           				} else {
           			    	this.critical_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.critical_obtain_score = null;
           				} else {
           			    	this.critical_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.high_max_score = null;
           				} else {
           			    	this.high_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.high_obtain_score = null;
           				} else {
           			    	this.high_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.medium_max_score = null;
           				} else {
           			    	this.medium_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.medium_obtain_score = null;
           				} else {
           			    	this.medium_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.low_max_score = null;
           				} else {
           			    	this.low_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_percentage_score = null;
           				} else {
           			    	this.risk_percentage_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.low_obtain_score = null;
           				} else {
           			    	this.low_obtain_score = dis.readDouble();
           				}
					
						this.bm_status = readInteger(dis);
					
						this.dam_status = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.branch_audit_details_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.division = readString(dis);
					
					this.area = readString(dis);
					
			        this.branch_id = dis.readInt();
					
					this.branch = readString(dis);
					
						this.month_audit_cycle = readInteger(dis);
					
						this.year = readInteger(dis);
					
						this.audit_no = readInteger(dis);
					
					this.audited_from_date = readDate(dis);
					
					this.audited_to_date = readDate(dis);
					
			        this.auditor_id = dis.readInt();
					
					this.auditor = readString(dis);
					
			        this.audit_plan_id = dis.readInt();
					
						this.noofcenter_attended_by_auditor = readInteger(dis);
					
						this.no_of_luc_done_by_auditor = readInteger(dis);
					
						this.no_of_cre = readInteger(dis);
					
						this.total_no_of_center = readInteger(dis);
					
						this.total_no_of_members = readInteger(dis);
					
						this.total_luc = readInteger(dis);
					
						this.active_borrowers = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.principal_Os = null;
           				} else {
           			    	this.principal_Os = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percentage_of_center_coverage = null;
           				} else {
           			    	this.percentage_of_center_coverage = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percetage_of_luc_coverage = null;
           				} else {
           			    	this.percetage_of_luc_coverage = dis.readDouble();
           				}
					
					this.grade = readString(dis);
					
					this.grade_risk = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_score = null;
           				} else {
           			    	this.total_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.actual_score = null;
           				} else {
           			    	this.actual_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percetage_of_score = null;
           				} else {
           			    	this.percetage_of_score = dis.readDouble();
           				}
					
						this.is_force_audit_update = readInteger(dis);
					
					this.description = readString(dis);
					
						this.force_audit_updated_by = readInteger(dis);
					
					this.force_audit_updated_on = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_actual_score = null;
           				} else {
           			    	this.risk_actual_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_total_score = null;
           				} else {
           			    	this.risk_total_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.critical_max_score = null;
           				} else {
           			    	this.critical_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.critical_obtain_score = null;
           				} else {
           			    	this.critical_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.high_max_score = null;
           				} else {
           			    	this.high_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.high_obtain_score = null;
           				} else {
           			    	this.high_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.medium_max_score = null;
           				} else {
           			    	this.medium_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.medium_obtain_score = null;
           				} else {
           			    	this.medium_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.low_max_score = null;
           				} else {
           			    	this.low_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_percentage_score = null;
           				} else {
           			    	this.risk_percentage_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.low_obtain_score = null;
           				} else {
           			    	this.low_obtain_score = dis.readDouble();
           				}
					
						this.bm_status = readInteger(dis);
					
						this.dam_status = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.branch_audit_details_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.area,dos);
					
					// int
				
		            	dos.writeInt(this.branch_id);
					
					// String
				
						writeString(this.branch,dos);
					
					// Integer
				
						writeInteger(this.month_audit_cycle,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// Integer
				
						writeInteger(this.audit_no,dos);
					
					// java.util.Date
				
						writeDate(this.audited_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.audited_to_date,dos);
					
					// int
				
		            	dos.writeInt(this.auditor_id);
					
					// String
				
						writeString(this.auditor,dos);
					
					// int
				
		            	dos.writeInt(this.audit_plan_id);
					
					// Integer
				
						writeInteger(this.noofcenter_attended_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.no_of_luc_done_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.no_of_cre,dos);
					
					// Integer
				
						writeInteger(this.total_no_of_center,dos);
					
					// Integer
				
						writeInteger(this.total_no_of_members,dos);
					
					// Integer
				
						writeInteger(this.total_luc,dos);
					
					// Integer
				
						writeInteger(this.active_borrowers,dos);
					
					// Float
				
						if(this.principal_Os == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.principal_Os);
		            	}
					
					// Double
				
						if(this.percentage_of_center_coverage == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percentage_of_center_coverage);
		            	}
					
					// Double
				
						if(this.percetage_of_luc_coverage == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percetage_of_luc_coverage);
		            	}
					
					// String
				
						writeString(this.grade,dos);
					
					// String
				
						writeString(this.grade_risk,dos);
					
					// Double
				
						if(this.total_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_score);
		            	}
					
					// Double
				
						if(this.actual_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.actual_score);
		            	}
					
					// Double
				
						if(this.percetage_of_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percetage_of_score);
		            	}
					
					// Integer
				
						writeInteger(this.is_force_audit_update,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// Integer
				
						writeInteger(this.force_audit_updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.force_audit_updated_on,dos);
					
					// Double
				
						if(this.risk_actual_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_actual_score);
		            	}
					
					// Double
				
						if(this.risk_total_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_total_score);
		            	}
					
					// Double
				
						if(this.critical_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.critical_max_score);
		            	}
					
					// Double
				
						if(this.critical_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.critical_obtain_score);
		            	}
					
					// Double
				
						if(this.high_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.high_max_score);
		            	}
					
					// Double
				
						if(this.high_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.high_obtain_score);
		            	}
					
					// Double
				
						if(this.medium_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.medium_max_score);
		            	}
					
					// Double
				
						if(this.medium_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.medium_obtain_score);
		            	}
					
					// Double
				
						if(this.low_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.low_max_score);
		            	}
					
					// Double
				
						if(this.risk_percentage_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_percentage_score);
		            	}
					
					// Double
				
						if(this.low_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.low_obtain_score);
		            	}
					
					// Integer
				
						writeInteger(this.bm_status,dos);
					
					// Integer
				
						writeInteger(this.dam_status,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.branch_audit_details_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.area,dos);
					
					// int
				
		            	dos.writeInt(this.branch_id);
					
					// String
				
						writeString(this.branch,dos);
					
					// Integer
				
						writeInteger(this.month_audit_cycle,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// Integer
				
						writeInteger(this.audit_no,dos);
					
					// java.util.Date
				
						writeDate(this.audited_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.audited_to_date,dos);
					
					// int
				
		            	dos.writeInt(this.auditor_id);
					
					// String
				
						writeString(this.auditor,dos);
					
					// int
				
		            	dos.writeInt(this.audit_plan_id);
					
					// Integer
				
						writeInteger(this.noofcenter_attended_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.no_of_luc_done_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.no_of_cre,dos);
					
					// Integer
				
						writeInteger(this.total_no_of_center,dos);
					
					// Integer
				
						writeInteger(this.total_no_of_members,dos);
					
					// Integer
				
						writeInteger(this.total_luc,dos);
					
					// Integer
				
						writeInteger(this.active_borrowers,dos);
					
					// Float
				
						if(this.principal_Os == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.principal_Os);
		            	}
					
					// Double
				
						if(this.percentage_of_center_coverage == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percentage_of_center_coverage);
		            	}
					
					// Double
				
						if(this.percetage_of_luc_coverage == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percetage_of_luc_coverage);
		            	}
					
					// String
				
						writeString(this.grade,dos);
					
					// String
				
						writeString(this.grade_risk,dos);
					
					// Double
				
						if(this.total_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_score);
		            	}
					
					// Double
				
						if(this.actual_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.actual_score);
		            	}
					
					// Double
				
						if(this.percetage_of_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percetage_of_score);
		            	}
					
					// Integer
				
						writeInteger(this.is_force_audit_update,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// Integer
				
						writeInteger(this.force_audit_updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.force_audit_updated_on,dos);
					
					// Double
				
						if(this.risk_actual_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_actual_score);
		            	}
					
					// Double
				
						if(this.risk_total_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_total_score);
		            	}
					
					// Double
				
						if(this.critical_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.critical_max_score);
		            	}
					
					// Double
				
						if(this.critical_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.critical_obtain_score);
		            	}
					
					// Double
				
						if(this.high_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.high_max_score);
		            	}
					
					// Double
				
						if(this.high_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.high_obtain_score);
		            	}
					
					// Double
				
						if(this.medium_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.medium_max_score);
		            	}
					
					// Double
				
						if(this.medium_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.medium_obtain_score);
		            	}
					
					// Double
				
						if(this.low_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.low_max_score);
		            	}
					
					// Double
				
						if(this.risk_percentage_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_percentage_score);
		            	}
					
					// Double
				
						if(this.low_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.low_obtain_score);
		            	}
					
					// Integer
				
						writeInteger(this.bm_status,dos);
					
					// Integer
				
						writeInteger(this.dam_status,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.branch_audit_details_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",division="+division);
		sb.append(",area="+area);
		sb.append(",branch_id="+String.valueOf(branch_id));
		sb.append(",branch="+branch);
		sb.append(",month_audit_cycle="+String.valueOf(month_audit_cycle));
		sb.append(",year="+String.valueOf(year));
		sb.append(",audit_no="+String.valueOf(audit_no));
		sb.append(",audited_from_date="+String.valueOf(audited_from_date));
		sb.append(",audited_to_date="+String.valueOf(audited_to_date));
		sb.append(",auditor_id="+String.valueOf(auditor_id));
		sb.append(",auditor="+auditor);
		sb.append(",audit_plan_id="+String.valueOf(audit_plan_id));
		sb.append(",noofcenter_attended_by_auditor="+String.valueOf(noofcenter_attended_by_auditor));
		sb.append(",no_of_luc_done_by_auditor="+String.valueOf(no_of_luc_done_by_auditor));
		sb.append(",no_of_cre="+String.valueOf(no_of_cre));
		sb.append(",total_no_of_center="+String.valueOf(total_no_of_center));
		sb.append(",total_no_of_members="+String.valueOf(total_no_of_members));
		sb.append(",total_luc="+String.valueOf(total_luc));
		sb.append(",active_borrowers="+String.valueOf(active_borrowers));
		sb.append(",principal_Os="+String.valueOf(principal_Os));
		sb.append(",percentage_of_center_coverage="+String.valueOf(percentage_of_center_coverage));
		sb.append(",percetage_of_luc_coverage="+String.valueOf(percetage_of_luc_coverage));
		sb.append(",grade="+grade);
		sb.append(",grade_risk="+grade_risk);
		sb.append(",total_score="+String.valueOf(total_score));
		sb.append(",actual_score="+String.valueOf(actual_score));
		sb.append(",percetage_of_score="+String.valueOf(percetage_of_score));
		sb.append(",is_force_audit_update="+String.valueOf(is_force_audit_update));
		sb.append(",description="+description);
		sb.append(",force_audit_updated_by="+String.valueOf(force_audit_updated_by));
		sb.append(",force_audit_updated_on="+String.valueOf(force_audit_updated_on));
		sb.append(",risk_actual_score="+String.valueOf(risk_actual_score));
		sb.append(",risk_total_score="+String.valueOf(risk_total_score));
		sb.append(",critical_max_score="+String.valueOf(critical_max_score));
		sb.append(",critical_obtain_score="+String.valueOf(critical_obtain_score));
		sb.append(",high_max_score="+String.valueOf(high_max_score));
		sb.append(",high_obtain_score="+String.valueOf(high_obtain_score));
		sb.append(",medium_max_score="+String.valueOf(medium_max_score));
		sb.append(",medium_obtain_score="+String.valueOf(medium_obtain_score));
		sb.append(",low_max_score="+String.valueOf(low_max_score));
		sb.append(",risk_percentage_score="+String.valueOf(risk_percentage_score));
		sb.append(",low_obtain_score="+String.valueOf(low_obtain_score));
		sb.append(",bm_status="+String.valueOf(bm_status));
		sb.append(",dam_status="+String.valueOf(dam_status));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",branch_audit_details_id="+branch_audit_details_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(division == null){
        					sb.append("<null>");
        				}else{
            				sb.append(division);
            			}
            		
        			sb.append("|");
        		
        				if(area == null){
        					sb.append("<null>");
        				}else{
            				sb.append(area);
            			}
            		
        			sb.append("|");
        		
        				sb.append(branch_id);
        			
        			sb.append("|");
        		
        				if(branch == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch);
            			}
            		
        			sb.append("|");
        		
        				if(month_audit_cycle == null){
        					sb.append("<null>");
        				}else{
            				sb.append(month_audit_cycle);
            			}
            		
        			sb.append("|");
        		
        				if(year == null){
        					sb.append("<null>");
        				}else{
            				sb.append(year);
            			}
            		
        			sb.append("|");
        		
        				if(audit_no == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_no);
            			}
            		
        			sb.append("|");
        		
        				if(audited_from_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audited_from_date);
            			}
            		
        			sb.append("|");
        		
        				if(audited_to_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audited_to_date);
            			}
            		
        			sb.append("|");
        		
        				sb.append(auditor_id);
        			
        			sb.append("|");
        		
        				if(auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor);
            			}
            		
        			sb.append("|");
        		
        				sb.append(audit_plan_id);
        			
        			sb.append("|");
        		
        				if(noofcenter_attended_by_auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(noofcenter_attended_by_auditor);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_luc_done_by_auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_luc_done_by_auditor);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_cre == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_cre);
            			}
            		
        			sb.append("|");
        		
        				if(total_no_of_center == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_no_of_center);
            			}
            		
        			sb.append("|");
        		
        				if(total_no_of_members == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_no_of_members);
            			}
            		
        			sb.append("|");
        		
        				if(total_luc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_luc);
            			}
            		
        			sb.append("|");
        		
        				if(active_borrowers == null){
        					sb.append("<null>");
        				}else{
            				sb.append(active_borrowers);
            			}
            		
        			sb.append("|");
        		
        				if(principal_Os == null){
        					sb.append("<null>");
        				}else{
            				sb.append(principal_Os);
            			}
            		
        			sb.append("|");
        		
        				if(percentage_of_center_coverage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(percentage_of_center_coverage);
            			}
            		
        			sb.append("|");
        		
        				if(percetage_of_luc_coverage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(percetage_of_luc_coverage);
            			}
            		
        			sb.append("|");
        		
        				if(grade == null){
        					sb.append("<null>");
        				}else{
            				sb.append(grade);
            			}
            		
        			sb.append("|");
        		
        				if(grade_risk == null){
        					sb.append("<null>");
        				}else{
            				sb.append(grade_risk);
            			}
            		
        			sb.append("|");
        		
        				if(total_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_score);
            			}
            		
        			sb.append("|");
        		
        				if(actual_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(actual_score);
            			}
            		
        			sb.append("|");
        		
        				if(percetage_of_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(percetage_of_score);
            			}
            		
        			sb.append("|");
        		
        				if(is_force_audit_update == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_force_audit_update);
            			}
            		
        			sb.append("|");
        		
        				if(description == null){
        					sb.append("<null>");
        				}else{
            				sb.append(description);
            			}
            		
        			sb.append("|");
        		
        				if(force_audit_updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(force_audit_updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(force_audit_updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(force_audit_updated_on);
            			}
            		
        			sb.append("|");
        		
        				if(risk_actual_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(risk_actual_score);
            			}
            		
        			sb.append("|");
        		
        				if(risk_total_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(risk_total_score);
            			}
            		
        			sb.append("|");
        		
        				if(critical_max_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(critical_max_score);
            			}
            		
        			sb.append("|");
        		
        				if(critical_obtain_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(critical_obtain_score);
            			}
            		
        			sb.append("|");
        		
        				if(high_max_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(high_max_score);
            			}
            		
        			sb.append("|");
        		
        				if(high_obtain_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(high_obtain_score);
            			}
            		
        			sb.append("|");
        		
        				if(medium_max_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(medium_max_score);
            			}
            		
        			sb.append("|");
        		
        				if(medium_obtain_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(medium_obtain_score);
            			}
            		
        			sb.append("|");
        		
        				if(low_max_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(low_max_score);
            			}
            		
        			sb.append("|");
        		
        				if(risk_percentage_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(risk_percentage_score);
            			}
            		
        			sb.append("|");
        		
        				if(low_obtain_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(low_obtain_score);
            			}
            		
        			sb.append("|");
        		
        				if(bm_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(bm_status);
            			}
            		
        			sb.append("|");
        		
        				if(dam_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(dam_status);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(branch_audit_details_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_audit_details_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", "mJUgU4_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_2", false);
		start_Hash.put("tAsyncOut_tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tAsyncOut_tDBOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_2", "tAsyncOut_tDBOutput_2", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_2 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_2 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_2 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_2=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_2 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_2", pool_tAsyncOut_tDBOutput_2);
	final Object[] lockWrite_tAsyncOut_tDBOutput_2 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_2", lockWrite_tAsyncOut_tDBOutput_2);
 



/**
 * [tAsyncOut_tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"branch_audit_details\"";
		
		int tos_count_tDBInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
                    log4jParamters_tDBInput_2.append("Parameters:");
                            log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"branch_audit_details\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERY" + " = " + "\"SELECT    `branch_audit_details`.`id`,    `branch_audit_details`.`division`,    `branch_audit_details`.`area`,    `branch_audit_details`.`branch_id`,    `branch_audit_details`.`branch`,    `branch_audit_details`.`month_audit_cycle`,    `branch_audit_details`.`year`,    `branch_audit_details`.`audit_no`,    `branch_audit_details`.`audited_from_date`,    `branch_audit_details`.`audited_to_date`,    `branch_audit_details`.`auditor_id`,    `branch_audit_details`.`auditor`,    `branch_audit_details`.`audit_plan_id`,    `branch_audit_details`.`noofcenter_attended_by_auditor`,    `branch_audit_details`.`no_of_luc_done_by_auditor`,    `branch_audit_details`.`no_of_cre`,    `branch_audit_details`.`total_no_of_center`,    `branch_audit_details`.`total_no_of_members`,    `branch_audit_details`.`total_luc`,    `branch_audit_details`.`active_borrowers`,    `branch_audit_details`.`principal_Os`,    `branch_audit_details`.`percentage_of_center_coverage`,    `branch_audit_details`.`percetage_of_luc_coverage`,    `branch_audit_details`.`grade`,    `branch_audit_details`.`grade_risk`,    `branch_audit_details`.`total_score`,    `branch_audit_details`.`actual_score`,    `branch_audit_details`.`percetage_of_score`,    `branch_audit_details`.`is_force_audit_update`,    `branch_audit_details`.`description`,    `branch_audit_details`.`force_audit_updated_by`,    `branch_audit_details`.`force_audit_updated_on`,    `branch_audit_details`.`risk_actual_score`,    `branch_audit_details`.`risk_total_score`,    `branch_audit_details`.`critical_max_score`,    `branch_audit_details`.`critical_obtain_score`,    `branch_audit_details`.`high_max_score`,    `branch_audit_details`.`high_obtain_score`,    `branch_audit_details`.`medium_max_score`,    `branch_audit_details`.`medium_obtain_score`,    `branch_audit_details`.`low_max_score`,    `branch_audit_details`.`risk_percentage_score`,    `branch_audit_details`.`low_obtain_score`,    `branch_audit_details`.`bm_status`,    `branch_audit_details`.`dam_status`,    `branch_audit_details`.`created_by`,    `branch_audit_details`.`created_on`,    `branch_audit_details`.`updated_by`,    `branch_audit_details`.`updated_on`,    `branch_audit_details`.`is_active`,    `branch_audit_details`.`is_deleted`,    `branch_audit_details`.`branch_audit_details_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `branch_audit_details`\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("division")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("area")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("month_audit_cycle")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("year")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audit_no")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audited_from_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audited_to_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("auditor_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("auditor")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audit_plan_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("noofcenter_attended_by_auditor")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("no_of_luc_done_by_auditor")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("no_of_cre")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("total_no_of_center")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("total_no_of_members")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("total_luc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("active_borrowers")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("principal_Os")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("percentage_of_center_coverage")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("percetage_of_luc_coverage")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("grade")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("grade_risk")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("total_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("actual_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("percetage_of_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_force_audit_update")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("description")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("force_audit_updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("force_audit_updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("risk_actual_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("risk_total_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("critical_max_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("critical_obtain_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("high_max_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("high_obtain_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("medium_max_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("medium_obtain_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("low_max_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("risk_percentage_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("low_obtain_score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("bm_status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("dam_status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_audit_details_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + (log4jParamters_tDBInput_2) );
                    } 
                } 
            new BytesLimit65535_tDBInput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "\"branch_audit_details\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_2 = java.util.Calendar.getInstance();
		    calendar_tDBInput_2.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_2 = calendar_tDBInput_2.getTime();
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_2 != null) {
					if(conn_tDBInput_2.getMetaData() != null) {
						
							log.debug("tDBInput_2 - Uses an existing connection with username '" + conn_tDBInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();
				if(stmt_tDBInput_2 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_2).enableStreamingResults();
				}else if(stmt_tDBInput_2 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_2).enableStreamingResults();
				}

		    String dbquery_tDBInput_2 = "SELECT \n  `branch_audit_details`.`id`, \n  `branch_audit_details`.`division`, \n  `branch_audit_details`.`area`, \n  `bran"
+"ch_audit_details`.`branch_id`, \n  `branch_audit_details`.`branch`, \n  `branch_audit_details`.`month_audit_cycle`, \n  `br"
+"anch_audit_details`.`year`, \n  `branch_audit_details`.`audit_no`, \n  `branch_audit_details`.`audited_from_date`, \n  `bra"
+"nch_audit_details`.`audited_to_date`, \n  `branch_audit_details`.`auditor_id`, \n  `branch_audit_details`.`auditor`, \n  `b"
+"ranch_audit_details`.`audit_plan_id`, \n  `branch_audit_details`.`noofcenter_attended_by_auditor`, \n  `branch_audit_detai"
+"ls`.`no_of_luc_done_by_auditor`, \n  `branch_audit_details`.`no_of_cre`, \n  `branch_audit_details`.`total_no_of_center`, "
+"\n  `branch_audit_details`.`total_no_of_members`, \n  `branch_audit_details`.`total_luc`, \n  `branch_audit_details`.`activ"
+"e_borrowers`, \n  `branch_audit_details`.`principal_Os`, \n  `branch_audit_details`.`percentage_of_center_coverage`, \n  `b"
+"ranch_audit_details`.`percetage_of_luc_coverage`, \n  `branch_audit_details`.`grade`, \n  `branch_audit_details`.`grade_ri"
+"sk`, \n  `branch_audit_details`.`total_score`, \n  `branch_audit_details`.`actual_score`, \n  `branch_audit_details`.`perce"
+"tage_of_score`, \n  `branch_audit_details`.`is_force_audit_update`, \n  `branch_audit_details`.`description`, \n  `branch_a"
+"udit_details`.`force_audit_updated_by`, \n  `branch_audit_details`.`force_audit_updated_on`, \n  `branch_audit_details`.`r"
+"isk_actual_score`, \n  `branch_audit_details`.`risk_total_score`, \n  `branch_audit_details`.`critical_max_score`, \n  `bra"
+"nch_audit_details`.`critical_obtain_score`, \n  `branch_audit_details`.`high_max_score`, \n  `branch_audit_details`.`high_"
+"obtain_score`, \n  `branch_audit_details`.`medium_max_score`, \n  `branch_audit_details`.`medium_obtain_score`, \n  `branch"
+"_audit_details`.`low_max_score`, \n  `branch_audit_details`.`risk_percentage_score`, \n  `branch_audit_details`.`low_obtai"
+"n_score`, \n  `branch_audit_details`.`bm_status`, \n  `branch_audit_details`.`dam_status`, \n  `branch_audit_details`.`crea"
+"ted_by`, \n  `branch_audit_details`.`created_on`, \n  `branch_audit_details`.`updated_by`, \n  `branch_audit_details`.`upda"
+"ted_on`, \n  `branch_audit_details`.`is_active`, \n  `branch_audit_details`.`is_deleted`, \n  `branch_audit_details`.`branc"
+"h_audit_details_id`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `branch_audit_details`";
		    
	    		log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    	log.debug("tDBInput_2 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row2.id = 0;
							} else {
		                          
            row2.id = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row2.division = null;
							} else {
	                         		
        	row2.division = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row2.area = null;
							} else {
	                         		
        	row2.area = routines.system.JDBCUtil.getString(rs_tDBInput_2, 3, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row2.branch_id = 0;
							} else {
		                          
            row2.branch_id = rs_tDBInput_2.getInt(4);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row2.branch = null;
							} else {
	                         		
        	row2.branch = routines.system.JDBCUtil.getString(rs_tDBInput_2, 5, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row2.month_audit_cycle = null;
							} else {
		                          
            row2.month_audit_cycle = rs_tDBInput_2.getInt(6);
            if(rs_tDBInput_2.wasNull()){
                    row2.month_audit_cycle = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row2.year = null;
							} else {
		                          
            row2.year = rs_tDBInput_2.getInt(7);
            if(rs_tDBInput_2.wasNull()){
                    row2.year = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row2.audit_no = null;
							} else {
		                          
            row2.audit_no = rs_tDBInput_2.getInt(8);
            if(rs_tDBInput_2.wasNull()){
                    row2.audit_no = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 9) {
								row2.audited_from_date = null;
							} else {
										
				if(rs_tDBInput_2.getString(9) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(9);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.audited_from_date = rs_tDBInput_2.getTimestamp(9);
					} else {
						row2.audited_from_date = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.audited_from_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 10) {
								row2.audited_to_date = null;
							} else {
										
				if(rs_tDBInput_2.getString(10) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(10);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.audited_to_date = rs_tDBInput_2.getTimestamp(10);
					} else {
						row2.audited_to_date = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.audited_to_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 11) {
								row2.auditor_id = 0;
							} else {
		                          
            row2.auditor_id = rs_tDBInput_2.getInt(11);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 12) {
								row2.auditor = null;
							} else {
	                         		
        	row2.auditor = routines.system.JDBCUtil.getString(rs_tDBInput_2, 12, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 13) {
								row2.audit_plan_id = 0;
							} else {
		                          
            row2.audit_plan_id = rs_tDBInput_2.getInt(13);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 14) {
								row2.noofcenter_attended_by_auditor = null;
							} else {
		                          
            row2.noofcenter_attended_by_auditor = rs_tDBInput_2.getInt(14);
            if(rs_tDBInput_2.wasNull()){
                    row2.noofcenter_attended_by_auditor = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 15) {
								row2.no_of_luc_done_by_auditor = null;
							} else {
		                          
            row2.no_of_luc_done_by_auditor = rs_tDBInput_2.getInt(15);
            if(rs_tDBInput_2.wasNull()){
                    row2.no_of_luc_done_by_auditor = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 16) {
								row2.no_of_cre = null;
							} else {
		                          
            row2.no_of_cre = rs_tDBInput_2.getInt(16);
            if(rs_tDBInput_2.wasNull()){
                    row2.no_of_cre = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 17) {
								row2.total_no_of_center = null;
							} else {
		                          
            row2.total_no_of_center = rs_tDBInput_2.getInt(17);
            if(rs_tDBInput_2.wasNull()){
                    row2.total_no_of_center = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 18) {
								row2.total_no_of_members = null;
							} else {
		                          
            row2.total_no_of_members = rs_tDBInput_2.getInt(18);
            if(rs_tDBInput_2.wasNull()){
                    row2.total_no_of_members = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 19) {
								row2.total_luc = null;
							} else {
		                          
            row2.total_luc = rs_tDBInput_2.getInt(19);
            if(rs_tDBInput_2.wasNull()){
                    row2.total_luc = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 20) {
								row2.active_borrowers = null;
							} else {
		                          
            row2.active_borrowers = rs_tDBInput_2.getInt(20);
            if(rs_tDBInput_2.wasNull()){
                    row2.active_borrowers = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 21) {
								row2.principal_Os = null;
							} else {
		                          
            row2.principal_Os = rs_tDBInput_2.getFloat(21);
            if(rs_tDBInput_2.wasNull()){
                    row2.principal_Os = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 22) {
								row2.percentage_of_center_coverage = null;
							} else {
	                         		
            row2.percentage_of_center_coverage = rs_tDBInput_2.getDouble(22);
            if(rs_tDBInput_2.wasNull()){
                    row2.percentage_of_center_coverage = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 23) {
								row2.percetage_of_luc_coverage = null;
							} else {
	                         		
            row2.percetage_of_luc_coverage = rs_tDBInput_2.getDouble(23);
            if(rs_tDBInput_2.wasNull()){
                    row2.percetage_of_luc_coverage = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 24) {
								row2.grade = null;
							} else {
	                         		
        	row2.grade = routines.system.JDBCUtil.getString(rs_tDBInput_2, 24, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 25) {
								row2.grade_risk = null;
							} else {
	                         		
        	row2.grade_risk = routines.system.JDBCUtil.getString(rs_tDBInput_2, 25, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 26) {
								row2.total_score = null;
							} else {
	                         		
            row2.total_score = rs_tDBInput_2.getDouble(26);
            if(rs_tDBInput_2.wasNull()){
                    row2.total_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 27) {
								row2.actual_score = null;
							} else {
	                         		
            row2.actual_score = rs_tDBInput_2.getDouble(27);
            if(rs_tDBInput_2.wasNull()){
                    row2.actual_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 28) {
								row2.percetage_of_score = null;
							} else {
	                         		
            row2.percetage_of_score = rs_tDBInput_2.getDouble(28);
            if(rs_tDBInput_2.wasNull()){
                    row2.percetage_of_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 29) {
								row2.is_force_audit_update = null;
							} else {
		                          
            row2.is_force_audit_update = rs_tDBInput_2.getInt(29);
            if(rs_tDBInput_2.wasNull()){
                    row2.is_force_audit_update = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 30) {
								row2.description = null;
							} else {
	                         		
        	row2.description = routines.system.JDBCUtil.getString(rs_tDBInput_2, 30, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 31) {
								row2.force_audit_updated_by = null;
							} else {
		                          
            row2.force_audit_updated_by = rs_tDBInput_2.getInt(31);
            if(rs_tDBInput_2.wasNull()){
                    row2.force_audit_updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 32) {
								row2.force_audit_updated_on = null;
							} else {
										
				if(rs_tDBInput_2.getString(32) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(32);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.force_audit_updated_on = rs_tDBInput_2.getTimestamp(32);
					} else {
						row2.force_audit_updated_on = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.force_audit_updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 33) {
								row2.risk_actual_score = null;
							} else {
	                         		
            row2.risk_actual_score = rs_tDBInput_2.getDouble(33);
            if(rs_tDBInput_2.wasNull()){
                    row2.risk_actual_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 34) {
								row2.risk_total_score = null;
							} else {
	                         		
            row2.risk_total_score = rs_tDBInput_2.getDouble(34);
            if(rs_tDBInput_2.wasNull()){
                    row2.risk_total_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 35) {
								row2.critical_max_score = null;
							} else {
	                         		
            row2.critical_max_score = rs_tDBInput_2.getDouble(35);
            if(rs_tDBInput_2.wasNull()){
                    row2.critical_max_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 36) {
								row2.critical_obtain_score = null;
							} else {
	                         		
            row2.critical_obtain_score = rs_tDBInput_2.getDouble(36);
            if(rs_tDBInput_2.wasNull()){
                    row2.critical_obtain_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 37) {
								row2.high_max_score = null;
							} else {
	                         		
            row2.high_max_score = rs_tDBInput_2.getDouble(37);
            if(rs_tDBInput_2.wasNull()){
                    row2.high_max_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 38) {
								row2.high_obtain_score = null;
							} else {
	                         		
            row2.high_obtain_score = rs_tDBInput_2.getDouble(38);
            if(rs_tDBInput_2.wasNull()){
                    row2.high_obtain_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 39) {
								row2.medium_max_score = null;
							} else {
	                         		
            row2.medium_max_score = rs_tDBInput_2.getDouble(39);
            if(rs_tDBInput_2.wasNull()){
                    row2.medium_max_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 40) {
								row2.medium_obtain_score = null;
							} else {
	                         		
            row2.medium_obtain_score = rs_tDBInput_2.getDouble(40);
            if(rs_tDBInput_2.wasNull()){
                    row2.medium_obtain_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 41) {
								row2.low_max_score = null;
							} else {
	                         		
            row2.low_max_score = rs_tDBInput_2.getDouble(41);
            if(rs_tDBInput_2.wasNull()){
                    row2.low_max_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 42) {
								row2.risk_percentage_score = null;
							} else {
	                         		
            row2.risk_percentage_score = rs_tDBInput_2.getDouble(42);
            if(rs_tDBInput_2.wasNull()){
                    row2.risk_percentage_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 43) {
								row2.low_obtain_score = null;
							} else {
	                         		
            row2.low_obtain_score = rs_tDBInput_2.getDouble(43);
            if(rs_tDBInput_2.wasNull()){
                    row2.low_obtain_score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 44) {
								row2.bm_status = null;
							} else {
		                          
            row2.bm_status = rs_tDBInput_2.getInt(44);
            if(rs_tDBInput_2.wasNull()){
                    row2.bm_status = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 45) {
								row2.dam_status = null;
							} else {
		                          
            row2.dam_status = rs_tDBInput_2.getInt(45);
            if(rs_tDBInput_2.wasNull()){
                    row2.dam_status = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 46) {
								row2.created_by = null;
							} else {
		                          
            row2.created_by = rs_tDBInput_2.getInt(46);
            if(rs_tDBInput_2.wasNull()){
                    row2.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 47) {
								row2.created_on = null;
							} else {
										
				if(rs_tDBInput_2.getString(47) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(47);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.created_on = rs_tDBInput_2.getTimestamp(47);
					} else {
						row2.created_on = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 48) {
								row2.updated_by = null;
							} else {
		                          
            row2.updated_by = rs_tDBInput_2.getInt(48);
            if(rs_tDBInput_2.wasNull()){
                    row2.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 49) {
								row2.updated_on = null;
							} else {
										
				if(rs_tDBInput_2.getString(49) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(49);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.updated_on = rs_tDBInput_2.getTimestamp(49);
					} else {
						row2.updated_on = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 50) {
								row2.is_active = 0;
							} else {
		                          
            row2.is_active = rs_tDBInput_2.getInt(50);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 51) {
								row2.is_deleted = 0;
							} else {
		                          
            row2.is_deleted = rs_tDBInput_2.getInt(51);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 52) {
								row2.branch_audit_details_id = null;
							} else {
	                         		
        	row2.branch_audit_details_id = routines.system.JDBCUtil.getString(rs_tDBInput_2, 52, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 53) {
								row2.as_on = null;
							} else {
										
				if(rs_tDBInput_2.getString(53) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(53);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.as_on = rs_tDBInput_2.getTimestamp(53);
					} else {
						row2.as_on = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");
					

 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"branch_audit_details\"";
		

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"branch_audit_details\"";
		

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tDBInput_2","\"branch_audit_details\"","tMysqlInput","tAsyncOut_tDBOutput_2","tAsyncOut_tDBOutput_2","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_2=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_2[0] = String.valueOf(row2.id); 
	if(row2.division != null){
		row_tAsyncOut_tDBOutput_2[1] = row2.division;                			    
	}
	if(row2.area != null){
		row_tAsyncOut_tDBOutput_2[2] = row2.area;                			    
	}
	row_tAsyncOut_tDBOutput_2[3] = String.valueOf(row2.branch_id); 
	if(row2.branch != null){
		row_tAsyncOut_tDBOutput_2[4] = row2.branch;                			    
	}
	if(row2.month_audit_cycle != null){
		row_tAsyncOut_tDBOutput_2[5] = String.valueOf(row2.month_audit_cycle);                			    
	}
	if(row2.year != null){
		row_tAsyncOut_tDBOutput_2[6] = String.valueOf(row2.year);                			    
	}
	if(row2.audit_no != null){
		row_tAsyncOut_tDBOutput_2[7] = String.valueOf(row2.audit_no);                			    
	}
	if(row2.audited_from_date != null){
		row_tAsyncOut_tDBOutput_2[8] = row2.audited_from_date;                			    
	}
	if(row2.audited_to_date != null){
		row_tAsyncOut_tDBOutput_2[9] = row2.audited_to_date;                			    
	}
	row_tAsyncOut_tDBOutput_2[10] = String.valueOf(row2.auditor_id); 
	if(row2.auditor != null){
		row_tAsyncOut_tDBOutput_2[11] = row2.auditor;                			    
	}
	row_tAsyncOut_tDBOutput_2[12] = String.valueOf(row2.audit_plan_id); 
	if(row2.noofcenter_attended_by_auditor != null){
		row_tAsyncOut_tDBOutput_2[13] = String.valueOf(row2.noofcenter_attended_by_auditor);                			    
	}
	if(row2.no_of_luc_done_by_auditor != null){
		row_tAsyncOut_tDBOutput_2[14] = String.valueOf(row2.no_of_luc_done_by_auditor);                			    
	}
	if(row2.no_of_cre != null){
		row_tAsyncOut_tDBOutput_2[15] = String.valueOf(row2.no_of_cre);                			    
	}
	if(row2.total_no_of_center != null){
		row_tAsyncOut_tDBOutput_2[16] = String.valueOf(row2.total_no_of_center);                			    
	}
	if(row2.total_no_of_members != null){
		row_tAsyncOut_tDBOutput_2[17] = String.valueOf(row2.total_no_of_members);                			    
	}
	if(row2.total_luc != null){
		row_tAsyncOut_tDBOutput_2[18] = String.valueOf(row2.total_luc);                			    
	}
	if(row2.active_borrowers != null){
		row_tAsyncOut_tDBOutput_2[19] = String.valueOf(row2.active_borrowers);                			    
	}
	if(row2.principal_Os != null){
		row_tAsyncOut_tDBOutput_2[20] = String.valueOf(row2.principal_Os);                			    
	}
	if(row2.percentage_of_center_coverage != null){
		row_tAsyncOut_tDBOutput_2[21] = String.valueOf(row2.percentage_of_center_coverage);                			    
	}
	if(row2.percetage_of_luc_coverage != null){
		row_tAsyncOut_tDBOutput_2[22] = String.valueOf(row2.percetage_of_luc_coverage);                			    
	}
	if(row2.grade != null){
		row_tAsyncOut_tDBOutput_2[23] = row2.grade;                			    
	}
	if(row2.grade_risk != null){
		row_tAsyncOut_tDBOutput_2[24] = row2.grade_risk;                			    
	}
	if(row2.total_score != null){
		row_tAsyncOut_tDBOutput_2[25] = String.valueOf(row2.total_score);                			    
	}
	if(row2.actual_score != null){
		row_tAsyncOut_tDBOutput_2[26] = String.valueOf(row2.actual_score);                			    
	}
	if(row2.percetage_of_score != null){
		row_tAsyncOut_tDBOutput_2[27] = String.valueOf(row2.percetage_of_score);                			    
	}
	if(row2.is_force_audit_update != null){
		row_tAsyncOut_tDBOutput_2[28] = String.valueOf(row2.is_force_audit_update);                			    
	}
	if(row2.description != null){
		row_tAsyncOut_tDBOutput_2[29] = row2.description;                			    
	}
	if(row2.force_audit_updated_by != null){
		row_tAsyncOut_tDBOutput_2[30] = String.valueOf(row2.force_audit_updated_by);                			    
	}
	if(row2.force_audit_updated_on != null){
		row_tAsyncOut_tDBOutput_2[31] = row2.force_audit_updated_on;                			    
	}
	if(row2.risk_actual_score != null){
		row_tAsyncOut_tDBOutput_2[32] = String.valueOf(row2.risk_actual_score);                			    
	}
	if(row2.risk_total_score != null){
		row_tAsyncOut_tDBOutput_2[33] = String.valueOf(row2.risk_total_score);                			    
	}
	if(row2.critical_max_score != null){
		row_tAsyncOut_tDBOutput_2[34] = String.valueOf(row2.critical_max_score);                			    
	}
	if(row2.critical_obtain_score != null){
		row_tAsyncOut_tDBOutput_2[35] = String.valueOf(row2.critical_obtain_score);                			    
	}
	if(row2.high_max_score != null){
		row_tAsyncOut_tDBOutput_2[36] = String.valueOf(row2.high_max_score);                			    
	}
	if(row2.high_obtain_score != null){
		row_tAsyncOut_tDBOutput_2[37] = String.valueOf(row2.high_obtain_score);                			    
	}
	if(row2.medium_max_score != null){
		row_tAsyncOut_tDBOutput_2[38] = String.valueOf(row2.medium_max_score);                			    
	}
	if(row2.medium_obtain_score != null){
		row_tAsyncOut_tDBOutput_2[39] = String.valueOf(row2.medium_obtain_score);                			    
	}
	if(row2.low_max_score != null){
		row_tAsyncOut_tDBOutput_2[40] = String.valueOf(row2.low_max_score);                			    
	}
	if(row2.risk_percentage_score != null){
		row_tAsyncOut_tDBOutput_2[41] = String.valueOf(row2.risk_percentage_score);                			    
	}
	if(row2.low_obtain_score != null){
		row_tAsyncOut_tDBOutput_2[42] = String.valueOf(row2.low_obtain_score);                			    
	}
	if(row2.bm_status != null){
		row_tAsyncOut_tDBOutput_2[43] = String.valueOf(row2.bm_status);                			    
	}
	if(row2.dam_status != null){
		row_tAsyncOut_tDBOutput_2[44] = String.valueOf(row2.dam_status);                			    
	}
	if(row2.created_by != null){
		row_tAsyncOut_tDBOutput_2[45] = String.valueOf(row2.created_by);                			    
	}
	if(row2.created_on != null){
		row_tAsyncOut_tDBOutput_2[46] = row2.created_on;                			    
	}
	if(row2.updated_by != null){
		row_tAsyncOut_tDBOutput_2[47] = String.valueOf(row2.updated_by);                			    
	}
	if(row2.updated_on != null){
		row_tAsyncOut_tDBOutput_2[48] = row2.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_2[49] = String.valueOf(row2.is_active); 
	row_tAsyncOut_tDBOutput_2[50] = String.valueOf(row2.is_deleted); 
	if(row2.branch_audit_details_id != null){
		row_tAsyncOut_tDBOutput_2[51] = row2.branch_audit_details_id;                			    
	}
	if(row2.as_on != null){
		row_tAsyncOut_tDBOutput_2[52] = row2.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_2 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_2", buffers_tAsyncOut_tDBOutput_2);
		/*tAsyncIn_tDBOutput_7Process(globalMap);*/
		tAsyncIn_tDBOutput_2Process(globalMap);
		buffers_tAsyncOut_tDBOutput_2 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_2 = 0;
	}
	buffers_tAsyncOut_tDBOutput_2.add(row_tAsyncOut_tDBOutput_2);
	index_tAsyncOut_tDBOutput_2++;
 


	tos_count_tAsyncOut_tDBOutput_2++;

/**
 * [tAsyncOut_tDBOutput_2 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	

 



/**
 * [tAsyncOut_tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	

 



/**
 * [tAsyncOut_tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"branch_audit_details\"";
		

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"branch_audit_details\"";
		

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}

		   globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
		

	    		log.debug("tDBInput_2 - Retrieved records count: "+nb_line_tDBInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Done.") );

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	


	if (buffers_tAsyncOut_tDBOutput_2.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_2", buffers_tAsyncOut_tDBOutput_2);
	    tAsyncIn_tDBOutput_2Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_2.waitForEnd();
	pool_tAsyncOut_tDBOutput_2.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tDBInput_2","\"branch_audit_details\"","tMysqlInput","tAsyncOut_tDBOutput_2","tAsyncOut_tDBOutput_2","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_2", true);
end_Hash.put("tAsyncOut_tDBOutput_2", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"branch_audit_details\"";
		

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	

 



/**
 * [tAsyncOut_tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String apk_version;

				public String getApk_version () {
					return this.apk_version;
				}

				public Boolean apk_versionIsNullable(){
				    return true;
				}
				public Boolean apk_versionIsKey(){
				    return false;
				}
				public Integer apk_versionLength(){
				    return 45;
				}
				public Integer apk_versionPrecision(){
				    return 0;
				}
				public String apk_versionDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String apk_versionComment(){
				
				    return "";
				
				}
				public String apk_versionPattern(){
				
					return "";
				
				}
				public String apk_versionOriginalDbColumnName(){
				
					return "apk_version";
				
				}

				
			    public String apk_url;

				public String getApk_url () {
					return this.apk_url;
				}

				public Boolean apk_urlIsNullable(){
				    return true;
				}
				public Boolean apk_urlIsKey(){
				    return false;
				}
				public Integer apk_urlLength(){
				    return 150;
				}
				public Integer apk_urlPrecision(){
				    return 0;
				}
				public String apk_urlDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String apk_urlComment(){
				
				    return "";
				
				}
				public String apk_urlPattern(){
				
					return "";
				
				}
				public String apk_urlOriginalDbColumnName(){
				
					return "apk_url";
				
				}

				
			    public String created_by;

				public String getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 45;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return true;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public String updated_by;

				public String getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 45;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return true;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public Integer is_active;

				public Integer getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return true;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public Integer is_deleted;

				public Integer getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return true;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.id = this.id;
	            other.apk_version = this.apk_version;
	            other.apk_url = this.apk_url;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.apk_version = readString(dis);
					
					this.apk_url = readString(dis);
					
					this.created_by = readString(dis);
					
					this.created_on = readDate(dis);
					
					this.updated_by = readString(dis);
					
					this.updated_on = readDate(dis);
					
						this.is_active = readInteger(dis);
					
						this.is_deleted = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.apk_version = readString(dis);
					
					this.apk_url = readString(dis);
					
					this.created_by = readString(dis);
					
					this.created_on = readDate(dis);
					
					this.updated_by = readString(dis);
					
					this.updated_on = readDate(dis);
					
						this.is_active = readInteger(dis);
					
						this.is_deleted = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.apk_version,dos);
					
					// String
				
						writeString(this.apk_url,dos);
					
					// String
				
						writeString(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// String
				
						writeString(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// Integer
				
						writeInteger(this.is_active,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.apk_version,dos);
					
					// String
				
						writeString(this.apk_url,dos);
					
					// String
				
						writeString(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// String
				
						writeString(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// Integer
				
						writeInteger(this.is_active,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",apk_version="+apk_version);
		sb.append(",apk_url="+apk_url);
		sb.append(",created_by="+created_by);
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+updated_by);
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(apk_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(apk_version);
            			}
            		
        			sb.append("|");
        		
        				if(apk_url == null){
        					sb.append("<null>");
        				}else{
            				sb.append(apk_url);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				if(is_active == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_active);
            			}
            		
        			sb.append("|");
        		
        				if(is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", "iRXLjR_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_3", false);
		start_Hash.put("tAsyncOut_tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tAsyncOut_tDBOutput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_3", "tAsyncOut_tDBOutput_3", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_3 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_3 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_3 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_3=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_3 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_3", pool_tAsyncOut_tDBOutput_3);
	final Object[] lockWrite_tAsyncOut_tDBOutput_3 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_3", lockWrite_tAsyncOut_tDBOutput_3);
 



/**
 * [tAsyncOut_tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_apk\"";
		
		int tos_count_tDBInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
                    log4jParamters_tDBInput_3.append("Parameters:");
                            log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"mst_apk\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERY" + " = " + "\"SELECT    `mst_apk`.`id`,    `mst_apk`.`apk_version`,    `mst_apk`.`apk_url`,    `mst_apk`.`created_by`,    `mst_apk`.`created_on`,    `mst_apk`.`updated_by`,    `mst_apk`.`updated_on`,    `mst_apk`.`is_active`,    `mst_apk`.`is_deleted`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_apk`\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("apk_version")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("apk_url")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + (log4jParamters_tDBInput_3) );
                    } 
                } 
            new BytesLimit65535_tDBInput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_3", "\"mst_apk\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_3 = java.util.Calendar.getInstance();
		    calendar_tDBInput_3.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_3 = calendar_tDBInput_3.getTime();
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				conn_tDBInput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_3 != null) {
					if(conn_tDBInput_3.getMetaData() != null) {
						
							log.debug("tDBInput_3 - Uses an existing connection with username '" + conn_tDBInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();
				if(stmt_tDBInput_3 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_3).enableStreamingResults();
				}else if(stmt_tDBInput_3 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_3).enableStreamingResults();
				}

		    String dbquery_tDBInput_3 = "SELECT \n  `mst_apk`.`id`, \n  `mst_apk`.`apk_version`, \n  `mst_apk`.`apk_url`, \n  `mst_apk`.`created_by`, \n  `mst_apk`.`"
+"created_on`, \n  `mst_apk`.`updated_by`, \n  `mst_apk`.`updated_on`, \n  `mst_apk`.`is_active`, \n  `mst_apk`.`is_deleted`,"
+"\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_apk`";
		    
	    		log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");
			

            	globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);
		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    	log.debug("tDBInput_3 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row3.id = 0;
							} else {
		                          
            row3.id = rs_tDBInput_3.getInt(1);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row3.apk_version = null;
							} else {
	                         		
        	row3.apk_version = routines.system.JDBCUtil.getString(rs_tDBInput_3, 2, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row3.apk_url = null;
							} else {
	                         		
        	row3.apk_url = routines.system.JDBCUtil.getString(rs_tDBInput_3, 3, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 4) {
								row3.created_by = null;
							} else {
	                         		
        	row3.created_by = routines.system.JDBCUtil.getString(rs_tDBInput_3, 4, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 5) {
								row3.created_on = null;
							} else {
										
				if(rs_tDBInput_3.getString(5) != null) {
					String dateString_tDBInput_3 = rs_tDBInput_3.getString(5);
					if (!("0000-00-00").equals(dateString_tDBInput_3) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_3)) {
						row3.created_on = rs_tDBInput_3.getTimestamp(5);
					} else {
						row3.created_on = (java.util.Date) year0_tDBInput_3.clone();
					}
				} else {
					row3.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_3 < 6) {
								row3.updated_by = null;
							} else {
	                         		
        	row3.updated_by = routines.system.JDBCUtil.getString(rs_tDBInput_3, 6, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 7) {
								row3.updated_on = null;
							} else {
										
				if(rs_tDBInput_3.getString(7) != null) {
					String dateString_tDBInput_3 = rs_tDBInput_3.getString(7);
					if (!("0000-00-00").equals(dateString_tDBInput_3) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_3)) {
						row3.updated_on = rs_tDBInput_3.getTimestamp(7);
					} else {
						row3.updated_on = (java.util.Date) year0_tDBInput_3.clone();
					}
				} else {
					row3.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_3 < 8) {
								row3.is_active = null;
							} else {
		                          
            row3.is_active = rs_tDBInput_3.getInt(8);
            if(rs_tDBInput_3.wasNull()){
                    row3.is_active = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 9) {
								row3.is_deleted = null;
							} else {
		                          
            row3.is_deleted = rs_tDBInput_3.getInt(9);
            if(rs_tDBInput_3.wasNull()){
                    row3.is_deleted = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 10) {
								row3.as_on = null;
							} else {
										
				if(rs_tDBInput_3.getString(10) != null) {
					String dateString_tDBInput_3 = rs_tDBInput_3.getString(10);
					if (!("0000-00-00").equals(dateString_tDBInput_3) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_3)) {
						row3.as_on = rs_tDBInput_3.getTimestamp(10);
					} else {
						row3.as_on = (java.util.Date) year0_tDBInput_3.clone();
					}
				} else {
					row3.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");
					

 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_apk\"";
		

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_apk\"";
		

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tDBInput_3","\"mst_apk\"","tMysqlInput","tAsyncOut_tDBOutput_3","tAsyncOut_tDBOutput_3","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_3=new Object[]{null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_3[0] = String.valueOf(row3.id); 
	if(row3.apk_version != null){
		row_tAsyncOut_tDBOutput_3[1] = row3.apk_version;                			    
	}
	if(row3.apk_url != null){
		row_tAsyncOut_tDBOutput_3[2] = row3.apk_url;                			    
	}
	if(row3.created_by != null){
		row_tAsyncOut_tDBOutput_3[3] = row3.created_by;                			    
	}
	if(row3.created_on != null){
		row_tAsyncOut_tDBOutput_3[4] = row3.created_on;                			    
	}
	if(row3.updated_by != null){
		row_tAsyncOut_tDBOutput_3[5] = row3.updated_by;                			    
	}
	if(row3.updated_on != null){
		row_tAsyncOut_tDBOutput_3[6] = row3.updated_on;                			    
	}
	if(row3.is_active != null){
		row_tAsyncOut_tDBOutput_3[7] = String.valueOf(row3.is_active);                			    
	}
	if(row3.is_deleted != null){
		row_tAsyncOut_tDBOutput_3[8] = String.valueOf(row3.is_deleted);                			    
	}
	if(row3.as_on != null){
		row_tAsyncOut_tDBOutput_3[9] = row3.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_3 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_3", buffers_tAsyncOut_tDBOutput_3);
		/*tAsyncIn_tDBOutput_7Process(globalMap);*/
		tAsyncIn_tDBOutput_3Process(globalMap);
		buffers_tAsyncOut_tDBOutput_3 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_3 = 0;
	}
	buffers_tAsyncOut_tDBOutput_3.add(row_tAsyncOut_tDBOutput_3);
	index_tAsyncOut_tDBOutput_3++;
 


	tos_count_tAsyncOut_tDBOutput_3++;

/**
 * [tAsyncOut_tDBOutput_3 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	

 



/**
 * [tAsyncOut_tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	

 



/**
 * [tAsyncOut_tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_apk\"";
		

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_apk\"";
		

	}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
}

		   globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
		

	    		log.debug("tDBInput_3 - Retrieved records count: "+nb_line_tDBInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Done.") );

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());




/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	


	if (buffers_tAsyncOut_tDBOutput_3.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_3", buffers_tAsyncOut_tDBOutput_3);
	    tAsyncIn_tDBOutput_3Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_3.waitForEnd();
	pool_tAsyncOut_tDBOutput_3.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tDBInput_3","\"mst_apk\"","tMysqlInput","tAsyncOut_tDBOutput_3","tAsyncOut_tDBOutput_3","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_3", true);
end_Hash.put("tAsyncOut_tDBOutput_3", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_apk\"";
		

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	

 



/**
 * [tAsyncOut_tDBOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String criteria;

				public String getCriteria () {
					return this.criteria;
				}

				public Boolean criteriaIsNullable(){
				    return false;
				}
				public Boolean criteriaIsKey(){
				    return false;
				}
				public Integer criteriaLength(){
				    return 200;
				}
				public Integer criteriaPrecision(){
				    return 0;
				}
				public String criteriaDefault(){
				
					return null;
				
				}
				public String criteriaComment(){
				
				    return "";
				
				}
				public String criteriaPattern(){
				
					return "";
				
				}
				public String criteriaOriginalDbColumnName(){
				
					return "criteria";
				
				}

				
			    public Integer data_period;

				public Integer getData_period () {
					return this.data_period;
				}

				public Boolean data_periodIsNullable(){
				    return true;
				}
				public Boolean data_periodIsKey(){
				    return false;
				}
				public Integer data_periodLength(){
				    return 10;
				}
				public Integer data_periodPrecision(){
				    return 0;
				}
				public String data_periodDefault(){
				
					return null;
				
				}
				public String data_periodComment(){
				
				    return "";
				
				}
				public String data_periodPattern(){
				
					return "";
				
				}
				public String data_periodOriginalDbColumnName(){
				
					return "data_period";
				
				}

				
			    public Float cut_off;

				public Float getCut_off () {
					return this.cut_off;
				}

				public Boolean cut_offIsNullable(){
				    return true;
				}
				public Boolean cut_offIsKey(){
				    return false;
				}
				public Integer cut_offLength(){
				    return 8;
				}
				public Integer cut_offPrecision(){
				    return 8;
				}
				public String cut_offDefault(){
				
					return null;
				
				}
				public String cut_offComment(){
				
				    return "";
				
				}
				public String cut_offPattern(){
				
					return "";
				
				}
				public String cut_offOriginalDbColumnName(){
				
					return "cut_off";
				
				}

				
			    public String criteria_type;

				public String getCriteria_type () {
					return this.criteria_type;
				}

				public Boolean criteria_typeIsNullable(){
				    return true;
				}
				public Boolean criteria_typeIsKey(){
				    return false;
				}
				public Integer criteria_typeLength(){
				    return 10;
				}
				public Integer criteria_typePrecision(){
				    return 0;
				}
				public String criteria_typeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String criteria_typeComment(){
				
				    return "";
				
				}
				public String criteria_typePattern(){
				
					return "";
				
				}
				public String criteria_typeOriginalDbColumnName(){
				
					return "criteria_type";
				
				}

				
			    public int is_default;

				public int getIs_default () {
					return this.is_default;
				}

				public Boolean is_defaultIsNullable(){
				    return false;
				}
				public Boolean is_defaultIsKey(){
				    return false;
				}
				public Integer is_defaultLength(){
				    return 10;
				}
				public Integer is_defaultPrecision(){
				    return 0;
				}
				public String is_defaultDefault(){
				
					return "0";
				
				}
				public String is_defaultComment(){
				
				    return "";
				
				}
				public String is_defaultPattern(){
				
					return "";
				
				}
				public String is_defaultOriginalDbColumnName(){
				
					return "is_default";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String audit_criteria_id;

				public String getAudit_criteria_id () {
					return this.audit_criteria_id;
				}

				public Boolean audit_criteria_idIsNullable(){
				    return true;
				}
				public Boolean audit_criteria_idIsKey(){
				    return false;
				}
				public Integer audit_criteria_idLength(){
				    return 32;
				}
				public Integer audit_criteria_idPrecision(){
				    return 0;
				}
				public String audit_criteria_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String audit_criteria_idComment(){
				
				    return "";
				
				}
				public String audit_criteria_idPattern(){
				
					return "";
				
				}
				public String audit_criteria_idOriginalDbColumnName(){
				
					return "audit_criteria_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.id = this.id;
	            other.criteria = this.criteria;
	            other.data_period = this.data_period;
	            other.cut_off = this.cut_off;
	            other.criteria_type = this.criteria_type;
	            other.is_default = this.is_default;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.audit_criteria_id = this.audit_criteria_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.criteria = readString(dis);
					
						this.data_period = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.cut_off = null;
           				} else {
           			    	this.cut_off = dis.readFloat();
           				}
					
					this.criteria_type = readString(dis);
					
			        this.is_default = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.audit_criteria_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.criteria = readString(dis);
					
						this.data_period = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.cut_off = null;
           				} else {
           			    	this.cut_off = dis.readFloat();
           				}
					
					this.criteria_type = readString(dis);
					
			        this.is_default = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.audit_criteria_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.criteria,dos);
					
					// Integer
				
						writeInteger(this.data_period,dos);
					
					// Float
				
						if(this.cut_off == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.cut_off);
		            	}
					
					// String
				
						writeString(this.criteria_type,dos);
					
					// int
				
		            	dos.writeInt(this.is_default);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.audit_criteria_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.criteria,dos);
					
					// Integer
				
						writeInteger(this.data_period,dos);
					
					// Float
				
						if(this.cut_off == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.cut_off);
		            	}
					
					// String
				
						writeString(this.criteria_type,dos);
					
					// int
				
		            	dos.writeInt(this.is_default);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.audit_criteria_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",criteria="+criteria);
		sb.append(",data_period="+String.valueOf(data_period));
		sb.append(",cut_off="+String.valueOf(cut_off));
		sb.append(",criteria_type="+criteria_type);
		sb.append(",is_default="+String.valueOf(is_default));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",audit_criteria_id="+audit_criteria_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(criteria == null){
        					sb.append("<null>");
        				}else{
            				sb.append(criteria);
            			}
            		
        			sb.append("|");
        		
        				if(data_period == null){
        					sb.append("<null>");
        				}else{
            				sb.append(data_period);
            			}
            		
        			sb.append("|");
        		
        				if(cut_off == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cut_off);
            			}
            		
        			sb.append("|");
        		
        				if(criteria_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(criteria_type);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_default);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(audit_criteria_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_criteria_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_4");
		org.slf4j.MDC.put("_subJobPid", "sUzy5D_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_4", false);
		start_Hash.put("tAsyncOut_tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tAsyncOut_tDBOutput_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_4", "tAsyncOut_tDBOutput_4", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_4 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_4 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_4 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_4=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_4 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_4", pool_tAsyncOut_tDBOutput_4);
	final Object[] lockWrite_tAsyncOut_tDBOutput_4 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_4", lockWrite_tAsyncOut_tDBOutput_4);
 



/**
 * [tAsyncOut_tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tDBInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_4", false);
		start_Hash.put("tDBInput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_audit_criteria\"";
		
		int tos_count_tDBInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_4 = new StringBuilder();
                    log4jParamters_tDBInput_4.append("Parameters:");
                            log4jParamters_tDBInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TABLE" + " = " + "\"mst_audit_criteria\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERY" + " = " + "\"SELECT    `mst_audit_criteria`.`id`,    `mst_audit_criteria`.`criteria`,    `mst_audit_criteria`.`data_period`,    `mst_audit_criteria`.`cut_off`,    `mst_audit_criteria`.`criteria_type`,    `mst_audit_criteria`.`is_default`,    `mst_audit_criteria`.`created_by`,    `mst_audit_criteria`.`created_on`,    `mst_audit_criteria`.`updated_by`,    `mst_audit_criteria`.`updated_on`,    `mst_audit_criteria`.`is_active`,    `mst_audit_criteria`.`is_deleted`,    `mst_audit_criteria`.`audit_criteria_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_audit_criteria`\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("criteria")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("data_period")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("cut_off")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("criteria_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_default")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audit_criteria_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + (log4jParamters_tDBInput_4) );
                    } 
                } 
            new BytesLimit65535_tDBInput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_4", "\"mst_audit_criteria\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_4 = java.util.Calendar.getInstance();
		    calendar_tDBInput_4.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_4 = calendar_tDBInput_4.getTime();
		    int nb_line_tDBInput_4 = 0;
		    java.sql.Connection conn_tDBInput_4 = null;
				conn_tDBInput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_4 != null) {
					if(conn_tDBInput_4.getMetaData() != null) {
						
							log.debug("tDBInput_4 - Uses an existing connection with username '" + conn_tDBInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();
				if(stmt_tDBInput_4 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_4).enableStreamingResults();
				}else if(stmt_tDBInput_4 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_4).enableStreamingResults();
				}

		    String dbquery_tDBInput_4 = "SELECT \n  `mst_audit_criteria`.`id`, \n  `mst_audit_criteria`.`criteria`, \n  `mst_audit_criteria`.`data_period`, \n  `mst"
+"_audit_criteria`.`cut_off`, \n  `mst_audit_criteria`.`criteria_type`, \n  `mst_audit_criteria`.`is_default`, \n  `mst_audit"
+"_criteria`.`created_by`, \n  `mst_audit_criteria`.`created_on`, \n  `mst_audit_criteria`.`updated_by`, \n  `mst_audit_crite"
+"ria`.`updated_on`, \n  `mst_audit_criteria`.`is_active`, \n  `mst_audit_criteria`.`is_deleted`, \n  `mst_audit_criteria`.`a"
+"udit_criteria_id`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_audit_criteria`";
		    
	    		log.debug("tDBInput_4 - Executing the query: '" + dbquery_tDBInput_4 + "'.");
			

            	globalMap.put("tDBInput_4_QUERY",dbquery_tDBInput_4);
		    java.sql.ResultSet rs_tDBInput_4 = null;

		    try {
		    	rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
		    	int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

		    String tmpContent_tDBInput_4 = null;
		    
		    
		    	log.debug("tDBInput_4 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_4.next()) {
		        nb_line_tDBInput_4++;
		        
							if(colQtyInRs_tDBInput_4 < 1) {
								row4.id = 0;
							} else {
		                          
            row4.id = rs_tDBInput_4.getInt(1);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 2) {
								row4.criteria = null;
							} else {
	                         		
        	row4.criteria = routines.system.JDBCUtil.getString(rs_tDBInput_4, 2, false);
		                    }
							if(colQtyInRs_tDBInput_4 < 3) {
								row4.data_period = null;
							} else {
		                          
            row4.data_period = rs_tDBInput_4.getInt(3);
            if(rs_tDBInput_4.wasNull()){
                    row4.data_period = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 4) {
								row4.cut_off = null;
							} else {
		                          
            row4.cut_off = rs_tDBInput_4.getFloat(4);
            if(rs_tDBInput_4.wasNull()){
                    row4.cut_off = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 5) {
								row4.criteria_type = null;
							} else {
	                         		
        	row4.criteria_type = routines.system.JDBCUtil.getString(rs_tDBInput_4, 5, false);
		                    }
							if(colQtyInRs_tDBInput_4 < 6) {
								row4.is_default = 0;
							} else {
		                          
            row4.is_default = rs_tDBInput_4.getInt(6);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 7) {
								row4.created_by = null;
							} else {
		                          
            row4.created_by = rs_tDBInput_4.getInt(7);
            if(rs_tDBInput_4.wasNull()){
                    row4.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 8) {
								row4.created_on = null;
							} else {
										
				if(rs_tDBInput_4.getString(8) != null) {
					String dateString_tDBInput_4 = rs_tDBInput_4.getString(8);
					if (!("0000-00-00").equals(dateString_tDBInput_4) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_4)) {
						row4.created_on = rs_tDBInput_4.getTimestamp(8);
					} else {
						row4.created_on = (java.util.Date) year0_tDBInput_4.clone();
					}
				} else {
					row4.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_4 < 9) {
								row4.updated_by = null;
							} else {
		                          
            row4.updated_by = rs_tDBInput_4.getInt(9);
            if(rs_tDBInput_4.wasNull()){
                    row4.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 10) {
								row4.updated_on = null;
							} else {
										
				if(rs_tDBInput_4.getString(10) != null) {
					String dateString_tDBInput_4 = rs_tDBInput_4.getString(10);
					if (!("0000-00-00").equals(dateString_tDBInput_4) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_4)) {
						row4.updated_on = rs_tDBInput_4.getTimestamp(10);
					} else {
						row4.updated_on = (java.util.Date) year0_tDBInput_4.clone();
					}
				} else {
					row4.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_4 < 11) {
								row4.is_active = 0;
							} else {
		                          
            row4.is_active = rs_tDBInput_4.getInt(11);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 12) {
								row4.is_deleted = 0;
							} else {
		                          
            row4.is_deleted = rs_tDBInput_4.getInt(12);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 13) {
								row4.audit_criteria_id = null;
							} else {
	                         		
        	row4.audit_criteria_id = routines.system.JDBCUtil.getString(rs_tDBInput_4, 13, false);
		                    }
							if(colQtyInRs_tDBInput_4 < 14) {
								row4.as_on = null;
							} else {
										
				if(rs_tDBInput_4.getString(14) != null) {
					String dateString_tDBInput_4 = rs_tDBInput_4.getString(14);
					if (!("0000-00-00").equals(dateString_tDBInput_4) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_4)) {
						row4.as_on = rs_tDBInput_4.getTimestamp(14);
					} else {
						row4.as_on = (java.util.Date) year0_tDBInput_4.clone();
					}
				} else {
					row4.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_4 - Retrieving the record " + nb_line_tDBInput_4 + ".");
					

 



/**
 * [tDBInput_4 begin ] stop
 */
	
	/**
	 * [tDBInput_4 main ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_audit_criteria\"";
		

 


	tos_count_tDBInput_4++;

/**
 * [tDBInput_4 main ] stop
 */
	
	/**
	 * [tDBInput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_audit_criteria\"";
		

 



/**
 * [tDBInput_4 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tDBInput_4","\"mst_audit_criteria\"","tMysqlInput","tAsyncOut_tDBOutput_4","tAsyncOut_tDBOutput_4","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_4=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_4[0] = String.valueOf(row4.id); 
	if(row4.criteria != null){
		row_tAsyncOut_tDBOutput_4[1] = row4.criteria;                			    
	}
	if(row4.data_period != null){
		row_tAsyncOut_tDBOutput_4[2] = String.valueOf(row4.data_period);                			    
	}
	if(row4.cut_off != null){
		row_tAsyncOut_tDBOutput_4[3] = String.valueOf(row4.cut_off);                			    
	}
	if(row4.criteria_type != null){
		row_tAsyncOut_tDBOutput_4[4] = row4.criteria_type;                			    
	}
	row_tAsyncOut_tDBOutput_4[5] = String.valueOf(row4.is_default); 
	if(row4.created_by != null){
		row_tAsyncOut_tDBOutput_4[6] = String.valueOf(row4.created_by);                			    
	}
	if(row4.created_on != null){
		row_tAsyncOut_tDBOutput_4[7] = row4.created_on;                			    
	}
	if(row4.updated_by != null){
		row_tAsyncOut_tDBOutput_4[8] = String.valueOf(row4.updated_by);                			    
	}
	if(row4.updated_on != null){
		row_tAsyncOut_tDBOutput_4[9] = row4.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_4[10] = String.valueOf(row4.is_active); 
	row_tAsyncOut_tDBOutput_4[11] = String.valueOf(row4.is_deleted); 
	if(row4.audit_criteria_id != null){
		row_tAsyncOut_tDBOutput_4[12] = row4.audit_criteria_id;                			    
	}
	if(row4.as_on != null){
		row_tAsyncOut_tDBOutput_4[13] = row4.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_4 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_4", buffers_tAsyncOut_tDBOutput_4);
		/*tAsyncIn_tDBOutput_7Process(globalMap);*/
		tAsyncIn_tDBOutput_4Process(globalMap);
		buffers_tAsyncOut_tDBOutput_4 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_4 = 0;
	}
	buffers_tAsyncOut_tDBOutput_4.add(row_tAsyncOut_tDBOutput_4);
	index_tAsyncOut_tDBOutput_4++;
 


	tos_count_tAsyncOut_tDBOutput_4++;

/**
 * [tAsyncOut_tDBOutput_4 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	

 



/**
 * [tAsyncOut_tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	

 



/**
 * [tAsyncOut_tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_audit_criteria\"";
		

 



/**
 * [tDBInput_4 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_4 end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_audit_criteria\"";
		

	}
}finally{
	if (rs_tDBInput_4 != null) {
		rs_tDBInput_4.close();
	}
	if (stmt_tDBInput_4 != null) {
		stmt_tDBInput_4.close();
	}
}

		   globalMap.put("tDBInput_4_NB_LINE",nb_line_tDBInput_4);
		

	    		log.debug("tDBInput_4 - Retrieved records count: "+nb_line_tDBInput_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Done.") );

ok_Hash.put("tDBInput_4", true);
end_Hash.put("tDBInput_4", System.currentTimeMillis());




/**
 * [tDBInput_4 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	


	if (buffers_tAsyncOut_tDBOutput_4.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_4", buffers_tAsyncOut_tDBOutput_4);
	    tAsyncIn_tDBOutput_4Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_4.waitForEnd();
	pool_tAsyncOut_tDBOutput_4.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tDBInput_4","\"mst_audit_criteria\"","tMysqlInput","tAsyncOut_tDBOutput_4","tAsyncOut_tDBOutput_4","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_4", true);
end_Hash.put("tAsyncOut_tDBOutput_4", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_audit_criteria\"";
		

 



/**
 * [tDBInput_4 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	

 



/**
 * [tAsyncOut_tDBOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String branch_code;

				public String getBranch_code () {
					return this.branch_code;
				}

				public Boolean branch_codeIsNullable(){
				    return false;
				}
				public Boolean branch_codeIsKey(){
				    return false;
				}
				public Integer branch_codeLength(){
				    return 5;
				}
				public Integer branch_codePrecision(){
				    return 0;
				}
				public String branch_codeDefault(){
				
					return null;
				
				}
				public String branch_codeComment(){
				
				    return "";
				
				}
				public String branch_codePattern(){
				
					return "";
				
				}
				public String branch_codeOriginalDbColumnName(){
				
					return "branch_code";
				
				}

				
			    public String branch;

				public String getBranch () {
					return this.branch;
				}

				public Boolean branchIsNullable(){
				    return false;
				}
				public Boolean branchIsKey(){
				    return false;
				}
				public Integer branchLength(){
				    return 45;
				}
				public Integer branchPrecision(){
				    return 0;
				}
				public String branchDefault(){
				
					return null;
				
				}
				public String branchComment(){
				
				    return "";
				
				}
				public String branchPattern(){
				
					return "";
				
				}
				public String branchOriginalDbColumnName(){
				
					return "branch";
				
				}

				
			    public int region_id;

				public int getRegion_id () {
					return this.region_id;
				}

				public Boolean region_idIsNullable(){
				    return false;
				}
				public Boolean region_idIsKey(){
				    return false;
				}
				public Integer region_idLength(){
				    return 10;
				}
				public Integer region_idPrecision(){
				    return 0;
				}
				public String region_idDefault(){
				
					return null;
				
				}
				public String region_idComment(){
				
				    return "";
				
				}
				public String region_idPattern(){
				
					return "";
				
				}
				public String region_idOriginalDbColumnName(){
				
					return "region_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String branch_id;

				public String getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return true;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 32;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row5Struct other = (row5Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row5Struct other) {

		other.id = this.id;
	            other.branch_code = this.branch_code;
	            other.branch = this.branch;
	            other.region_id = this.region_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.branch_id = this.branch_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row5Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.branch_code = readString(dis);
					
					this.branch = readString(dis);
					
			        this.region_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.branch_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.branch_code = readString(dis);
					
					this.branch = readString(dis);
					
			        this.region_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.branch_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.branch_code,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// int
				
		            	dos.writeInt(this.region_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.branch_code,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// int
				
		            	dos.writeInt(this.region_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",branch_code="+branch_code);
		sb.append(",branch="+branch);
		sb.append(",region_id="+String.valueOf(region_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",branch_id="+branch_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(branch_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_code);
            			}
            		
        			sb.append("|");
        		
        				if(branch == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch);
            			}
            		
        			sb.append("|");
        		
        				sb.append(region_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(branch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_5");
		org.slf4j.MDC.put("_subJobPid", "6HRpVB_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_5", false);
		start_Hash.put("tAsyncOut_tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tAsyncOut_tDBOutput_5 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_5", "tAsyncOut_tDBOutput_5", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_5 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_5 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_5 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_5=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_5 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_5", pool_tAsyncOut_tDBOutput_5);
	final Object[] lockWrite_tAsyncOut_tDBOutput_5 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_5", lockWrite_tAsyncOut_tDBOutput_5);
 



/**
 * [tAsyncOut_tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tDBInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_5", false);
		start_Hash.put("tDBInput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_branch\"";
		
		int tos_count_tDBInput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_5 = new StringBuilder();
                    log4jParamters_tDBInput_5.append("Parameters:");
                            log4jParamters_tDBInput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TABLE" + " = " + "\"mst_branch\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERY" + " = " + "\"SELECT    `mst_branch`.`id`,    `mst_branch`.`branch_code`,    `mst_branch`.`branch`,    `mst_branch`.`region_id`,    `mst_branch`.`created_by`,    `mst_branch`.`created_on`,    `mst_branch`.`updated_by`,    `mst_branch`.`updated_on`,    `mst_branch`.`is_active`,    `mst_branch`.`is_deleted`,    `mst_branch`.`branch_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_branch`\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_code")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("region_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + (log4jParamters_tDBInput_5) );
                    } 
                } 
            new BytesLimit65535_tDBInput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_5", "\"mst_branch\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_5 = java.util.Calendar.getInstance();
		    calendar_tDBInput_5.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_5 = calendar_tDBInput_5.getTime();
		    int nb_line_tDBInput_5 = 0;
		    java.sql.Connection conn_tDBInput_5 = null;
				conn_tDBInput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_5 != null) {
					if(conn_tDBInput_5.getMetaData() != null) {
						
							log.debug("tDBInput_5 - Uses an existing connection with username '" + conn_tDBInput_5.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_5.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_5 = conn_tDBInput_5.createStatement();
				if(stmt_tDBInput_5 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_5).enableStreamingResults();
				}else if(stmt_tDBInput_5 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_5).enableStreamingResults();
				}

		    String dbquery_tDBInput_5 = "SELECT \n  `mst_branch`.`id`, \n  `mst_branch`.`branch_code`, \n  `mst_branch`.`branch`, \n  `mst_branch`.`region_id`, \n  `"
+"mst_branch`.`created_by`, \n  `mst_branch`.`created_on`, \n  `mst_branch`.`updated_by`, \n  `mst_branch`.`updated_on`, \n  `"
+"mst_branch`.`is_active`, \n  `mst_branch`.`is_deleted`, \n  `mst_branch`.`branch_id`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERV"
+"AL 1 DAY) AS `as_on`\nFROM `mst_branch`";
		    
	    		log.debug("tDBInput_5 - Executing the query: '" + dbquery_tDBInput_5 + "'.");
			

            	globalMap.put("tDBInput_5_QUERY",dbquery_tDBInput_5);
		    java.sql.ResultSet rs_tDBInput_5 = null;

		    try {
		    	rs_tDBInput_5 = stmt_tDBInput_5.executeQuery(dbquery_tDBInput_5);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_5 = rs_tDBInput_5.getMetaData();
		    	int colQtyInRs_tDBInput_5 = rsmd_tDBInput_5.getColumnCount();

		    String tmpContent_tDBInput_5 = null;
		    
		    
		    	log.debug("tDBInput_5 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_5.next()) {
		        nb_line_tDBInput_5++;
		        
							if(colQtyInRs_tDBInput_5 < 1) {
								row5.id = 0;
							} else {
		                          
            row5.id = rs_tDBInput_5.getInt(1);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 2) {
								row5.branch_code = null;
							} else {
	                         		
        	row5.branch_code = routines.system.JDBCUtil.getString(rs_tDBInput_5, 2, false);
		                    }
							if(colQtyInRs_tDBInput_5 < 3) {
								row5.branch = null;
							} else {
	                         		
        	row5.branch = routines.system.JDBCUtil.getString(rs_tDBInput_5, 3, false);
		                    }
							if(colQtyInRs_tDBInput_5 < 4) {
								row5.region_id = 0;
							} else {
		                          
            row5.region_id = rs_tDBInput_5.getInt(4);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 5) {
								row5.created_by = null;
							} else {
		                          
            row5.created_by = rs_tDBInput_5.getInt(5);
            if(rs_tDBInput_5.wasNull()){
                    row5.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 6) {
								row5.created_on = null;
							} else {
										
				if(rs_tDBInput_5.getString(6) != null) {
					String dateString_tDBInput_5 = rs_tDBInput_5.getString(6);
					if (!("0000-00-00").equals(dateString_tDBInput_5) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_5)) {
						row5.created_on = rs_tDBInput_5.getTimestamp(6);
					} else {
						row5.created_on = (java.util.Date) year0_tDBInput_5.clone();
					}
				} else {
					row5.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_5 < 7) {
								row5.updated_by = null;
							} else {
		                          
            row5.updated_by = rs_tDBInput_5.getInt(7);
            if(rs_tDBInput_5.wasNull()){
                    row5.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 8) {
								row5.updated_on = null;
							} else {
										
				if(rs_tDBInput_5.getString(8) != null) {
					String dateString_tDBInput_5 = rs_tDBInput_5.getString(8);
					if (!("0000-00-00").equals(dateString_tDBInput_5) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_5)) {
						row5.updated_on = rs_tDBInput_5.getTimestamp(8);
					} else {
						row5.updated_on = (java.util.Date) year0_tDBInput_5.clone();
					}
				} else {
					row5.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_5 < 9) {
								row5.is_active = 0;
							} else {
		                          
            row5.is_active = rs_tDBInput_5.getInt(9);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 10) {
								row5.is_deleted = 0;
							} else {
		                          
            row5.is_deleted = rs_tDBInput_5.getInt(10);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 11) {
								row5.branch_id = null;
							} else {
	                         		
        	row5.branch_id = routines.system.JDBCUtil.getString(rs_tDBInput_5, 11, false);
		                    }
							if(colQtyInRs_tDBInput_5 < 12) {
								row5.as_on = null;
							} else {
										
				if(rs_tDBInput_5.getString(12) != null) {
					String dateString_tDBInput_5 = rs_tDBInput_5.getString(12);
					if (!("0000-00-00").equals(dateString_tDBInput_5) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_5)) {
						row5.as_on = rs_tDBInput_5.getTimestamp(12);
					} else {
						row5.as_on = (java.util.Date) year0_tDBInput_5.clone();
					}
				} else {
					row5.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_5 - Retrieving the record " + nb_line_tDBInput_5 + ".");
					

 



/**
 * [tDBInput_5 begin ] stop
 */
	
	/**
	 * [tDBInput_5 main ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_branch\"";
		

 


	tos_count_tDBInput_5++;

/**
 * [tDBInput_5 main ] stop
 */
	
	/**
	 * [tDBInput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_branch\"";
		

 



/**
 * [tDBInput_5 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tDBInput_5","\"mst_branch\"","tMysqlInput","tAsyncOut_tDBOutput_5","tAsyncOut_tDBOutput_5","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_5=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_5[0] = String.valueOf(row5.id); 
	if(row5.branch_code != null){
		row_tAsyncOut_tDBOutput_5[1] = row5.branch_code;                			    
	}
	if(row5.branch != null){
		row_tAsyncOut_tDBOutput_5[2] = row5.branch;                			    
	}
	row_tAsyncOut_tDBOutput_5[3] = String.valueOf(row5.region_id); 
	if(row5.created_by != null){
		row_tAsyncOut_tDBOutput_5[4] = String.valueOf(row5.created_by);                			    
	}
	if(row5.created_on != null){
		row_tAsyncOut_tDBOutput_5[5] = row5.created_on;                			    
	}
	if(row5.updated_by != null){
		row_tAsyncOut_tDBOutput_5[6] = String.valueOf(row5.updated_by);                			    
	}
	if(row5.updated_on != null){
		row_tAsyncOut_tDBOutput_5[7] = row5.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_5[8] = String.valueOf(row5.is_active); 
	row_tAsyncOut_tDBOutput_5[9] = String.valueOf(row5.is_deleted); 
	if(row5.branch_id != null){
		row_tAsyncOut_tDBOutput_5[10] = row5.branch_id;                			    
	}
	if(row5.as_on != null){
		row_tAsyncOut_tDBOutput_5[11] = row5.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_5 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_5", buffers_tAsyncOut_tDBOutput_5);
		/*tAsyncIn_tDBOutput_7Process(globalMap);*/
		tAsyncIn_tDBOutput_5Process(globalMap);
		buffers_tAsyncOut_tDBOutput_5 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_5 = 0;
	}
	buffers_tAsyncOut_tDBOutput_5.add(row_tAsyncOut_tDBOutput_5);
	index_tAsyncOut_tDBOutput_5++;
 


	tos_count_tAsyncOut_tDBOutput_5++;

/**
 * [tAsyncOut_tDBOutput_5 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	

 



/**
 * [tAsyncOut_tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	

 



/**
 * [tAsyncOut_tDBOutput_5 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_branch\"";
		

 



/**
 * [tDBInput_5 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_5 end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_branch\"";
		

	}
}finally{
	if (rs_tDBInput_5 != null) {
		rs_tDBInput_5.close();
	}
	if (stmt_tDBInput_5 != null) {
		stmt_tDBInput_5.close();
	}
}

		   globalMap.put("tDBInput_5_NB_LINE",nb_line_tDBInput_5);
		

	    		log.debug("tDBInput_5 - Retrieved records count: "+nb_line_tDBInput_5 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Done.") );

ok_Hash.put("tDBInput_5", true);
end_Hash.put("tDBInput_5", System.currentTimeMillis());




/**
 * [tDBInput_5 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	


	if (buffers_tAsyncOut_tDBOutput_5.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_5", buffers_tAsyncOut_tDBOutput_5);
	    tAsyncIn_tDBOutput_5Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_5.waitForEnd();
	pool_tAsyncOut_tDBOutput_5.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tDBInput_5","\"mst_branch\"","tMysqlInput","tAsyncOut_tDBOutput_5","tAsyncOut_tDBOutput_5","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_5", true);
end_Hash.put("tAsyncOut_tDBOutput_5", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_branch\"";
		

 



/**
 * [tDBInput_5 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	

 



/**
 * [tAsyncOut_tDBOutput_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return false;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 45;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String category_id;

				public String getCategory_id () {
					return this.category_id;
				}

				public Boolean category_idIsNullable(){
				    return true;
				}
				public Boolean category_idIsKey(){
				    return false;
				}
				public Integer category_idLength(){
				    return 32;
				}
				public Integer category_idPrecision(){
				    return 0;
				}
				public String category_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String category_idComment(){
				
				    return "";
				
				}
				public String category_idPattern(){
				
					return "";
				
				}
				public String category_idOriginalDbColumnName(){
				
					return "category_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row6Struct other = (row6Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row6Struct other) {

		other.id = this.id;
	            other.name = this.name;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.category_id = this.category_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row6Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.name = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.category_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.name = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.category_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.name,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.category_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.name,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.category_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",name="+name);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",category_id="+category_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(category_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(category_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_6");
		org.slf4j.MDC.put("_subJobPid", "wkieMn_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_6", false);
		start_Hash.put("tAsyncOut_tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tAsyncOut_tDBOutput_6 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_6", "tAsyncOut_tDBOutput_6", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_6 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_6 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_6 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_6=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_6 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_6", pool_tAsyncOut_tDBOutput_6);
	final Object[] lockWrite_tAsyncOut_tDBOutput_6 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_6", lockWrite_tAsyncOut_tDBOutput_6);
 



/**
 * [tAsyncOut_tDBOutput_6 begin ] stop
 */



	
	/**
	 * [tDBInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_6", false);
		start_Hash.put("tDBInput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_category\"";
		
		int tos_count_tDBInput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_6 = new StringBuilder();
                    log4jParamters_tDBInput_6.append("Parameters:");
                            log4jParamters_tDBInput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TABLE" + " = " + "\"mst_category\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERY" + " = " + "\"SELECT    `mst_category`.`id`,    `mst_category`.`name`,    `mst_category`.`created_by`,    `mst_category`.`created_on`,    `mst_category`.`updated_by`,    `mst_category`.`updated_on`,    `mst_category`.`is_active`,    `mst_category`.`is_deleted`,    `mst_category`.`category_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_category`\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("category_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + (log4jParamters_tDBInput_6) );
                    } 
                } 
            new BytesLimit65535_tDBInput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_6", "\"mst_category\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_6 = java.util.Calendar.getInstance();
		    calendar_tDBInput_6.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_6 = calendar_tDBInput_6.getTime();
		    int nb_line_tDBInput_6 = 0;
		    java.sql.Connection conn_tDBInput_6 = null;
				conn_tDBInput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_6 != null) {
					if(conn_tDBInput_6.getMetaData() != null) {
						
							log.debug("tDBInput_6 - Uses an existing connection with username '" + conn_tDBInput_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_6.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_6 = conn_tDBInput_6.createStatement();
				if(stmt_tDBInput_6 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_6).enableStreamingResults();
				}else if(stmt_tDBInput_6 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_6).enableStreamingResults();
				}

		    String dbquery_tDBInput_6 = "SELECT \n  `mst_category`.`id`, \n  `mst_category`.`name`, \n  `mst_category`.`created_by`, \n  `mst_category`.`created_on`"
+", \n  `mst_category`.`updated_by`, \n  `mst_category`.`updated_on`, \n  `mst_category`.`is_active`, \n  `mst_category`.`is_d"
+"eleted`, \n  `mst_category`.`category_id`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_category`";
		    
	    		log.debug("tDBInput_6 - Executing the query: '" + dbquery_tDBInput_6 + "'.");
			

            	globalMap.put("tDBInput_6_QUERY",dbquery_tDBInput_6);
		    java.sql.ResultSet rs_tDBInput_6 = null;

		    try {
		    	rs_tDBInput_6 = stmt_tDBInput_6.executeQuery(dbquery_tDBInput_6);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_6 = rs_tDBInput_6.getMetaData();
		    	int colQtyInRs_tDBInput_6 = rsmd_tDBInput_6.getColumnCount();

		    String tmpContent_tDBInput_6 = null;
		    
		    
		    	log.debug("tDBInput_6 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_6.next()) {
		        nb_line_tDBInput_6++;
		        
							if(colQtyInRs_tDBInput_6 < 1) {
								row6.id = 0;
							} else {
		                          
            row6.id = rs_tDBInput_6.getInt(1);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 2) {
								row6.name = null;
							} else {
	                         		
        	row6.name = routines.system.JDBCUtil.getString(rs_tDBInput_6, 2, false);
		                    }
							if(colQtyInRs_tDBInput_6 < 3) {
								row6.created_by = null;
							} else {
		                          
            row6.created_by = rs_tDBInput_6.getInt(3);
            if(rs_tDBInput_6.wasNull()){
                    row6.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 4) {
								row6.created_on = null;
							} else {
										
				if(rs_tDBInput_6.getString(4) != null) {
					String dateString_tDBInput_6 = rs_tDBInput_6.getString(4);
					if (!("0000-00-00").equals(dateString_tDBInput_6) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_6)) {
						row6.created_on = rs_tDBInput_6.getTimestamp(4);
					} else {
						row6.created_on = (java.util.Date) year0_tDBInput_6.clone();
					}
				} else {
					row6.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_6 < 5) {
								row6.updated_by = null;
							} else {
		                          
            row6.updated_by = rs_tDBInput_6.getInt(5);
            if(rs_tDBInput_6.wasNull()){
                    row6.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 6) {
								row6.updated_on = null;
							} else {
										
				if(rs_tDBInput_6.getString(6) != null) {
					String dateString_tDBInput_6 = rs_tDBInput_6.getString(6);
					if (!("0000-00-00").equals(dateString_tDBInput_6) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_6)) {
						row6.updated_on = rs_tDBInput_6.getTimestamp(6);
					} else {
						row6.updated_on = (java.util.Date) year0_tDBInput_6.clone();
					}
				} else {
					row6.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_6 < 7) {
								row6.is_active = 0;
							} else {
		                          
            row6.is_active = rs_tDBInput_6.getInt(7);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 8) {
								row6.is_deleted = 0;
							} else {
		                          
            row6.is_deleted = rs_tDBInput_6.getInt(8);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 9) {
								row6.category_id = null;
							} else {
	                         		
        	row6.category_id = routines.system.JDBCUtil.getString(rs_tDBInput_6, 9, false);
		                    }
							if(colQtyInRs_tDBInput_6 < 10) {
								row6.as_on = null;
							} else {
										
				if(rs_tDBInput_6.getString(10) != null) {
					String dateString_tDBInput_6 = rs_tDBInput_6.getString(10);
					if (!("0000-00-00").equals(dateString_tDBInput_6) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_6)) {
						row6.as_on = rs_tDBInput_6.getTimestamp(10);
					} else {
						row6.as_on = (java.util.Date) year0_tDBInput_6.clone();
					}
				} else {
					row6.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_6 - Retrieving the record " + nb_line_tDBInput_6 + ".");
					

 



/**
 * [tDBInput_6 begin ] stop
 */
	
	/**
	 * [tDBInput_6 main ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_category\"";
		

 


	tos_count_tDBInput_6++;

/**
 * [tDBInput_6 main ] stop
 */
	
	/**
	 * [tDBInput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_category\"";
		

 



/**
 * [tDBInput_6 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tDBInput_6","\"mst_category\"","tMysqlInput","tAsyncOut_tDBOutput_6","tAsyncOut_tDBOutput_6","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_6=new Object[]{null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_6[0] = String.valueOf(row6.id); 
	if(row6.name != null){
		row_tAsyncOut_tDBOutput_6[1] = row6.name;                			    
	}
	if(row6.created_by != null){
		row_tAsyncOut_tDBOutput_6[2] = String.valueOf(row6.created_by);                			    
	}
	if(row6.created_on != null){
		row_tAsyncOut_tDBOutput_6[3] = row6.created_on;                			    
	}
	if(row6.updated_by != null){
		row_tAsyncOut_tDBOutput_6[4] = String.valueOf(row6.updated_by);                			    
	}
	if(row6.updated_on != null){
		row_tAsyncOut_tDBOutput_6[5] = row6.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_6[6] = String.valueOf(row6.is_active); 
	row_tAsyncOut_tDBOutput_6[7] = String.valueOf(row6.is_deleted); 
	if(row6.category_id != null){
		row_tAsyncOut_tDBOutput_6[8] = row6.category_id;                			    
	}
	if(row6.as_on != null){
		row_tAsyncOut_tDBOutput_6[9] = row6.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_6 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_6", buffers_tAsyncOut_tDBOutput_6);
		/*tAsyncIn_tDBOutput_7Process(globalMap);*/
		tAsyncIn_tDBOutput_6Process(globalMap);
		buffers_tAsyncOut_tDBOutput_6 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_6 = 0;
	}
	buffers_tAsyncOut_tDBOutput_6.add(row_tAsyncOut_tDBOutput_6);
	index_tAsyncOut_tDBOutput_6++;
 


	tos_count_tAsyncOut_tDBOutput_6++;

/**
 * [tAsyncOut_tDBOutput_6 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	

 



/**
 * [tAsyncOut_tDBOutput_6 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	

 



/**
 * [tAsyncOut_tDBOutput_6 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_category\"";
		

 



/**
 * [tDBInput_6 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_6 end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_category\"";
		

	}
}finally{
	if (rs_tDBInput_6 != null) {
		rs_tDBInput_6.close();
	}
	if (stmt_tDBInput_6 != null) {
		stmt_tDBInput_6.close();
	}
}

		   globalMap.put("tDBInput_6_NB_LINE",nb_line_tDBInput_6);
		

	    		log.debug("tDBInput_6 - Retrieved records count: "+nb_line_tDBInput_6 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Done.") );

ok_Hash.put("tDBInput_6", true);
end_Hash.put("tDBInput_6", System.currentTimeMillis());




/**
 * [tDBInput_6 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	


	if (buffers_tAsyncOut_tDBOutput_6.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_6", buffers_tAsyncOut_tDBOutput_6);
	    tAsyncIn_tDBOutput_6Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_6.waitForEnd();
	pool_tAsyncOut_tDBOutput_6.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tDBInput_6","\"mst_category\"","tMysqlInput","tAsyncOut_tDBOutput_6","tAsyncOut_tDBOutput_6","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_6", true);
end_Hash.put("tAsyncOut_tDBOutput_6", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_6 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_category\"";
		

 



/**
 * [tDBInput_6 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	

 



/**
 * [tAsyncOut_tDBOutput_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String branch_name;

				public String getBranch_name () {
					return this.branch_name;
				}

				public Boolean branch_nameIsNullable(){
				    return false;
				}
				public Boolean branch_nameIsKey(){
				    return false;
				}
				public Integer branch_nameLength(){
				    return 45;
				}
				public Integer branch_namePrecision(){
				    return 0;
				}
				public String branch_nameDefault(){
				
					return null;
				
				}
				public String branch_nameComment(){
				
				    return "";
				
				}
				public String branch_namePattern(){
				
					return "";
				
				}
				public String branch_nameOriginalDbColumnName(){
				
					return "branch_name";
				
				}

				
			    public int branch_id;

				public int getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return false;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 10;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return null;
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public String center_name;

				public String getCenter_name () {
					return this.center_name;
				}

				public Boolean center_nameIsNullable(){
				    return false;
				}
				public Boolean center_nameIsKey(){
				    return false;
				}
				public Integer center_nameLength(){
				    return 60;
				}
				public Integer center_namePrecision(){
				    return 0;
				}
				public String center_nameDefault(){
				
					return null;
				
				}
				public String center_nameComment(){
				
				    return "";
				
				}
				public String center_namePattern(){
				
					return "";
				
				}
				public String center_nameOriginalDbColumnName(){
				
					return "center_name";
				
				}

				
			    public String wh_center_id;

				public String getWh_center_id () {
					return this.wh_center_id;
				}

				public Boolean wh_center_idIsNullable(){
				    return true;
				}
				public Boolean wh_center_idIsKey(){
				    return false;
				}
				public Integer wh_center_idLength(){
				    return 11;
				}
				public Integer wh_center_idPrecision(){
				    return 0;
				}
				public String wh_center_idDefault(){
				
					return "'0'::character varying'";
				
				}
				public String wh_center_idComment(){
				
				    return "";
				
				}
				public String wh_center_idPattern(){
				
					return "";
				
				}
				public String wh_center_idOriginalDbColumnName(){
				
					return "wh_center_id";
				
				}

				
			    public String meeting_day;

				public String getMeeting_day () {
					return this.meeting_day;
				}

				public Boolean meeting_dayIsNullable(){
				    return false;
				}
				public Boolean meeting_dayIsKey(){
				    return false;
				}
				public Integer meeting_dayLength(){
				    return 10;
				}
				public Integer meeting_dayPrecision(){
				    return 0;
				}
				public String meeting_dayDefault(){
				
					return null;
				
				}
				public String meeting_dayComment(){
				
				    return "";
				
				}
				public String meeting_dayPattern(){
				
					return "";
				
				}
				public String meeting_dayOriginalDbColumnName(){
				
					return "meeting_day";
				
				}

				
			    public String meeting_time_from;

				public String getMeeting_time_from () {
					return this.meeting_time_from;
				}

				public Boolean meeting_time_fromIsNullable(){
				    return true;
				}
				public Boolean meeting_time_fromIsKey(){
				    return false;
				}
				public Integer meeting_time_fromLength(){
				    return 10;
				}
				public Integer meeting_time_fromPrecision(){
				    return 0;
				}
				public String meeting_time_fromDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String meeting_time_fromComment(){
				
				    return "";
				
				}
				public String meeting_time_fromPattern(){
				
					return "";
				
				}
				public String meeting_time_fromOriginalDbColumnName(){
				
					return "meeting_time_from";
				
				}

				
			    public String meeting_time_to;

				public String getMeeting_time_to () {
					return this.meeting_time_to;
				}

				public Boolean meeting_time_toIsNullable(){
				    return true;
				}
				public Boolean meeting_time_toIsKey(){
				    return false;
				}
				public Integer meeting_time_toLength(){
				    return 10;
				}
				public Integer meeting_time_toPrecision(){
				    return 0;
				}
				public String meeting_time_toDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String meeting_time_toComment(){
				
				    return "";
				
				}
				public String meeting_time_toPattern(){
				
					return "";
				
				}
				public String meeting_time_toOriginalDbColumnName(){
				
					return "meeting_time_to";
				
				}

				
			    public String center_manager_id;

				public String getCenter_manager_id () {
					return this.center_manager_id;
				}

				public Boolean center_manager_idIsNullable(){
				    return true;
				}
				public Boolean center_manager_idIsKey(){
				    return false;
				}
				public Integer center_manager_idLength(){
				    return 10;
				}
				public Integer center_manager_idPrecision(){
				    return 0;
				}
				public String center_manager_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String center_manager_idComment(){
				
				    return "";
				
				}
				public String center_manager_idPattern(){
				
					return "";
				
				}
				public String center_manager_idOriginalDbColumnName(){
				
					return "center_manager_id";
				
				}

				
			    public String center_manager;

				public String getCenter_manager () {
					return this.center_manager;
				}

				public Boolean center_managerIsNullable(){
				    return true;
				}
				public Boolean center_managerIsKey(){
				    return false;
				}
				public Integer center_managerLength(){
				    return 45;
				}
				public Integer center_managerPrecision(){
				    return 0;
				}
				public String center_managerDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String center_managerComment(){
				
				    return "";
				
				}
				public String center_managerPattern(){
				
					return "";
				
				}
				public String center_managerOriginalDbColumnName(){
				
					return "center_manager";
				
				}

				
			    public Integer no_of_active_mem;

				public Integer getNo_of_active_mem () {
					return this.no_of_active_mem;
				}

				public Boolean no_of_active_memIsNullable(){
				    return true;
				}
				public Boolean no_of_active_memIsKey(){
				    return false;
				}
				public Integer no_of_active_memLength(){
				    return 10;
				}
				public Integer no_of_active_memPrecision(){
				    return 0;
				}
				public String no_of_active_memDefault(){
				
					return "0";
				
				}
				public String no_of_active_memComment(){
				
				    return "";
				
				}
				public String no_of_active_memPattern(){
				
					return "";
				
				}
				public String no_of_active_memOriginalDbColumnName(){
				
					return "no_of_active_mem";
				
				}

				
			    public Integer no_of_borrowers;

				public Integer getNo_of_borrowers () {
					return this.no_of_borrowers;
				}

				public Boolean no_of_borrowersIsNullable(){
				    return true;
				}
				public Boolean no_of_borrowersIsKey(){
				    return false;
				}
				public Integer no_of_borrowersLength(){
				    return 10;
				}
				public Integer no_of_borrowersPrecision(){
				    return 0;
				}
				public String no_of_borrowersDefault(){
				
					return "0";
				
				}
				public String no_of_borrowersComment(){
				
				    return "";
				
				}
				public String no_of_borrowersPattern(){
				
					return "";
				
				}
				public String no_of_borrowersOriginalDbColumnName(){
				
					return "no_of_borrowers";
				
				}

				
			    public Float principal_os;

				public Float getPrincipal_os () {
					return this.principal_os;
				}

				public Boolean principal_osIsNullable(){
				    return true;
				}
				public Boolean principal_osIsKey(){
				    return false;
				}
				public Integer principal_osLength(){
				    return 8;
				}
				public Integer principal_osPrecision(){
				    return 8;
				}
				public String principal_osDefault(){
				
					return "'0'::real";
				
				}
				public String principal_osComment(){
				
				    return "";
				
				}
				public String principal_osPattern(){
				
					return "";
				
				}
				public String principal_osOriginalDbColumnName(){
				
					return "principal_os";
				
				}

				
			    public Integer no_of_group;

				public Integer getNo_of_group () {
					return this.no_of_group;
				}

				public Boolean no_of_groupIsNullable(){
				    return true;
				}
				public Boolean no_of_groupIsKey(){
				    return false;
				}
				public Integer no_of_groupLength(){
				    return 10;
				}
				public Integer no_of_groupPrecision(){
				    return 0;
				}
				public String no_of_groupDefault(){
				
					return "0";
				
				}
				public String no_of_groupComment(){
				
				    return "";
				
				}
				public String no_of_groupPattern(){
				
					return "";
				
				}
				public String no_of_groupOriginalDbColumnName(){
				
					return "no_of_group";
				
				}

				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}

				public Boolean longitudeIsNullable(){
				    return true;
				}
				public Boolean longitudeIsKey(){
				    return false;
				}
				public Integer longitudeLength(){
				    return 45;
				}
				public Integer longitudePrecision(){
				    return 0;
				}
				public String longitudeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String longitudeComment(){
				
				    return "";
				
				}
				public String longitudePattern(){
				
					return "";
				
				}
				public String longitudeOriginalDbColumnName(){
				
					return "longitude";
				
				}

				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}

				public Boolean latitudeIsNullable(){
				    return true;
				}
				public Boolean latitudeIsKey(){
				    return false;
				}
				public Integer latitudeLength(){
				    return 45;
				}
				public Integer latitudePrecision(){
				    return 0;
				}
				public String latitudeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String latitudeComment(){
				
				    return "";
				
				}
				public String latitudePattern(){
				
					return "";
				
				}
				public String latitudeOriginalDbColumnName(){
				
					return "latitude";
				
				}

				
			    public String center_risk_level;

				public String getCenter_risk_level () {
					return this.center_risk_level;
				}

				public Boolean center_risk_levelIsNullable(){
				    return true;
				}
				public Boolean center_risk_levelIsKey(){
				    return false;
				}
				public Integer center_risk_levelLength(){
				    return 45;
				}
				public Integer center_risk_levelPrecision(){
				    return 0;
				}
				public String center_risk_levelDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String center_risk_levelComment(){
				
				    return "";
				
				}
				public String center_risk_levelPattern(){
				
					return "";
				
				}
				public String center_risk_levelOriginalDbColumnName(){
				
					return "center_risk_level";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return "0";
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return "0";
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String center_id;

				public String getCenter_id () {
					return this.center_id;
				}

				public Boolean center_idIsNullable(){
				    return true;
				}
				public Boolean center_idIsKey(){
				    return false;
				}
				public Integer center_idLength(){
				    return 32;
				}
				public Integer center_idPrecision(){
				    return 0;
				}
				public String center_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String center_idComment(){
				
				    return "";
				
				}
				public String center_idPattern(){
				
					return "";
				
				}
				public String center_idOriginalDbColumnName(){
				
					return "center_id";
				
				}

				
			    public java.util.Date audit_completed_date;

				public java.util.Date getAudit_completed_date () {
					return this.audit_completed_date;
				}

				public Boolean audit_completed_dateIsNullable(){
				    return true;
				}
				public Boolean audit_completed_dateIsKey(){
				    return false;
				}
				public Integer audit_completed_dateLength(){
				    return 13;
				}
				public Integer audit_completed_datePrecision(){
				    return 0;
				}
				public String audit_completed_dateDefault(){
				
					return null;
				
				}
				public String audit_completed_dateComment(){
				
				    return "";
				
				}
				public String audit_completed_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audit_completed_dateOriginalDbColumnName(){
				
					return "audit_completed_date";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row7Struct other = (row7Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row7Struct other) {

		other.id = this.id;
	            other.branch_name = this.branch_name;
	            other.branch_id = this.branch_id;
	            other.center_name = this.center_name;
	            other.wh_center_id = this.wh_center_id;
	            other.meeting_day = this.meeting_day;
	            other.meeting_time_from = this.meeting_time_from;
	            other.meeting_time_to = this.meeting_time_to;
	            other.center_manager_id = this.center_manager_id;
	            other.center_manager = this.center_manager;
	            other.no_of_active_mem = this.no_of_active_mem;
	            other.no_of_borrowers = this.no_of_borrowers;
	            other.principal_os = this.principal_os;
	            other.no_of_group = this.no_of_group;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.center_risk_level = this.center_risk_level;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.center_id = this.center_id;
	            other.audit_completed_date = this.audit_completed_date;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row7Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.branch_name = readString(dis);
					
			        this.branch_id = dis.readInt();
					
					this.center_name = readString(dis);
					
					this.wh_center_id = readString(dis);
					
					this.meeting_day = readString(dis);
					
					this.meeting_time_from = readString(dis);
					
					this.meeting_time_to = readString(dis);
					
					this.center_manager_id = readString(dis);
					
					this.center_manager = readString(dis);
					
						this.no_of_active_mem = readInteger(dis);
					
						this.no_of_borrowers = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.principal_os = null;
           				} else {
           			    	this.principal_os = dis.readFloat();
           				}
					
						this.no_of_group = readInteger(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
					this.center_risk_level = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.center_id = readString(dis);
					
					this.audit_completed_date = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.branch_name = readString(dis);
					
			        this.branch_id = dis.readInt();
					
					this.center_name = readString(dis);
					
					this.wh_center_id = readString(dis);
					
					this.meeting_day = readString(dis);
					
					this.meeting_time_from = readString(dis);
					
					this.meeting_time_to = readString(dis);
					
					this.center_manager_id = readString(dis);
					
					this.center_manager = readString(dis);
					
						this.no_of_active_mem = readInteger(dis);
					
						this.no_of_borrowers = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.principal_os = null;
           				} else {
           			    	this.principal_os = dis.readFloat();
           				}
					
						this.no_of_group = readInteger(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
					this.center_risk_level = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.center_id = readString(dis);
					
					this.audit_completed_date = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.branch_name,dos);
					
					// int
				
		            	dos.writeInt(this.branch_id);
					
					// String
				
						writeString(this.center_name,dos);
					
					// String
				
						writeString(this.wh_center_id,dos);
					
					// String
				
						writeString(this.meeting_day,dos);
					
					// String
				
						writeString(this.meeting_time_from,dos);
					
					// String
				
						writeString(this.meeting_time_to,dos);
					
					// String
				
						writeString(this.center_manager_id,dos);
					
					// String
				
						writeString(this.center_manager,dos);
					
					// Integer
				
						writeInteger(this.no_of_active_mem,dos);
					
					// Integer
				
						writeInteger(this.no_of_borrowers,dos);
					
					// Float
				
						if(this.principal_os == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.principal_os);
		            	}
					
					// Integer
				
						writeInteger(this.no_of_group,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// String
				
						writeString(this.center_risk_level,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.center_id,dos);
					
					// java.util.Date
				
						writeDate(this.audit_completed_date,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.branch_name,dos);
					
					// int
				
		            	dos.writeInt(this.branch_id);
					
					// String
				
						writeString(this.center_name,dos);
					
					// String
				
						writeString(this.wh_center_id,dos);
					
					// String
				
						writeString(this.meeting_day,dos);
					
					// String
				
						writeString(this.meeting_time_from,dos);
					
					// String
				
						writeString(this.meeting_time_to,dos);
					
					// String
				
						writeString(this.center_manager_id,dos);
					
					// String
				
						writeString(this.center_manager,dos);
					
					// Integer
				
						writeInteger(this.no_of_active_mem,dos);
					
					// Integer
				
						writeInteger(this.no_of_borrowers,dos);
					
					// Float
				
						if(this.principal_os == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.principal_os);
		            	}
					
					// Integer
				
						writeInteger(this.no_of_group,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// String
				
						writeString(this.center_risk_level,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.center_id,dos);
					
					// java.util.Date
				
						writeDate(this.audit_completed_date,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",branch_name="+branch_name);
		sb.append(",branch_id="+String.valueOf(branch_id));
		sb.append(",center_name="+center_name);
		sb.append(",wh_center_id="+wh_center_id);
		sb.append(",meeting_day="+meeting_day);
		sb.append(",meeting_time_from="+meeting_time_from);
		sb.append(",meeting_time_to="+meeting_time_to);
		sb.append(",center_manager_id="+center_manager_id);
		sb.append(",center_manager="+center_manager);
		sb.append(",no_of_active_mem="+String.valueOf(no_of_active_mem));
		sb.append(",no_of_borrowers="+String.valueOf(no_of_borrowers));
		sb.append(",principal_os="+String.valueOf(principal_os));
		sb.append(",no_of_group="+String.valueOf(no_of_group));
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",center_risk_level="+center_risk_level);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",center_id="+center_id);
		sb.append(",audit_completed_date="+String.valueOf(audit_completed_date));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(branch_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_name);
            			}
            		
        			sb.append("|");
        		
        				sb.append(branch_id);
        			
        			sb.append("|");
        		
        				if(center_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_name);
            			}
            		
        			sb.append("|");
        		
        				if(wh_center_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(wh_center_id);
            			}
            		
        			sb.append("|");
        		
        				if(meeting_day == null){
        					sb.append("<null>");
        				}else{
            				sb.append(meeting_day);
            			}
            		
        			sb.append("|");
        		
        				if(meeting_time_from == null){
        					sb.append("<null>");
        				}else{
            				sb.append(meeting_time_from);
            			}
            		
        			sb.append("|");
        		
        				if(meeting_time_to == null){
        					sb.append("<null>");
        				}else{
            				sb.append(meeting_time_to);
            			}
            		
        			sb.append("|");
        		
        				if(center_manager_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_manager_id);
            			}
            		
        			sb.append("|");
        		
        				if(center_manager == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_manager);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_active_mem == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_active_mem);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_borrowers == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_borrowers);
            			}
            		
        			sb.append("|");
        		
        				if(principal_os == null){
        					sb.append("<null>");
        				}else{
            				sb.append(principal_os);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_group == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_group);
            			}
            		
        			sb.append("|");
        		
        				if(longitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(longitude);
            			}
            		
        			sb.append("|");
        		
        				if(latitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(latitude);
            			}
            		
        			sb.append("|");
        		
        				if(center_risk_level == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_risk_level);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(center_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_id);
            			}
            		
        			sb.append("|");
        		
        				if(audit_completed_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_completed_date);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_7");
		org.slf4j.MDC.put("_subJobPid", "QcO1JV_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_7", false);
		start_Hash.put("tAsyncOut_tDBOutput_7", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tAsyncOut_tDBOutput_7 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_7", "tAsyncOut_tDBOutput_7", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_7 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_7 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_7 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_7=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_7 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_7", pool_tAsyncOut_tDBOutput_7);
	final Object[] lockWrite_tAsyncOut_tDBOutput_7 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_7", lockWrite_tAsyncOut_tDBOutput_7);
 



/**
 * [tAsyncOut_tDBOutput_7 begin ] stop
 */



	
	/**
	 * [tDBInput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_7", false);
		start_Hash.put("tDBInput_7", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_center\"";
		
		int tos_count_tDBInput_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_7 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_7{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_7 = new StringBuilder();
                    log4jParamters_tDBInput_7.append("Parameters:");
                            log4jParamters_tDBInput_7.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("TABLE" + " = " + "\"mst_center\"");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("QUERY" + " = " + "\"SELECT    `mst_center`.`id`,    `mst_center`.`branch_name`,    `mst_center`.`branch_id`,    `mst_center`.`center_name`,    `mst_center`.`wh_center_id`,    `mst_center`.`meeting_day`,    `mst_center`.`meeting_time_from`,    `mst_center`.`meeting_time_to`,    `mst_center`.`center_manager_id`,    `mst_center`.`center_manager`,    `mst_center`.`no_of_active_mem`,    `mst_center`.`no_of_borrowers`,    `mst_center`.`principal_os`,    `mst_center`.`no_of_group`,    `mst_center`.`longitude`,    `mst_center`.`latitude`,    `mst_center`.`center_risk_level`,    `mst_center`.`created_by`,    `mst_center`.`created_on`,    `mst_center`.`updated_by`,    `mst_center`.`updated_on`,    `mst_center`.`is_active`,    `mst_center`.`is_deleted`,    `mst_center`.`center_id`,    `mst_center`.`audit_completed_date`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_center`\"");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("center_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("wh_center_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("meeting_day")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("meeting_time_from")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("meeting_time_to")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("center_manager_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("center_manager")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("no_of_active_mem")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("no_of_borrowers")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("principal_os")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("no_of_group")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("longitude")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("latitude")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("center_risk_level")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("center_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audit_completed_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_7 - "  + (log4jParamters_tDBInput_7) );
                    } 
                } 
            new BytesLimit65535_tDBInput_7().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_7", "\"mst_center\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_7 = java.util.Calendar.getInstance();
		    calendar_tDBInput_7.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_7 = calendar_tDBInput_7.getTime();
		    int nb_line_tDBInput_7 = 0;
		    java.sql.Connection conn_tDBInput_7 = null;
				conn_tDBInput_7 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_7 != null) {
					if(conn_tDBInput_7.getMetaData() != null) {
						
							log.debug("tDBInput_7 - Uses an existing connection with username '" + conn_tDBInput_7.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_7.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_7 = conn_tDBInput_7.createStatement();
				if(stmt_tDBInput_7 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_7).enableStreamingResults();
				}else if(stmt_tDBInput_7 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_7).enableStreamingResults();
				}

		    String dbquery_tDBInput_7 = "SELECT \n  `mst_center`.`id`, \n  `mst_center`.`branch_name`, \n  `mst_center`.`branch_id`, \n  `mst_center`.`center_name`,"
+" \n  `mst_center`.`wh_center_id`, \n  `mst_center`.`meeting_day`, \n  `mst_center`.`meeting_time_from`, \n  `mst_center`.`me"
+"eting_time_to`, \n  `mst_center`.`center_manager_id`, \n  `mst_center`.`center_manager`, \n  `mst_center`.`no_of_active_mem"
+"`, \n  `mst_center`.`no_of_borrowers`, \n  `mst_center`.`principal_os`, \n  `mst_center`.`no_of_group`, \n  `mst_center`.`lo"
+"ngitude`, \n  `mst_center`.`latitude`, \n  `mst_center`.`center_risk_level`, \n  `mst_center`.`created_by`, \n  `mst_center`"
+".`created_on`, \n  `mst_center`.`updated_by`, \n  `mst_center`.`updated_on`, \n  `mst_center`.`is_active`, \n  `mst_center`."
+"`is_deleted`, \n  `mst_center`.`center_id`, \n  `mst_center`.`audit_completed_date`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVA"
+"L 1 DAY) AS `as_on`\nFROM `mst_center`";
		    
	    		log.debug("tDBInput_7 - Executing the query: '" + dbquery_tDBInput_7 + "'.");
			

            	globalMap.put("tDBInput_7_QUERY",dbquery_tDBInput_7);
		    java.sql.ResultSet rs_tDBInput_7 = null;

		    try {
		    	rs_tDBInput_7 = stmt_tDBInput_7.executeQuery(dbquery_tDBInput_7);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_7 = rs_tDBInput_7.getMetaData();
		    	int colQtyInRs_tDBInput_7 = rsmd_tDBInput_7.getColumnCount();

		    String tmpContent_tDBInput_7 = null;
		    
		    
		    	log.debug("tDBInput_7 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_7.next()) {
		        nb_line_tDBInput_7++;
		        
							if(colQtyInRs_tDBInput_7 < 1) {
								row7.id = 0;
							} else {
		                          
            row7.id = rs_tDBInput_7.getInt(1);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 2) {
								row7.branch_name = null;
							} else {
	                         		
        	row7.branch_name = routines.system.JDBCUtil.getString(rs_tDBInput_7, 2, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 3) {
								row7.branch_id = 0;
							} else {
		                          
            row7.branch_id = rs_tDBInput_7.getInt(3);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 4) {
								row7.center_name = null;
							} else {
	                         		
        	row7.center_name = routines.system.JDBCUtil.getString(rs_tDBInput_7, 4, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 5) {
								row7.wh_center_id = null;
							} else {
	                         		
        	row7.wh_center_id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 5, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 6) {
								row7.meeting_day = null;
							} else {
	                         		
        	row7.meeting_day = routines.system.JDBCUtil.getString(rs_tDBInput_7, 6, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 7) {
								row7.meeting_time_from = null;
							} else {
	                         		
        	row7.meeting_time_from = routines.system.JDBCUtil.getString(rs_tDBInput_7, 7, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 8) {
								row7.meeting_time_to = null;
							} else {
	                         		
        	row7.meeting_time_to = routines.system.JDBCUtil.getString(rs_tDBInput_7, 8, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 9) {
								row7.center_manager_id = null;
							} else {
	                         		
        	row7.center_manager_id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 9, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 10) {
								row7.center_manager = null;
							} else {
	                         		
        	row7.center_manager = routines.system.JDBCUtil.getString(rs_tDBInput_7, 10, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 11) {
								row7.no_of_active_mem = null;
							} else {
		                          
            row7.no_of_active_mem = rs_tDBInput_7.getInt(11);
            if(rs_tDBInput_7.wasNull()){
                    row7.no_of_active_mem = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 12) {
								row7.no_of_borrowers = null;
							} else {
		                          
            row7.no_of_borrowers = rs_tDBInput_7.getInt(12);
            if(rs_tDBInput_7.wasNull()){
                    row7.no_of_borrowers = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 13) {
								row7.principal_os = null;
							} else {
		                          
            row7.principal_os = rs_tDBInput_7.getFloat(13);
            if(rs_tDBInput_7.wasNull()){
                    row7.principal_os = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 14) {
								row7.no_of_group = null;
							} else {
		                          
            row7.no_of_group = rs_tDBInput_7.getInt(14);
            if(rs_tDBInput_7.wasNull()){
                    row7.no_of_group = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 15) {
								row7.longitude = null;
							} else {
	                         		
        	row7.longitude = routines.system.JDBCUtil.getString(rs_tDBInput_7, 15, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 16) {
								row7.latitude = null;
							} else {
	                         		
        	row7.latitude = routines.system.JDBCUtil.getString(rs_tDBInput_7, 16, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 17) {
								row7.center_risk_level = null;
							} else {
	                         		
        	row7.center_risk_level = routines.system.JDBCUtil.getString(rs_tDBInput_7, 17, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 18) {
								row7.created_by = null;
							} else {
		                          
            row7.created_by = rs_tDBInput_7.getInt(18);
            if(rs_tDBInput_7.wasNull()){
                    row7.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 19) {
								row7.created_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(19) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(19);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row7.created_on = rs_tDBInput_7.getTimestamp(19);
					} else {
						row7.created_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row7.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_7 < 20) {
								row7.updated_by = null;
							} else {
		                          
            row7.updated_by = rs_tDBInput_7.getInt(20);
            if(rs_tDBInput_7.wasNull()){
                    row7.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 21) {
								row7.updated_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(21) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(21);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row7.updated_on = rs_tDBInput_7.getTimestamp(21);
					} else {
						row7.updated_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row7.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_7 < 22) {
								row7.is_active = 0;
							} else {
		                          
            row7.is_active = rs_tDBInput_7.getInt(22);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 23) {
								row7.is_deleted = 0;
							} else {
		                          
            row7.is_deleted = rs_tDBInput_7.getInt(23);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 24) {
								row7.center_id = null;
							} else {
	                         		
        	row7.center_id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 24, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 25) {
								row7.audit_completed_date = null;
							} else {
										
				if(rs_tDBInput_7.getString(25) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(25);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row7.audit_completed_date = rs_tDBInput_7.getTimestamp(25);
					} else {
						row7.audit_completed_date = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row7.audit_completed_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_7 < 26) {
								row7.as_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(26) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(26);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row7.as_on = rs_tDBInput_7.getTimestamp(26);
					} else {
						row7.as_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row7.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_7 - Retrieving the record " + nb_line_tDBInput_7 + ".");
					

 



/**
 * [tDBInput_7 begin ] stop
 */
	
	/**
	 * [tDBInput_7 main ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_center\"";
		

 


	tos_count_tDBInput_7++;

/**
 * [tDBInput_7 main ] stop
 */
	
	/**
	 * [tDBInput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_center\"";
		

 



/**
 * [tDBInput_7 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_7 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row7","tDBInput_7","\"mst_center\"","tMysqlInput","tAsyncOut_tDBOutput_7","tAsyncOut_tDBOutput_7","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_7=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_7[0] = String.valueOf(row7.id); 
	if(row7.branch_name != null){
		row_tAsyncOut_tDBOutput_7[1] = row7.branch_name;                			    
	}
	row_tAsyncOut_tDBOutput_7[2] = String.valueOf(row7.branch_id); 
	if(row7.center_name != null){
		row_tAsyncOut_tDBOutput_7[3] = row7.center_name;                			    
	}
	if(row7.wh_center_id != null){
		row_tAsyncOut_tDBOutput_7[4] = row7.wh_center_id;                			    
	}
	if(row7.meeting_day != null){
		row_tAsyncOut_tDBOutput_7[5] = row7.meeting_day;                			    
	}
	if(row7.meeting_time_from != null){
		row_tAsyncOut_tDBOutput_7[6] = row7.meeting_time_from;                			    
	}
	if(row7.meeting_time_to != null){
		row_tAsyncOut_tDBOutput_7[7] = row7.meeting_time_to;                			    
	}
	if(row7.center_manager_id != null){
		row_tAsyncOut_tDBOutput_7[8] = row7.center_manager_id;                			    
	}
	if(row7.center_manager != null){
		row_tAsyncOut_tDBOutput_7[9] = row7.center_manager;                			    
	}
	if(row7.no_of_active_mem != null){
		row_tAsyncOut_tDBOutput_7[10] = String.valueOf(row7.no_of_active_mem);                			    
	}
	if(row7.no_of_borrowers != null){
		row_tAsyncOut_tDBOutput_7[11] = String.valueOf(row7.no_of_borrowers);                			    
	}
	if(row7.principal_os != null){
		row_tAsyncOut_tDBOutput_7[12] = String.valueOf(row7.principal_os);                			    
	}
	if(row7.no_of_group != null){
		row_tAsyncOut_tDBOutput_7[13] = String.valueOf(row7.no_of_group);                			    
	}
	if(row7.longitude != null){
		row_tAsyncOut_tDBOutput_7[14] = row7.longitude;                			    
	}
	if(row7.latitude != null){
		row_tAsyncOut_tDBOutput_7[15] = row7.latitude;                			    
	}
	if(row7.center_risk_level != null){
		row_tAsyncOut_tDBOutput_7[16] = row7.center_risk_level;                			    
	}
	if(row7.created_by != null){
		row_tAsyncOut_tDBOutput_7[17] = String.valueOf(row7.created_by);                			    
	}
	if(row7.created_on != null){
		row_tAsyncOut_tDBOutput_7[18] = row7.created_on;                			    
	}
	if(row7.updated_by != null){
		row_tAsyncOut_tDBOutput_7[19] = String.valueOf(row7.updated_by);                			    
	}
	if(row7.updated_on != null){
		row_tAsyncOut_tDBOutput_7[20] = row7.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_7[21] = String.valueOf(row7.is_active); 
	row_tAsyncOut_tDBOutput_7[22] = String.valueOf(row7.is_deleted); 
	if(row7.center_id != null){
		row_tAsyncOut_tDBOutput_7[23] = row7.center_id;                			    
	}
	if(row7.audit_completed_date != null){
		row_tAsyncOut_tDBOutput_7[24] = row7.audit_completed_date;                			    
	}
	if(row7.as_on != null){
		row_tAsyncOut_tDBOutput_7[25] = row7.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_7 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_7", buffers_tAsyncOut_tDBOutput_7);
		/*tAsyncIn_tDBOutput_7Process(globalMap);*/
		tAsyncIn_tDBOutput_7Process(globalMap);
		buffers_tAsyncOut_tDBOutput_7 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_7 = 0;
	}
	buffers_tAsyncOut_tDBOutput_7.add(row_tAsyncOut_tDBOutput_7);
	index_tAsyncOut_tDBOutput_7++;
 


	tos_count_tAsyncOut_tDBOutput_7++;

/**
 * [tAsyncOut_tDBOutput_7 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	

 



/**
 * [tAsyncOut_tDBOutput_7 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	

 



/**
 * [tAsyncOut_tDBOutput_7 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_center\"";
		

 



/**
 * [tDBInput_7 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_7 end ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_center\"";
		

	}
}finally{
	if (rs_tDBInput_7 != null) {
		rs_tDBInput_7.close();
	}
	if (stmt_tDBInput_7 != null) {
		stmt_tDBInput_7.close();
	}
}

		   globalMap.put("tDBInput_7_NB_LINE",nb_line_tDBInput_7);
		

	    		log.debug("tDBInput_7 - Retrieved records count: "+nb_line_tDBInput_7 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_7 - "  + ("Done.") );

ok_Hash.put("tDBInput_7", true);
end_Hash.put("tDBInput_7", System.currentTimeMillis());




/**
 * [tDBInput_7 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_7 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	


	if (buffers_tAsyncOut_tDBOutput_7.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_7", buffers_tAsyncOut_tDBOutput_7);
	    tAsyncIn_tDBOutput_7Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_7.waitForEnd();
	pool_tAsyncOut_tDBOutput_7.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			"tDBInput_7","\"mst_center\"","tMysqlInput","tAsyncOut_tDBOutput_7","tAsyncOut_tDBOutput_7","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_7", true);
end_Hash.put("tAsyncOut_tDBOutput_7", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_7 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_7 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_center\"";
		

 



/**
 * [tDBInput_7 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_7 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	

 



/**
 * [tAsyncOut_tDBOutput_7 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_7_SUBPROCESS_STATE", 1);
	}
	


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "oOH2Gj_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "4P2AVn_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"115.124.105.62\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"3306\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"chaitanya_audit\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"chaitanya_auditprd\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:KVi+i9s3rUEBfD7cUoRO1MolNq2sNmO1IC25DXvIjpAWDxBd").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "Audit_source", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + "115.124.105.62" + ":" + "3306" + "/" + "chaitanya_audit" + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = "chaitanya_auditprd";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:w7Mxoqj5te/RHg/NGD8UlfD1b5N+dGY3F1gh4EvIbSimdI6U");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1","chaitanya_audit");
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_2");
		org.slf4j.MDC.put("_subJobPid", "tfgita_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "\"audit_dwh\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "\"audit_user\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:hMwR5HduSEe/KA+HFrahm7gaaoALBrtGUzQaZo5IRqtRTh7UgVSb").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_2", "Audit_target", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_2 = "";
            String url_tDBConnection_2 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"audit_dwh";
            
            if(dbProperties_tDBConnection_2 != null && !"".equals(dbProperties_tDBConnection_2.trim())) {
                url_tDBConnection_2 = url_tDBConnection_2 + "?" + dbProperties_tDBConnection_2;
            }
	String dbUser_tDBConnection_2 = "audit_user";
	
	
		 
	final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:mjvLJ0vI9xKTFh/+MfxCMnuvT9ru8nC7eET8uIzVmi2QLqBOIrv+");
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_2 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_2 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_2.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_2 = drivers_tDBConnection_2.nextElement();
        if (redShiftDriverNames_tDBConnection_2.contains(d_tDBConnection_2.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_2);
                java.sql.DriverManager.registerDriver(d_tDBConnection_2);
            } catch (java.lang.Exception e_tDBConnection_2) {
globalMap.put("tDBConnection_2_ERROR_MESSAGE",e_tDBConnection_2.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_2 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_2","");

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "8dcqyF_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", "6shpoE_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMysqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
		
	    		log.debug("tDBClose_1 - Closing the connection 'tDBConnection_1' to the database.");
			
			conn_tDBClose_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	    		log.debug("tDBClose_1 - Connection 'tDBConnection_1' to the database closed.");
			
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_2Process(globalMap);



/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_2");
		org.slf4j.MDC.put("_subJobPid", "T5vJCi_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_2", false);
		start_Hash.put("tDBClose_2", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_2";
	
	
		int tos_count_tDBClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_2 = new StringBuilder();
                    log4jParamters_tDBClose_2.append("Parameters:");
                            log4jParamters_tDBClose_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBClose_2.append(" | ");
                            log4jParamters_tDBClose_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + (log4jParamters_tDBClose_2) );
                    } 
                } 
            new BytesLimit65535_tDBClose_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_2", "tDBClose_2", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_2 begin ] stop
 */
	
	/**
	 * [tDBClose_2 main ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	



	java.sql.Connection conn_tDBClose_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	if(conn_tDBClose_2 != null && !conn_tDBClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Closing the connection ")  + ("conn_tDBConnection_2")  + (" to the database.") );
        conn_tDBClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Connection ")  + ("conn_tDBConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_2++;

/**
 * [tDBClose_2 main ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_2 end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Done.") );

ok_Hash.put("tDBClose_2", true);
end_Hash.put("tDBClose_2", System.currentTimeMillis());




/**
 * [tDBClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_2 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_2_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row1Struct implements routines.system.IPersistableRow<pRow_row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public int audit_plan_id;

				public int getAudit_plan_id () {
					return this.audit_plan_id;
				}

				public Boolean audit_plan_idIsNullable(){
				    return false;
				}
				public Boolean audit_plan_idIsKey(){
				    return false;
				}
				public Integer audit_plan_idLength(){
				    return 10;
				}
				public Integer audit_plan_idPrecision(){
				    return 0;
				}
				public String audit_plan_idDefault(){
				
					return null;
				
				}
				public String audit_plan_idComment(){
				
				    return "";
				
				}
				public String audit_plan_idPattern(){
				
					return "";
				
				}
				public String audit_plan_idOriginalDbColumnName(){
				
					return "audit_plan_id";
				
				}

				
			    public Integer total_questions;

				public Integer getTotal_questions () {
					return this.total_questions;
				}

				public Boolean total_questionsIsNullable(){
				    return true;
				}
				public Boolean total_questionsIsKey(){
				    return false;
				}
				public Integer total_questionsLength(){
				    return 10;
				}
				public Integer total_questionsPrecision(){
				    return 0;
				}
				public String total_questionsDefault(){
				
					return null;
				
				}
				public String total_questionsComment(){
				
				    return "";
				
				}
				public String total_questionsPattern(){
				
					return "";
				
				}
				public String total_questionsOriginalDbColumnName(){
				
					return "total_questions";
				
				}

				
			    public Integer total_process;

				public Integer getTotal_process () {
					return this.total_process;
				}

				public Boolean total_processIsNullable(){
				    return true;
				}
				public Boolean total_processIsKey(){
				    return false;
				}
				public Integer total_processLength(){
				    return 10;
				}
				public Integer total_processPrecision(){
				    return 0;
				}
				public String total_processDefault(){
				
					return null;
				
				}
				public String total_processComment(){
				
				    return "";
				
				}
				public String total_processPattern(){
				
					return "";
				
				}
				public String total_processOriginalDbColumnName(){
				
					return "total_process";
				
				}

				
			    public Integer is_partial;

				public Integer getIs_partial () {
					return this.is_partial;
				}

				public Boolean is_partialIsNullable(){
				    return true;
				}
				public Boolean is_partialIsKey(){
				    return false;
				}
				public Integer is_partialLength(){
				    return 10;
				}
				public Integer is_partialPrecision(){
				    return 0;
				}
				public String is_partialDefault(){
				
					return null;
				
				}
				public String is_partialComment(){
				
				    return "";
				
				}
				public String is_partialPattern(){
				
					return "";
				
				}
				public String is_partialOriginalDbColumnName(){
				
					return "is_partial";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return true;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row1Struct other = (pRow_row1Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row1Struct other) {

		other.id = this.id;
	            other.audit_plan_id = this.audit_plan_id;
	            other.total_questions = this.total_questions;
	            other.total_process = this.total_process;
	            other.is_partial = this.is_partial;
	            other.created_on = this.created_on;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row1Struct other) {

		other.id = this.id;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
			        this.audit_plan_id = dis.readInt();
					
						this.total_questions = readInteger(dis);
					
						this.total_process = readInteger(dis);
					
						this.is_partial = readInteger(dis);
					
					this.created_on = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
			        this.audit_plan_id = dis.readInt();
					
						this.total_questions = readInteger(dis);
					
						this.total_process = readInteger(dis);
					
						this.is_partial = readInteger(dis);
					
					this.created_on = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// int
				
		            	dos.writeInt(this.audit_plan_id);
					
					// Integer
				
						writeInteger(this.total_questions,dos);
					
					// Integer
				
						writeInteger(this.total_process,dos);
					
					// Integer
				
						writeInteger(this.is_partial,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// int
				
		            	dos.writeInt(this.audit_plan_id);
					
					// Integer
				
						writeInteger(this.total_questions,dos);
					
					// Integer
				
						writeInteger(this.total_process,dos);
					
					// Integer
				
						writeInteger(this.is_partial,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",audit_plan_id="+String.valueOf(audit_plan_id));
		sb.append(",total_questions="+String.valueOf(total_questions));
		sb.append(",total_process="+String.valueOf(total_process));
		sb.append(",is_partial="+String.valueOf(is_partial));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				sb.append(audit_plan_id);
        			
        			sb.append("|");
        		
        				if(total_questions == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_questions);
            			}
            		
        			sb.append("|");
        		
        				if(total_process == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_process);
            			}
            		
        			sb.append("|");
        		
        				if(is_partial == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_partial);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_1");
		org.slf4j.MDC.put("_subJobPid", "S8lT86_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_1");
		class tAsyncIn_tDBOutput_1_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_1_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row1Struct pRow_row1 = new pRow_row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_details_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row1");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"audit_details_dw\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "\"audit_details_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("audit_details_dw");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("audit_details_dw");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
        java.lang.StringBuilder sb_tDBOutput_1 = new java.lang.StringBuilder();
        sb_tDBOutput_1.append("INSERT INTO \"").append(tableName_tDBOutput_1).append("\" (\"id\",\"audit_plan_id\",\"total_questions\",\"total_process\",\"is_partial\",\"created_on\",\"as_on\") VALUES (?,?,?,?,?,?,?)");


            sb_tDBOutput_1.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"audit_plan_id\" = EXCLUDED.\"audit_plan_id\",\"total_questions\" = EXCLUDED.\"total_questions\",\"total_process\" = EXCLUDED.\"total_process\",\"is_partial\" = EXCLUDED.\"is_partial\",\"created_on\" = EXCLUDED.\"created_on\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_1 = sb_tDBOutput_1.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing '")  + (insert_tDBOutput_1)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_1", false);
		start_Hash.put("tAsyncIn_tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	
		int tos_count_tAsyncIn_tDBOutput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_1", "tAsyncIn_tDBOutput_1", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_1= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_1 = buffers_tAsyncIn_tDBOutput_1.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_1 != null && buffers_tAsyncIn_tDBOutput_1.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_1 : buffers_tAsyncIn_tDBOutput_1) {
    		pRow_row1 = null;						
			pRow_row1 = new pRow_row1Struct();
		
		
			String temp_tAsyncIn_tDBOutput_1_0 = row_tAsyncIn_tDBOutput_1[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[0]);
			if(temp_tAsyncIn_tDBOutput_1_0 != null) {
		
			pRow_row1.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_1_0);
		} else {						
			pRow_row1.id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_1 = row_tAsyncIn_tDBOutput_1[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[1]);
			if(temp_tAsyncIn_tDBOutput_1_1 != null) {
		
			pRow_row1.audit_plan_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_1_1);
		} else {						
			pRow_row1.audit_plan_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_2 = row_tAsyncIn_tDBOutput_1[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[2]);
			if(temp_tAsyncIn_tDBOutput_1_2 != null) {
		
			pRow_row1.total_questions = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_2);
		} else {						
			pRow_row1.total_questions = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_3 = row_tAsyncIn_tDBOutput_1[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[3]);
			if(temp_tAsyncIn_tDBOutput_1_3 != null) {
		
			pRow_row1.total_process = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_3);
		} else {						
			pRow_row1.total_process = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_4 = row_tAsyncIn_tDBOutput_1[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[4]);
			if(temp_tAsyncIn_tDBOutput_1_4 != null) {
		
			pRow_row1.is_partial = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_4);
		} else {						
			pRow_row1.is_partial = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_5 = row_tAsyncIn_tDBOutput_1[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[5]);
			if(temp_tAsyncIn_tDBOutput_1_5 != null) {
		
			pRow_row1.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_1[5]);
		} else {						
			pRow_row1.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_6 = row_tAsyncIn_tDBOutput_1[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[6]);
			if(temp_tAsyncIn_tDBOutput_1_6 != null) {
		
			pRow_row1.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_1[6]);
		} else {						
			pRow_row1.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_1 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

 


	tos_count_tAsyncIn_tDBOutput_1++;

/**
 * [tAsyncIn_tDBOutput_1 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

 



/**
 * [tAsyncIn_tDBOutput_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_details_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row1","tAsyncIn_tDBOutput_1","tAsyncIn_tDBOutput_1","tAsyncIn","tDBOutput_1","\"audit_details_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row1 - " + (pRow_row1==null? "": pRow_row1.toLogString()));
    			}
    		



				batchSize_tDBOutput_1 = buffersSize_tAsyncIn_tDBOutput_1;
        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, pRow_row1.id);

                    pstmt_tDBOutput_1.setInt(2, pRow_row1.audit_plan_id);

                    if(pRow_row1.total_questions == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(3, pRow_row1.total_questions);
}

                    if(pRow_row1.total_process == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(4, pRow_row1.total_process);
}

                    if(pRow_row1.is_partial == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(5, pRow_row1.is_partial);
}

                    if(pRow_row1.created_on != null) {
pstmt_tDBOutput_1.setTimestamp(6, new java.sql.Timestamp(pRow_row1.created_on.getTime()));
} else {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.as_on != null) {
pstmt_tDBOutput_1.setTimestamp(7, new java.sql.Timestamp(pRow_row1.as_on.getTime()));
} else {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Adding the record ")  + (nb_line_tDBOutput_1)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_details_dw\"";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_details_dw\"";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

 



/**
 * [tAsyncIn_tDBOutput_1 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_1.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_1", true);
end_Hash.put("tAsyncIn_tDBOutput_1", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_details_dw\"";
		



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
    	if (globalMap.get("tDBOutput_1_NB_LINE") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE",(Integer)globalMap.get("tDBOutput_1_NB_LINE") + nb_line_tDBOutput_1);
        }
        if (globalMap.get("tDBOutput_1_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_1_NB_LINE_UPDATED") + nb_line_update_tDBOutput_1);
        }
        if (globalMap.get("tDBOutput_1_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_1_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_1);
        }
        if (globalMap.get("tDBOutput_1_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_1_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_1);
        }
        if (globalMap.get("tDBOutput_1_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_1_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_1);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row1",2,0,
			 			"tAsyncIn_tDBOutput_1","tAsyncIn_tDBOutput_1","tAsyncIn","tDBOutput_1","\"audit_details_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

 



/**
 * [tAsyncIn_tDBOutput_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_details_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_1");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_1_ParallelThread pt = new tAsyncIn_tDBOutput_1_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_1"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_1_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row2Struct implements routines.system.IPersistableRow<pRow_row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String division;

				public String getDivision () {
					return this.division;
				}

				public Boolean divisionIsNullable(){
				    return true;
				}
				public Boolean divisionIsKey(){
				    return false;
				}
				public Integer divisionLength(){
				    return 100;
				}
				public Integer divisionPrecision(){
				    return 0;
				}
				public String divisionDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String divisionComment(){
				
				    return "";
				
				}
				public String divisionPattern(){
				
					return "";
				
				}
				public String divisionOriginalDbColumnName(){
				
					return "division";
				
				}

				
			    public String area;

				public String getArea () {
					return this.area;
				}

				public Boolean areaIsNullable(){
				    return true;
				}
				public Boolean areaIsKey(){
				    return false;
				}
				public Integer areaLength(){
				    return 100;
				}
				public Integer areaPrecision(){
				    return 0;
				}
				public String areaDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String areaComment(){
				
				    return "";
				
				}
				public String areaPattern(){
				
					return "";
				
				}
				public String areaOriginalDbColumnName(){
				
					return "area";
				
				}

				
			    public int branch_id;

				public int getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return false;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 10;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return null;
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public String branch;

				public String getBranch () {
					return this.branch;
				}

				public Boolean branchIsNullable(){
				    return true;
				}
				public Boolean branchIsKey(){
				    return false;
				}
				public Integer branchLength(){
				    return 100;
				}
				public Integer branchPrecision(){
				    return 0;
				}
				public String branchDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branchComment(){
				
				    return "";
				
				}
				public String branchPattern(){
				
					return "";
				
				}
				public String branchOriginalDbColumnName(){
				
					return "branch";
				
				}

				
			    public Integer month_audit_cycle;

				public Integer getMonth_audit_cycle () {
					return this.month_audit_cycle;
				}

				public Boolean month_audit_cycleIsNullable(){
				    return true;
				}
				public Boolean month_audit_cycleIsKey(){
				    return false;
				}
				public Integer month_audit_cycleLength(){
				    return 10;
				}
				public Integer month_audit_cyclePrecision(){
				    return 0;
				}
				public String month_audit_cycleDefault(){
				
					return null;
				
				}
				public String month_audit_cycleComment(){
				
				    return "";
				
				}
				public String month_audit_cyclePattern(){
				
					return "";
				
				}
				public String month_audit_cycleOriginalDbColumnName(){
				
					return "month_audit_cycle";
				
				}

				
			    public Integer year;

				public Integer getYear () {
					return this.year;
				}

				public Boolean yearIsNullable(){
				    return true;
				}
				public Boolean yearIsKey(){
				    return false;
				}
				public Integer yearLength(){
				    return 10;
				}
				public Integer yearPrecision(){
				    return 0;
				}
				public String yearDefault(){
				
					return null;
				
				}
				public String yearComment(){
				
				    return "";
				
				}
				public String yearPattern(){
				
					return "";
				
				}
				public String yearOriginalDbColumnName(){
				
					return "year";
				
				}

				
			    public Integer audit_no;

				public Integer getAudit_no () {
					return this.audit_no;
				}

				public Boolean audit_noIsNullable(){
				    return true;
				}
				public Boolean audit_noIsKey(){
				    return false;
				}
				public Integer audit_noLength(){
				    return 10;
				}
				public Integer audit_noPrecision(){
				    return 0;
				}
				public String audit_noDefault(){
				
					return null;
				
				}
				public String audit_noComment(){
				
				    return "";
				
				}
				public String audit_noPattern(){
				
					return "";
				
				}
				public String audit_noOriginalDbColumnName(){
				
					return "audit_no";
				
				}

				
			    public java.util.Date audited_from_date;

				public java.util.Date getAudited_from_date () {
					return this.audited_from_date;
				}

				public Boolean audited_from_dateIsNullable(){
				    return true;
				}
				public Boolean audited_from_dateIsKey(){
				    return false;
				}
				public Integer audited_from_dateLength(){
				    return 13;
				}
				public Integer audited_from_datePrecision(){
				    return 0;
				}
				public String audited_from_dateDefault(){
				
					return null;
				
				}
				public String audited_from_dateComment(){
				
				    return "";
				
				}
				public String audited_from_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audited_from_dateOriginalDbColumnName(){
				
					return "audited_from_date";
				
				}

				
			    public java.util.Date audited_to_date;

				public java.util.Date getAudited_to_date () {
					return this.audited_to_date;
				}

				public Boolean audited_to_dateIsNullable(){
				    return true;
				}
				public Boolean audited_to_dateIsKey(){
				    return false;
				}
				public Integer audited_to_dateLength(){
				    return 13;
				}
				public Integer audited_to_datePrecision(){
				    return 0;
				}
				public String audited_to_dateDefault(){
				
					return null;
				
				}
				public String audited_to_dateComment(){
				
				    return "";
				
				}
				public String audited_to_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audited_to_dateOriginalDbColumnName(){
				
					return "audited_to_date";
				
				}

				
			    public int auditor_id;

				public int getAuditor_id () {
					return this.auditor_id;
				}

				public Boolean auditor_idIsNullable(){
				    return false;
				}
				public Boolean auditor_idIsKey(){
				    return false;
				}
				public Integer auditor_idLength(){
				    return 10;
				}
				public Integer auditor_idPrecision(){
				    return 0;
				}
				public String auditor_idDefault(){
				
					return null;
				
				}
				public String auditor_idComment(){
				
				    return "";
				
				}
				public String auditor_idPattern(){
				
					return "";
				
				}
				public String auditor_idOriginalDbColumnName(){
				
					return "auditor_id";
				
				}

				
			    public String auditor;

				public String getAuditor () {
					return this.auditor;
				}

				public Boolean auditorIsNullable(){
				    return true;
				}
				public Boolean auditorIsKey(){
				    return false;
				}
				public Integer auditorLength(){
				    return 145;
				}
				public Integer auditorPrecision(){
				    return 0;
				}
				public String auditorDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String auditorComment(){
				
				    return "";
				
				}
				public String auditorPattern(){
				
					return "";
				
				}
				public String auditorOriginalDbColumnName(){
				
					return "auditor";
				
				}

				
			    public int audit_plan_id;

				public int getAudit_plan_id () {
					return this.audit_plan_id;
				}

				public Boolean audit_plan_idIsNullable(){
				    return false;
				}
				public Boolean audit_plan_idIsKey(){
				    return false;
				}
				public Integer audit_plan_idLength(){
				    return 10;
				}
				public Integer audit_plan_idPrecision(){
				    return 0;
				}
				public String audit_plan_idDefault(){
				
					return null;
				
				}
				public String audit_plan_idComment(){
				
				    return "";
				
				}
				public String audit_plan_idPattern(){
				
					return "";
				
				}
				public String audit_plan_idOriginalDbColumnName(){
				
					return "audit_plan_id";
				
				}

				
			    public Integer noofcenter_attended_by_auditor;

				public Integer getNoofcenter_attended_by_auditor () {
					return this.noofcenter_attended_by_auditor;
				}

				public Boolean noofcenter_attended_by_auditorIsNullable(){
				    return true;
				}
				public Boolean noofcenter_attended_by_auditorIsKey(){
				    return false;
				}
				public Integer noofcenter_attended_by_auditorLength(){
				    return 10;
				}
				public Integer noofcenter_attended_by_auditorPrecision(){
				    return 0;
				}
				public String noofcenter_attended_by_auditorDefault(){
				
					return "0";
				
				}
				public String noofcenter_attended_by_auditorComment(){
				
				    return "";
				
				}
				public String noofcenter_attended_by_auditorPattern(){
				
					return "";
				
				}
				public String noofcenter_attended_by_auditorOriginalDbColumnName(){
				
					return "noofcenter_attended_by_auditor";
				
				}

				
			    public Integer no_of_luc_done_by_auditor;

				public Integer getNo_of_luc_done_by_auditor () {
					return this.no_of_luc_done_by_auditor;
				}

				public Boolean no_of_luc_done_by_auditorIsNullable(){
				    return true;
				}
				public Boolean no_of_luc_done_by_auditorIsKey(){
				    return false;
				}
				public Integer no_of_luc_done_by_auditorLength(){
				    return 10;
				}
				public Integer no_of_luc_done_by_auditorPrecision(){
				    return 0;
				}
				public String no_of_luc_done_by_auditorDefault(){
				
					return "0";
				
				}
				public String no_of_luc_done_by_auditorComment(){
				
				    return "";
				
				}
				public String no_of_luc_done_by_auditorPattern(){
				
					return "";
				
				}
				public String no_of_luc_done_by_auditorOriginalDbColumnName(){
				
					return "no_of_luc_done_by_auditor";
				
				}

				
			    public Integer no_of_cre;

				public Integer getNo_of_cre () {
					return this.no_of_cre;
				}

				public Boolean no_of_creIsNullable(){
				    return true;
				}
				public Boolean no_of_creIsKey(){
				    return false;
				}
				public Integer no_of_creLength(){
				    return 10;
				}
				public Integer no_of_crePrecision(){
				    return 0;
				}
				public String no_of_creDefault(){
				
					return "0";
				
				}
				public String no_of_creComment(){
				
				    return "";
				
				}
				public String no_of_crePattern(){
				
					return "";
				
				}
				public String no_of_creOriginalDbColumnName(){
				
					return "no_of_cre";
				
				}

				
			    public Integer total_no_of_center;

				public Integer getTotal_no_of_center () {
					return this.total_no_of_center;
				}

				public Boolean total_no_of_centerIsNullable(){
				    return true;
				}
				public Boolean total_no_of_centerIsKey(){
				    return false;
				}
				public Integer total_no_of_centerLength(){
				    return 10;
				}
				public Integer total_no_of_centerPrecision(){
				    return 0;
				}
				public String total_no_of_centerDefault(){
				
					return "0";
				
				}
				public String total_no_of_centerComment(){
				
				    return "";
				
				}
				public String total_no_of_centerPattern(){
				
					return "";
				
				}
				public String total_no_of_centerOriginalDbColumnName(){
				
					return "total_no_of_center";
				
				}

				
			    public Integer total_no_of_members;

				public Integer getTotal_no_of_members () {
					return this.total_no_of_members;
				}

				public Boolean total_no_of_membersIsNullable(){
				    return true;
				}
				public Boolean total_no_of_membersIsKey(){
				    return false;
				}
				public Integer total_no_of_membersLength(){
				    return 10;
				}
				public Integer total_no_of_membersPrecision(){
				    return 0;
				}
				public String total_no_of_membersDefault(){
				
					return "0";
				
				}
				public String total_no_of_membersComment(){
				
				    return "";
				
				}
				public String total_no_of_membersPattern(){
				
					return "";
				
				}
				public String total_no_of_membersOriginalDbColumnName(){
				
					return "total_no_of_members";
				
				}

				
			    public Integer total_luc;

				public Integer getTotal_luc () {
					return this.total_luc;
				}

				public Boolean total_lucIsNullable(){
				    return true;
				}
				public Boolean total_lucIsKey(){
				    return false;
				}
				public Integer total_lucLength(){
				    return 10;
				}
				public Integer total_lucPrecision(){
				    return 0;
				}
				public String total_lucDefault(){
				
					return "0";
				
				}
				public String total_lucComment(){
				
				    return "";
				
				}
				public String total_lucPattern(){
				
					return "";
				
				}
				public String total_lucOriginalDbColumnName(){
				
					return "total_luc";
				
				}

				
			    public Integer active_borrowers;

				public Integer getActive_borrowers () {
					return this.active_borrowers;
				}

				public Boolean active_borrowersIsNullable(){
				    return true;
				}
				public Boolean active_borrowersIsKey(){
				    return false;
				}
				public Integer active_borrowersLength(){
				    return 10;
				}
				public Integer active_borrowersPrecision(){
				    return 0;
				}
				public String active_borrowersDefault(){
				
					return "0";
				
				}
				public String active_borrowersComment(){
				
				    return "";
				
				}
				public String active_borrowersPattern(){
				
					return "";
				
				}
				public String active_borrowersOriginalDbColumnName(){
				
					return "active_borrowers";
				
				}

				
			    public Float principal_Os;

				public Float getPrincipal_Os () {
					return this.principal_Os;
				}

				public Boolean principal_OsIsNullable(){
				    return true;
				}
				public Boolean principal_OsIsKey(){
				    return false;
				}
				public Integer principal_OsLength(){
				    return 8;
				}
				public Integer principal_OsPrecision(){
				    return 8;
				}
				public String principal_OsDefault(){
				
					return "'0'::real";
				
				}
				public String principal_OsComment(){
				
				    return "";
				
				}
				public String principal_OsPattern(){
				
					return "";
				
				}
				public String principal_OsOriginalDbColumnName(){
				
					return "principal_Os";
				
				}

				
			    public Double percentage_of_center_coverage;

				public Double getPercentage_of_center_coverage () {
					return this.percentage_of_center_coverage;
				}

				public Boolean percentage_of_center_coverageIsNullable(){
				    return true;
				}
				public Boolean percentage_of_center_coverageIsKey(){
				    return false;
				}
				public Integer percentage_of_center_coverageLength(){
				    return 17;
				}
				public Integer percentage_of_center_coveragePrecision(){
				    return 17;
				}
				public String percentage_of_center_coverageDefault(){
				
					return "'0'::double precision";
				
				}
				public String percentage_of_center_coverageComment(){
				
				    return "";
				
				}
				public String percentage_of_center_coveragePattern(){
				
					return "";
				
				}
				public String percentage_of_center_coverageOriginalDbColumnName(){
				
					return "percentage_of_center_coverage";
				
				}

				
			    public Double percetage_of_luc_coverage;

				public Double getPercetage_of_luc_coverage () {
					return this.percetage_of_luc_coverage;
				}

				public Boolean percetage_of_luc_coverageIsNullable(){
				    return true;
				}
				public Boolean percetage_of_luc_coverageIsKey(){
				    return false;
				}
				public Integer percetage_of_luc_coverageLength(){
				    return 17;
				}
				public Integer percetage_of_luc_coveragePrecision(){
				    return 17;
				}
				public String percetage_of_luc_coverageDefault(){
				
					return "'0'::double precision";
				
				}
				public String percetage_of_luc_coverageComment(){
				
				    return "";
				
				}
				public String percetage_of_luc_coveragePattern(){
				
					return "";
				
				}
				public String percetage_of_luc_coverageOriginalDbColumnName(){
				
					return "percetage_of_luc_coverage";
				
				}

				
			    public String grade;

				public String getGrade () {
					return this.grade;
				}

				public Boolean gradeIsNullable(){
				    return true;
				}
				public Boolean gradeIsKey(){
				    return false;
				}
				public Integer gradeLength(){
				    return 45;
				}
				public Integer gradePrecision(){
				    return 0;
				}
				public String gradeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String gradeComment(){
				
				    return "";
				
				}
				public String gradePattern(){
				
					return "";
				
				}
				public String gradeOriginalDbColumnName(){
				
					return "grade";
				
				}

				
			    public String grade_risk;

				public String getGrade_risk () {
					return this.grade_risk;
				}

				public Boolean grade_riskIsNullable(){
				    return true;
				}
				public Boolean grade_riskIsKey(){
				    return false;
				}
				public Integer grade_riskLength(){
				    return 45;
				}
				public Integer grade_riskPrecision(){
				    return 0;
				}
				public String grade_riskDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String grade_riskComment(){
				
				    return "";
				
				}
				public String grade_riskPattern(){
				
					return "";
				
				}
				public String grade_riskOriginalDbColumnName(){
				
					return "grade_risk";
				
				}

				
			    public Double total_score;

				public Double getTotal_score () {
					return this.total_score;
				}

				public Boolean total_scoreIsNullable(){
				    return true;
				}
				public Boolean total_scoreIsKey(){
				    return false;
				}
				public Integer total_scoreLength(){
				    return 17;
				}
				public Integer total_scorePrecision(){
				    return 17;
				}
				public String total_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String total_scoreComment(){
				
				    return "";
				
				}
				public String total_scorePattern(){
				
					return "";
				
				}
				public String total_scoreOriginalDbColumnName(){
				
					return "total_score";
				
				}

				
			    public Double actual_score;

				public Double getActual_score () {
					return this.actual_score;
				}

				public Boolean actual_scoreIsNullable(){
				    return true;
				}
				public Boolean actual_scoreIsKey(){
				    return false;
				}
				public Integer actual_scoreLength(){
				    return 17;
				}
				public Integer actual_scorePrecision(){
				    return 17;
				}
				public String actual_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String actual_scoreComment(){
				
				    return "";
				
				}
				public String actual_scorePattern(){
				
					return "";
				
				}
				public String actual_scoreOriginalDbColumnName(){
				
					return "actual_score";
				
				}

				
			    public Double percetage_of_score;

				public Double getPercetage_of_score () {
					return this.percetage_of_score;
				}

				public Boolean percetage_of_scoreIsNullable(){
				    return true;
				}
				public Boolean percetage_of_scoreIsKey(){
				    return false;
				}
				public Integer percetage_of_scoreLength(){
				    return 17;
				}
				public Integer percetage_of_scorePrecision(){
				    return 17;
				}
				public String percetage_of_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String percetage_of_scoreComment(){
				
				    return "";
				
				}
				public String percetage_of_scorePattern(){
				
					return "";
				
				}
				public String percetage_of_scoreOriginalDbColumnName(){
				
					return "percetage_of_score";
				
				}

				
			    public Integer is_force_audit_update;

				public Integer getIs_force_audit_update () {
					return this.is_force_audit_update;
				}

				public Boolean is_force_audit_updateIsNullable(){
				    return true;
				}
				public Boolean is_force_audit_updateIsKey(){
				    return false;
				}
				public Integer is_force_audit_updateLength(){
				    return 10;
				}
				public Integer is_force_audit_updatePrecision(){
				    return 0;
				}
				public String is_force_audit_updateDefault(){
				
					return "0";
				
				}
				public String is_force_audit_updateComment(){
				
				    return "";
				
				}
				public String is_force_audit_updatePattern(){
				
					return "";
				
				}
				public String is_force_audit_updateOriginalDbColumnName(){
				
					return "is_force_audit_update";
				
				}

				
			    public String description;

				public String getDescription () {
					return this.description;
				}

				public Boolean descriptionIsNullable(){
				    return true;
				}
				public Boolean descriptionIsKey(){
				    return false;
				}
				public Integer descriptionLength(){
				    return 2147483647;
				}
				public Integer descriptionPrecision(){
				    return 0;
				}
				public String descriptionDefault(){
				
					return null;
				
				}
				public String descriptionComment(){
				
				    return "";
				
				}
				public String descriptionPattern(){
				
					return "";
				
				}
				public String descriptionOriginalDbColumnName(){
				
					return "description";
				
				}

				
			    public Integer force_audit_updated_by;

				public Integer getForce_audit_updated_by () {
					return this.force_audit_updated_by;
				}

				public Boolean force_audit_updated_byIsNullable(){
				    return true;
				}
				public Boolean force_audit_updated_byIsKey(){
				    return false;
				}
				public Integer force_audit_updated_byLength(){
				    return 10;
				}
				public Integer force_audit_updated_byPrecision(){
				    return 0;
				}
				public String force_audit_updated_byDefault(){
				
					return "0";
				
				}
				public String force_audit_updated_byComment(){
				
				    return "";
				
				}
				public String force_audit_updated_byPattern(){
				
					return "";
				
				}
				public String force_audit_updated_byOriginalDbColumnName(){
				
					return "force_audit_updated_by";
				
				}

				
			    public java.util.Date force_audit_updated_on;

				public java.util.Date getForce_audit_updated_on () {
					return this.force_audit_updated_on;
				}

				public Boolean force_audit_updated_onIsNullable(){
				    return true;
				}
				public Boolean force_audit_updated_onIsKey(){
				    return false;
				}
				public Integer force_audit_updated_onLength(){
				    return 13;
				}
				public Integer force_audit_updated_onPrecision(){
				    return 0;
				}
				public String force_audit_updated_onDefault(){
				
					return null;
				
				}
				public String force_audit_updated_onComment(){
				
				    return "";
				
				}
				public String force_audit_updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String force_audit_updated_onOriginalDbColumnName(){
				
					return "force_audit_updated_on";
				
				}

				
			    public Double risk_actual_score;

				public Double getRisk_actual_score () {
					return this.risk_actual_score;
				}

				public Boolean risk_actual_scoreIsNullable(){
				    return true;
				}
				public Boolean risk_actual_scoreIsKey(){
				    return false;
				}
				public Integer risk_actual_scoreLength(){
				    return 17;
				}
				public Integer risk_actual_scorePrecision(){
				    return 17;
				}
				public String risk_actual_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String risk_actual_scoreComment(){
				
				    return "";
				
				}
				public String risk_actual_scorePattern(){
				
					return "";
				
				}
				public String risk_actual_scoreOriginalDbColumnName(){
				
					return "risk_actual_score";
				
				}

				
			    public Double risk_total_score;

				public Double getRisk_total_score () {
					return this.risk_total_score;
				}

				public Boolean risk_total_scoreIsNullable(){
				    return true;
				}
				public Boolean risk_total_scoreIsKey(){
				    return false;
				}
				public Integer risk_total_scoreLength(){
				    return 17;
				}
				public Integer risk_total_scorePrecision(){
				    return 17;
				}
				public String risk_total_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String risk_total_scoreComment(){
				
				    return "";
				
				}
				public String risk_total_scorePattern(){
				
					return "";
				
				}
				public String risk_total_scoreOriginalDbColumnName(){
				
					return "risk_total_score";
				
				}

				
			    public Double critical_max_score;

				public Double getCritical_max_score () {
					return this.critical_max_score;
				}

				public Boolean critical_max_scoreIsNullable(){
				    return true;
				}
				public Boolean critical_max_scoreIsKey(){
				    return false;
				}
				public Integer critical_max_scoreLength(){
				    return 17;
				}
				public Integer critical_max_scorePrecision(){
				    return 17;
				}
				public String critical_max_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String critical_max_scoreComment(){
				
				    return "";
				
				}
				public String critical_max_scorePattern(){
				
					return "";
				
				}
				public String critical_max_scoreOriginalDbColumnName(){
				
					return "critical_max_score";
				
				}

				
			    public Double critical_obtain_score;

				public Double getCritical_obtain_score () {
					return this.critical_obtain_score;
				}

				public Boolean critical_obtain_scoreIsNullable(){
				    return true;
				}
				public Boolean critical_obtain_scoreIsKey(){
				    return false;
				}
				public Integer critical_obtain_scoreLength(){
				    return 17;
				}
				public Integer critical_obtain_scorePrecision(){
				    return 17;
				}
				public String critical_obtain_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String critical_obtain_scoreComment(){
				
				    return "";
				
				}
				public String critical_obtain_scorePattern(){
				
					return "";
				
				}
				public String critical_obtain_scoreOriginalDbColumnName(){
				
					return "critical_obtain_score";
				
				}

				
			    public Double high_max_score;

				public Double getHigh_max_score () {
					return this.high_max_score;
				}

				public Boolean high_max_scoreIsNullable(){
				    return true;
				}
				public Boolean high_max_scoreIsKey(){
				    return false;
				}
				public Integer high_max_scoreLength(){
				    return 17;
				}
				public Integer high_max_scorePrecision(){
				    return 17;
				}
				public String high_max_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String high_max_scoreComment(){
				
				    return "";
				
				}
				public String high_max_scorePattern(){
				
					return "";
				
				}
				public String high_max_scoreOriginalDbColumnName(){
				
					return "high_max_score";
				
				}

				
			    public Double high_obtain_score;

				public Double getHigh_obtain_score () {
					return this.high_obtain_score;
				}

				public Boolean high_obtain_scoreIsNullable(){
				    return true;
				}
				public Boolean high_obtain_scoreIsKey(){
				    return false;
				}
				public Integer high_obtain_scoreLength(){
				    return 17;
				}
				public Integer high_obtain_scorePrecision(){
				    return 17;
				}
				public String high_obtain_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String high_obtain_scoreComment(){
				
				    return "";
				
				}
				public String high_obtain_scorePattern(){
				
					return "";
				
				}
				public String high_obtain_scoreOriginalDbColumnName(){
				
					return "high_obtain_score";
				
				}

				
			    public Double medium_max_score;

				public Double getMedium_max_score () {
					return this.medium_max_score;
				}

				public Boolean medium_max_scoreIsNullable(){
				    return true;
				}
				public Boolean medium_max_scoreIsKey(){
				    return false;
				}
				public Integer medium_max_scoreLength(){
				    return 17;
				}
				public Integer medium_max_scorePrecision(){
				    return 17;
				}
				public String medium_max_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String medium_max_scoreComment(){
				
				    return "";
				
				}
				public String medium_max_scorePattern(){
				
					return "";
				
				}
				public String medium_max_scoreOriginalDbColumnName(){
				
					return "medium_max_score";
				
				}

				
			    public Double medium_obtain_score;

				public Double getMedium_obtain_score () {
					return this.medium_obtain_score;
				}

				public Boolean medium_obtain_scoreIsNullable(){
				    return true;
				}
				public Boolean medium_obtain_scoreIsKey(){
				    return false;
				}
				public Integer medium_obtain_scoreLength(){
				    return 17;
				}
				public Integer medium_obtain_scorePrecision(){
				    return 17;
				}
				public String medium_obtain_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String medium_obtain_scoreComment(){
				
				    return "";
				
				}
				public String medium_obtain_scorePattern(){
				
					return "";
				
				}
				public String medium_obtain_scoreOriginalDbColumnName(){
				
					return "medium_obtain_score";
				
				}

				
			    public Double low_max_score;

				public Double getLow_max_score () {
					return this.low_max_score;
				}

				public Boolean low_max_scoreIsNullable(){
				    return true;
				}
				public Boolean low_max_scoreIsKey(){
				    return false;
				}
				public Integer low_max_scoreLength(){
				    return 17;
				}
				public Integer low_max_scorePrecision(){
				    return 17;
				}
				public String low_max_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String low_max_scoreComment(){
				
				    return "";
				
				}
				public String low_max_scorePattern(){
				
					return "";
				
				}
				public String low_max_scoreOriginalDbColumnName(){
				
					return "low_max_score";
				
				}

				
			    public Double risk_percentage_score;

				public Double getRisk_percentage_score () {
					return this.risk_percentage_score;
				}

				public Boolean risk_percentage_scoreIsNullable(){
				    return true;
				}
				public Boolean risk_percentage_scoreIsKey(){
				    return false;
				}
				public Integer risk_percentage_scoreLength(){
				    return 17;
				}
				public Integer risk_percentage_scorePrecision(){
				    return 17;
				}
				public String risk_percentage_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String risk_percentage_scoreComment(){
				
				    return "";
				
				}
				public String risk_percentage_scorePattern(){
				
					return "";
				
				}
				public String risk_percentage_scoreOriginalDbColumnName(){
				
					return "risk_percentage_score";
				
				}

				
			    public Double low_obtain_score;

				public Double getLow_obtain_score () {
					return this.low_obtain_score;
				}

				public Boolean low_obtain_scoreIsNullable(){
				    return true;
				}
				public Boolean low_obtain_scoreIsKey(){
				    return false;
				}
				public Integer low_obtain_scoreLength(){
				    return 17;
				}
				public Integer low_obtain_scorePrecision(){
				    return 17;
				}
				public String low_obtain_scoreDefault(){
				
					return "'0'::double precision";
				
				}
				public String low_obtain_scoreComment(){
				
				    return "";
				
				}
				public String low_obtain_scorePattern(){
				
					return "";
				
				}
				public String low_obtain_scoreOriginalDbColumnName(){
				
					return "low_obtain_score";
				
				}

				
			    public Integer bm_status;

				public Integer getBm_status () {
					return this.bm_status;
				}

				public Boolean bm_statusIsNullable(){
				    return true;
				}
				public Boolean bm_statusIsKey(){
				    return false;
				}
				public Integer bm_statusLength(){
				    return 10;
				}
				public Integer bm_statusPrecision(){
				    return 0;
				}
				public String bm_statusDefault(){
				
					return "0";
				
				}
				public String bm_statusComment(){
				
				    return "";
				
				}
				public String bm_statusPattern(){
				
					return "";
				
				}
				public String bm_statusOriginalDbColumnName(){
				
					return "bm_status";
				
				}

				
			    public Integer dam_status;

				public Integer getDam_status () {
					return this.dam_status;
				}

				public Boolean dam_statusIsNullable(){
				    return true;
				}
				public Boolean dam_statusIsKey(){
				    return false;
				}
				public Integer dam_statusLength(){
				    return 10;
				}
				public Integer dam_statusPrecision(){
				    return 0;
				}
				public String dam_statusDefault(){
				
					return "0";
				
				}
				public String dam_statusComment(){
				
				    return "";
				
				}
				public String dam_statusPattern(){
				
					return "";
				
				}
				public String dam_statusOriginalDbColumnName(){
				
					return "dam_status";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String branch_audit_details_id;

				public String getBranch_audit_details_id () {
					return this.branch_audit_details_id;
				}

				public Boolean branch_audit_details_idIsNullable(){
				    return true;
				}
				public Boolean branch_audit_details_idIsKey(){
				    return false;
				}
				public Integer branch_audit_details_idLength(){
				    return 32;
				}
				public Integer branch_audit_details_idPrecision(){
				    return 0;
				}
				public String branch_audit_details_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branch_audit_details_idComment(){
				
				    return "";
				
				}
				public String branch_audit_details_idPattern(){
				
					return "";
				
				}
				public String branch_audit_details_idOriginalDbColumnName(){
				
					return "branch_audit_details_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row2Struct other = (pRow_row2Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row2Struct other) {

		other.id = this.id;
	            other.division = this.division;
	            other.area = this.area;
	            other.branch_id = this.branch_id;
	            other.branch = this.branch;
	            other.month_audit_cycle = this.month_audit_cycle;
	            other.year = this.year;
	            other.audit_no = this.audit_no;
	            other.audited_from_date = this.audited_from_date;
	            other.audited_to_date = this.audited_to_date;
	            other.auditor_id = this.auditor_id;
	            other.auditor = this.auditor;
	            other.audit_plan_id = this.audit_plan_id;
	            other.noofcenter_attended_by_auditor = this.noofcenter_attended_by_auditor;
	            other.no_of_luc_done_by_auditor = this.no_of_luc_done_by_auditor;
	            other.no_of_cre = this.no_of_cre;
	            other.total_no_of_center = this.total_no_of_center;
	            other.total_no_of_members = this.total_no_of_members;
	            other.total_luc = this.total_luc;
	            other.active_borrowers = this.active_borrowers;
	            other.principal_Os = this.principal_Os;
	            other.percentage_of_center_coverage = this.percentage_of_center_coverage;
	            other.percetage_of_luc_coverage = this.percetage_of_luc_coverage;
	            other.grade = this.grade;
	            other.grade_risk = this.grade_risk;
	            other.total_score = this.total_score;
	            other.actual_score = this.actual_score;
	            other.percetage_of_score = this.percetage_of_score;
	            other.is_force_audit_update = this.is_force_audit_update;
	            other.description = this.description;
	            other.force_audit_updated_by = this.force_audit_updated_by;
	            other.force_audit_updated_on = this.force_audit_updated_on;
	            other.risk_actual_score = this.risk_actual_score;
	            other.risk_total_score = this.risk_total_score;
	            other.critical_max_score = this.critical_max_score;
	            other.critical_obtain_score = this.critical_obtain_score;
	            other.high_max_score = this.high_max_score;
	            other.high_obtain_score = this.high_obtain_score;
	            other.medium_max_score = this.medium_max_score;
	            other.medium_obtain_score = this.medium_obtain_score;
	            other.low_max_score = this.low_max_score;
	            other.risk_percentage_score = this.risk_percentage_score;
	            other.low_obtain_score = this.low_obtain_score;
	            other.bm_status = this.bm_status;
	            other.dam_status = this.dam_status;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.branch_audit_details_id = this.branch_audit_details_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row2Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.division = readString(dis);
					
					this.area = readString(dis);
					
			        this.branch_id = dis.readInt();
					
					this.branch = readString(dis);
					
						this.month_audit_cycle = readInteger(dis);
					
						this.year = readInteger(dis);
					
						this.audit_no = readInteger(dis);
					
					this.audited_from_date = readDate(dis);
					
					this.audited_to_date = readDate(dis);
					
			        this.auditor_id = dis.readInt();
					
					this.auditor = readString(dis);
					
			        this.audit_plan_id = dis.readInt();
					
						this.noofcenter_attended_by_auditor = readInteger(dis);
					
						this.no_of_luc_done_by_auditor = readInteger(dis);
					
						this.no_of_cre = readInteger(dis);
					
						this.total_no_of_center = readInteger(dis);
					
						this.total_no_of_members = readInteger(dis);
					
						this.total_luc = readInteger(dis);
					
						this.active_borrowers = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.principal_Os = null;
           				} else {
           			    	this.principal_Os = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percentage_of_center_coverage = null;
           				} else {
           			    	this.percentage_of_center_coverage = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percetage_of_luc_coverage = null;
           				} else {
           			    	this.percetage_of_luc_coverage = dis.readDouble();
           				}
					
					this.grade = readString(dis);
					
					this.grade_risk = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_score = null;
           				} else {
           			    	this.total_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.actual_score = null;
           				} else {
           			    	this.actual_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percetage_of_score = null;
           				} else {
           			    	this.percetage_of_score = dis.readDouble();
           				}
					
						this.is_force_audit_update = readInteger(dis);
					
					this.description = readString(dis);
					
						this.force_audit_updated_by = readInteger(dis);
					
					this.force_audit_updated_on = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_actual_score = null;
           				} else {
           			    	this.risk_actual_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_total_score = null;
           				} else {
           			    	this.risk_total_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.critical_max_score = null;
           				} else {
           			    	this.critical_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.critical_obtain_score = null;
           				} else {
           			    	this.critical_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.high_max_score = null;
           				} else {
           			    	this.high_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.high_obtain_score = null;
           				} else {
           			    	this.high_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.medium_max_score = null;
           				} else {
           			    	this.medium_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.medium_obtain_score = null;
           				} else {
           			    	this.medium_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.low_max_score = null;
           				} else {
           			    	this.low_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_percentage_score = null;
           				} else {
           			    	this.risk_percentage_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.low_obtain_score = null;
           				} else {
           			    	this.low_obtain_score = dis.readDouble();
           				}
					
						this.bm_status = readInteger(dis);
					
						this.dam_status = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.branch_audit_details_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.division = readString(dis);
					
					this.area = readString(dis);
					
			        this.branch_id = dis.readInt();
					
					this.branch = readString(dis);
					
						this.month_audit_cycle = readInteger(dis);
					
						this.year = readInteger(dis);
					
						this.audit_no = readInteger(dis);
					
					this.audited_from_date = readDate(dis);
					
					this.audited_to_date = readDate(dis);
					
			        this.auditor_id = dis.readInt();
					
					this.auditor = readString(dis);
					
			        this.audit_plan_id = dis.readInt();
					
						this.noofcenter_attended_by_auditor = readInteger(dis);
					
						this.no_of_luc_done_by_auditor = readInteger(dis);
					
						this.no_of_cre = readInteger(dis);
					
						this.total_no_of_center = readInteger(dis);
					
						this.total_no_of_members = readInteger(dis);
					
						this.total_luc = readInteger(dis);
					
						this.active_borrowers = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.principal_Os = null;
           				} else {
           			    	this.principal_Os = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percentage_of_center_coverage = null;
           				} else {
           			    	this.percentage_of_center_coverage = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percetage_of_luc_coverage = null;
           				} else {
           			    	this.percetage_of_luc_coverage = dis.readDouble();
           				}
					
					this.grade = readString(dis);
					
					this.grade_risk = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.total_score = null;
           				} else {
           			    	this.total_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.actual_score = null;
           				} else {
           			    	this.actual_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.percetage_of_score = null;
           				} else {
           			    	this.percetage_of_score = dis.readDouble();
           				}
					
						this.is_force_audit_update = readInteger(dis);
					
					this.description = readString(dis);
					
						this.force_audit_updated_by = readInteger(dis);
					
					this.force_audit_updated_on = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_actual_score = null;
           				} else {
           			    	this.risk_actual_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_total_score = null;
           				} else {
           			    	this.risk_total_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.critical_max_score = null;
           				} else {
           			    	this.critical_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.critical_obtain_score = null;
           				} else {
           			    	this.critical_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.high_max_score = null;
           				} else {
           			    	this.high_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.high_obtain_score = null;
           				} else {
           			    	this.high_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.medium_max_score = null;
           				} else {
           			    	this.medium_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.medium_obtain_score = null;
           				} else {
           			    	this.medium_obtain_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.low_max_score = null;
           				} else {
           			    	this.low_max_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.risk_percentage_score = null;
           				} else {
           			    	this.risk_percentage_score = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.low_obtain_score = null;
           				} else {
           			    	this.low_obtain_score = dis.readDouble();
           				}
					
						this.bm_status = readInteger(dis);
					
						this.dam_status = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.branch_audit_details_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.area,dos);
					
					// int
				
		            	dos.writeInt(this.branch_id);
					
					// String
				
						writeString(this.branch,dos);
					
					// Integer
				
						writeInteger(this.month_audit_cycle,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// Integer
				
						writeInteger(this.audit_no,dos);
					
					// java.util.Date
				
						writeDate(this.audited_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.audited_to_date,dos);
					
					// int
				
		            	dos.writeInt(this.auditor_id);
					
					// String
				
						writeString(this.auditor,dos);
					
					// int
				
		            	dos.writeInt(this.audit_plan_id);
					
					// Integer
				
						writeInteger(this.noofcenter_attended_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.no_of_luc_done_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.no_of_cre,dos);
					
					// Integer
				
						writeInteger(this.total_no_of_center,dos);
					
					// Integer
				
						writeInteger(this.total_no_of_members,dos);
					
					// Integer
				
						writeInteger(this.total_luc,dos);
					
					// Integer
				
						writeInteger(this.active_borrowers,dos);
					
					// Float
				
						if(this.principal_Os == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.principal_Os);
		            	}
					
					// Double
				
						if(this.percentage_of_center_coverage == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percentage_of_center_coverage);
		            	}
					
					// Double
				
						if(this.percetage_of_luc_coverage == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percetage_of_luc_coverage);
		            	}
					
					// String
				
						writeString(this.grade,dos);
					
					// String
				
						writeString(this.grade_risk,dos);
					
					// Double
				
						if(this.total_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_score);
		            	}
					
					// Double
				
						if(this.actual_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.actual_score);
		            	}
					
					// Double
				
						if(this.percetage_of_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percetage_of_score);
		            	}
					
					// Integer
				
						writeInteger(this.is_force_audit_update,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// Integer
				
						writeInteger(this.force_audit_updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.force_audit_updated_on,dos);
					
					// Double
				
						if(this.risk_actual_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_actual_score);
		            	}
					
					// Double
				
						if(this.risk_total_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_total_score);
		            	}
					
					// Double
				
						if(this.critical_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.critical_max_score);
		            	}
					
					// Double
				
						if(this.critical_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.critical_obtain_score);
		            	}
					
					// Double
				
						if(this.high_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.high_max_score);
		            	}
					
					// Double
				
						if(this.high_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.high_obtain_score);
		            	}
					
					// Double
				
						if(this.medium_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.medium_max_score);
		            	}
					
					// Double
				
						if(this.medium_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.medium_obtain_score);
		            	}
					
					// Double
				
						if(this.low_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.low_max_score);
		            	}
					
					// Double
				
						if(this.risk_percentage_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_percentage_score);
		            	}
					
					// Double
				
						if(this.low_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.low_obtain_score);
		            	}
					
					// Integer
				
						writeInteger(this.bm_status,dos);
					
					// Integer
				
						writeInteger(this.dam_status,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.branch_audit_details_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.area,dos);
					
					// int
				
		            	dos.writeInt(this.branch_id);
					
					// String
				
						writeString(this.branch,dos);
					
					// Integer
				
						writeInteger(this.month_audit_cycle,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// Integer
				
						writeInteger(this.audit_no,dos);
					
					// java.util.Date
				
						writeDate(this.audited_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.audited_to_date,dos);
					
					// int
				
		            	dos.writeInt(this.auditor_id);
					
					// String
				
						writeString(this.auditor,dos);
					
					// int
				
		            	dos.writeInt(this.audit_plan_id);
					
					// Integer
				
						writeInteger(this.noofcenter_attended_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.no_of_luc_done_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.no_of_cre,dos);
					
					// Integer
				
						writeInteger(this.total_no_of_center,dos);
					
					// Integer
				
						writeInteger(this.total_no_of_members,dos);
					
					// Integer
				
						writeInteger(this.total_luc,dos);
					
					// Integer
				
						writeInteger(this.active_borrowers,dos);
					
					// Float
				
						if(this.principal_Os == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.principal_Os);
		            	}
					
					// Double
				
						if(this.percentage_of_center_coverage == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percentage_of_center_coverage);
		            	}
					
					// Double
				
						if(this.percetage_of_luc_coverage == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percetage_of_luc_coverage);
		            	}
					
					// String
				
						writeString(this.grade,dos);
					
					// String
				
						writeString(this.grade_risk,dos);
					
					// Double
				
						if(this.total_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.total_score);
		            	}
					
					// Double
				
						if(this.actual_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.actual_score);
		            	}
					
					// Double
				
						if(this.percetage_of_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.percetage_of_score);
		            	}
					
					// Integer
				
						writeInteger(this.is_force_audit_update,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// Integer
				
						writeInteger(this.force_audit_updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.force_audit_updated_on,dos);
					
					// Double
				
						if(this.risk_actual_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_actual_score);
		            	}
					
					// Double
				
						if(this.risk_total_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_total_score);
		            	}
					
					// Double
				
						if(this.critical_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.critical_max_score);
		            	}
					
					// Double
				
						if(this.critical_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.critical_obtain_score);
		            	}
					
					// Double
				
						if(this.high_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.high_max_score);
		            	}
					
					// Double
				
						if(this.high_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.high_obtain_score);
		            	}
					
					// Double
				
						if(this.medium_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.medium_max_score);
		            	}
					
					// Double
				
						if(this.medium_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.medium_obtain_score);
		            	}
					
					// Double
				
						if(this.low_max_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.low_max_score);
		            	}
					
					// Double
				
						if(this.risk_percentage_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.risk_percentage_score);
		            	}
					
					// Double
				
						if(this.low_obtain_score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.low_obtain_score);
		            	}
					
					// Integer
				
						writeInteger(this.bm_status,dos);
					
					// Integer
				
						writeInteger(this.dam_status,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.branch_audit_details_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",division="+division);
		sb.append(",area="+area);
		sb.append(",branch_id="+String.valueOf(branch_id));
		sb.append(",branch="+branch);
		sb.append(",month_audit_cycle="+String.valueOf(month_audit_cycle));
		sb.append(",year="+String.valueOf(year));
		sb.append(",audit_no="+String.valueOf(audit_no));
		sb.append(",audited_from_date="+String.valueOf(audited_from_date));
		sb.append(",audited_to_date="+String.valueOf(audited_to_date));
		sb.append(",auditor_id="+String.valueOf(auditor_id));
		sb.append(",auditor="+auditor);
		sb.append(",audit_plan_id="+String.valueOf(audit_plan_id));
		sb.append(",noofcenter_attended_by_auditor="+String.valueOf(noofcenter_attended_by_auditor));
		sb.append(",no_of_luc_done_by_auditor="+String.valueOf(no_of_luc_done_by_auditor));
		sb.append(",no_of_cre="+String.valueOf(no_of_cre));
		sb.append(",total_no_of_center="+String.valueOf(total_no_of_center));
		sb.append(",total_no_of_members="+String.valueOf(total_no_of_members));
		sb.append(",total_luc="+String.valueOf(total_luc));
		sb.append(",active_borrowers="+String.valueOf(active_borrowers));
		sb.append(",principal_Os="+String.valueOf(principal_Os));
		sb.append(",percentage_of_center_coverage="+String.valueOf(percentage_of_center_coverage));
		sb.append(",percetage_of_luc_coverage="+String.valueOf(percetage_of_luc_coverage));
		sb.append(",grade="+grade);
		sb.append(",grade_risk="+grade_risk);
		sb.append(",total_score="+String.valueOf(total_score));
		sb.append(",actual_score="+String.valueOf(actual_score));
		sb.append(",percetage_of_score="+String.valueOf(percetage_of_score));
		sb.append(",is_force_audit_update="+String.valueOf(is_force_audit_update));
		sb.append(",description="+description);
		sb.append(",force_audit_updated_by="+String.valueOf(force_audit_updated_by));
		sb.append(",force_audit_updated_on="+String.valueOf(force_audit_updated_on));
		sb.append(",risk_actual_score="+String.valueOf(risk_actual_score));
		sb.append(",risk_total_score="+String.valueOf(risk_total_score));
		sb.append(",critical_max_score="+String.valueOf(critical_max_score));
		sb.append(",critical_obtain_score="+String.valueOf(critical_obtain_score));
		sb.append(",high_max_score="+String.valueOf(high_max_score));
		sb.append(",high_obtain_score="+String.valueOf(high_obtain_score));
		sb.append(",medium_max_score="+String.valueOf(medium_max_score));
		sb.append(",medium_obtain_score="+String.valueOf(medium_obtain_score));
		sb.append(",low_max_score="+String.valueOf(low_max_score));
		sb.append(",risk_percentage_score="+String.valueOf(risk_percentage_score));
		sb.append(",low_obtain_score="+String.valueOf(low_obtain_score));
		sb.append(",bm_status="+String.valueOf(bm_status));
		sb.append(",dam_status="+String.valueOf(dam_status));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",branch_audit_details_id="+branch_audit_details_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(division == null){
        					sb.append("<null>");
        				}else{
            				sb.append(division);
            			}
            		
        			sb.append("|");
        		
        				if(area == null){
        					sb.append("<null>");
        				}else{
            				sb.append(area);
            			}
            		
        			sb.append("|");
        		
        				sb.append(branch_id);
        			
        			sb.append("|");
        		
        				if(branch == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch);
            			}
            		
        			sb.append("|");
        		
        				if(month_audit_cycle == null){
        					sb.append("<null>");
        				}else{
            				sb.append(month_audit_cycle);
            			}
            		
        			sb.append("|");
        		
        				if(year == null){
        					sb.append("<null>");
        				}else{
            				sb.append(year);
            			}
            		
        			sb.append("|");
        		
        				if(audit_no == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_no);
            			}
            		
        			sb.append("|");
        		
        				if(audited_from_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audited_from_date);
            			}
            		
        			sb.append("|");
        		
        				if(audited_to_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audited_to_date);
            			}
            		
        			sb.append("|");
        		
        				sb.append(auditor_id);
        			
        			sb.append("|");
        		
        				if(auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor);
            			}
            		
        			sb.append("|");
        		
        				sb.append(audit_plan_id);
        			
        			sb.append("|");
        		
        				if(noofcenter_attended_by_auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(noofcenter_attended_by_auditor);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_luc_done_by_auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_luc_done_by_auditor);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_cre == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_cre);
            			}
            		
        			sb.append("|");
        		
        				if(total_no_of_center == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_no_of_center);
            			}
            		
        			sb.append("|");
        		
        				if(total_no_of_members == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_no_of_members);
            			}
            		
        			sb.append("|");
        		
        				if(total_luc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_luc);
            			}
            		
        			sb.append("|");
        		
        				if(active_borrowers == null){
        					sb.append("<null>");
        				}else{
            				sb.append(active_borrowers);
            			}
            		
        			sb.append("|");
        		
        				if(principal_Os == null){
        					sb.append("<null>");
        				}else{
            				sb.append(principal_Os);
            			}
            		
        			sb.append("|");
        		
        				if(percentage_of_center_coverage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(percentage_of_center_coverage);
            			}
            		
        			sb.append("|");
        		
        				if(percetage_of_luc_coverage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(percetage_of_luc_coverage);
            			}
            		
        			sb.append("|");
        		
        				if(grade == null){
        					sb.append("<null>");
        				}else{
            				sb.append(grade);
            			}
            		
        			sb.append("|");
        		
        				if(grade_risk == null){
        					sb.append("<null>");
        				}else{
            				sb.append(grade_risk);
            			}
            		
        			sb.append("|");
        		
        				if(total_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(total_score);
            			}
            		
        			sb.append("|");
        		
        				if(actual_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(actual_score);
            			}
            		
        			sb.append("|");
        		
        				if(percetage_of_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(percetage_of_score);
            			}
            		
        			sb.append("|");
        		
        				if(is_force_audit_update == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_force_audit_update);
            			}
            		
        			sb.append("|");
        		
        				if(description == null){
        					sb.append("<null>");
        				}else{
            				sb.append(description);
            			}
            		
        			sb.append("|");
        		
        				if(force_audit_updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(force_audit_updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(force_audit_updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(force_audit_updated_on);
            			}
            		
        			sb.append("|");
        		
        				if(risk_actual_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(risk_actual_score);
            			}
            		
        			sb.append("|");
        		
        				if(risk_total_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(risk_total_score);
            			}
            		
        			sb.append("|");
        		
        				if(critical_max_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(critical_max_score);
            			}
            		
        			sb.append("|");
        		
        				if(critical_obtain_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(critical_obtain_score);
            			}
            		
        			sb.append("|");
        		
        				if(high_max_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(high_max_score);
            			}
            		
        			sb.append("|");
        		
        				if(high_obtain_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(high_obtain_score);
            			}
            		
        			sb.append("|");
        		
        				if(medium_max_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(medium_max_score);
            			}
            		
        			sb.append("|");
        		
        				if(medium_obtain_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(medium_obtain_score);
            			}
            		
        			sb.append("|");
        		
        				if(low_max_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(low_max_score);
            			}
            		
        			sb.append("|");
        		
        				if(risk_percentage_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(risk_percentage_score);
            			}
            		
        			sb.append("|");
        		
        				if(low_obtain_score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(low_obtain_score);
            			}
            		
        			sb.append("|");
        		
        				if(bm_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(bm_status);
            			}
            		
        			sb.append("|");
        		
        				if(dam_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(dam_status);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(branch_audit_details_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_audit_details_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_2");
		org.slf4j.MDC.put("_subJobPid", "7N9IaJ_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_2");
		class tAsyncIn_tDBOutput_2_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_2_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row2Struct pRow_row2 = new pRow_row2Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"branch_audit_details_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row2");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"branch_audit_details_dw\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "\"branch_audit_details_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("branch_audit_details_dw");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("branch_audit_details_dw");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
        java.lang.StringBuilder sb_tDBOutput_2 = new java.lang.StringBuilder();
        sb_tDBOutput_2.append("INSERT INTO \"").append(tableName_tDBOutput_2).append("\" (\"id\",\"division\",\"area\",\"branch_id\",\"branch\",\"month_audit_cycle\",\"year\",\"audit_no\",\"audited_from_date\",\"audited_to_date\",\"auditor_id\",\"auditor\",\"audit_plan_id\",\"noofcenter_attended_by_auditor\",\"no_of_luc_done_by_auditor\",\"no_of_cre\",\"total_no_of_center\",\"total_no_of_members\",\"total_luc\",\"active_borrowers\",\"principal_Os\",\"percentage_of_center_coverage\",\"percetage_of_luc_coverage\",\"grade\",\"grade_risk\",\"total_score\",\"actual_score\",\"percetage_of_score\",\"is_force_audit_update\",\"description\",\"force_audit_updated_by\",\"force_audit_updated_on\",\"risk_actual_score\",\"risk_total_score\",\"critical_max_score\",\"critical_obtain_score\",\"high_max_score\",\"high_obtain_score\",\"medium_max_score\",\"medium_obtain_score\",\"low_max_score\",\"risk_percentage_score\",\"low_obtain_score\",\"bm_status\",\"dam_status\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"branch_audit_details_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_2.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"division\" = EXCLUDED.\"division\",\"area\" = EXCLUDED.\"area\",\"branch_id\" = EXCLUDED.\"branch_id\",\"branch\" = EXCLUDED.\"branch\",\"month_audit_cycle\" = EXCLUDED.\"month_audit_cycle\",\"year\" = EXCLUDED.\"year\",\"audit_no\" = EXCLUDED.\"audit_no\",\"audited_from_date\" = EXCLUDED.\"audited_from_date\",\"audited_to_date\" = EXCLUDED.\"audited_to_date\",\"auditor_id\" = EXCLUDED.\"auditor_id\",\"auditor\" = EXCLUDED.\"auditor\",\"audit_plan_id\" = EXCLUDED.\"audit_plan_id\",\"noofcenter_attended_by_auditor\" = EXCLUDED.\"noofcenter_attended_by_auditor\",\"no_of_luc_done_by_auditor\" = EXCLUDED.\"no_of_luc_done_by_auditor\",\"no_of_cre\" = EXCLUDED.\"no_of_cre\",\"total_no_of_center\" = EXCLUDED.\"total_no_of_center\",\"total_no_of_members\" = EXCLUDED.\"total_no_of_members\",\"total_luc\" = EXCLUDED.\"total_luc\",\"active_borrowers\" = EXCLUDED.\"active_borrowers\",\"principal_Os\" = EXCLUDED.\"principal_Os\",\"percentage_of_center_coverage\" = EXCLUDED.\"percentage_of_center_coverage\",\"percetage_of_luc_coverage\" = EXCLUDED.\"percetage_of_luc_coverage\",\"grade\" = EXCLUDED.\"grade\",\"grade_risk\" = EXCLUDED.\"grade_risk\",\"total_score\" = EXCLUDED.\"total_score\",\"actual_score\" = EXCLUDED.\"actual_score\",\"percetage_of_score\" = EXCLUDED.\"percetage_of_score\",\"is_force_audit_update\" = EXCLUDED.\"is_force_audit_update\",\"description\" = EXCLUDED.\"description\",\"force_audit_updated_by\" = EXCLUDED.\"force_audit_updated_by\",\"force_audit_updated_on\" = EXCLUDED.\"force_audit_updated_on\",\"risk_actual_score\" = EXCLUDED.\"risk_actual_score\",\"risk_total_score\" = EXCLUDED.\"risk_total_score\",\"critical_max_score\" = EXCLUDED.\"critical_max_score\",\"critical_obtain_score\" = EXCLUDED.\"critical_obtain_score\",\"high_max_score\" = EXCLUDED.\"high_max_score\",\"high_obtain_score\" = EXCLUDED.\"high_obtain_score\",\"medium_max_score\" = EXCLUDED.\"medium_max_score\",\"medium_obtain_score\" = EXCLUDED.\"medium_obtain_score\",\"low_max_score\" = EXCLUDED.\"low_max_score\",\"risk_percentage_score\" = EXCLUDED.\"risk_percentage_score\",\"low_obtain_score\" = EXCLUDED.\"low_obtain_score\",\"bm_status\" = EXCLUDED.\"bm_status\",\"dam_status\" = EXCLUDED.\"dam_status\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"branch_audit_details_id\" = EXCLUDED.\"branch_audit_details_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_2 = sb_tDBOutput_2.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing '")  + (insert_tDBOutput_2)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_2", false);
		start_Hash.put("tAsyncIn_tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	
		int tos_count_tAsyncIn_tDBOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_2", "tAsyncIn_tDBOutput_2", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_2= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_2 = buffers_tAsyncIn_tDBOutput_2.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_2 != null && buffers_tAsyncIn_tDBOutput_2.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_2 : buffers_tAsyncIn_tDBOutput_2) {
    		pRow_row2 = null;						
			pRow_row2 = new pRow_row2Struct();
		
		
			String temp_tAsyncIn_tDBOutput_2_0 = row_tAsyncIn_tDBOutput_2[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[0]);
			if(temp_tAsyncIn_tDBOutput_2_0 != null) {
		
			pRow_row2.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_0);
		} else {						
			pRow_row2.id = 0;
		}
		pRow_row2.division = row_tAsyncIn_tDBOutput_2[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[1]);
		pRow_row2.area = row_tAsyncIn_tDBOutput_2[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[2]);
		
		
			String temp_tAsyncIn_tDBOutput_2_3 = row_tAsyncIn_tDBOutput_2[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[3]);
			if(temp_tAsyncIn_tDBOutput_2_3 != null) {
		
			pRow_row2.branch_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_3);
		} else {						
			pRow_row2.branch_id = 0;
		}
		pRow_row2.branch = row_tAsyncIn_tDBOutput_2[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[4]);
		
		
			String temp_tAsyncIn_tDBOutput_2_5 = row_tAsyncIn_tDBOutput_2[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[5]);
			if(temp_tAsyncIn_tDBOutput_2_5 != null) {
		
			pRow_row2.month_audit_cycle = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_5);
		} else {						
			pRow_row2.month_audit_cycle = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_6 = row_tAsyncIn_tDBOutput_2[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[6]);
			if(temp_tAsyncIn_tDBOutput_2_6 != null) {
		
			pRow_row2.year = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_6);
		} else {						
			pRow_row2.year = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_7 = row_tAsyncIn_tDBOutput_2[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[7]);
			if(temp_tAsyncIn_tDBOutput_2_7 != null) {
		
			pRow_row2.audit_no = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_7);
		} else {						
			pRow_row2.audit_no = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_8 = row_tAsyncIn_tDBOutput_2[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[8]);
			if(temp_tAsyncIn_tDBOutput_2_8 != null) {
		
			pRow_row2.audited_from_date = (java.util.Date)(row_tAsyncIn_tDBOutput_2[8]);
		} else {						
			pRow_row2.audited_from_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_9 = row_tAsyncIn_tDBOutput_2[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[9]);
			if(temp_tAsyncIn_tDBOutput_2_9 != null) {
		
			pRow_row2.audited_to_date = (java.util.Date)(row_tAsyncIn_tDBOutput_2[9]);
		} else {						
			pRow_row2.audited_to_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_10 = row_tAsyncIn_tDBOutput_2[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[10]);
			if(temp_tAsyncIn_tDBOutput_2_10 != null) {
		
			pRow_row2.auditor_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_10);
		} else {						
			pRow_row2.auditor_id = 0;
		}
		pRow_row2.auditor = row_tAsyncIn_tDBOutput_2[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[11]);
		
		
			String temp_tAsyncIn_tDBOutput_2_12 = row_tAsyncIn_tDBOutput_2[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[12]);
			if(temp_tAsyncIn_tDBOutput_2_12 != null) {
		
			pRow_row2.audit_plan_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_12);
		} else {						
			pRow_row2.audit_plan_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_13 = row_tAsyncIn_tDBOutput_2[13]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[13]);
			if(temp_tAsyncIn_tDBOutput_2_13 != null) {
		
			pRow_row2.noofcenter_attended_by_auditor = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_13);
		} else {						
			pRow_row2.noofcenter_attended_by_auditor = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_14 = row_tAsyncIn_tDBOutput_2[14]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[14]);
			if(temp_tAsyncIn_tDBOutput_2_14 != null) {
		
			pRow_row2.no_of_luc_done_by_auditor = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_14);
		} else {						
			pRow_row2.no_of_luc_done_by_auditor = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_15 = row_tAsyncIn_tDBOutput_2[15]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[15]);
			if(temp_tAsyncIn_tDBOutput_2_15 != null) {
		
			pRow_row2.no_of_cre = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_15);
		} else {						
			pRow_row2.no_of_cre = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_16 = row_tAsyncIn_tDBOutput_2[16]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[16]);
			if(temp_tAsyncIn_tDBOutput_2_16 != null) {
		
			pRow_row2.total_no_of_center = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_16);
		} else {						
			pRow_row2.total_no_of_center = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_17 = row_tAsyncIn_tDBOutput_2[17]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[17]);
			if(temp_tAsyncIn_tDBOutput_2_17 != null) {
		
			pRow_row2.total_no_of_members = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_17);
		} else {						
			pRow_row2.total_no_of_members = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_18 = row_tAsyncIn_tDBOutput_2[18]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[18]);
			if(temp_tAsyncIn_tDBOutput_2_18 != null) {
		
			pRow_row2.total_luc = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_18);
		} else {						
			pRow_row2.total_luc = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_19 = row_tAsyncIn_tDBOutput_2[19]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[19]);
			if(temp_tAsyncIn_tDBOutput_2_19 != null) {
		
			pRow_row2.active_borrowers = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_19);
		} else {						
			pRow_row2.active_borrowers = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_20 = row_tAsyncIn_tDBOutput_2[20]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[20]);
			if(temp_tAsyncIn_tDBOutput_2_20 != null) {
		
			pRow_row2.principal_Os = ParserUtils.parseTo_Float(temp_tAsyncIn_tDBOutput_2_20);
		} else {						
			pRow_row2.principal_Os = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_21 = row_tAsyncIn_tDBOutput_2[21]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[21]);
			if(temp_tAsyncIn_tDBOutput_2_21 != null) {
		
			pRow_row2.percentage_of_center_coverage = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_21);
		} else {						
			pRow_row2.percentage_of_center_coverage = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_22 = row_tAsyncIn_tDBOutput_2[22]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[22]);
			if(temp_tAsyncIn_tDBOutput_2_22 != null) {
		
			pRow_row2.percetage_of_luc_coverage = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_22);
		} else {						
			pRow_row2.percetage_of_luc_coverage = null;
		}
		pRow_row2.grade = row_tAsyncIn_tDBOutput_2[23]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[23]);
		pRow_row2.grade_risk = row_tAsyncIn_tDBOutput_2[24]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[24]);
		
		
			String temp_tAsyncIn_tDBOutput_2_25 = row_tAsyncIn_tDBOutput_2[25]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[25]);
			if(temp_tAsyncIn_tDBOutput_2_25 != null) {
		
			pRow_row2.total_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_25);
		} else {						
			pRow_row2.total_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_26 = row_tAsyncIn_tDBOutput_2[26]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[26]);
			if(temp_tAsyncIn_tDBOutput_2_26 != null) {
		
			pRow_row2.actual_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_26);
		} else {						
			pRow_row2.actual_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_27 = row_tAsyncIn_tDBOutput_2[27]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[27]);
			if(temp_tAsyncIn_tDBOutput_2_27 != null) {
		
			pRow_row2.percetage_of_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_27);
		} else {						
			pRow_row2.percetage_of_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_28 = row_tAsyncIn_tDBOutput_2[28]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[28]);
			if(temp_tAsyncIn_tDBOutput_2_28 != null) {
		
			pRow_row2.is_force_audit_update = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_28);
		} else {						
			pRow_row2.is_force_audit_update = null;
		}
		pRow_row2.description = row_tAsyncIn_tDBOutput_2[29]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[29]);
		
		
			String temp_tAsyncIn_tDBOutput_2_30 = row_tAsyncIn_tDBOutput_2[30]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[30]);
			if(temp_tAsyncIn_tDBOutput_2_30 != null) {
		
			pRow_row2.force_audit_updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_30);
		} else {						
			pRow_row2.force_audit_updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_31 = row_tAsyncIn_tDBOutput_2[31]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[31]);
			if(temp_tAsyncIn_tDBOutput_2_31 != null) {
		
			pRow_row2.force_audit_updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_2[31]);
		} else {						
			pRow_row2.force_audit_updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_32 = row_tAsyncIn_tDBOutput_2[32]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[32]);
			if(temp_tAsyncIn_tDBOutput_2_32 != null) {
		
			pRow_row2.risk_actual_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_32);
		} else {						
			pRow_row2.risk_actual_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_33 = row_tAsyncIn_tDBOutput_2[33]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[33]);
			if(temp_tAsyncIn_tDBOutput_2_33 != null) {
		
			pRow_row2.risk_total_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_33);
		} else {						
			pRow_row2.risk_total_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_34 = row_tAsyncIn_tDBOutput_2[34]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[34]);
			if(temp_tAsyncIn_tDBOutput_2_34 != null) {
		
			pRow_row2.critical_max_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_34);
		} else {						
			pRow_row2.critical_max_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_35 = row_tAsyncIn_tDBOutput_2[35]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[35]);
			if(temp_tAsyncIn_tDBOutput_2_35 != null) {
		
			pRow_row2.critical_obtain_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_35);
		} else {						
			pRow_row2.critical_obtain_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_36 = row_tAsyncIn_tDBOutput_2[36]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[36]);
			if(temp_tAsyncIn_tDBOutput_2_36 != null) {
		
			pRow_row2.high_max_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_36);
		} else {						
			pRow_row2.high_max_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_37 = row_tAsyncIn_tDBOutput_2[37]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[37]);
			if(temp_tAsyncIn_tDBOutput_2_37 != null) {
		
			pRow_row2.high_obtain_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_37);
		} else {						
			pRow_row2.high_obtain_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_38 = row_tAsyncIn_tDBOutput_2[38]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[38]);
			if(temp_tAsyncIn_tDBOutput_2_38 != null) {
		
			pRow_row2.medium_max_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_38);
		} else {						
			pRow_row2.medium_max_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_39 = row_tAsyncIn_tDBOutput_2[39]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[39]);
			if(temp_tAsyncIn_tDBOutput_2_39 != null) {
		
			pRow_row2.medium_obtain_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_39);
		} else {						
			pRow_row2.medium_obtain_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_40 = row_tAsyncIn_tDBOutput_2[40]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[40]);
			if(temp_tAsyncIn_tDBOutput_2_40 != null) {
		
			pRow_row2.low_max_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_40);
		} else {						
			pRow_row2.low_max_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_41 = row_tAsyncIn_tDBOutput_2[41]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[41]);
			if(temp_tAsyncIn_tDBOutput_2_41 != null) {
		
			pRow_row2.risk_percentage_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_41);
		} else {						
			pRow_row2.risk_percentage_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_42 = row_tAsyncIn_tDBOutput_2[42]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[42]);
			if(temp_tAsyncIn_tDBOutput_2_42 != null) {
		
			pRow_row2.low_obtain_score = ParserUtils.parseTo_Double(temp_tAsyncIn_tDBOutput_2_42);
		} else {						
			pRow_row2.low_obtain_score = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_43 = row_tAsyncIn_tDBOutput_2[43]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[43]);
			if(temp_tAsyncIn_tDBOutput_2_43 != null) {
		
			pRow_row2.bm_status = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_43);
		} else {						
			pRow_row2.bm_status = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_44 = row_tAsyncIn_tDBOutput_2[44]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[44]);
			if(temp_tAsyncIn_tDBOutput_2_44 != null) {
		
			pRow_row2.dam_status = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_44);
		} else {						
			pRow_row2.dam_status = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_45 = row_tAsyncIn_tDBOutput_2[45]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[45]);
			if(temp_tAsyncIn_tDBOutput_2_45 != null) {
		
			pRow_row2.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_45);
		} else {						
			pRow_row2.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_46 = row_tAsyncIn_tDBOutput_2[46]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[46]);
			if(temp_tAsyncIn_tDBOutput_2_46 != null) {
		
			pRow_row2.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_2[46]);
		} else {						
			pRow_row2.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_47 = row_tAsyncIn_tDBOutput_2[47]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[47]);
			if(temp_tAsyncIn_tDBOutput_2_47 != null) {
		
			pRow_row2.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_47);
		} else {						
			pRow_row2.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_48 = row_tAsyncIn_tDBOutput_2[48]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[48]);
			if(temp_tAsyncIn_tDBOutput_2_48 != null) {
		
			pRow_row2.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_2[48]);
		} else {						
			pRow_row2.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_49 = row_tAsyncIn_tDBOutput_2[49]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[49]);
			if(temp_tAsyncIn_tDBOutput_2_49 != null) {
		
			pRow_row2.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_49);
		} else {						
			pRow_row2.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_50 = row_tAsyncIn_tDBOutput_2[50]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[50]);
			if(temp_tAsyncIn_tDBOutput_2_50 != null) {
		
			pRow_row2.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_50);
		} else {						
			pRow_row2.is_deleted = 0;
		}
		pRow_row2.branch_audit_details_id = row_tAsyncIn_tDBOutput_2[51]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[51]);
		
		
			String temp_tAsyncIn_tDBOutput_2_52 = row_tAsyncIn_tDBOutput_2[52]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[52]);
			if(temp_tAsyncIn_tDBOutput_2_52 != null) {
		
			pRow_row2.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_2[52]);
		} else {						
			pRow_row2.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_2 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 


	tos_count_tAsyncIn_tDBOutput_2++;

/**
 * [tAsyncIn_tDBOutput_2 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 



/**
 * [tAsyncIn_tDBOutput_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"branch_audit_details_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row2","tAsyncIn_tDBOutput_2","tAsyncIn_tDBOutput_2","tAsyncIn","tDBOutput_2","\"branch_audit_details_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row2 - " + (pRow_row2==null? "": pRow_row2.toLogString()));
    			}
    		



				batchSize_tDBOutput_2 = buffersSize_tAsyncIn_tDBOutput_2;
        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, pRow_row2.id);

                    if(pRow_row2.division == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, pRow_row2.division);
}

                    if(pRow_row2.area == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, pRow_row2.area);
}

                    pstmt_tDBOutput_2.setInt(4, pRow_row2.branch_id);

                    if(pRow_row2.branch == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, pRow_row2.branch);
}

                    if(pRow_row2.month_audit_cycle == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(6, pRow_row2.month_audit_cycle);
}

                    if(pRow_row2.year == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(7, pRow_row2.year);
}

                    if(pRow_row2.audit_no == null) {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(8, pRow_row2.audit_no);
}

                    if(pRow_row2.audited_from_date != null) {
pstmt_tDBOutput_2.setTimestamp(9, new java.sql.Timestamp(pRow_row2.audited_from_date.getTime()));
} else {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row2.audited_to_date != null) {
pstmt_tDBOutput_2.setTimestamp(10, new java.sql.Timestamp(pRow_row2.audited_to_date.getTime()));
} else {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_2.setInt(11, pRow_row2.auditor_id);

                    if(pRow_row2.auditor == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(12, pRow_row2.auditor);
}

                    pstmt_tDBOutput_2.setInt(13, pRow_row2.audit_plan_id);

                    if(pRow_row2.noofcenter_attended_by_auditor == null) {
pstmt_tDBOutput_2.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(14, pRow_row2.noofcenter_attended_by_auditor);
}

                    if(pRow_row2.no_of_luc_done_by_auditor == null) {
pstmt_tDBOutput_2.setNull(15, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(15, pRow_row2.no_of_luc_done_by_auditor);
}

                    if(pRow_row2.no_of_cre == null) {
pstmt_tDBOutput_2.setNull(16, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(16, pRow_row2.no_of_cre);
}

                    if(pRow_row2.total_no_of_center == null) {
pstmt_tDBOutput_2.setNull(17, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(17, pRow_row2.total_no_of_center);
}

                    if(pRow_row2.total_no_of_members == null) {
pstmt_tDBOutput_2.setNull(18, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(18, pRow_row2.total_no_of_members);
}

                    if(pRow_row2.total_luc == null) {
pstmt_tDBOutput_2.setNull(19, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(19, pRow_row2.total_luc);
}

                    if(pRow_row2.active_borrowers == null) {
pstmt_tDBOutput_2.setNull(20, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(20, pRow_row2.active_borrowers);
}

                    if(pRow_row2.principal_Os == null) {
pstmt_tDBOutput_2.setNull(21, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_2.setFloat(21, pRow_row2.principal_Os);
}

                    if(pRow_row2.percentage_of_center_coverage == null) {
pstmt_tDBOutput_2.setNull(22, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(22, pRow_row2.percentage_of_center_coverage);
}

                    if(pRow_row2.percetage_of_luc_coverage == null) {
pstmt_tDBOutput_2.setNull(23, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(23, pRow_row2.percetage_of_luc_coverage);
}

                    if(pRow_row2.grade == null) {
pstmt_tDBOutput_2.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(24, pRow_row2.grade);
}

                    if(pRow_row2.grade_risk == null) {
pstmt_tDBOutput_2.setNull(25, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(25, pRow_row2.grade_risk);
}

                    if(pRow_row2.total_score == null) {
pstmt_tDBOutput_2.setNull(26, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(26, pRow_row2.total_score);
}

                    if(pRow_row2.actual_score == null) {
pstmt_tDBOutput_2.setNull(27, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(27, pRow_row2.actual_score);
}

                    if(pRow_row2.percetage_of_score == null) {
pstmt_tDBOutput_2.setNull(28, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(28, pRow_row2.percetage_of_score);
}

                    if(pRow_row2.is_force_audit_update == null) {
pstmt_tDBOutput_2.setNull(29, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(29, pRow_row2.is_force_audit_update);
}

                    if(pRow_row2.description == null) {
pstmt_tDBOutput_2.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(30, pRow_row2.description);
}

                    if(pRow_row2.force_audit_updated_by == null) {
pstmt_tDBOutput_2.setNull(31, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(31, pRow_row2.force_audit_updated_by);
}

                    if(pRow_row2.force_audit_updated_on != null) {
pstmt_tDBOutput_2.setTimestamp(32, new java.sql.Timestamp(pRow_row2.force_audit_updated_on.getTime()));
} else {
pstmt_tDBOutput_2.setNull(32, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row2.risk_actual_score == null) {
pstmt_tDBOutput_2.setNull(33, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(33, pRow_row2.risk_actual_score);
}

                    if(pRow_row2.risk_total_score == null) {
pstmt_tDBOutput_2.setNull(34, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(34, pRow_row2.risk_total_score);
}

                    if(pRow_row2.critical_max_score == null) {
pstmt_tDBOutput_2.setNull(35, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(35, pRow_row2.critical_max_score);
}

                    if(pRow_row2.critical_obtain_score == null) {
pstmt_tDBOutput_2.setNull(36, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(36, pRow_row2.critical_obtain_score);
}

                    if(pRow_row2.high_max_score == null) {
pstmt_tDBOutput_2.setNull(37, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(37, pRow_row2.high_max_score);
}

                    if(pRow_row2.high_obtain_score == null) {
pstmt_tDBOutput_2.setNull(38, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(38, pRow_row2.high_obtain_score);
}

                    if(pRow_row2.medium_max_score == null) {
pstmt_tDBOutput_2.setNull(39, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(39, pRow_row2.medium_max_score);
}

                    if(pRow_row2.medium_obtain_score == null) {
pstmt_tDBOutput_2.setNull(40, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(40, pRow_row2.medium_obtain_score);
}

                    if(pRow_row2.low_max_score == null) {
pstmt_tDBOutput_2.setNull(41, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(41, pRow_row2.low_max_score);
}

                    if(pRow_row2.risk_percentage_score == null) {
pstmt_tDBOutput_2.setNull(42, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(42, pRow_row2.risk_percentage_score);
}

                    if(pRow_row2.low_obtain_score == null) {
pstmt_tDBOutput_2.setNull(43, java.sql.Types.DOUBLE);
} else {pstmt_tDBOutput_2.setDouble(43, pRow_row2.low_obtain_score);
}

                    if(pRow_row2.bm_status == null) {
pstmt_tDBOutput_2.setNull(44, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(44, pRow_row2.bm_status);
}

                    if(pRow_row2.dam_status == null) {
pstmt_tDBOutput_2.setNull(45, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(45, pRow_row2.dam_status);
}

                    if(pRow_row2.created_by == null) {
pstmt_tDBOutput_2.setNull(46, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(46, pRow_row2.created_by);
}

                    if(pRow_row2.created_on != null) {
pstmt_tDBOutput_2.setTimestamp(47, new java.sql.Timestamp(pRow_row2.created_on.getTime()));
} else {
pstmt_tDBOutput_2.setNull(47, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row2.updated_by == null) {
pstmt_tDBOutput_2.setNull(48, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(48, pRow_row2.updated_by);
}

                    if(pRow_row2.updated_on != null) {
pstmt_tDBOutput_2.setTimestamp(49, new java.sql.Timestamp(pRow_row2.updated_on.getTime()));
} else {
pstmt_tDBOutput_2.setNull(49, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_2.setInt(50, pRow_row2.is_active);

                    pstmt_tDBOutput_2.setInt(51, pRow_row2.is_deleted);

                    if(pRow_row2.branch_audit_details_id == null) {
pstmt_tDBOutput_2.setNull(52, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(52, pRow_row2.branch_audit_details_id);
}

                    if(pRow_row2.as_on != null) {
pstmt_tDBOutput_2.setTimestamp(53, new java.sql.Timestamp(pRow_row2.as_on.getTime()));
} else {
pstmt_tDBOutput_2.setNull(53, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"branch_audit_details_dw\"";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"branch_audit_details_dw\"";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 



/**
 * [tAsyncIn_tDBOutput_2 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_2.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_2", true);
end_Hash.put("tAsyncIn_tDBOutput_2", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"branch_audit_details_dw\"";
		



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
    	if (globalMap.get("tDBOutput_2_NB_LINE") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE",(Integer)globalMap.get("tDBOutput_2_NB_LINE") + nb_line_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_UPDATED") + nb_line_update_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_2);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row2",2,0,
			 			"tAsyncIn_tDBOutput_2","tAsyncIn_tDBOutput_2","tAsyncIn","tDBOutput_2","\"branch_audit_details_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 



/**
 * [tAsyncIn_tDBOutput_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"branch_audit_details_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_2");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_2_ParallelThread pt = new tAsyncIn_tDBOutput_2_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_2"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_2_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row3Struct implements routines.system.IPersistableRow<pRow_row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String apk_version;

				public String getApk_version () {
					return this.apk_version;
				}

				public Boolean apk_versionIsNullable(){
				    return true;
				}
				public Boolean apk_versionIsKey(){
				    return false;
				}
				public Integer apk_versionLength(){
				    return 45;
				}
				public Integer apk_versionPrecision(){
				    return 0;
				}
				public String apk_versionDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String apk_versionComment(){
				
				    return "";
				
				}
				public String apk_versionPattern(){
				
					return "";
				
				}
				public String apk_versionOriginalDbColumnName(){
				
					return "apk_version";
				
				}

				
			    public String apk_url;

				public String getApk_url () {
					return this.apk_url;
				}

				public Boolean apk_urlIsNullable(){
				    return true;
				}
				public Boolean apk_urlIsKey(){
				    return false;
				}
				public Integer apk_urlLength(){
				    return 150;
				}
				public Integer apk_urlPrecision(){
				    return 0;
				}
				public String apk_urlDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String apk_urlComment(){
				
				    return "";
				
				}
				public String apk_urlPattern(){
				
					return "";
				
				}
				public String apk_urlOriginalDbColumnName(){
				
					return "apk_url";
				
				}

				
			    public String created_by;

				public String getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 45;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return true;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public String updated_by;

				public String getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 45;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return true;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public Integer is_active;

				public Integer getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return true;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public Integer is_deleted;

				public Integer getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return true;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row3Struct other = (pRow_row3Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row3Struct other) {

		other.id = this.id;
	            other.apk_version = this.apk_version;
	            other.apk_url = this.apk_url;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row3Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.apk_version = readString(dis);
					
					this.apk_url = readString(dis);
					
					this.created_by = readString(dis);
					
					this.created_on = readDate(dis);
					
					this.updated_by = readString(dis);
					
					this.updated_on = readDate(dis);
					
						this.is_active = readInteger(dis);
					
						this.is_deleted = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.apk_version = readString(dis);
					
					this.apk_url = readString(dis);
					
					this.created_by = readString(dis);
					
					this.created_on = readDate(dis);
					
					this.updated_by = readString(dis);
					
					this.updated_on = readDate(dis);
					
						this.is_active = readInteger(dis);
					
						this.is_deleted = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.apk_version,dos);
					
					// String
				
						writeString(this.apk_url,dos);
					
					// String
				
						writeString(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// String
				
						writeString(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// Integer
				
						writeInteger(this.is_active,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.apk_version,dos);
					
					// String
				
						writeString(this.apk_url,dos);
					
					// String
				
						writeString(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// String
				
						writeString(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// Integer
				
						writeInteger(this.is_active,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",apk_version="+apk_version);
		sb.append(",apk_url="+apk_url);
		sb.append(",created_by="+created_by);
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+updated_by);
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(apk_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(apk_version);
            			}
            		
        			sb.append("|");
        		
        				if(apk_url == null){
        					sb.append("<null>");
        				}else{
            				sb.append(apk_url);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				if(is_active == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_active);
            			}
            		
        			sb.append("|");
        		
        				if(is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_3");
		org.slf4j.MDC.put("_subJobPid", "BW8Trq_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_3");
		class tAsyncIn_tDBOutput_3_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_3_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row3Struct pRow_row3 = new pRow_row3Struct();




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_apk_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row3");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"mst_apk_dw\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "\"mst_apk_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_3 = null;
	dbschema_tDBOutput_3 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_3 = null;
if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
	tableName_tDBOutput_3 = ("mst_apk_dw");
} else {
	tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "\".\"" + ("mst_apk_dw");
}


int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

boolean whetherReject_tDBOutput_3 = false;

java.sql.Connection conn_tDBOutput_3 = null;
String dbUser_tDBOutput_3 = null;

	conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_3 = 10000;
   int batchSizeCounter_tDBOutput_3=0;

int count_tDBOutput_3=0;
        java.lang.StringBuilder sb_tDBOutput_3 = new java.lang.StringBuilder();
        sb_tDBOutput_3.append("INSERT INTO \"").append(tableName_tDBOutput_3).append("\" (\"id\",\"apk_version\",\"apk_url\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_3.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"apk_version\" = EXCLUDED.\"apk_version\",\"apk_url\" = EXCLUDED.\"apk_url\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_3 = sb_tDBOutput_3.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing '")  + (insert_tDBOutput_3)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_3", false);
		start_Hash.put("tAsyncIn_tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	
		int tos_count_tAsyncIn_tDBOutput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_3", "tAsyncIn_tDBOutput_3", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_3= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_3 = buffers_tAsyncIn_tDBOutput_3.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_3 != null && buffers_tAsyncIn_tDBOutput_3.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_3 : buffers_tAsyncIn_tDBOutput_3) {
    		pRow_row3 = null;						
			pRow_row3 = new pRow_row3Struct();
		
		
			String temp_tAsyncIn_tDBOutput_3_0 = row_tAsyncIn_tDBOutput_3[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[0]);
			if(temp_tAsyncIn_tDBOutput_3_0 != null) {
		
			pRow_row3.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_3_0);
		} else {						
			pRow_row3.id = 0;
		}
		pRow_row3.apk_version = row_tAsyncIn_tDBOutput_3[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[1]);
		pRow_row3.apk_url = row_tAsyncIn_tDBOutput_3[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[2]);
		pRow_row3.created_by = row_tAsyncIn_tDBOutput_3[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[3]);
		
		
			String temp_tAsyncIn_tDBOutput_3_4 = row_tAsyncIn_tDBOutput_3[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[4]);
			if(temp_tAsyncIn_tDBOutput_3_4 != null) {
		
			pRow_row3.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_3[4]);
		} else {						
			pRow_row3.created_on = null;
		}
		pRow_row3.updated_by = row_tAsyncIn_tDBOutput_3[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[5]);
		
		
			String temp_tAsyncIn_tDBOutput_3_6 = row_tAsyncIn_tDBOutput_3[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[6]);
			if(temp_tAsyncIn_tDBOutput_3_6 != null) {
		
			pRow_row3.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_3[6]);
		} else {						
			pRow_row3.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_3_7 = row_tAsyncIn_tDBOutput_3[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[7]);
			if(temp_tAsyncIn_tDBOutput_3_7 != null) {
		
			pRow_row3.is_active = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_3_7);
		} else {						
			pRow_row3.is_active = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_3_8 = row_tAsyncIn_tDBOutput_3[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[8]);
			if(temp_tAsyncIn_tDBOutput_3_8 != null) {
		
			pRow_row3.is_deleted = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_3_8);
		} else {						
			pRow_row3.is_deleted = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_3_9 = row_tAsyncIn_tDBOutput_3[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[9]);
			if(temp_tAsyncIn_tDBOutput_3_9 != null) {
		
			pRow_row3.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_3[9]);
		} else {						
			pRow_row3.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_3 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

 


	tos_count_tAsyncIn_tDBOutput_3++;

/**
 * [tAsyncIn_tDBOutput_3 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

 



/**
 * [tAsyncIn_tDBOutput_3 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_apk_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row3","tAsyncIn_tDBOutput_3","tAsyncIn_tDBOutput_3","tAsyncIn","tDBOutput_3","\"mst_apk_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row3 - " + (pRow_row3==null? "": pRow_row3.toLogString()));
    			}
    		



				batchSize_tDBOutput_3 = buffersSize_tAsyncIn_tDBOutput_3;
        whetherReject_tDBOutput_3 = false;
                    pstmt_tDBOutput_3.setInt(1, pRow_row3.id);

                    if(pRow_row3.apk_version == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, pRow_row3.apk_version);
}

                    if(pRow_row3.apk_url == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(3, pRow_row3.apk_url);
}

                    if(pRow_row3.created_by == null) {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(4, pRow_row3.created_by);
}

                    if(pRow_row3.created_on != null) {
pstmt_tDBOutput_3.setTimestamp(5, new java.sql.Timestamp(pRow_row3.created_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row3.updated_by == null) {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(6, pRow_row3.updated_by);
}

                    if(pRow_row3.updated_on != null) {
pstmt_tDBOutput_3.setTimestamp(7, new java.sql.Timestamp(pRow_row3.updated_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row3.is_active == null) {
pstmt_tDBOutput_3.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(8, pRow_row3.is_active);
}

                    if(pRow_row3.is_deleted == null) {
pstmt_tDBOutput_3.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(9, pRow_row3.is_deleted);
}

                    if(pRow_row3.as_on != null) {
pstmt_tDBOutput_3.setTimestamp(10, new java.sql.Timestamp(pRow_row3.as_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(10, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_3.addBatch();
    		nb_line_tDBOutput_3++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Adding the record ")  + (nb_line_tDBOutput_3)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_3++;
    		  
    			if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                try {
						int countSum_tDBOutput_3 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            	    	batchSizeCounter_tDBOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
				    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
				    	String errormessage_tDBOutput_3;
						if (ne_tDBOutput_3 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
							errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
						}else{
							errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
						}
				    	
				    	int countSum_tDBOutput_3 = 0;
						for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
				    	System.err.println(errormessage_tDBOutput_3);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_apk_dw\"";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_apk_dw\"";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

 



/**
 * [tAsyncIn_tDBOutput_3 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_3.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_3", true);
end_Hash.put("tAsyncIn_tDBOutput_3", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_3 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_apk_dw\"";
		



	    try {
				int countSum_tDBOutput_3 = 0;
				if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
	    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
	    	String errormessage_tDBOutput_3;
			if (ne_tDBOutput_3 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
				errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
			}else{
				errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
			}
	    	
	    	int countSum_tDBOutput_3 = 0;
			for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
				countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
			}
			rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
			
	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
	    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
	    	System.err.println(errormessage_tDBOutput_3);
	    	
		}
	    
        if(pstmt_tDBOutput_3 != null) {
        		
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
    	if (globalMap.get("tDBOutput_3_NB_LINE") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE",(Integer)globalMap.get("tDBOutput_3_NB_LINE") + nb_line_tDBOutput_3);
        }
        if (globalMap.get("tDBOutput_3_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_3_NB_LINE_UPDATED") + nb_line_update_tDBOutput_3);
        }
        if (globalMap.get("tDBOutput_3_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_3_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_3);
        }
        if (globalMap.get("tDBOutput_3_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_3_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_3);
        }
        if (globalMap.get("tDBOutput_3_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_3_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_3);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row3",2,0,
			 			"tAsyncIn_tDBOutput_3","tAsyncIn_tDBOutput_3","tAsyncIn","tDBOutput_3","\"mst_apk_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

 



/**
 * [tAsyncIn_tDBOutput_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_apk_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_3");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_3_ParallelThread pt = new tAsyncIn_tDBOutput_3_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_3"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_3_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row4Struct implements routines.system.IPersistableRow<pRow_row4Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String criteria;

				public String getCriteria () {
					return this.criteria;
				}

				public Boolean criteriaIsNullable(){
				    return false;
				}
				public Boolean criteriaIsKey(){
				    return false;
				}
				public Integer criteriaLength(){
				    return 200;
				}
				public Integer criteriaPrecision(){
				    return 0;
				}
				public String criteriaDefault(){
				
					return null;
				
				}
				public String criteriaComment(){
				
				    return "";
				
				}
				public String criteriaPattern(){
				
					return "";
				
				}
				public String criteriaOriginalDbColumnName(){
				
					return "criteria";
				
				}

				
			    public Integer data_period;

				public Integer getData_period () {
					return this.data_period;
				}

				public Boolean data_periodIsNullable(){
				    return true;
				}
				public Boolean data_periodIsKey(){
				    return false;
				}
				public Integer data_periodLength(){
				    return 10;
				}
				public Integer data_periodPrecision(){
				    return 0;
				}
				public String data_periodDefault(){
				
					return null;
				
				}
				public String data_periodComment(){
				
				    return "";
				
				}
				public String data_periodPattern(){
				
					return "";
				
				}
				public String data_periodOriginalDbColumnName(){
				
					return "data_period";
				
				}

				
			    public Float cut_off;

				public Float getCut_off () {
					return this.cut_off;
				}

				public Boolean cut_offIsNullable(){
				    return true;
				}
				public Boolean cut_offIsKey(){
				    return false;
				}
				public Integer cut_offLength(){
				    return 8;
				}
				public Integer cut_offPrecision(){
				    return 8;
				}
				public String cut_offDefault(){
				
					return null;
				
				}
				public String cut_offComment(){
				
				    return "";
				
				}
				public String cut_offPattern(){
				
					return "";
				
				}
				public String cut_offOriginalDbColumnName(){
				
					return "cut_off";
				
				}

				
			    public String criteria_type;

				public String getCriteria_type () {
					return this.criteria_type;
				}

				public Boolean criteria_typeIsNullable(){
				    return true;
				}
				public Boolean criteria_typeIsKey(){
				    return false;
				}
				public Integer criteria_typeLength(){
				    return 10;
				}
				public Integer criteria_typePrecision(){
				    return 0;
				}
				public String criteria_typeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String criteria_typeComment(){
				
				    return "";
				
				}
				public String criteria_typePattern(){
				
					return "";
				
				}
				public String criteria_typeOriginalDbColumnName(){
				
					return "criteria_type";
				
				}

				
			    public int is_default;

				public int getIs_default () {
					return this.is_default;
				}

				public Boolean is_defaultIsNullable(){
				    return false;
				}
				public Boolean is_defaultIsKey(){
				    return false;
				}
				public Integer is_defaultLength(){
				    return 10;
				}
				public Integer is_defaultPrecision(){
				    return 0;
				}
				public String is_defaultDefault(){
				
					return "0";
				
				}
				public String is_defaultComment(){
				
				    return "";
				
				}
				public String is_defaultPattern(){
				
					return "";
				
				}
				public String is_defaultOriginalDbColumnName(){
				
					return "is_default";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String audit_criteria_id;

				public String getAudit_criteria_id () {
					return this.audit_criteria_id;
				}

				public Boolean audit_criteria_idIsNullable(){
				    return true;
				}
				public Boolean audit_criteria_idIsKey(){
				    return false;
				}
				public Integer audit_criteria_idLength(){
				    return 32;
				}
				public Integer audit_criteria_idPrecision(){
				    return 0;
				}
				public String audit_criteria_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String audit_criteria_idComment(){
				
				    return "";
				
				}
				public String audit_criteria_idPattern(){
				
					return "";
				
				}
				public String audit_criteria_idOriginalDbColumnName(){
				
					return "audit_criteria_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row4Struct other = (pRow_row4Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row4Struct other) {

		other.id = this.id;
	            other.criteria = this.criteria;
	            other.data_period = this.data_period;
	            other.cut_off = this.cut_off;
	            other.criteria_type = this.criteria_type;
	            other.is_default = this.is_default;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.audit_criteria_id = this.audit_criteria_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row4Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.criteria = readString(dis);
					
						this.data_period = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.cut_off = null;
           				} else {
           			    	this.cut_off = dis.readFloat();
           				}
					
					this.criteria_type = readString(dis);
					
			        this.is_default = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.audit_criteria_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.criteria = readString(dis);
					
						this.data_period = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.cut_off = null;
           				} else {
           			    	this.cut_off = dis.readFloat();
           				}
					
					this.criteria_type = readString(dis);
					
			        this.is_default = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.audit_criteria_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.criteria,dos);
					
					// Integer
				
						writeInteger(this.data_period,dos);
					
					// Float
				
						if(this.cut_off == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.cut_off);
		            	}
					
					// String
				
						writeString(this.criteria_type,dos);
					
					// int
				
		            	dos.writeInt(this.is_default);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.audit_criteria_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.criteria,dos);
					
					// Integer
				
						writeInteger(this.data_period,dos);
					
					// Float
				
						if(this.cut_off == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.cut_off);
		            	}
					
					// String
				
						writeString(this.criteria_type,dos);
					
					// int
				
		            	dos.writeInt(this.is_default);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.audit_criteria_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",criteria="+criteria);
		sb.append(",data_period="+String.valueOf(data_period));
		sb.append(",cut_off="+String.valueOf(cut_off));
		sb.append(",criteria_type="+criteria_type);
		sb.append(",is_default="+String.valueOf(is_default));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",audit_criteria_id="+audit_criteria_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(criteria == null){
        					sb.append("<null>");
        				}else{
            				sb.append(criteria);
            			}
            		
        			sb.append("|");
        		
        				if(data_period == null){
        					sb.append("<null>");
        				}else{
            				sb.append(data_period);
            			}
            		
        			sb.append("|");
        		
        				if(cut_off == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cut_off);
            			}
            		
        			sb.append("|");
        		
        				if(criteria_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(criteria_type);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_default);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(audit_criteria_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_criteria_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_4");
		org.slf4j.MDC.put("_subJobPid", "8fyi7m_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_4");
		class tAsyncIn_tDBOutput_4_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_4_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row4Struct pRow_row4 = new pRow_row4Struct();




	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_audit_criteria_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row4");
			
		int tos_count_tDBOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
                    log4jParamters_tDBOutput_4.append("Parameters:");
                            log4jParamters_tDBOutput_4.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"mst_audit_criteria_dw\"");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + (log4jParamters_tDBOutput_4) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_4", "\"mst_audit_criteria_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_4 = null;
	dbschema_tDBOutput_4 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_4 = null;
if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
	tableName_tDBOutput_4 = ("mst_audit_criteria_dw");
} else {
	tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "\".\"" + ("mst_audit_criteria_dw");
}


int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

boolean whetherReject_tDBOutput_4 = false;

java.sql.Connection conn_tDBOutput_4 = null;
String dbUser_tDBOutput_4 = null;

	conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_4.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_4.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_4 = 10000;
   int batchSizeCounter_tDBOutput_4=0;

int count_tDBOutput_4=0;
        java.lang.StringBuilder sb_tDBOutput_4 = new java.lang.StringBuilder();
        sb_tDBOutput_4.append("INSERT INTO \"").append(tableName_tDBOutput_4).append("\" (\"id\",\"criteria\",\"data_period\",\"cut_off\",\"criteria_type\",\"is_default\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"audit_criteria_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_4.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"criteria\" = EXCLUDED.\"criteria\",\"data_period\" = EXCLUDED.\"data_period\",\"cut_off\" = EXCLUDED.\"cut_off\",\"criteria_type\" = EXCLUDED.\"criteria_type\",\"is_default\" = EXCLUDED.\"is_default\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"audit_criteria_id\" = EXCLUDED.\"audit_criteria_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_4 = sb_tDBOutput_4.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing '")  + (insert_tDBOutput_4)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
	    resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
	    

 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_4", false);
		start_Hash.put("tAsyncIn_tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	
		int tos_count_tAsyncIn_tDBOutput_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_4", "tAsyncIn_tDBOutput_4", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_4= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_4 = buffers_tAsyncIn_tDBOutput_4.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_4 != null && buffers_tAsyncIn_tDBOutput_4.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_4 : buffers_tAsyncIn_tDBOutput_4) {
    		pRow_row4 = null;						
			pRow_row4 = new pRow_row4Struct();
		
		
			String temp_tAsyncIn_tDBOutput_4_0 = row_tAsyncIn_tDBOutput_4[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[0]);
			if(temp_tAsyncIn_tDBOutput_4_0 != null) {
		
			pRow_row4.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_4_0);
		} else {						
			pRow_row4.id = 0;
		}
		pRow_row4.criteria = row_tAsyncIn_tDBOutput_4[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[1]);
		
		
			String temp_tAsyncIn_tDBOutput_4_2 = row_tAsyncIn_tDBOutput_4[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[2]);
			if(temp_tAsyncIn_tDBOutput_4_2 != null) {
		
			pRow_row4.data_period = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_4_2);
		} else {						
			pRow_row4.data_period = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_3 = row_tAsyncIn_tDBOutput_4[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[3]);
			if(temp_tAsyncIn_tDBOutput_4_3 != null) {
		
			pRow_row4.cut_off = ParserUtils.parseTo_Float(temp_tAsyncIn_tDBOutput_4_3);
		} else {						
			pRow_row4.cut_off = null;
		}
		pRow_row4.criteria_type = row_tAsyncIn_tDBOutput_4[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[4]);
		
		
			String temp_tAsyncIn_tDBOutput_4_5 = row_tAsyncIn_tDBOutput_4[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[5]);
			if(temp_tAsyncIn_tDBOutput_4_5 != null) {
		
			pRow_row4.is_default = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_4_5);
		} else {						
			pRow_row4.is_default = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_6 = row_tAsyncIn_tDBOutput_4[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[6]);
			if(temp_tAsyncIn_tDBOutput_4_6 != null) {
		
			pRow_row4.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_4_6);
		} else {						
			pRow_row4.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_7 = row_tAsyncIn_tDBOutput_4[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[7]);
			if(temp_tAsyncIn_tDBOutput_4_7 != null) {
		
			pRow_row4.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_4[7]);
		} else {						
			pRow_row4.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_8 = row_tAsyncIn_tDBOutput_4[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[8]);
			if(temp_tAsyncIn_tDBOutput_4_8 != null) {
		
			pRow_row4.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_4_8);
		} else {						
			pRow_row4.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_9 = row_tAsyncIn_tDBOutput_4[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[9]);
			if(temp_tAsyncIn_tDBOutput_4_9 != null) {
		
			pRow_row4.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_4[9]);
		} else {						
			pRow_row4.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_10 = row_tAsyncIn_tDBOutput_4[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[10]);
			if(temp_tAsyncIn_tDBOutput_4_10 != null) {
		
			pRow_row4.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_4_10);
		} else {						
			pRow_row4.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_11 = row_tAsyncIn_tDBOutput_4[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[11]);
			if(temp_tAsyncIn_tDBOutput_4_11 != null) {
		
			pRow_row4.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_4_11);
		} else {						
			pRow_row4.is_deleted = 0;
		}
		pRow_row4.audit_criteria_id = row_tAsyncIn_tDBOutput_4[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[12]);
		
		
			String temp_tAsyncIn_tDBOutput_4_13 = row_tAsyncIn_tDBOutput_4[13]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[13]);
			if(temp_tAsyncIn_tDBOutput_4_13 != null) {
		
			pRow_row4.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_4[13]);
		} else {						
			pRow_row4.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_4 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

 


	tos_count_tAsyncIn_tDBOutput_4++;

/**
 * [tAsyncIn_tDBOutput_4 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

 



/**
 * [tAsyncIn_tDBOutput_4 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_audit_criteria_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row4","tAsyncIn_tDBOutput_4","tAsyncIn_tDBOutput_4","tAsyncIn","tDBOutput_4","\"mst_audit_criteria_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row4 - " + (pRow_row4==null? "": pRow_row4.toLogString()));
    			}
    		



				batchSize_tDBOutput_4 = buffersSize_tAsyncIn_tDBOutput_4;
        whetherReject_tDBOutput_4 = false;
                    pstmt_tDBOutput_4.setInt(1, pRow_row4.id);

                    if(pRow_row4.criteria == null) {
pstmt_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(2, pRow_row4.criteria);
}

                    if(pRow_row4.data_period == null) {
pstmt_tDBOutput_4.setNull(3, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(3, pRow_row4.data_period);
}

                    if(pRow_row4.cut_off == null) {
pstmt_tDBOutput_4.setNull(4, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_4.setFloat(4, pRow_row4.cut_off);
}

                    if(pRow_row4.criteria_type == null) {
pstmt_tDBOutput_4.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(5, pRow_row4.criteria_type);
}

                    pstmt_tDBOutput_4.setInt(6, pRow_row4.is_default);

                    if(pRow_row4.created_by == null) {
pstmt_tDBOutput_4.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(7, pRow_row4.created_by);
}

                    if(pRow_row4.created_on != null) {
pstmt_tDBOutput_4.setTimestamp(8, new java.sql.Timestamp(pRow_row4.created_on.getTime()));
} else {
pstmt_tDBOutput_4.setNull(8, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row4.updated_by == null) {
pstmt_tDBOutput_4.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(9, pRow_row4.updated_by);
}

                    if(pRow_row4.updated_on != null) {
pstmt_tDBOutput_4.setTimestamp(10, new java.sql.Timestamp(pRow_row4.updated_on.getTime()));
} else {
pstmt_tDBOutput_4.setNull(10, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_4.setInt(11, pRow_row4.is_active);

                    pstmt_tDBOutput_4.setInt(12, pRow_row4.is_deleted);

                    if(pRow_row4.audit_criteria_id == null) {
pstmt_tDBOutput_4.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(13, pRow_row4.audit_criteria_id);
}

                    if(pRow_row4.as_on != null) {
pstmt_tDBOutput_4.setTimestamp(14, new java.sql.Timestamp(pRow_row4.as_on.getTime()));
} else {
pstmt_tDBOutput_4.setNull(14, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_4.addBatch();
    		nb_line_tDBOutput_4++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Adding the record ")  + (nb_line_tDBOutput_4)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_4++;
    		  
    			if ((batchSize_tDBOutput_4 > 0) && (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {
                try {
						int countSum_tDBOutput_4 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            	    	batchSizeCounter_tDBOutput_4 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
				    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
				    	String errormessage_tDBOutput_4;
						if (ne_tDBOutput_4 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
							errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
						}else{
							errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
						}
				    	
				    	int countSum_tDBOutput_4 = 0;
						for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
				    	System.err.println(errormessage_tDBOutput_4);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_audit_criteria_dw\"";
		

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_audit_criteria_dw\"";
		

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

 



/**
 * [tAsyncIn_tDBOutput_4 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_4.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_4", true);
end_Hash.put("tAsyncIn_tDBOutput_4", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_4 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_audit_criteria_dw\"";
		



	    try {
				int countSum_tDBOutput_4 = 0;
				if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
	    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
	    	String errormessage_tDBOutput_4;
			if (ne_tDBOutput_4 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
				errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
			}else{
				errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
			}
	    	
	    	int countSum_tDBOutput_4 = 0;
			for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
				countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
			}
			rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
			
	    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
	    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
	    	System.err.println(errormessage_tDBOutput_4);
	    	
		}
	    
        if(pstmt_tDBOutput_4 != null) {
        		
            pstmt_tDBOutput_4.close();
            resourceMap.remove("pstmt_tDBOutput_4");
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
    	if (globalMap.get("tDBOutput_4_NB_LINE") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE",(Integer)globalMap.get("tDBOutput_4_NB_LINE") + nb_line_tDBOutput_4);
        }
        if (globalMap.get("tDBOutput_4_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_4_NB_LINE_UPDATED") + nb_line_update_tDBOutput_4);
        }
        if (globalMap.get("tDBOutput_4_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_4_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_4);
        }
        if (globalMap.get("tDBOutput_4_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_4_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_4);
        }
        if (globalMap.get("tDBOutput_4_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_4_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_4);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row4",2,0,
			 			"tAsyncIn_tDBOutput_4","tAsyncIn_tDBOutput_4","tAsyncIn","tDBOutput_4","\"mst_audit_criteria_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Done.") );

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

 



/**
 * [tAsyncIn_tDBOutput_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_audit_criteria_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_4");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_4_ParallelThread pt = new tAsyncIn_tDBOutput_4_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_4"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_4_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row5Struct implements routines.system.IPersistableRow<pRow_row5Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String branch_code;

				public String getBranch_code () {
					return this.branch_code;
				}

				public Boolean branch_codeIsNullable(){
				    return false;
				}
				public Boolean branch_codeIsKey(){
				    return false;
				}
				public Integer branch_codeLength(){
				    return 5;
				}
				public Integer branch_codePrecision(){
				    return 0;
				}
				public String branch_codeDefault(){
				
					return null;
				
				}
				public String branch_codeComment(){
				
				    return "";
				
				}
				public String branch_codePattern(){
				
					return "";
				
				}
				public String branch_codeOriginalDbColumnName(){
				
					return "branch_code";
				
				}

				
			    public String branch;

				public String getBranch () {
					return this.branch;
				}

				public Boolean branchIsNullable(){
				    return false;
				}
				public Boolean branchIsKey(){
				    return false;
				}
				public Integer branchLength(){
				    return 45;
				}
				public Integer branchPrecision(){
				    return 0;
				}
				public String branchDefault(){
				
					return null;
				
				}
				public String branchComment(){
				
				    return "";
				
				}
				public String branchPattern(){
				
					return "";
				
				}
				public String branchOriginalDbColumnName(){
				
					return "branch";
				
				}

				
			    public int region_id;

				public int getRegion_id () {
					return this.region_id;
				}

				public Boolean region_idIsNullable(){
				    return false;
				}
				public Boolean region_idIsKey(){
				    return false;
				}
				public Integer region_idLength(){
				    return 10;
				}
				public Integer region_idPrecision(){
				    return 0;
				}
				public String region_idDefault(){
				
					return null;
				
				}
				public String region_idComment(){
				
				    return "";
				
				}
				public String region_idPattern(){
				
					return "";
				
				}
				public String region_idOriginalDbColumnName(){
				
					return "region_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String branch_id;

				public String getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return true;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 32;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row5Struct other = (pRow_row5Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row5Struct other) {

		other.id = this.id;
	            other.branch_code = this.branch_code;
	            other.branch = this.branch;
	            other.region_id = this.region_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.branch_id = this.branch_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row5Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.branch_code = readString(dis);
					
					this.branch = readString(dis);
					
			        this.region_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.branch_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.branch_code = readString(dis);
					
					this.branch = readString(dis);
					
			        this.region_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.branch_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.branch_code,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// int
				
		            	dos.writeInt(this.region_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.branch_code,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// int
				
		            	dos.writeInt(this.region_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",branch_code="+branch_code);
		sb.append(",branch="+branch);
		sb.append(",region_id="+String.valueOf(region_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",branch_id="+branch_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(branch_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_code);
            			}
            		
        			sb.append("|");
        		
        				if(branch == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch);
            			}
            		
        			sb.append("|");
        		
        				sb.append(region_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(branch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_5");
		org.slf4j.MDC.put("_subJobPid", "kAFMGp_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_5");
		class tAsyncIn_tDBOutput_5_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_5_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row5Struct pRow_row5 = new pRow_row5Struct();




	
	/**
	 * [tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_5", false);
		start_Hash.put("tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_branch_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row5");
			
		int tos_count_tDBOutput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_5 = new StringBuilder();
                    log4jParamters_tDBOutput_5.append("Parameters:");
                            log4jParamters_tDBOutput_5.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE" + " = " + "\"mst_branch_dw\"");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + (log4jParamters_tDBOutput_5) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_5", "\"mst_branch_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_5 = null;
	dbschema_tDBOutput_5 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_5 = null;
if(dbschema_tDBOutput_5 == null || dbschema_tDBOutput_5.trim().length() == 0) {
	tableName_tDBOutput_5 = ("mst_branch_dw");
} else {
	tableName_tDBOutput_5 = dbschema_tDBOutput_5 + "\".\"" + ("mst_branch_dw");
}


int nb_line_tDBOutput_5 = 0;
int nb_line_update_tDBOutput_5 = 0;
int nb_line_inserted_tDBOutput_5 = 0;
int nb_line_deleted_tDBOutput_5 = 0;
int nb_line_rejected_tDBOutput_5 = 0;

int deletedCount_tDBOutput_5=0;
int updatedCount_tDBOutput_5=0;
int insertedCount_tDBOutput_5=0;
int rowsToCommitCount_tDBOutput_5=0;
int rejectedCount_tDBOutput_5=0;

boolean whetherReject_tDBOutput_5 = false;

java.sql.Connection conn_tDBOutput_5 = null;
String dbUser_tDBOutput_5 = null;

	conn_tDBOutput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_5.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_5.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_5.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_5 = 10000;
   int batchSizeCounter_tDBOutput_5=0;

int count_tDBOutput_5=0;
        java.lang.StringBuilder sb_tDBOutput_5 = new java.lang.StringBuilder();
        sb_tDBOutput_5.append("INSERT INTO \"").append(tableName_tDBOutput_5).append("\" (\"id\",\"branch_code\",\"branch\",\"region_id\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"branch_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_5.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"branch_code\" = EXCLUDED.\"branch_code\",\"branch\" = EXCLUDED.\"branch\",\"region_id\" = EXCLUDED.\"region_id\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"branch_id\" = EXCLUDED.\"branch_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_5 = sb_tDBOutput_5.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing '")  + (insert_tDBOutput_5)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
	    resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);
	    

 



/**
 * [tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_5", false);
		start_Hash.put("tAsyncIn_tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	
		int tos_count_tAsyncIn_tDBOutput_5 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_5", "tAsyncIn_tDBOutput_5", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_5= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_5 = buffers_tAsyncIn_tDBOutput_5.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_5 != null && buffers_tAsyncIn_tDBOutput_5.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_5 : buffers_tAsyncIn_tDBOutput_5) {
    		pRow_row5 = null;						
			pRow_row5 = new pRow_row5Struct();
		
		
			String temp_tAsyncIn_tDBOutput_5_0 = row_tAsyncIn_tDBOutput_5[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[0]);
			if(temp_tAsyncIn_tDBOutput_5_0 != null) {
		
			pRow_row5.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_5_0);
		} else {						
			pRow_row5.id = 0;
		}
		pRow_row5.branch_code = row_tAsyncIn_tDBOutput_5[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[1]);
		pRow_row5.branch = row_tAsyncIn_tDBOutput_5[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[2]);
		
		
			String temp_tAsyncIn_tDBOutput_5_3 = row_tAsyncIn_tDBOutput_5[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[3]);
			if(temp_tAsyncIn_tDBOutput_5_3 != null) {
		
			pRow_row5.region_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_5_3);
		} else {						
			pRow_row5.region_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_4 = row_tAsyncIn_tDBOutput_5[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[4]);
			if(temp_tAsyncIn_tDBOutput_5_4 != null) {
		
			pRow_row5.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_5_4);
		} else {						
			pRow_row5.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_5 = row_tAsyncIn_tDBOutput_5[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[5]);
			if(temp_tAsyncIn_tDBOutput_5_5 != null) {
		
			pRow_row5.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_5[5]);
		} else {						
			pRow_row5.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_6 = row_tAsyncIn_tDBOutput_5[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[6]);
			if(temp_tAsyncIn_tDBOutput_5_6 != null) {
		
			pRow_row5.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_5_6);
		} else {						
			pRow_row5.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_7 = row_tAsyncIn_tDBOutput_5[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[7]);
			if(temp_tAsyncIn_tDBOutput_5_7 != null) {
		
			pRow_row5.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_5[7]);
		} else {						
			pRow_row5.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_8 = row_tAsyncIn_tDBOutput_5[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[8]);
			if(temp_tAsyncIn_tDBOutput_5_8 != null) {
		
			pRow_row5.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_5_8);
		} else {						
			pRow_row5.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_9 = row_tAsyncIn_tDBOutput_5[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[9]);
			if(temp_tAsyncIn_tDBOutput_5_9 != null) {
		
			pRow_row5.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_5_9);
		} else {						
			pRow_row5.is_deleted = 0;
		}
		pRow_row5.branch_id = row_tAsyncIn_tDBOutput_5[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[10]);
		
		
			String temp_tAsyncIn_tDBOutput_5_11 = row_tAsyncIn_tDBOutput_5[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[11]);
			if(temp_tAsyncIn_tDBOutput_5_11 != null) {
		
			pRow_row5.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_5[11]);
		} else {						
			pRow_row5.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_5 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

 


	tos_count_tAsyncIn_tDBOutput_5++;

/**
 * [tAsyncIn_tDBOutput_5 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

 



/**
 * [tAsyncIn_tDBOutput_5 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_branch_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row5","tAsyncIn_tDBOutput_5","tAsyncIn_tDBOutput_5","tAsyncIn","tDBOutput_5","\"mst_branch_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row5 - " + (pRow_row5==null? "": pRow_row5.toLogString()));
    			}
    		



				batchSize_tDBOutput_5 = buffersSize_tAsyncIn_tDBOutput_5;
        whetherReject_tDBOutput_5 = false;
                    pstmt_tDBOutput_5.setInt(1, pRow_row5.id);

                    if(pRow_row5.branch_code == null) {
pstmt_tDBOutput_5.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(2, pRow_row5.branch_code);
}

                    if(pRow_row5.branch == null) {
pstmt_tDBOutput_5.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(3, pRow_row5.branch);
}

                    pstmt_tDBOutput_5.setInt(4, pRow_row5.region_id);

                    if(pRow_row5.created_by == null) {
pstmt_tDBOutput_5.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(5, pRow_row5.created_by);
}

                    if(pRow_row5.created_on != null) {
pstmt_tDBOutput_5.setTimestamp(6, new java.sql.Timestamp(pRow_row5.created_on.getTime()));
} else {
pstmt_tDBOutput_5.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row5.updated_by == null) {
pstmt_tDBOutput_5.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(7, pRow_row5.updated_by);
}

                    if(pRow_row5.updated_on != null) {
pstmt_tDBOutput_5.setTimestamp(8, new java.sql.Timestamp(pRow_row5.updated_on.getTime()));
} else {
pstmt_tDBOutput_5.setNull(8, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_5.setInt(9, pRow_row5.is_active);

                    pstmt_tDBOutput_5.setInt(10, pRow_row5.is_deleted);

                    if(pRow_row5.branch_id == null) {
pstmt_tDBOutput_5.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(11, pRow_row5.branch_id);
}

                    if(pRow_row5.as_on != null) {
pstmt_tDBOutput_5.setTimestamp(12, new java.sql.Timestamp(pRow_row5.as_on.getTime()));
} else {
pstmt_tDBOutput_5.setNull(12, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_5.addBatch();
    		nb_line_tDBOutput_5++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Adding the record ")  + (nb_line_tDBOutput_5)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_5++;
    		  
    			if ((batchSize_tDBOutput_5 > 0) && (batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5)) {
                try {
						int countSum_tDBOutput_5 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            	    	batchSizeCounter_tDBOutput_5 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
				    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
				    	String errormessage_tDBOutput_5;
						if (ne_tDBOutput_5 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
							errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
						}else{
							errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
						}
				    	
				    	int countSum_tDBOutput_5 = 0;
						for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
						rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
				    	System.err.println(errormessage_tDBOutput_5);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_5++;

/**
 * [tDBOutput_5 main ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_branch_dw\"";
		

 



/**
 * [tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_branch_dw\"";
		

 



/**
 * [tDBOutput_5 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

 



/**
 * [tAsyncIn_tDBOutput_5 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_5.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_5", true);
end_Hash.put("tAsyncIn_tDBOutput_5", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_5 end ] stop
 */

	
	/**
	 * [tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_branch_dw\"";
		



	    try {
				int countSum_tDBOutput_5 = 0;
				if (pstmt_tDBOutput_5 != null && batchSizeCounter_tDBOutput_5 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
	    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
	    	String errormessage_tDBOutput_5;
			if (ne_tDBOutput_5 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
				errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
			}else{
				errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
			}
	    	
	    	int countSum_tDBOutput_5 = 0;
			for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
				countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
			}
			rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
			
	    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
	    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
	    	System.err.println(errormessage_tDBOutput_5);
	    	
		}
	    
        if(pstmt_tDBOutput_5 != null) {
        		
            pstmt_tDBOutput_5.close();
            resourceMap.remove("pstmt_tDBOutput_5");
        }
    resourceMap.put("statementClosed_tDBOutput_5", true);

	nb_line_deleted_tDBOutput_5=nb_line_deleted_tDBOutput_5+ deletedCount_tDBOutput_5;
	nb_line_update_tDBOutput_5=nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
	nb_line_inserted_tDBOutput_5=nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
	nb_line_rejected_tDBOutput_5=nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;
	
    	if (globalMap.get("tDBOutput_5_NB_LINE") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE",nb_line_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE",(Integer)globalMap.get("tDBOutput_5_NB_LINE") + nb_line_tDBOutput_5);
        }
        if (globalMap.get("tDBOutput_5_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE_UPDATED",nb_line_update_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_5_NB_LINE_UPDATED") + nb_line_update_tDBOutput_5);
        }
        if (globalMap.get("tDBOutput_5_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_5_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_5);
        }
        if (globalMap.get("tDBOutput_5_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE_DELETED",nb_line_deleted_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_5_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_5);
        }
        if (globalMap.get("tDBOutput_5_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_5_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_5);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row5",2,0,
			 			"tAsyncIn_tDBOutput_5","tAsyncIn_tDBOutput_5","tAsyncIn","tDBOutput_5","\"mst_branch_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Done.") );

ok_Hash.put("tDBOutput_5", true);
end_Hash.put("tDBOutput_5", System.currentTimeMillis());




/**
 * [tDBOutput_5 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

 



/**
 * [tAsyncIn_tDBOutput_5 finally ] stop
 */

	
	/**
	 * [tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_branch_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
                if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_5")) != null) {
                    pstmtToClose_tDBOutput_5.close();
                }
    }
 



/**
 * [tDBOutput_5 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_5");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_5_ParallelThread pt = new tAsyncIn_tDBOutput_5_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_5"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_5_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row6Struct implements routines.system.IPersistableRow<pRow_row6Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return false;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 45;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String category_id;

				public String getCategory_id () {
					return this.category_id;
				}

				public Boolean category_idIsNullable(){
				    return true;
				}
				public Boolean category_idIsKey(){
				    return false;
				}
				public Integer category_idLength(){
				    return 32;
				}
				public Integer category_idPrecision(){
				    return 0;
				}
				public String category_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String category_idComment(){
				
				    return "";
				
				}
				public String category_idPattern(){
				
					return "";
				
				}
				public String category_idOriginalDbColumnName(){
				
					return "category_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row6Struct other = (pRow_row6Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row6Struct other) {

		other.id = this.id;
	            other.name = this.name;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.category_id = this.category_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row6Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.name = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.category_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.name = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.category_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.name,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.category_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.name,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.category_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",name="+name);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",category_id="+category_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(category_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(category_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row6Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_6");
		org.slf4j.MDC.put("_subJobPid", "QimJjO_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_6");
		class tAsyncIn_tDBOutput_6_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_6_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row6Struct pRow_row6 = new pRow_row6Struct();




	
	/**
	 * [tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_6", false);
		start_Hash.put("tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_category_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row6");
			
		int tos_count_tDBOutput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_6 = new StringBuilder();
                    log4jParamters_tDBOutput_6.append("Parameters:");
                            log4jParamters_tDBOutput_6.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("TABLE" + " = " + "\"mst_category_dw\"");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + (log4jParamters_tDBOutput_6) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_6", "\"mst_category_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_6 = null;
	dbschema_tDBOutput_6 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_6 = null;
if(dbschema_tDBOutput_6 == null || dbschema_tDBOutput_6.trim().length() == 0) {
	tableName_tDBOutput_6 = ("mst_category_dw");
} else {
	tableName_tDBOutput_6 = dbschema_tDBOutput_6 + "\".\"" + ("mst_category_dw");
}


int nb_line_tDBOutput_6 = 0;
int nb_line_update_tDBOutput_6 = 0;
int nb_line_inserted_tDBOutput_6 = 0;
int nb_line_deleted_tDBOutput_6 = 0;
int nb_line_rejected_tDBOutput_6 = 0;

int deletedCount_tDBOutput_6=0;
int updatedCount_tDBOutput_6=0;
int insertedCount_tDBOutput_6=0;
int rowsToCommitCount_tDBOutput_6=0;
int rejectedCount_tDBOutput_6=0;

boolean whetherReject_tDBOutput_6 = false;

java.sql.Connection conn_tDBOutput_6 = null;
String dbUser_tDBOutput_6 = null;

	conn_tDBOutput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_6.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_6.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_6.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_6 = 10000;
   int batchSizeCounter_tDBOutput_6=0;

int count_tDBOutput_6=0;
        java.lang.StringBuilder sb_tDBOutput_6 = new java.lang.StringBuilder();
        sb_tDBOutput_6.append("INSERT INTO \"").append(tableName_tDBOutput_6).append("\" (\"id\",\"name\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"category_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_6.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"name\" = EXCLUDED.\"name\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"category_id\" = EXCLUDED.\"category_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_6 = sb_tDBOutput_6.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing '")  + (insert_tDBOutput_6)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
	    resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);
	    

 



/**
 * [tDBOutput_6 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_6", false);
		start_Hash.put("tAsyncIn_tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	
		int tos_count_tAsyncIn_tDBOutput_6 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_6", "tAsyncIn_tDBOutput_6", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_6= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_6 = buffers_tAsyncIn_tDBOutput_6.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_6 != null && buffers_tAsyncIn_tDBOutput_6.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_6 : buffers_tAsyncIn_tDBOutput_6) {
    		pRow_row6 = null;						
			pRow_row6 = new pRow_row6Struct();
		
		
			String temp_tAsyncIn_tDBOutput_6_0 = row_tAsyncIn_tDBOutput_6[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[0]);
			if(temp_tAsyncIn_tDBOutput_6_0 != null) {
		
			pRow_row6.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_0);
		} else {						
			pRow_row6.id = 0;
		}
		pRow_row6.name = row_tAsyncIn_tDBOutput_6[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[1]);
		
		
			String temp_tAsyncIn_tDBOutput_6_2 = row_tAsyncIn_tDBOutput_6[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[2]);
			if(temp_tAsyncIn_tDBOutput_6_2 != null) {
		
			pRow_row6.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_2);
		} else {						
			pRow_row6.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_3 = row_tAsyncIn_tDBOutput_6[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[3]);
			if(temp_tAsyncIn_tDBOutput_6_3 != null) {
		
			pRow_row6.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_6[3]);
		} else {						
			pRow_row6.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_4 = row_tAsyncIn_tDBOutput_6[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[4]);
			if(temp_tAsyncIn_tDBOutput_6_4 != null) {
		
			pRow_row6.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_4);
		} else {						
			pRow_row6.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_5 = row_tAsyncIn_tDBOutput_6[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[5]);
			if(temp_tAsyncIn_tDBOutput_6_5 != null) {
		
			pRow_row6.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_6[5]);
		} else {						
			pRow_row6.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_6 = row_tAsyncIn_tDBOutput_6[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[6]);
			if(temp_tAsyncIn_tDBOutput_6_6 != null) {
		
			pRow_row6.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_6);
		} else {						
			pRow_row6.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_7 = row_tAsyncIn_tDBOutput_6[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[7]);
			if(temp_tAsyncIn_tDBOutput_6_7 != null) {
		
			pRow_row6.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_7);
		} else {						
			pRow_row6.is_deleted = 0;
		}
		pRow_row6.category_id = row_tAsyncIn_tDBOutput_6[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[8]);
		
		
			String temp_tAsyncIn_tDBOutput_6_9 = row_tAsyncIn_tDBOutput_6[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[9]);
			if(temp_tAsyncIn_tDBOutput_6_9 != null) {
		
			pRow_row6.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_6[9]);
		} else {						
			pRow_row6.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_6 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

 


	tos_count_tAsyncIn_tDBOutput_6++;

/**
 * [tAsyncIn_tDBOutput_6 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

 



/**
 * [tAsyncIn_tDBOutput_6 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_category_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row6","tAsyncIn_tDBOutput_6","tAsyncIn_tDBOutput_6","tAsyncIn","tDBOutput_6","\"mst_category_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row6 - " + (pRow_row6==null? "": pRow_row6.toLogString()));
    			}
    		



				batchSize_tDBOutput_6 = buffersSize_tAsyncIn_tDBOutput_6;
        whetherReject_tDBOutput_6 = false;
                    pstmt_tDBOutput_6.setInt(1, pRow_row6.id);

                    if(pRow_row6.name == null) {
pstmt_tDBOutput_6.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(2, pRow_row6.name);
}

                    if(pRow_row6.created_by == null) {
pstmt_tDBOutput_6.setNull(3, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(3, pRow_row6.created_by);
}

                    if(pRow_row6.created_on != null) {
pstmt_tDBOutput_6.setTimestamp(4, new java.sql.Timestamp(pRow_row6.created_on.getTime()));
} else {
pstmt_tDBOutput_6.setNull(4, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row6.updated_by == null) {
pstmt_tDBOutput_6.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(5, pRow_row6.updated_by);
}

                    if(pRow_row6.updated_on != null) {
pstmt_tDBOutput_6.setTimestamp(6, new java.sql.Timestamp(pRow_row6.updated_on.getTime()));
} else {
pstmt_tDBOutput_6.setNull(6, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_6.setInt(7, pRow_row6.is_active);

                    pstmt_tDBOutput_6.setInt(8, pRow_row6.is_deleted);

                    if(pRow_row6.category_id == null) {
pstmt_tDBOutput_6.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(9, pRow_row6.category_id);
}

                    if(pRow_row6.as_on != null) {
pstmt_tDBOutput_6.setTimestamp(10, new java.sql.Timestamp(pRow_row6.as_on.getTime()));
} else {
pstmt_tDBOutput_6.setNull(10, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_6.addBatch();
    		nb_line_tDBOutput_6++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Adding the record ")  + (nb_line_tDBOutput_6)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_6++;
    		  
    			if ((batchSize_tDBOutput_6 > 0) && (batchSize_tDBOutput_6 <= batchSizeCounter_tDBOutput_6)) {
                try {
						int countSum_tDBOutput_6 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            	    	batchSizeCounter_tDBOutput_6 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
				    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
				    	String errormessage_tDBOutput_6;
						if (ne_tDBOutput_6 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
							errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
						}else{
							errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
						}
				    	
				    	int countSum_tDBOutput_6 = 0;
						for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
						rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
				    	System.err.println(errormessage_tDBOutput_6);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_6++;

/**
 * [tDBOutput_6 main ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_category_dw\"";
		

 



/**
 * [tDBOutput_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_category_dw\"";
		

 



/**
 * [tDBOutput_6 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

 



/**
 * [tAsyncIn_tDBOutput_6 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_6.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_6", true);
end_Hash.put("tAsyncIn_tDBOutput_6", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_6 end ] stop
 */

	
	/**
	 * [tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_category_dw\"";
		



	    try {
				int countSum_tDBOutput_6 = 0;
				if (pstmt_tDBOutput_6 != null && batchSizeCounter_tDBOutput_6 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
						countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
					}
					rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
	    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
	    	String errormessage_tDBOutput_6;
			if (ne_tDBOutput_6 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
				errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
			}else{
				errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
			}
	    	
	    	int countSum_tDBOutput_6 = 0;
			for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
				countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
			}
			rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
			
	    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
	    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
	    	System.err.println(errormessage_tDBOutput_6);
	    	
		}
	    
        if(pstmt_tDBOutput_6 != null) {
        		
            pstmt_tDBOutput_6.close();
            resourceMap.remove("pstmt_tDBOutput_6");
        }
    resourceMap.put("statementClosed_tDBOutput_6", true);

	nb_line_deleted_tDBOutput_6=nb_line_deleted_tDBOutput_6+ deletedCount_tDBOutput_6;
	nb_line_update_tDBOutput_6=nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
	nb_line_inserted_tDBOutput_6=nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
	nb_line_rejected_tDBOutput_6=nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;
	
    	if (globalMap.get("tDBOutput_6_NB_LINE") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE",nb_line_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE",(Integer)globalMap.get("tDBOutput_6_NB_LINE") + nb_line_tDBOutput_6);
        }
        if (globalMap.get("tDBOutput_6_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE_UPDATED",nb_line_update_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_6_NB_LINE_UPDATED") + nb_line_update_tDBOutput_6);
        }
        if (globalMap.get("tDBOutput_6_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_6_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_6);
        }
        if (globalMap.get("tDBOutput_6_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE_DELETED",nb_line_deleted_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_6_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_6);
        }
        if (globalMap.get("tDBOutput_6_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_6_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_6);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row6",2,0,
			 			"tAsyncIn_tDBOutput_6","tAsyncIn_tDBOutput_6","tAsyncIn","tDBOutput_6","\"mst_category_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Done.") );

ok_Hash.put("tDBOutput_6", true);
end_Hash.put("tDBOutput_6", System.currentTimeMillis());




/**
 * [tDBOutput_6 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

 



/**
 * [tAsyncIn_tDBOutput_6 finally ] stop
 */

	
	/**
	 * [tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_category_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
                if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_6")) != null) {
                    pstmtToClose_tDBOutput_6.close();
                }
    }
 



/**
 * [tDBOutput_6 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_6");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_6_ParallelThread pt = new tAsyncIn_tDBOutput_6_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_6"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_6_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row7Struct implements routines.system.IPersistableRow<pRow_row7Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String branch_name;

				public String getBranch_name () {
					return this.branch_name;
				}

				public Boolean branch_nameIsNullable(){
				    return false;
				}
				public Boolean branch_nameIsKey(){
				    return false;
				}
				public Integer branch_nameLength(){
				    return 45;
				}
				public Integer branch_namePrecision(){
				    return 0;
				}
				public String branch_nameDefault(){
				
					return null;
				
				}
				public String branch_nameComment(){
				
				    return "";
				
				}
				public String branch_namePattern(){
				
					return "";
				
				}
				public String branch_nameOriginalDbColumnName(){
				
					return "branch_name";
				
				}

				
			    public int branch_id;

				public int getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return false;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 10;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return null;
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public String center_name;

				public String getCenter_name () {
					return this.center_name;
				}

				public Boolean center_nameIsNullable(){
				    return false;
				}
				public Boolean center_nameIsKey(){
				    return false;
				}
				public Integer center_nameLength(){
				    return 60;
				}
				public Integer center_namePrecision(){
				    return 0;
				}
				public String center_nameDefault(){
				
					return null;
				
				}
				public String center_nameComment(){
				
				    return "";
				
				}
				public String center_namePattern(){
				
					return "";
				
				}
				public String center_nameOriginalDbColumnName(){
				
					return "center_name";
				
				}

				
			    public String wh_center_id;

				public String getWh_center_id () {
					return this.wh_center_id;
				}

				public Boolean wh_center_idIsNullable(){
				    return true;
				}
				public Boolean wh_center_idIsKey(){
				    return false;
				}
				public Integer wh_center_idLength(){
				    return 11;
				}
				public Integer wh_center_idPrecision(){
				    return 0;
				}
				public String wh_center_idDefault(){
				
					return "'0'::character varying'";
				
				}
				public String wh_center_idComment(){
				
				    return "";
				
				}
				public String wh_center_idPattern(){
				
					return "";
				
				}
				public String wh_center_idOriginalDbColumnName(){
				
					return "wh_center_id";
				
				}

				
			    public String meeting_day;

				public String getMeeting_day () {
					return this.meeting_day;
				}

				public Boolean meeting_dayIsNullable(){
				    return false;
				}
				public Boolean meeting_dayIsKey(){
				    return false;
				}
				public Integer meeting_dayLength(){
				    return 10;
				}
				public Integer meeting_dayPrecision(){
				    return 0;
				}
				public String meeting_dayDefault(){
				
					return null;
				
				}
				public String meeting_dayComment(){
				
				    return "";
				
				}
				public String meeting_dayPattern(){
				
					return "";
				
				}
				public String meeting_dayOriginalDbColumnName(){
				
					return "meeting_day";
				
				}

				
			    public String meeting_time_from;

				public String getMeeting_time_from () {
					return this.meeting_time_from;
				}

				public Boolean meeting_time_fromIsNullable(){
				    return true;
				}
				public Boolean meeting_time_fromIsKey(){
				    return false;
				}
				public Integer meeting_time_fromLength(){
				    return 10;
				}
				public Integer meeting_time_fromPrecision(){
				    return 0;
				}
				public String meeting_time_fromDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String meeting_time_fromComment(){
				
				    return "";
				
				}
				public String meeting_time_fromPattern(){
				
					return "";
				
				}
				public String meeting_time_fromOriginalDbColumnName(){
				
					return "meeting_time_from";
				
				}

				
			    public String meeting_time_to;

				public String getMeeting_time_to () {
					return this.meeting_time_to;
				}

				public Boolean meeting_time_toIsNullable(){
				    return true;
				}
				public Boolean meeting_time_toIsKey(){
				    return false;
				}
				public Integer meeting_time_toLength(){
				    return 10;
				}
				public Integer meeting_time_toPrecision(){
				    return 0;
				}
				public String meeting_time_toDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String meeting_time_toComment(){
				
				    return "";
				
				}
				public String meeting_time_toPattern(){
				
					return "";
				
				}
				public String meeting_time_toOriginalDbColumnName(){
				
					return "meeting_time_to";
				
				}

				
			    public String center_manager_id;

				public String getCenter_manager_id () {
					return this.center_manager_id;
				}

				public Boolean center_manager_idIsNullable(){
				    return true;
				}
				public Boolean center_manager_idIsKey(){
				    return false;
				}
				public Integer center_manager_idLength(){
				    return 10;
				}
				public Integer center_manager_idPrecision(){
				    return 0;
				}
				public String center_manager_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String center_manager_idComment(){
				
				    return "";
				
				}
				public String center_manager_idPattern(){
				
					return "";
				
				}
				public String center_manager_idOriginalDbColumnName(){
				
					return "center_manager_id";
				
				}

				
			    public String center_manager;

				public String getCenter_manager () {
					return this.center_manager;
				}

				public Boolean center_managerIsNullable(){
				    return true;
				}
				public Boolean center_managerIsKey(){
				    return false;
				}
				public Integer center_managerLength(){
				    return 45;
				}
				public Integer center_managerPrecision(){
				    return 0;
				}
				public String center_managerDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String center_managerComment(){
				
				    return "";
				
				}
				public String center_managerPattern(){
				
					return "";
				
				}
				public String center_managerOriginalDbColumnName(){
				
					return "center_manager";
				
				}

				
			    public Integer no_of_active_mem;

				public Integer getNo_of_active_mem () {
					return this.no_of_active_mem;
				}

				public Boolean no_of_active_memIsNullable(){
				    return true;
				}
				public Boolean no_of_active_memIsKey(){
				    return false;
				}
				public Integer no_of_active_memLength(){
				    return 10;
				}
				public Integer no_of_active_memPrecision(){
				    return 0;
				}
				public String no_of_active_memDefault(){
				
					return "0";
				
				}
				public String no_of_active_memComment(){
				
				    return "";
				
				}
				public String no_of_active_memPattern(){
				
					return "";
				
				}
				public String no_of_active_memOriginalDbColumnName(){
				
					return "no_of_active_mem";
				
				}

				
			    public Integer no_of_borrowers;

				public Integer getNo_of_borrowers () {
					return this.no_of_borrowers;
				}

				public Boolean no_of_borrowersIsNullable(){
				    return true;
				}
				public Boolean no_of_borrowersIsKey(){
				    return false;
				}
				public Integer no_of_borrowersLength(){
				    return 10;
				}
				public Integer no_of_borrowersPrecision(){
				    return 0;
				}
				public String no_of_borrowersDefault(){
				
					return "0";
				
				}
				public String no_of_borrowersComment(){
				
				    return "";
				
				}
				public String no_of_borrowersPattern(){
				
					return "";
				
				}
				public String no_of_borrowersOriginalDbColumnName(){
				
					return "no_of_borrowers";
				
				}

				
			    public Float principal_os;

				public Float getPrincipal_os () {
					return this.principal_os;
				}

				public Boolean principal_osIsNullable(){
				    return true;
				}
				public Boolean principal_osIsKey(){
				    return false;
				}
				public Integer principal_osLength(){
				    return 8;
				}
				public Integer principal_osPrecision(){
				    return 8;
				}
				public String principal_osDefault(){
				
					return "'0'::real";
				
				}
				public String principal_osComment(){
				
				    return "";
				
				}
				public String principal_osPattern(){
				
					return "";
				
				}
				public String principal_osOriginalDbColumnName(){
				
					return "principal_os";
				
				}

				
			    public Integer no_of_group;

				public Integer getNo_of_group () {
					return this.no_of_group;
				}

				public Boolean no_of_groupIsNullable(){
				    return true;
				}
				public Boolean no_of_groupIsKey(){
				    return false;
				}
				public Integer no_of_groupLength(){
				    return 10;
				}
				public Integer no_of_groupPrecision(){
				    return 0;
				}
				public String no_of_groupDefault(){
				
					return "0";
				
				}
				public String no_of_groupComment(){
				
				    return "";
				
				}
				public String no_of_groupPattern(){
				
					return "";
				
				}
				public String no_of_groupOriginalDbColumnName(){
				
					return "no_of_group";
				
				}

				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}

				public Boolean longitudeIsNullable(){
				    return true;
				}
				public Boolean longitudeIsKey(){
				    return false;
				}
				public Integer longitudeLength(){
				    return 45;
				}
				public Integer longitudePrecision(){
				    return 0;
				}
				public String longitudeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String longitudeComment(){
				
				    return "";
				
				}
				public String longitudePattern(){
				
					return "";
				
				}
				public String longitudeOriginalDbColumnName(){
				
					return "longitude";
				
				}

				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}

				public Boolean latitudeIsNullable(){
				    return true;
				}
				public Boolean latitudeIsKey(){
				    return false;
				}
				public Integer latitudeLength(){
				    return 45;
				}
				public Integer latitudePrecision(){
				    return 0;
				}
				public String latitudeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String latitudeComment(){
				
				    return "";
				
				}
				public String latitudePattern(){
				
					return "";
				
				}
				public String latitudeOriginalDbColumnName(){
				
					return "latitude";
				
				}

				
			    public String center_risk_level;

				public String getCenter_risk_level () {
					return this.center_risk_level;
				}

				public Boolean center_risk_levelIsNullable(){
				    return true;
				}
				public Boolean center_risk_levelIsKey(){
				    return false;
				}
				public Integer center_risk_levelLength(){
				    return 45;
				}
				public Integer center_risk_levelPrecision(){
				    return 0;
				}
				public String center_risk_levelDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String center_risk_levelComment(){
				
				    return "";
				
				}
				public String center_risk_levelPattern(){
				
					return "";
				
				}
				public String center_risk_levelOriginalDbColumnName(){
				
					return "center_risk_level";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return "0";
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return "0";
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String center_id;

				public String getCenter_id () {
					return this.center_id;
				}

				public Boolean center_idIsNullable(){
				    return true;
				}
				public Boolean center_idIsKey(){
				    return false;
				}
				public Integer center_idLength(){
				    return 32;
				}
				public Integer center_idPrecision(){
				    return 0;
				}
				public String center_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String center_idComment(){
				
				    return "";
				
				}
				public String center_idPattern(){
				
					return "";
				
				}
				public String center_idOriginalDbColumnName(){
				
					return "center_id";
				
				}

				
			    public java.util.Date audit_completed_date;

				public java.util.Date getAudit_completed_date () {
					return this.audit_completed_date;
				}

				public Boolean audit_completed_dateIsNullable(){
				    return true;
				}
				public Boolean audit_completed_dateIsKey(){
				    return false;
				}
				public Integer audit_completed_dateLength(){
				    return 13;
				}
				public Integer audit_completed_datePrecision(){
				    return 0;
				}
				public String audit_completed_dateDefault(){
				
					return null;
				
				}
				public String audit_completed_dateComment(){
				
				    return "";
				
				}
				public String audit_completed_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audit_completed_dateOriginalDbColumnName(){
				
					return "audit_completed_date";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row7Struct other = (pRow_row7Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row7Struct other) {

		other.id = this.id;
	            other.branch_name = this.branch_name;
	            other.branch_id = this.branch_id;
	            other.center_name = this.center_name;
	            other.wh_center_id = this.wh_center_id;
	            other.meeting_day = this.meeting_day;
	            other.meeting_time_from = this.meeting_time_from;
	            other.meeting_time_to = this.meeting_time_to;
	            other.center_manager_id = this.center_manager_id;
	            other.center_manager = this.center_manager;
	            other.no_of_active_mem = this.no_of_active_mem;
	            other.no_of_borrowers = this.no_of_borrowers;
	            other.principal_os = this.principal_os;
	            other.no_of_group = this.no_of_group;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.center_risk_level = this.center_risk_level;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.center_id = this.center_id;
	            other.audit_completed_date = this.audit_completed_date;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row7Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_3, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.branch_name = readString(dis);
					
			        this.branch_id = dis.readInt();
					
					this.center_name = readString(dis);
					
					this.wh_center_id = readString(dis);
					
					this.meeting_day = readString(dis);
					
					this.meeting_time_from = readString(dis);
					
					this.meeting_time_to = readString(dis);
					
					this.center_manager_id = readString(dis);
					
					this.center_manager = readString(dis);
					
						this.no_of_active_mem = readInteger(dis);
					
						this.no_of_borrowers = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.principal_os = null;
           				} else {
           			    	this.principal_os = dis.readFloat();
           				}
					
						this.no_of_group = readInteger(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
					this.center_risk_level = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.center_id = readString(dis);
					
					this.audit_completed_date = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_3) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.branch_name = readString(dis);
					
			        this.branch_id = dis.readInt();
					
					this.center_name = readString(dis);
					
					this.wh_center_id = readString(dis);
					
					this.meeting_day = readString(dis);
					
					this.meeting_time_from = readString(dis);
					
					this.meeting_time_to = readString(dis);
					
					this.center_manager_id = readString(dis);
					
					this.center_manager = readString(dis);
					
						this.no_of_active_mem = readInteger(dis);
					
						this.no_of_borrowers = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.principal_os = null;
           				} else {
           			    	this.principal_os = dis.readFloat();
           				}
					
						this.no_of_group = readInteger(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
					this.center_risk_level = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.center_id = readString(dis);
					
					this.audit_completed_date = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.branch_name,dos);
					
					// int
				
		            	dos.writeInt(this.branch_id);
					
					// String
				
						writeString(this.center_name,dos);
					
					// String
				
						writeString(this.wh_center_id,dos);
					
					// String
				
						writeString(this.meeting_day,dos);
					
					// String
				
						writeString(this.meeting_time_from,dos);
					
					// String
				
						writeString(this.meeting_time_to,dos);
					
					// String
				
						writeString(this.center_manager_id,dos);
					
					// String
				
						writeString(this.center_manager,dos);
					
					// Integer
				
						writeInteger(this.no_of_active_mem,dos);
					
					// Integer
				
						writeInteger(this.no_of_borrowers,dos);
					
					// Float
				
						if(this.principal_os == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.principal_os);
		            	}
					
					// Integer
				
						writeInteger(this.no_of_group,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// String
				
						writeString(this.center_risk_level,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.center_id,dos);
					
					// java.util.Date
				
						writeDate(this.audit_completed_date,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.branch_name,dos);
					
					// int
				
		            	dos.writeInt(this.branch_id);
					
					// String
				
						writeString(this.center_name,dos);
					
					// String
				
						writeString(this.wh_center_id,dos);
					
					// String
				
						writeString(this.meeting_day,dos);
					
					// String
				
						writeString(this.meeting_time_from,dos);
					
					// String
				
						writeString(this.meeting_time_to,dos);
					
					// String
				
						writeString(this.center_manager_id,dos);
					
					// String
				
						writeString(this.center_manager,dos);
					
					// Integer
				
						writeInteger(this.no_of_active_mem,dos);
					
					// Integer
				
						writeInteger(this.no_of_borrowers,dos);
					
					// Float
				
						if(this.principal_os == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.principal_os);
		            	}
					
					// Integer
				
						writeInteger(this.no_of_group,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// String
				
						writeString(this.center_risk_level,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.center_id,dos);
					
					// java.util.Date
				
						writeDate(this.audit_completed_date,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",branch_name="+branch_name);
		sb.append(",branch_id="+String.valueOf(branch_id));
		sb.append(",center_name="+center_name);
		sb.append(",wh_center_id="+wh_center_id);
		sb.append(",meeting_day="+meeting_day);
		sb.append(",meeting_time_from="+meeting_time_from);
		sb.append(",meeting_time_to="+meeting_time_to);
		sb.append(",center_manager_id="+center_manager_id);
		sb.append(",center_manager="+center_manager);
		sb.append(",no_of_active_mem="+String.valueOf(no_of_active_mem));
		sb.append(",no_of_borrowers="+String.valueOf(no_of_borrowers));
		sb.append(",principal_os="+String.valueOf(principal_os));
		sb.append(",no_of_group="+String.valueOf(no_of_group));
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",center_risk_level="+center_risk_level);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",center_id="+center_id);
		sb.append(",audit_completed_date="+String.valueOf(audit_completed_date));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(branch_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_name);
            			}
            		
        			sb.append("|");
        		
        				sb.append(branch_id);
        			
        			sb.append("|");
        		
        				if(center_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_name);
            			}
            		
        			sb.append("|");
        		
        				if(wh_center_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(wh_center_id);
            			}
            		
        			sb.append("|");
        		
        				if(meeting_day == null){
        					sb.append("<null>");
        				}else{
            				sb.append(meeting_day);
            			}
            		
        			sb.append("|");
        		
        				if(meeting_time_from == null){
        					sb.append("<null>");
        				}else{
            				sb.append(meeting_time_from);
            			}
            		
        			sb.append("|");
        		
        				if(meeting_time_to == null){
        					sb.append("<null>");
        				}else{
            				sb.append(meeting_time_to);
            			}
            		
        			sb.append("|");
        		
        				if(center_manager_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_manager_id);
            			}
            		
        			sb.append("|");
        		
        				if(center_manager == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_manager);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_active_mem == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_active_mem);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_borrowers == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_borrowers);
            			}
            		
        			sb.append("|");
        		
        				if(principal_os == null){
        					sb.append("<null>");
        				}else{
            				sb.append(principal_os);
            			}
            		
        			sb.append("|");
        		
        				if(no_of_group == null){
        					sb.append("<null>");
        				}else{
            				sb.append(no_of_group);
            			}
            		
        			sb.append("|");
        		
        				if(longitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(longitude);
            			}
            		
        			sb.append("|");
        		
        				if(latitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(latitude);
            			}
            		
        			sb.append("|");
        		
        				if(center_risk_level == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_risk_level);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(center_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(center_id);
            			}
            		
        			sb.append("|");
        		
        				if(audit_completed_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_completed_date);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_7");
		org.slf4j.MDC.put("_subJobPid", "AXsnw5_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_7");
		class tAsyncIn_tDBOutput_7_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_7_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row7Struct pRow_row7 = new pRow_row7Struct();




	
	/**
	 * [tDBOutput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_7", false);
		start_Hash.put("tDBOutput_7", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_center_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row7");
			
		int tos_count_tDBOutput_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_7{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_7 = new StringBuilder();
                    log4jParamters_tDBOutput_7.append("Parameters:");
                            log4jParamters_tDBOutput_7.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("TABLE" + " = " + "\"mst_center_dw\"");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + (log4jParamters_tDBOutput_7) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_7().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_7", "\"mst_center_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_7 = null;
	dbschema_tDBOutput_7 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_7 = null;
if(dbschema_tDBOutput_7 == null || dbschema_tDBOutput_7.trim().length() == 0) {
	tableName_tDBOutput_7 = ("mst_center_dw");
} else {
	tableName_tDBOutput_7 = dbschema_tDBOutput_7 + "\".\"" + ("mst_center_dw");
}


int nb_line_tDBOutput_7 = 0;
int nb_line_update_tDBOutput_7 = 0;
int nb_line_inserted_tDBOutput_7 = 0;
int nb_line_deleted_tDBOutput_7 = 0;
int nb_line_rejected_tDBOutput_7 = 0;

int deletedCount_tDBOutput_7=0;
int updatedCount_tDBOutput_7=0;
int insertedCount_tDBOutput_7=0;
int rowsToCommitCount_tDBOutput_7=0;
int rejectedCount_tDBOutput_7=0;

boolean whetherReject_tDBOutput_7 = false;

java.sql.Connection conn_tDBOutput_7 = null;
String dbUser_tDBOutput_7 = null;

	conn_tDBOutput_7 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_7.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_7.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_7.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_7 = 10000;
   int batchSizeCounter_tDBOutput_7=0;

int count_tDBOutput_7=0;
        java.lang.StringBuilder sb_tDBOutput_7 = new java.lang.StringBuilder();
        sb_tDBOutput_7.append("INSERT INTO \"").append(tableName_tDBOutput_7).append("\" (\"id\",\"branch_name\",\"branch_id\",\"center_name\",\"wh_center_id\",\"meeting_day\",\"meeting_time_from\",\"meeting_time_to\",\"center_manager_id\",\"center_manager\",\"no_of_active_mem\",\"no_of_borrowers\",\"principal_os\",\"no_of_group\",\"longitude\",\"latitude\",\"center_risk_level\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"center_id\",\"audit_completed_date\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_7.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"branch_name\" = EXCLUDED.\"branch_name\",\"branch_id\" = EXCLUDED.\"branch_id\",\"center_name\" = EXCLUDED.\"center_name\",\"wh_center_id\" = EXCLUDED.\"wh_center_id\",\"meeting_day\" = EXCLUDED.\"meeting_day\",\"meeting_time_from\" = EXCLUDED.\"meeting_time_from\",\"meeting_time_to\" = EXCLUDED.\"meeting_time_to\",\"center_manager_id\" = EXCLUDED.\"center_manager_id\",\"center_manager\" = EXCLUDED.\"center_manager\",\"no_of_active_mem\" = EXCLUDED.\"no_of_active_mem\",\"no_of_borrowers\" = EXCLUDED.\"no_of_borrowers\",\"principal_os\" = EXCLUDED.\"principal_os\",\"no_of_group\" = EXCLUDED.\"no_of_group\",\"longitude\" = EXCLUDED.\"longitude\",\"latitude\" = EXCLUDED.\"latitude\",\"center_risk_level\" = EXCLUDED.\"center_risk_level\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"center_id\" = EXCLUDED.\"center_id\",\"audit_completed_date\" = EXCLUDED.\"audit_completed_date\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_7 = sb_tDBOutput_7.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Executing '")  + (insert_tDBOutput_7)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_7 = conn_tDBOutput_7.prepareStatement(insert_tDBOutput_7);
	    resourceMap.put("pstmt_tDBOutput_7", pstmt_tDBOutput_7);
	    

 



/**
 * [tDBOutput_7 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_7", false);
		start_Hash.put("tAsyncIn_tDBOutput_7", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	
		int tos_count_tAsyncIn_tDBOutput_7 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_7", "tAsyncIn_tDBOutput_7", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_7= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_7 = buffers_tAsyncIn_tDBOutput_7.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_7 != null && buffers_tAsyncIn_tDBOutput_7.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_7 : buffers_tAsyncIn_tDBOutput_7) {
    		pRow_row7 = null;						
			pRow_row7 = new pRow_row7Struct();
		
		
			String temp_tAsyncIn_tDBOutput_7_0 = row_tAsyncIn_tDBOutput_7[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[0]);
			if(temp_tAsyncIn_tDBOutput_7_0 != null) {
		
			pRow_row7.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_7_0);
		} else {						
			pRow_row7.id = 0;
		}
		pRow_row7.branch_name = row_tAsyncIn_tDBOutput_7[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[1]);
		
		
			String temp_tAsyncIn_tDBOutput_7_2 = row_tAsyncIn_tDBOutput_7[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[2]);
			if(temp_tAsyncIn_tDBOutput_7_2 != null) {
		
			pRow_row7.branch_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_7_2);
		} else {						
			pRow_row7.branch_id = 0;
		}
		pRow_row7.center_name = row_tAsyncIn_tDBOutput_7[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[3]);
		pRow_row7.wh_center_id = row_tAsyncIn_tDBOutput_7[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[4]);
		pRow_row7.meeting_day = row_tAsyncIn_tDBOutput_7[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[5]);
		pRow_row7.meeting_time_from = row_tAsyncIn_tDBOutput_7[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[6]);
		pRow_row7.meeting_time_to = row_tAsyncIn_tDBOutput_7[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[7]);
		pRow_row7.center_manager_id = row_tAsyncIn_tDBOutput_7[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[8]);
		pRow_row7.center_manager = row_tAsyncIn_tDBOutput_7[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[9]);
		
		
			String temp_tAsyncIn_tDBOutput_7_10 = row_tAsyncIn_tDBOutput_7[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[10]);
			if(temp_tAsyncIn_tDBOutput_7_10 != null) {
		
			pRow_row7.no_of_active_mem = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_7_10);
		} else {						
			pRow_row7.no_of_active_mem = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_11 = row_tAsyncIn_tDBOutput_7[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[11]);
			if(temp_tAsyncIn_tDBOutput_7_11 != null) {
		
			pRow_row7.no_of_borrowers = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_7_11);
		} else {						
			pRow_row7.no_of_borrowers = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_12 = row_tAsyncIn_tDBOutput_7[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[12]);
			if(temp_tAsyncIn_tDBOutput_7_12 != null) {
		
			pRow_row7.principal_os = ParserUtils.parseTo_Float(temp_tAsyncIn_tDBOutput_7_12);
		} else {						
			pRow_row7.principal_os = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_13 = row_tAsyncIn_tDBOutput_7[13]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[13]);
			if(temp_tAsyncIn_tDBOutput_7_13 != null) {
		
			pRow_row7.no_of_group = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_7_13);
		} else {						
			pRow_row7.no_of_group = null;
		}
		pRow_row7.longitude = row_tAsyncIn_tDBOutput_7[14]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[14]);
		pRow_row7.latitude = row_tAsyncIn_tDBOutput_7[15]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[15]);
		pRow_row7.center_risk_level = row_tAsyncIn_tDBOutput_7[16]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[16]);
		
		
			String temp_tAsyncIn_tDBOutput_7_17 = row_tAsyncIn_tDBOutput_7[17]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[17]);
			if(temp_tAsyncIn_tDBOutput_7_17 != null) {
		
			pRow_row7.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_7_17);
		} else {						
			pRow_row7.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_18 = row_tAsyncIn_tDBOutput_7[18]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[18]);
			if(temp_tAsyncIn_tDBOutput_7_18 != null) {
		
			pRow_row7.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_7[18]);
		} else {						
			pRow_row7.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_19 = row_tAsyncIn_tDBOutput_7[19]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[19]);
			if(temp_tAsyncIn_tDBOutput_7_19 != null) {
		
			pRow_row7.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_7_19);
		} else {						
			pRow_row7.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_20 = row_tAsyncIn_tDBOutput_7[20]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[20]);
			if(temp_tAsyncIn_tDBOutput_7_20 != null) {
		
			pRow_row7.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_7[20]);
		} else {						
			pRow_row7.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_21 = row_tAsyncIn_tDBOutput_7[21]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[21]);
			if(temp_tAsyncIn_tDBOutput_7_21 != null) {
		
			pRow_row7.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_7_21);
		} else {						
			pRow_row7.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_22 = row_tAsyncIn_tDBOutput_7[22]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[22]);
			if(temp_tAsyncIn_tDBOutput_7_22 != null) {
		
			pRow_row7.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_7_22);
		} else {						
			pRow_row7.is_deleted = 0;
		}
		pRow_row7.center_id = row_tAsyncIn_tDBOutput_7[23]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[23]);
		
		
			String temp_tAsyncIn_tDBOutput_7_24 = row_tAsyncIn_tDBOutput_7[24]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[24]);
			if(temp_tAsyncIn_tDBOutput_7_24 != null) {
		
			pRow_row7.audit_completed_date = (java.util.Date)(row_tAsyncIn_tDBOutput_7[24]);
		} else {						
			pRow_row7.audit_completed_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_25 = row_tAsyncIn_tDBOutput_7[25]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[25]);
			if(temp_tAsyncIn_tDBOutput_7_25 != null) {
		
			pRow_row7.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_7[25]);
		} else {						
			pRow_row7.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_7 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_7 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

 


	tos_count_tAsyncIn_tDBOutput_7++;

/**
 * [tAsyncIn_tDBOutput_7 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

 



/**
 * [tAsyncIn_tDBOutput_7 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_7 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_center_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row7","tAsyncIn_tDBOutput_7","tAsyncIn_tDBOutput_7","tAsyncIn","tDBOutput_7","\"mst_center_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row7 - " + (pRow_row7==null? "": pRow_row7.toLogString()));
    			}
    		



				batchSize_tDBOutput_7 = buffersSize_tAsyncIn_tDBOutput_7;
        whetherReject_tDBOutput_7 = false;
                    pstmt_tDBOutput_7.setInt(1, pRow_row7.id);

                    if(pRow_row7.branch_name == null) {
pstmt_tDBOutput_7.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(2, pRow_row7.branch_name);
}

                    pstmt_tDBOutput_7.setInt(3, pRow_row7.branch_id);

                    if(pRow_row7.center_name == null) {
pstmt_tDBOutput_7.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(4, pRow_row7.center_name);
}

                    if(pRow_row7.wh_center_id == null) {
pstmt_tDBOutput_7.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(5, pRow_row7.wh_center_id);
}

                    if(pRow_row7.meeting_day == null) {
pstmt_tDBOutput_7.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(6, pRow_row7.meeting_day);
}

                    if(pRow_row7.meeting_time_from == null) {
pstmt_tDBOutput_7.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(7, pRow_row7.meeting_time_from);
}

                    if(pRow_row7.meeting_time_to == null) {
pstmt_tDBOutput_7.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(8, pRow_row7.meeting_time_to);
}

                    if(pRow_row7.center_manager_id == null) {
pstmt_tDBOutput_7.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(9, pRow_row7.center_manager_id);
}

                    if(pRow_row7.center_manager == null) {
pstmt_tDBOutput_7.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(10, pRow_row7.center_manager);
}

                    if(pRow_row7.no_of_active_mem == null) {
pstmt_tDBOutput_7.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_7.setInt(11, pRow_row7.no_of_active_mem);
}

                    if(pRow_row7.no_of_borrowers == null) {
pstmt_tDBOutput_7.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_7.setInt(12, pRow_row7.no_of_borrowers);
}

                    if(pRow_row7.principal_os == null) {
pstmt_tDBOutput_7.setNull(13, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_7.setFloat(13, pRow_row7.principal_os);
}

                    if(pRow_row7.no_of_group == null) {
pstmt_tDBOutput_7.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_7.setInt(14, pRow_row7.no_of_group);
}

                    if(pRow_row7.longitude == null) {
pstmt_tDBOutput_7.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(15, pRow_row7.longitude);
}

                    if(pRow_row7.latitude == null) {
pstmt_tDBOutput_7.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(16, pRow_row7.latitude);
}

                    if(pRow_row7.center_risk_level == null) {
pstmt_tDBOutput_7.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(17, pRow_row7.center_risk_level);
}

                    if(pRow_row7.created_by == null) {
pstmt_tDBOutput_7.setNull(18, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_7.setInt(18, pRow_row7.created_by);
}

                    if(pRow_row7.created_on != null) {
pstmt_tDBOutput_7.setTimestamp(19, new java.sql.Timestamp(pRow_row7.created_on.getTime()));
} else {
pstmt_tDBOutput_7.setNull(19, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row7.updated_by == null) {
pstmt_tDBOutput_7.setNull(20, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_7.setInt(20, pRow_row7.updated_by);
}

                    if(pRow_row7.updated_on != null) {
pstmt_tDBOutput_7.setTimestamp(21, new java.sql.Timestamp(pRow_row7.updated_on.getTime()));
} else {
pstmt_tDBOutput_7.setNull(21, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_7.setInt(22, pRow_row7.is_active);

                    pstmt_tDBOutput_7.setInt(23, pRow_row7.is_deleted);

                    if(pRow_row7.center_id == null) {
pstmt_tDBOutput_7.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(24, pRow_row7.center_id);
}

                    if(pRow_row7.audit_completed_date != null) {
pstmt_tDBOutput_7.setTimestamp(25, new java.sql.Timestamp(pRow_row7.audit_completed_date.getTime()));
} else {
pstmt_tDBOutput_7.setNull(25, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row7.as_on != null) {
pstmt_tDBOutput_7.setTimestamp(26, new java.sql.Timestamp(pRow_row7.as_on.getTime()));
} else {
pstmt_tDBOutput_7.setNull(26, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_7.addBatch();
    		nb_line_tDBOutput_7++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Adding the record ")  + (nb_line_tDBOutput_7)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_7++;
    		  
    			if ((batchSize_tDBOutput_7 > 0) && (batchSize_tDBOutput_7 <= batchSizeCounter_tDBOutput_7)) {
                try {
						int countSum_tDBOutput_7 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_7: pstmt_tDBOutput_7.executeBatch()) {
							countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
				    	
				    		insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
				    	
            	    	batchSizeCounter_tDBOutput_7 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_7){
globalMap.put("tDBOutput_7_ERROR_MESSAGE",e_tDBOutput_7.getMessage());
				    	java.sql.SQLException ne_tDBOutput_7 = e_tDBOutput_7.getNextException(),sqle_tDBOutput_7=null;
				    	String errormessage_tDBOutput_7;
						if (ne_tDBOutput_7 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_7 = new java.sql.SQLException(e_tDBOutput_7.getMessage() + "\ncaused by: " + ne_tDBOutput_7.getMessage(), ne_tDBOutput_7.getSQLState(), ne_tDBOutput_7.getErrorCode(), ne_tDBOutput_7);
							errormessage_tDBOutput_7 = sqle_tDBOutput_7.getMessage();
						}else{
							errormessage_tDBOutput_7 = e_tDBOutput_7.getMessage();
						}
				    	
				    	int countSum_tDBOutput_7 = 0;
						for(int countEach_tDBOutput_7: e_tDBOutput_7.getUpdateCounts()) {
							countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
						}
						rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
						
				    		insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
				    	
            log.error("tDBOutput_7 - "  + (errormessage_tDBOutput_7) );
				    	System.err.println(errormessage_tDBOutput_7);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_7++;

/**
 * [tDBOutput_7 main ] stop
 */
	
	/**
	 * [tDBOutput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_center_dw\"";
		

 



/**
 * [tDBOutput_7 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_center_dw\"";
		

 



/**
 * [tDBOutput_7 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

 



/**
 * [tAsyncIn_tDBOutput_7 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_7 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_7.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_7", true);
end_Hash.put("tAsyncIn_tDBOutput_7", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_7 end ] stop
 */

	
	/**
	 * [tDBOutput_7 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_center_dw\"";
		



	    try {
				int countSum_tDBOutput_7 = 0;
				if (pstmt_tDBOutput_7 != null && batchSizeCounter_tDBOutput_7 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_7: pstmt_tDBOutput_7.executeBatch()) {
						countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
					}
					rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_7){
globalMap.put("tDBOutput_7_ERROR_MESSAGE",e_tDBOutput_7.getMessage());
	    	java.sql.SQLException ne_tDBOutput_7 = e_tDBOutput_7.getNextException(),sqle_tDBOutput_7=null;
	    	String errormessage_tDBOutput_7;
			if (ne_tDBOutput_7 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_7 = new java.sql.SQLException(e_tDBOutput_7.getMessage() + "\ncaused by: " + ne_tDBOutput_7.getMessage(), ne_tDBOutput_7.getSQLState(), ne_tDBOutput_7.getErrorCode(), ne_tDBOutput_7);
				errormessage_tDBOutput_7 = sqle_tDBOutput_7.getMessage();
			}else{
				errormessage_tDBOutput_7 = e_tDBOutput_7.getMessage();
			}
	    	
	    	int countSum_tDBOutput_7 = 0;
			for(int countEach_tDBOutput_7: e_tDBOutput_7.getUpdateCounts()) {
				countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
			}
			rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
			
	    		insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
	    	
            log.error("tDBOutput_7 - "  + (errormessage_tDBOutput_7) );
	    	System.err.println(errormessage_tDBOutput_7);
	    	
		}
	    
        if(pstmt_tDBOutput_7 != null) {
        		
            pstmt_tDBOutput_7.close();
            resourceMap.remove("pstmt_tDBOutput_7");
        }
    resourceMap.put("statementClosed_tDBOutput_7", true);

	nb_line_deleted_tDBOutput_7=nb_line_deleted_tDBOutput_7+ deletedCount_tDBOutput_7;
	nb_line_update_tDBOutput_7=nb_line_update_tDBOutput_7 + updatedCount_tDBOutput_7;
	nb_line_inserted_tDBOutput_7=nb_line_inserted_tDBOutput_7 + insertedCount_tDBOutput_7;
	nb_line_rejected_tDBOutput_7=nb_line_rejected_tDBOutput_7 + rejectedCount_tDBOutput_7;
	
    	if (globalMap.get("tDBOutput_7_NB_LINE") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE",nb_line_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE",(Integer)globalMap.get("tDBOutput_7_NB_LINE") + nb_line_tDBOutput_7);
        }
        if (globalMap.get("tDBOutput_7_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE_UPDATED",nb_line_update_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_7_NB_LINE_UPDATED") + nb_line_update_tDBOutput_7);
        }
        if (globalMap.get("tDBOutput_7_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_7_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_7);
        }
        if (globalMap.get("tDBOutput_7_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE_DELETED",nb_line_deleted_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_7_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_7);
        }
        if (globalMap.get("tDBOutput_7_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_7_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_7);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row7",2,0,
			 			"tAsyncIn_tDBOutput_7","tAsyncIn_tDBOutput_7","tAsyncIn","tDBOutput_7","\"mst_center_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Done.") );

ok_Hash.put("tDBOutput_7", true);
end_Hash.put("tDBOutput_7", System.currentTimeMillis());




/**
 * [tDBOutput_7 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_7 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

 



/**
 * [tAsyncIn_tDBOutput_7 finally ] stop
 */

	
	/**
	 * [tDBOutput_7 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_center_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_7") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_7 = null;
                if ((pstmtToClose_tDBOutput_7 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_7")) != null) {
                    pstmtToClose_tDBOutput_7.close();
                }
    }
 



/**
 * [tDBOutput_7 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_7");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_7_ParallelThread pt = new tAsyncIn_tDBOutput_7_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_7"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_7_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "Qit0F1_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final Audit_incremental_7_tables_3 Audit_incremental_7_tables_3Class = new Audit_incremental_7_tables_3();

        int exitCode = Audit_incremental_7_tables_3Class.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'Audit_incremental_7_tables_3' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230612_1054-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'Audit_incremental_7_tables_3' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_4U2qwNkuEe2cDNax3wxz5A");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-08-02T11:50:19.690398700Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = Audit_incremental_7_tables_3.class.getClassLoader().getResourceAsStream("talend_tac2_repo/audit_incremental_7_tables_3_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = Audit_incremental_7_tables_3.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'Audit_incremental_7_tables_3' - Started.");
            mdcInfo.putAll(org.slf4j.MDC.getCopyOfContextMap());

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}
try {
errorCode = null;tDBInput_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_2) {
globalMap.put("tDBInput_2_SUBPROCESS_STATE", -1);

e_tDBInput_2.printStackTrace();

}
try {
errorCode = null;tDBInput_3Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_3) {
globalMap.put("tDBInput_3_SUBPROCESS_STATE", -1);

e_tDBInput_3.printStackTrace();

}
try {
errorCode = null;tDBInput_4Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_4) {
globalMap.put("tDBInput_4_SUBPROCESS_STATE", -1);

e_tDBInput_4.printStackTrace();

}
try {
errorCode = null;tDBInput_5Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_5) {
globalMap.put("tDBInput_5_SUBPROCESS_STATE", -1);

e_tDBInput_5.printStackTrace();

}
try {
errorCode = null;tDBInput_6Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_6) {
globalMap.put("tDBInput_6_SUBPROCESS_STATE", -1);

e_tDBInput_6.printStackTrace();

}
try {
errorCode = null;tDBInput_7Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_7) {
globalMap.put("tDBInput_7_SUBPROCESS_STATE", -1);

e_tDBInput_7.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : Audit_incremental_7_tables_3");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'Audit_incremental_7_tables_3' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     947867 characters generated by Talend Data Integration 
 *     on the August 2, 2023 at 5:20:19 PM IST
 ************************************************************************************************/