
package talend_tac2_repo.audit_incremental_2_tables_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: Audit_incremental_2_tables Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230612_1054-patch
 * @status 
 */
public class Audit_incremental_2_tables implements TalendJob {
	static {System.setProperty("TalendJob.log", "Audit_incremental_2_tables.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(Audit_incremental_2_tables.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "Audit_incremental_2_tables";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_bj4kQNnzEe2z1bmRttdHBw", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				Audit_incremental_2_tables.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(Audit_incremental_2_tables.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_1_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_2_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	



public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String region;

				public String getRegion () {
					return this.region;
				}

				public Boolean regionIsNullable(){
				    return true;
				}
				public Boolean regionIsKey(){
				    return false;
				}
				public Integer regionLength(){
				    return 2147483647;
				}
				public Integer regionPrecision(){
				    return 0;
				}
				public String regionDefault(){
				
					return null;
				
				}
				public String regionComment(){
				
				    return "";
				
				}
				public String regionPattern(){
				
					return "";
				
				}
				public String regionOriginalDbColumnName(){
				
					return "region";
				
				}

				
			    public String division;

				public String getDivision () {
					return this.division;
				}

				public Boolean divisionIsNullable(){
				    return true;
				}
				public Boolean divisionIsKey(){
				    return false;
				}
				public Integer divisionLength(){
				    return 2147483647;
				}
				public Integer divisionPrecision(){
				    return 0;
				}
				public String divisionDefault(){
				
					return null;
				
				}
				public String divisionComment(){
				
				    return "";
				
				}
				public String divisionPattern(){
				
					return "";
				
				}
				public String divisionOriginalDbColumnName(){
				
					return "division";
				
				}

				
			    public String branch_id;

				public String getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return true;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 2147483647;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return null;
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public String branch;

				public String getBranch () {
					return this.branch;
				}

				public Boolean branchIsNullable(){
				    return true;
				}
				public Boolean branchIsKey(){
				    return false;
				}
				public Integer branchLength(){
				    return 2147483647;
				}
				public Integer branchPrecision(){
				    return 0;
				}
				public String branchDefault(){
				
					return null;
				
				}
				public String branchComment(){
				
				    return "";
				
				}
				public String branchPattern(){
				
					return "";
				
				}
				public String branchOriginalDbColumnName(){
				
					return "branch";
				
				}

				
			    public Short month;

				public Short getMonth () {
					return this.month;
				}

				public Boolean monthIsNullable(){
				    return true;
				}
				public Boolean monthIsKey(){
				    return false;
				}
				public Integer monthLength(){
				    return 5;
				}
				public Integer monthPrecision(){
				    return 0;
				}
				public String monthDefault(){
				
					return null;
				
				}
				public String monthComment(){
				
				    return "";
				
				}
				public String monthPattern(){
				
					return "";
				
				}
				public String monthOriginalDbColumnName(){
				
					return "month";
				
				}

				
			    public Integer year;

				public Integer getYear () {
					return this.year;
				}

				public Boolean yearIsNullable(){
				    return true;
				}
				public Boolean yearIsKey(){
				    return false;
				}
				public Integer yearLength(){
				    return 10;
				}
				public Integer yearPrecision(){
				    return 0;
				}
				public String yearDefault(){
				
					return null;
				
				}
				public String yearComment(){
				
				    return "";
				
				}
				public String yearPattern(){
				
					return "";
				
				}
				public String yearOriginalDbColumnName(){
				
					return "year";
				
				}

				
			    public java.util.Date tentative_from_date;

				public java.util.Date getTentative_from_date () {
					return this.tentative_from_date;
				}

				public Boolean tentative_from_dateIsNullable(){
				    return true;
				}
				public Boolean tentative_from_dateIsKey(){
				    return false;
				}
				public Integer tentative_from_dateLength(){
				    return 13;
				}
				public Integer tentative_from_datePrecision(){
				    return 0;
				}
				public String tentative_from_dateDefault(){
				
					return null;
				
				}
				public String tentative_from_dateComment(){
				
				    return "";
				
				}
				public String tentative_from_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tentative_from_dateOriginalDbColumnName(){
				
					return "tentative_from_date";
				
				}

				
			    public java.util.Date tentative_to_date;

				public java.util.Date getTentative_to_date () {
					return this.tentative_to_date;
				}

				public Boolean tentative_to_dateIsNullable(){
				    return true;
				}
				public Boolean tentative_to_dateIsKey(){
				    return false;
				}
				public Integer tentative_to_dateLength(){
				    return 13;
				}
				public Integer tentative_to_datePrecision(){
				    return 0;
				}
				public String tentative_to_dateDefault(){
				
					return null;
				
				}
				public String tentative_to_dateComment(){
				
				    return "";
				
				}
				public String tentative_to_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tentative_to_dateOriginalDbColumnName(){
				
					return "tentative_to_date";
				
				}

				
			    public java.util.Date cutoff_date;

				public java.util.Date getCutoff_date () {
					return this.cutoff_date;
				}

				public Boolean cutoff_dateIsNullable(){
				    return true;
				}
				public Boolean cutoff_dateIsKey(){
				    return false;
				}
				public Integer cutoff_dateLength(){
				    return 13;
				}
				public Integer cutoff_datePrecision(){
				    return 0;
				}
				public String cutoff_dateDefault(){
				
					return null;
				
				}
				public String cutoff_dateComment(){
				
				    return "";
				
				}
				public String cutoff_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String cutoff_dateOriginalDbColumnName(){
				
					return "cutoff_date";
				
				}

				
			    public Integer auditor_id;

				public Integer getAuditor_id () {
					return this.auditor_id;
				}

				public Boolean auditor_idIsNullable(){
				    return true;
				}
				public Boolean auditor_idIsKey(){
				    return false;
				}
				public Integer auditor_idLength(){
				    return 10;
				}
				public Integer auditor_idPrecision(){
				    return 0;
				}
				public String auditor_idDefault(){
				
					return null;
				
				}
				public String auditor_idComment(){
				
				    return "";
				
				}
				public String auditor_idPattern(){
				
					return "";
				
				}
				public String auditor_idOriginalDbColumnName(){
				
					return "auditor_id";
				
				}

				
			    public String auditor;

				public String getAuditor () {
					return this.auditor;
				}

				public Boolean auditorIsNullable(){
				    return true;
				}
				public Boolean auditorIsKey(){
				    return false;
				}
				public Integer auditorLength(){
				    return 2147483647;
				}
				public Integer auditorPrecision(){
				    return 0;
				}
				public String auditorDefault(){
				
					return null;
				
				}
				public String auditorComment(){
				
				    return "";
				
				}
				public String auditorPattern(){
				
					return "";
				
				}
				public String auditorOriginalDbColumnName(){
				
					return "auditor";
				
				}

				
			    public String des;

				public String getDes () {
					return this.des;
				}

				public Boolean desIsNullable(){
				    return true;
				}
				public Boolean desIsKey(){
				    return false;
				}
				public Integer desLength(){
				    return 2147483647;
				}
				public Integer desPrecision(){
				    return 0;
				}
				public String desDefault(){
				
					return null;
				
				}
				public String desComment(){
				
				    return "";
				
				}
				public String desPattern(){
				
					return "";
				
				}
				public String desOriginalDbColumnName(){
				
					return "des";
				
				}

				
			    public java.util.Date audit_commencement_date;

				public java.util.Date getAudit_commencement_date () {
					return this.audit_commencement_date;
				}

				public Boolean audit_commencement_dateIsNullable(){
				    return true;
				}
				public Boolean audit_commencement_dateIsKey(){
				    return false;
				}
				public Integer audit_commencement_dateLength(){
				    return 13;
				}
				public Integer audit_commencement_datePrecision(){
				    return 0;
				}
				public String audit_commencement_dateDefault(){
				
					return null;
				
				}
				public String audit_commencement_dateComment(){
				
				    return "";
				
				}
				public String audit_commencement_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audit_commencement_dateOriginalDbColumnName(){
				
					return "audit_commencement_date";
				
				}

				
			    public java.util.Date closed_date;

				public java.util.Date getClosed_date () {
					return this.closed_date;
				}

				public Boolean closed_dateIsNullable(){
				    return true;
				}
				public Boolean closed_dateIsKey(){
				    return false;
				}
				public Integer closed_dateLength(){
				    return 13;
				}
				public Integer closed_datePrecision(){
				    return 0;
				}
				public String closed_dateDefault(){
				
					return null;
				
				}
				public String closed_dateComment(){
				
				    return "";
				
				}
				public String closed_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String closed_dateOriginalDbColumnName(){
				
					return "closed_date";
				
				}

				
			    public String comments_by_auditor;

				public String getComments_by_auditor () {
					return this.comments_by_auditor;
				}

				public Boolean comments_by_auditorIsNullable(){
				    return true;
				}
				public Boolean comments_by_auditorIsKey(){
				    return false;
				}
				public Integer comments_by_auditorLength(){
				    return 2147483647;
				}
				public Integer comments_by_auditorPrecision(){
				    return 0;
				}
				public String comments_by_auditorDefault(){
				
					return null;
				
				}
				public String comments_by_auditorComment(){
				
				    return "";
				
				}
				public String comments_by_auditorPattern(){
				
					return "";
				
				}
				public String comments_by_auditorOriginalDbColumnName(){
				
					return "comments_by_auditor";
				
				}

				
			    public Integer branch_audit_id;

				public Integer getBranch_audit_id () {
					return this.branch_audit_id;
				}

				public Boolean branch_audit_idIsNullable(){
				    return true;
				}
				public Boolean branch_audit_idIsKey(){
				    return false;
				}
				public Integer branch_audit_idLength(){
				    return 10;
				}
				public Integer branch_audit_idPrecision(){
				    return 0;
				}
				public String branch_audit_idDefault(){
				
					return null;
				
				}
				public String branch_audit_idComment(){
				
				    return "";
				
				}
				public String branch_audit_idPattern(){
				
					return "";
				
				}
				public String branch_audit_idOriginalDbColumnName(){
				
					return "branch_audit_id";
				
				}

				
			    public java.util.Date tat_requested_date;

				public java.util.Date getTat_requested_date () {
					return this.tat_requested_date;
				}

				public Boolean tat_requested_dateIsNullable(){
				    return true;
				}
				public Boolean tat_requested_dateIsKey(){
				    return false;
				}
				public Integer tat_requested_dateLength(){
				    return 13;
				}
				public Integer tat_requested_datePrecision(){
				    return 0;
				}
				public String tat_requested_dateDefault(){
				
					return null;
				
				}
				public String tat_requested_dateComment(){
				
				    return "";
				
				}
				public String tat_requested_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tat_requested_dateOriginalDbColumnName(){
				
					return "tat_requested_date";
				
				}

				
			    public String tat_reason;

				public String getTat_reason () {
					return this.tat_reason;
				}

				public Boolean tat_reasonIsNullable(){
				    return true;
				}
				public Boolean tat_reasonIsKey(){
				    return false;
				}
				public Integer tat_reasonLength(){
				    return 2147483647;
				}
				public Integer tat_reasonPrecision(){
				    return 0;
				}
				public String tat_reasonDefault(){
				
					return null;
				
				}
				public String tat_reasonComment(){
				
				    return "";
				
				}
				public String tat_reasonPattern(){
				
					return "";
				
				}
				public String tat_reasonOriginalDbColumnName(){
				
					return "tat_reason";
				
				}

				
			    public BigDecimal tat_status;

				public BigDecimal getTat_status () {
					return this.tat_status;
				}

				public Boolean tat_statusIsNullable(){
				    return true;
				}
				public Boolean tat_statusIsKey(){
				    return false;
				}
				public Integer tat_statusLength(){
				    return 16;
				}
				public Integer tat_statusPrecision(){
				    return 0;
				}
				public String tat_statusDefault(){
				
					return null;
				
				}
				public String tat_statusComment(){
				
				    return "";
				
				}
				public String tat_statusPattern(){
				
					return "";
				
				}
				public String tat_statusOriginalDbColumnName(){
				
					return "tat_status";
				
				}

				
			    public String final_comments;

				public String getFinal_comments () {
					return this.final_comments;
				}

				public Boolean final_commentsIsNullable(){
				    return true;
				}
				public Boolean final_commentsIsKey(){
				    return false;
				}
				public Integer final_commentsLength(){
				    return 2147483647;
				}
				public Integer final_commentsPrecision(){
				    return 0;
				}
				public String final_commentsDefault(){
				
					return null;
				
				}
				public String final_commentsComment(){
				
				    return "";
				
				}
				public String final_commentsPattern(){
				
					return "";
				
				}
				public String final_commentsOriginalDbColumnName(){
				
					return "final_comments";
				
				}

				
			    public Integer checklist_id;

				public Integer getChecklist_id () {
					return this.checklist_id;
				}

				public Boolean checklist_idIsNullable(){
				    return true;
				}
				public Boolean checklist_idIsKey(){
				    return false;
				}
				public Integer checklist_idLength(){
				    return 10;
				}
				public Integer checklist_idPrecision(){
				    return 0;
				}
				public String checklist_idDefault(){
				
					return null;
				
				}
				public String checklist_idComment(){
				
				    return "";
				
				}
				public String checklist_idPattern(){
				
					return "";
				
				}
				public String checklist_idOriginalDbColumnName(){
				
					return "checklist_id";
				
				}

				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}

				public Boolean longitudeIsNullable(){
				    return true;
				}
				public Boolean longitudeIsKey(){
				    return false;
				}
				public Integer longitudeLength(){
				    return 2147483647;
				}
				public Integer longitudePrecision(){
				    return 0;
				}
				public String longitudeDefault(){
				
					return null;
				
				}
				public String longitudeComment(){
				
				    return "";
				
				}
				public String longitudePattern(){
				
					return "";
				
				}
				public String longitudeOriginalDbColumnName(){
				
					return "longitude";
				
				}

				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}

				public Boolean latitudeIsNullable(){
				    return true;
				}
				public Boolean latitudeIsKey(){
				    return false;
				}
				public Integer latitudeLength(){
				    return 2147483647;
				}
				public Integer latitudePrecision(){
				    return 0;
				}
				public String latitudeDefault(){
				
					return null;
				
				}
				public String latitudeComment(){
				
				    return "";
				
				}
				public String latitudePattern(){
				
					return "";
				
				}
				public String latitudeOriginalDbColumnName(){
				
					return "latitude";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_date;

				public java.util.Date getCreated_date () {
					return this.created_date;
				}

				public Boolean created_dateIsNullable(){
				    return true;
				}
				public Boolean created_dateIsKey(){
				    return false;
				}
				public Integer created_dateLength(){
				    return 13;
				}
				public Integer created_datePrecision(){
				    return 0;
				}
				public String created_dateDefault(){
				
					return null;
				
				}
				public String created_dateComment(){
				
				    return "";
				
				}
				public String created_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_dateOriginalDbColumnName(){
				
					return "created_date";
				
				}

				
			    public Integer is_active;

				public Integer getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return true;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return null;
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public Integer is_deleted;

				public Integer getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return true;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return null;
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return true;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return null;
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public String status;

				public String getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 2147483647;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public Integer is_surprised;

				public Integer getIs_surprised () {
					return this.is_surprised;
				}

				public Boolean is_surprisedIsNullable(){
				    return true;
				}
				public Boolean is_surprisedIsKey(){
				    return false;
				}
				public Integer is_surprisedLength(){
				    return 10;
				}
				public Integer is_surprisedPrecision(){
				    return 0;
				}
				public String is_surprisedDefault(){
				
					return null;
				
				}
				public String is_surprisedComment(){
				
				    return "";
				
				}
				public String is_surprisedPattern(){
				
					return "";
				
				}
				public String is_surprisedOriginalDbColumnName(){
				
					return "is_surprised";
				
				}

				
			    public String audit_commencement_info_id;

				public String getAudit_commencement_info_id () {
					return this.audit_commencement_info_id;
				}

				public Boolean audit_commencement_info_idIsNullable(){
				    return true;
				}
				public Boolean audit_commencement_info_idIsKey(){
				    return false;
				}
				public Integer audit_commencement_info_idLength(){
				    return 2147483647;
				}
				public Integer audit_commencement_info_idPrecision(){
				    return 0;
				}
				public String audit_commencement_info_idDefault(){
				
					return null;
				
				}
				public String audit_commencement_info_idComment(){
				
				    return "";
				
				}
				public String audit_commencement_info_idPattern(){
				
					return "";
				
				}
				public String audit_commencement_info_idOriginalDbColumnName(){
				
					return "audit_commencement_info_id";
				
				}

				
			    public BigDecimal closed_by;

				public BigDecimal getClosed_by () {
					return this.closed_by;
				}

				public Boolean closed_byIsNullable(){
				    return true;
				}
				public Boolean closed_byIsKey(){
				    return false;
				}
				public Integer closed_byLength(){
				    return 0;
				}
				public Integer closed_byPrecision(){
				    return 0;
				}
				public String closed_byDefault(){
				
					return null;
				
				}
				public String closed_byComment(){
				
				    return "";
				
				}
				public String closed_byPattern(){
				
					return "";
				
				}
				public String closed_byOriginalDbColumnName(){
				
					return "closed_by";
				
				}

				
			    public Integer allow_forced_submit;

				public Integer getAllow_forced_submit () {
					return this.allow_forced_submit;
				}

				public Boolean allow_forced_submitIsNullable(){
				    return true;
				}
				public Boolean allow_forced_submitIsKey(){
				    return false;
				}
				public Integer allow_forced_submitLength(){
				    return 10;
				}
				public Integer allow_forced_submitPrecision(){
				    return 0;
				}
				public String allow_forced_submitDefault(){
				
					return null;
				
				}
				public String allow_forced_submitComment(){
				
				    return "";
				
				}
				public String allow_forced_submitPattern(){
				
					return "";
				
				}
				public String allow_forced_submitOriginalDbColumnName(){
				
					return "allow_forced_submit";
				
				}

				
			    public Integer is_sink;

				public Integer getIs_sink () {
					return this.is_sink;
				}

				public Boolean is_sinkIsNullable(){
				    return true;
				}
				public Boolean is_sinkIsKey(){
				    return false;
				}
				public Integer is_sinkLength(){
				    return 10;
				}
				public Integer is_sinkPrecision(){
				    return 0;
				}
				public String is_sinkDefault(){
				
					return null;
				
				}
				public String is_sinkComment(){
				
				    return "";
				
				}
				public String is_sinkPattern(){
				
					return "";
				
				}
				public String is_sinkOriginalDbColumnName(){
				
					return "is_sink";
				
				}

				
			    public Integer is_team_changed;

				public Integer getIs_team_changed () {
					return this.is_team_changed;
				}

				public Boolean is_team_changedIsNullable(){
				    return true;
				}
				public Boolean is_team_changedIsKey(){
				    return false;
				}
				public Integer is_team_changedLength(){
				    return 10;
				}
				public Integer is_team_changedPrecision(){
				    return 0;
				}
				public String is_team_changedDefault(){
				
					return null;
				
				}
				public String is_team_changedComment(){
				
				    return "";
				
				}
				public String is_team_changedPattern(){
				
					return "";
				
				}
				public String is_team_changedOriginalDbColumnName(){
				
					return "is_team_changed";
				
				}

				
			    public Integer is_editable;

				public Integer getIs_editable () {
					return this.is_editable;
				}

				public Boolean is_editableIsNullable(){
				    return true;
				}
				public Boolean is_editableIsKey(){
				    return false;
				}
				public Integer is_editableLength(){
				    return 10;
				}
				public Integer is_editablePrecision(){
				    return 0;
				}
				public String is_editableDefault(){
				
					return null;
				
				}
				public String is_editableComment(){
				
				    return "";
				
				}
				public String is_editablePattern(){
				
					return "";
				
				}
				public String is_editableOriginalDbColumnName(){
				
					return "is_editable";
				
				}

				
			    public java.util.Date freezing_date;

				public java.util.Date getFreezing_date () {
					return this.freezing_date;
				}

				public Boolean freezing_dateIsNullable(){
				    return true;
				}
				public Boolean freezing_dateIsKey(){
				    return false;
				}
				public Integer freezing_dateLength(){
				    return 13;
				}
				public Integer freezing_datePrecision(){
				    return 0;
				}
				public String freezing_dateDefault(){
				
					return null;
				
				}
				public String freezing_dateComment(){
				
				    return "";
				
				}
				public String freezing_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String freezing_dateOriginalDbColumnName(){
				
					return "freezing_date";
				
				}

				
			    public Integer recalculation;

				public Integer getRecalculation () {
					return this.recalculation;
				}

				public Boolean recalculationIsNullable(){
				    return true;
				}
				public Boolean recalculationIsKey(){
				    return false;
				}
				public Integer recalculationLength(){
				    return 10;
				}
				public Integer recalculationPrecision(){
				    return 0;
				}
				public String recalculationDefault(){
				
					return null;
				
				}
				public String recalculationComment(){
				
				    return "";
				
				}
				public String recalculationPattern(){
				
					return "";
				
				}
				public String recalculationOriginalDbColumnName(){
				
					return "recalculation";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.id = this.id;
	            other.region = this.region;
	            other.division = this.division;
	            other.branch_id = this.branch_id;
	            other.branch = this.branch;
	            other.month = this.month;
	            other.year = this.year;
	            other.tentative_from_date = this.tentative_from_date;
	            other.tentative_to_date = this.tentative_to_date;
	            other.cutoff_date = this.cutoff_date;
	            other.auditor_id = this.auditor_id;
	            other.auditor = this.auditor;
	            other.des = this.des;
	            other.audit_commencement_date = this.audit_commencement_date;
	            other.closed_date = this.closed_date;
	            other.comments_by_auditor = this.comments_by_auditor;
	            other.branch_audit_id = this.branch_audit_id;
	            other.tat_requested_date = this.tat_requested_date;
	            other.tat_reason = this.tat_reason;
	            other.tat_status = this.tat_status;
	            other.final_comments = this.final_comments;
	            other.checklist_id = this.checklist_id;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.created_by = this.created_by;
	            other.created_date = this.created_date;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.status = this.status;
	            other.is_surprised = this.is_surprised;
	            other.audit_commencement_info_id = this.audit_commencement_info_id;
	            other.closed_by = this.closed_by;
	            other.allow_forced_submit = this.allow_forced_submit;
	            other.is_sink = this.is_sink;
	            other.is_team_changed = this.is_team_changed;
	            other.is_editable = this.is_editable;
	            other.freezing_date = this.freezing_date;
	            other.recalculation = this.recalculation;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
					this.division = readString(dis);
					
					this.branch_id = readString(dis);
					
					this.branch = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.month = null;
           				} else {
           			    	this.month = dis.readShort();
           				}
					
						this.year = readInteger(dis);
					
					this.tentative_from_date = readDate(dis);
					
					this.tentative_to_date = readDate(dis);
					
					this.cutoff_date = readDate(dis);
					
						this.auditor_id = readInteger(dis);
					
					this.auditor = readString(dis);
					
					this.des = readString(dis);
					
					this.audit_commencement_date = readDate(dis);
					
					this.closed_date = readDate(dis);
					
					this.comments_by_auditor = readString(dis);
					
						this.branch_audit_id = readInteger(dis);
					
					this.tat_requested_date = readDate(dis);
					
					this.tat_reason = readString(dis);
					
						this.tat_status = (BigDecimal) dis.readObject();
					
					this.final_comments = readString(dis);
					
						this.checklist_id = readInteger(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_date = readDate(dis);
					
						this.is_active = readInteger(dis);
					
						this.is_deleted = readInteger(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
					this.status = readString(dis);
					
						this.is_surprised = readInteger(dis);
					
					this.audit_commencement_info_id = readString(dis);
					
						this.closed_by = (BigDecimal) dis.readObject();
					
						this.allow_forced_submit = readInteger(dis);
					
						this.is_sink = readInteger(dis);
					
						this.is_team_changed = readInteger(dis);
					
						this.is_editable = readInteger(dis);
					
					this.freezing_date = readDate(dis);
					
						this.recalculation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
					this.division = readString(dis);
					
					this.branch_id = readString(dis);
					
					this.branch = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.month = null;
           				} else {
           			    	this.month = dis.readShort();
           				}
					
						this.year = readInteger(dis);
					
					this.tentative_from_date = readDate(dis);
					
					this.tentative_to_date = readDate(dis);
					
					this.cutoff_date = readDate(dis);
					
						this.auditor_id = readInteger(dis);
					
					this.auditor = readString(dis);
					
					this.des = readString(dis);
					
					this.audit_commencement_date = readDate(dis);
					
					this.closed_date = readDate(dis);
					
					this.comments_by_auditor = readString(dis);
					
						this.branch_audit_id = readInteger(dis);
					
					this.tat_requested_date = readDate(dis);
					
					this.tat_reason = readString(dis);
					
						this.tat_status = (BigDecimal) dis.readObject();
					
					this.final_comments = readString(dis);
					
						this.checklist_id = readInteger(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_date = readDate(dis);
					
						this.is_active = readInteger(dis);
					
						this.is_deleted = readInteger(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
					this.status = readString(dis);
					
						this.is_surprised = readInteger(dis);
					
					this.audit_commencement_info_id = readString(dis);
					
						this.closed_by = (BigDecimal) dis.readObject();
					
						this.allow_forced_submit = readInteger(dis);
					
						this.is_sink = readInteger(dis);
					
						this.is_team_changed = readInteger(dis);
					
						this.is_editable = readInteger(dis);
					
					this.freezing_date = readDate(dis);
					
						this.recalculation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// Short
				
						if(this.month == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.month);
		            	}
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_to_date,dos);
					
					// java.util.Date
				
						writeDate(this.cutoff_date,dos);
					
					// Integer
				
						writeInteger(this.auditor_id,dos);
					
					// String
				
						writeString(this.auditor,dos);
					
					// String
				
						writeString(this.des,dos);
					
					// java.util.Date
				
						writeDate(this.audit_commencement_date,dos);
					
					// java.util.Date
				
						writeDate(this.closed_date,dos);
					
					// String
				
						writeString(this.comments_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.branch_audit_id,dos);
					
					// java.util.Date
				
						writeDate(this.tat_requested_date,dos);
					
					// String
				
						writeString(this.tat_reason,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.tat_status);
					
					// String
				
						writeString(this.final_comments,dos);
					
					// Integer
				
						writeInteger(this.checklist_id,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_date,dos);
					
					// Integer
				
						writeInteger(this.is_active,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Integer
				
						writeInteger(this.is_surprised,dos);
					
					// String
				
						writeString(this.audit_commencement_info_id,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.closed_by);
					
					// Integer
				
						writeInteger(this.allow_forced_submit,dos);
					
					// Integer
				
						writeInteger(this.is_sink,dos);
					
					// Integer
				
						writeInteger(this.is_team_changed,dos);
					
					// Integer
				
						writeInteger(this.is_editable,dos);
					
					// java.util.Date
				
						writeDate(this.freezing_date,dos);
					
					// Integer
				
						writeInteger(this.recalculation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// Short
				
						if(this.month == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.month);
		            	}
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_to_date,dos);
					
					// java.util.Date
				
						writeDate(this.cutoff_date,dos);
					
					// Integer
				
						writeInteger(this.auditor_id,dos);
					
					// String
				
						writeString(this.auditor,dos);
					
					// String
				
						writeString(this.des,dos);
					
					// java.util.Date
				
						writeDate(this.audit_commencement_date,dos);
					
					// java.util.Date
				
						writeDate(this.closed_date,dos);
					
					// String
				
						writeString(this.comments_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.branch_audit_id,dos);
					
					// java.util.Date
				
						writeDate(this.tat_requested_date,dos);
					
					// String
				
						writeString(this.tat_reason,dos);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.tat_status);
					
					// String
				
						writeString(this.final_comments,dos);
					
					// Integer
				
						writeInteger(this.checklist_id,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_date,dos);
					
					// Integer
				
						writeInteger(this.is_active,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Integer
				
						writeInteger(this.is_surprised,dos);
					
					// String
				
						writeString(this.audit_commencement_info_id,dos);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.closed_by);
					
					// Integer
				
						writeInteger(this.allow_forced_submit,dos);
					
					// Integer
				
						writeInteger(this.is_sink,dos);
					
					// Integer
				
						writeInteger(this.is_team_changed,dos);
					
					// Integer
				
						writeInteger(this.is_editable,dos);
					
					// java.util.Date
				
						writeDate(this.freezing_date,dos);
					
					// Integer
				
						writeInteger(this.recalculation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",region="+region);
		sb.append(",division="+division);
		sb.append(",branch_id="+branch_id);
		sb.append(",branch="+branch);
		sb.append(",month="+String.valueOf(month));
		sb.append(",year="+String.valueOf(year));
		sb.append(",tentative_from_date="+String.valueOf(tentative_from_date));
		sb.append(",tentative_to_date="+String.valueOf(tentative_to_date));
		sb.append(",cutoff_date="+String.valueOf(cutoff_date));
		sb.append(",auditor_id="+String.valueOf(auditor_id));
		sb.append(",auditor="+auditor);
		sb.append(",des="+des);
		sb.append(",audit_commencement_date="+String.valueOf(audit_commencement_date));
		sb.append(",closed_date="+String.valueOf(closed_date));
		sb.append(",comments_by_auditor="+comments_by_auditor);
		sb.append(",branch_audit_id="+String.valueOf(branch_audit_id));
		sb.append(",tat_requested_date="+String.valueOf(tat_requested_date));
		sb.append(",tat_reason="+tat_reason);
		sb.append(",tat_status="+String.valueOf(tat_status));
		sb.append(",final_comments="+final_comments);
		sb.append(",checklist_id="+String.valueOf(checklist_id));
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_date="+String.valueOf(created_date));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",status="+status);
		sb.append(",is_surprised="+String.valueOf(is_surprised));
		sb.append(",audit_commencement_info_id="+audit_commencement_info_id);
		sb.append(",closed_by="+String.valueOf(closed_by));
		sb.append(",allow_forced_submit="+String.valueOf(allow_forced_submit));
		sb.append(",is_sink="+String.valueOf(is_sink));
		sb.append(",is_team_changed="+String.valueOf(is_team_changed));
		sb.append(",is_editable="+String.valueOf(is_editable));
		sb.append(",freezing_date="+String.valueOf(freezing_date));
		sb.append(",recalculation="+String.valueOf(recalculation));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(region == null){
        					sb.append("<null>");
        				}else{
            				sb.append(region);
            			}
            		
        			sb.append("|");
        		
        				if(division == null){
        					sb.append("<null>");
        				}else{
            				sb.append(division);
            			}
            		
        			sb.append("|");
        		
        				if(branch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_id);
            			}
            		
        			sb.append("|");
        		
        				if(branch == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch);
            			}
            		
        			sb.append("|");
        		
        				if(month == null){
        					sb.append("<null>");
        				}else{
            				sb.append(month);
            			}
            		
        			sb.append("|");
        		
        				if(year == null){
        					sb.append("<null>");
        				}else{
            				sb.append(year);
            			}
            		
        			sb.append("|");
        		
        				if(tentative_from_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tentative_from_date);
            			}
            		
        			sb.append("|");
        		
        				if(tentative_to_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tentative_to_date);
            			}
            		
        			sb.append("|");
        		
        				if(cutoff_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cutoff_date);
            			}
            		
        			sb.append("|");
        		
        				if(auditor_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor_id);
            			}
            		
        			sb.append("|");
        		
        				if(auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor);
            			}
            		
        			sb.append("|");
        		
        				if(des == null){
        					sb.append("<null>");
        				}else{
            				sb.append(des);
            			}
            		
        			sb.append("|");
        		
        				if(audit_commencement_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_commencement_date);
            			}
            		
        			sb.append("|");
        		
        				if(closed_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(closed_date);
            			}
            		
        			sb.append("|");
        		
        				if(comments_by_auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(comments_by_auditor);
            			}
            		
        			sb.append("|");
        		
        				if(branch_audit_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_audit_id);
            			}
            		
        			sb.append("|");
        		
        				if(tat_requested_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tat_requested_date);
            			}
            		
        			sb.append("|");
        		
        				if(tat_reason == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tat_reason);
            			}
            		
        			sb.append("|");
        		
        				if(tat_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tat_status);
            			}
            		
        			sb.append("|");
        		
        				if(final_comments == null){
        					sb.append("<null>");
        				}else{
            				sb.append(final_comments);
            			}
            		
        			sb.append("|");
        		
        				if(checklist_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(checklist_id);
            			}
            		
        			sb.append("|");
        		
        				if(longitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(longitude);
            			}
            		
        			sb.append("|");
        		
        				if(latitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(latitude);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_date);
            			}
            		
        			sb.append("|");
        		
        				if(is_active == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_active);
            			}
            		
        			sb.append("|");
        		
        				if(is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(is_surprised == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_surprised);
            			}
            		
        			sb.append("|");
        		
        				if(audit_commencement_info_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_commencement_info_id);
            			}
            		
        			sb.append("|");
        		
        				if(closed_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(closed_by);
            			}
            		
        			sb.append("|");
        		
        				if(allow_forced_submit == null){
        					sb.append("<null>");
        				}else{
            				sb.append(allow_forced_submit);
            			}
            		
        			sb.append("|");
        		
        				if(is_sink == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_sink);
            			}
            		
        			sb.append("|");
        		
        				if(is_team_changed == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_team_changed);
            			}
            		
        			sb.append("|");
        		
        				if(is_editable == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_editable);
            			}
            		
        			sb.append("|");
        		
        				if(freezing_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(freezing_date);
            			}
            		
        			sb.append("|");
        		
        				if(recalculation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(recalculation);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", "s2hrSD_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_1", false);
		start_Hash.put("tAsyncOut_tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tAsyncOut_tDBOutput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_1", "tAsyncOut_tDBOutput_1", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_1 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_1 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_1 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_1=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_1 = new ParallelThreadPool(9);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_1", pool_tAsyncOut_tDBOutput_1);
	final Object[] lockWrite_tAsyncOut_tDBOutput_1 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_1", lockWrite_tAsyncOut_tDBOutput_1);
 



/**
 * [tAsyncOut_tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_commencement_info\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"audit_commencement_info\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT    `audit_commencement_info`.`id`,    `audit_commencement_info`.`region`,    `audit_commencement_info`.`division`,    `audit_commencement_info`.`branch_id`,    `audit_commencement_info`.`branch`,    `audit_commencement_info`.`month`,    `audit_commencement_info`.`year`,    `audit_commencement_info`.`tentative_from_date`,    `audit_commencement_info`.`tentative_to_date`,    `audit_commencement_info`.`cutoff_date`,    `audit_commencement_info`.`auditor_id`,    `audit_commencement_info`.`auditor`,    `audit_commencement_info`.`des`,    `audit_commencement_info`.`audit_commencement_date`,    `audit_commencement_info`.`closed_date`,    `audit_commencement_info`.`comments_by_auditor`,    `audit_commencement_info`.`branch_audit_id`,    `audit_commencement_info`.`tat_requested_date`,    `audit_commencement_info`.`tat_reason`,    `audit_commencement_info`.`tat_status`,    `audit_commencement_info`.`final_comments`,    `audit_commencement_info`.`checklist_id`,    `audit_commencement_info`.`longitude`,    `audit_commencement_info`.`latitude`,    `audit_commencement_info`.`created_by`,    `audit_commencement_info`.`created_date`,    `audit_commencement_info`.`is_active`,    `audit_commencement_info`.`is_deleted`,    `audit_commencement_info`.`updated_by`,    `audit_commencement_info`.`updated_on`,    `audit_commencement_info`.`status`,    `audit_commencement_info`.`is_surprised`,    `audit_commencement_info`.`audit_commencement_info_id`,    `audit_commencement_info`.`closed_by`,    `audit_commencement_info`.`allow_forced_submit`,    `audit_commencement_info`.`is_sink`,    `audit_commencement_info`.`is_team_changed`,    `audit_commencement_info`.`is_editable`,    `audit_commencement_info`.`freezing_date`,    `audit_commencement_info`.`recalculation`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `audit_commencement_info`\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("region")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("division")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("month")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("year")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tentative_from_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tentative_to_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("cutoff_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("auditor_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("auditor")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("des")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audit_commencement_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("closed_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("comments_by_auditor")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_audit_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tat_requested_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tat_reason")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tat_status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("final_comments")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("checklist_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("longitude")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("latitude")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_surprised")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audit_commencement_info_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("closed_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("allow_forced_submit")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_sink")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_team_changed")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_editable")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("freezing_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("recalculation")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"audit_commencement_info\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
		    calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();
				if(stmt_tDBInput_1 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_1).enableStreamingResults();
				}else if(stmt_tDBInput_1 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_1).enableStreamingResults();
				}

		    String dbquery_tDBInput_1 = "SELECT \n  `audit_commencement_info`.`id`, \n  `audit_commencement_info`.`region`, \n  `audit_commencement_info`.`division"
+"`, \n  `audit_commencement_info`.`branch_id`, \n  `audit_commencement_info`.`branch`, \n  `audit_commencement_info`.`month`"
+", \n  `audit_commencement_info`.`year`, \n  `audit_commencement_info`.`tentative_from_date`, \n  `audit_commencement_info`."
+"`tentative_to_date`, \n  `audit_commencement_info`.`cutoff_date`, \n  `audit_commencement_info`.`auditor_id`, \n  `audit_co"
+"mmencement_info`.`auditor`, \n  `audit_commencement_info`.`des`, \n  `audit_commencement_info`.`audit_commencement_date`, "
+"\n  `audit_commencement_info`.`closed_date`, \n  `audit_commencement_info`.`comments_by_auditor`, \n  `audit_commencement_i"
+"nfo`.`branch_audit_id`, \n  `audit_commencement_info`.`tat_requested_date`, \n  `audit_commencement_info`.`tat_reason`, \n "
+" `audit_commencement_info`.`tat_status`, \n  `audit_commencement_info`.`final_comments`, \n  `audit_commencement_info`.`ch"
+"ecklist_id`, \n  `audit_commencement_info`.`longitude`, \n  `audit_commencement_info`.`latitude`, \n  `audit_commencement_i"
+"nfo`.`created_by`, \n  `audit_commencement_info`.`created_date`, \n  `audit_commencement_info`.`is_active`, \n  `audit_comm"
+"encement_info`.`is_deleted`, \n  `audit_commencement_info`.`updated_by`, \n  `audit_commencement_info`.`updated_on`, \n  `a"
+"udit_commencement_info`.`status`, \n  `audit_commencement_info`.`is_surprised`, \n  `audit_commencement_info`.`audit_comme"
+"ncement_info_id`, \n  `audit_commencement_info`.`closed_by`, \n  `audit_commencement_info`.`allow_forced_submit`, \n  `audi"
+"t_commencement_info`.`is_sink`, \n  `audit_commencement_info`.`is_team_changed`, \n  `audit_commencement_info`.`is_editabl"
+"e`, \n  `audit_commencement_info`.`freezing_date`, \n  `audit_commencement_info`.`recalculation`,\n	DATE_SUB(CURRENT_TIMES"
+"TAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `audit_commencement_info`";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.id = 0;
							} else {
		                          
            row1.id = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.region = null;
							} else {
	                         		
        	row1.region = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.division = null;
							} else {
	                         		
        	row1.division = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.branch_id = null;
							} else {
	                         		
        	row1.branch_id = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.branch = null;
							} else {
	                         		
        	row1.branch = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.month = null;
							} else {
		                          
            row1.month = rs_tDBInput_1.getShort(6);
            if(rs_tDBInput_1.wasNull()){
                    row1.month = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.year = null;
							} else {
		                          
            row1.year = rs_tDBInput_1.getInt(7);
            if(rs_tDBInput_1.wasNull()){
                    row1.year = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row1.tentative_from_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(8) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(8);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.tentative_from_date = rs_tDBInput_1.getTimestamp(8);
					} else {
						row1.tentative_from_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.tentative_from_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row1.tentative_to_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(9) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(9);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.tentative_to_date = rs_tDBInput_1.getTimestamp(9);
					} else {
						row1.tentative_to_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.tentative_to_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row1.cutoff_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(10) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(10);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.cutoff_date = rs_tDBInput_1.getTimestamp(10);
					} else {
						row1.cutoff_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.cutoff_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row1.auditor_id = null;
							} else {
		                          
            row1.auditor_id = rs_tDBInput_1.getInt(11);
            if(rs_tDBInput_1.wasNull()){
                    row1.auditor_id = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 12) {
								row1.auditor = null;
							} else {
	                         		
        	row1.auditor = routines.system.JDBCUtil.getString(rs_tDBInput_1, 12, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 13) {
								row1.des = null;
							} else {
	                         		
        	row1.des = routines.system.JDBCUtil.getString(rs_tDBInput_1, 13, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 14) {
								row1.audit_commencement_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(14) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(14);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.audit_commencement_date = rs_tDBInput_1.getTimestamp(14);
					} else {
						row1.audit_commencement_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.audit_commencement_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 15) {
								row1.closed_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(15) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(15);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.closed_date = rs_tDBInput_1.getTimestamp(15);
					} else {
						row1.closed_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.closed_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 16) {
								row1.comments_by_auditor = null;
							} else {
	                         		
        	row1.comments_by_auditor = routines.system.JDBCUtil.getString(rs_tDBInput_1, 16, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 17) {
								row1.branch_audit_id = null;
							} else {
		                          
            row1.branch_audit_id = rs_tDBInput_1.getInt(17);
            if(rs_tDBInput_1.wasNull()){
                    row1.branch_audit_id = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 18) {
								row1.tat_requested_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(18) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(18);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.tat_requested_date = rs_tDBInput_1.getTimestamp(18);
					} else {
						row1.tat_requested_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.tat_requested_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 19) {
								row1.tat_reason = null;
							} else {
	                         		
        	row1.tat_reason = routines.system.JDBCUtil.getString(rs_tDBInput_1, 19, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 20) {
								row1.tat_status = null;
							} else {
		                          
            row1.tat_status = rs_tDBInput_1.getBigDecimal(20);
            if(rs_tDBInput_1.wasNull()){
                    row1.tat_status = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 21) {
								row1.final_comments = null;
							} else {
	                         		
        	row1.final_comments = routines.system.JDBCUtil.getString(rs_tDBInput_1, 21, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 22) {
								row1.checklist_id = null;
							} else {
		                          
            row1.checklist_id = rs_tDBInput_1.getInt(22);
            if(rs_tDBInput_1.wasNull()){
                    row1.checklist_id = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 23) {
								row1.longitude = null;
							} else {
	                         		
        	row1.longitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 23, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 24) {
								row1.latitude = null;
							} else {
	                         		
        	row1.latitude = routines.system.JDBCUtil.getString(rs_tDBInput_1, 24, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 25) {
								row1.created_by = null;
							} else {
		                          
            row1.created_by = rs_tDBInput_1.getInt(25);
            if(rs_tDBInput_1.wasNull()){
                    row1.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 26) {
								row1.created_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(26) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(26);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.created_date = rs_tDBInput_1.getTimestamp(26);
					} else {
						row1.created_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.created_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 27) {
								row1.is_active = null;
							} else {
		                          
            row1.is_active = rs_tDBInput_1.getInt(27);
            if(rs_tDBInput_1.wasNull()){
                    row1.is_active = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 28) {
								row1.is_deleted = null;
							} else {
		                          
            row1.is_deleted = rs_tDBInput_1.getInt(28);
            if(rs_tDBInput_1.wasNull()){
                    row1.is_deleted = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 29) {
								row1.updated_by = null;
							} else {
		                          
            row1.updated_by = rs_tDBInput_1.getInt(29);
            if(rs_tDBInput_1.wasNull()){
                    row1.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 30) {
								row1.updated_on = null;
							} else {
										
				if(rs_tDBInput_1.getString(30) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(30);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.updated_on = rs_tDBInput_1.getTimestamp(30);
					} else {
						row1.updated_on = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 31) {
								row1.status = null;
							} else {
	                         		
        	row1.status = routines.system.JDBCUtil.getString(rs_tDBInput_1, 31, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 32) {
								row1.is_surprised = null;
							} else {
		                          
            row1.is_surprised = rs_tDBInput_1.getInt(32);
            if(rs_tDBInput_1.wasNull()){
                    row1.is_surprised = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 33) {
								row1.audit_commencement_info_id = null;
							} else {
	                         		
        	row1.audit_commencement_info_id = routines.system.JDBCUtil.getString(rs_tDBInput_1, 33, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 34) {
								row1.closed_by = null;
							} else {
		                          
            row1.closed_by = rs_tDBInput_1.getBigDecimal(34);
            if(rs_tDBInput_1.wasNull()){
                    row1.closed_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 35) {
								row1.allow_forced_submit = null;
							} else {
		                          
            row1.allow_forced_submit = rs_tDBInput_1.getInt(35);
            if(rs_tDBInput_1.wasNull()){
                    row1.allow_forced_submit = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 36) {
								row1.is_sink = null;
							} else {
		                          
            row1.is_sink = rs_tDBInput_1.getInt(36);
            if(rs_tDBInput_1.wasNull()){
                    row1.is_sink = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 37) {
								row1.is_team_changed = null;
							} else {
		                          
            row1.is_team_changed = rs_tDBInput_1.getInt(37);
            if(rs_tDBInput_1.wasNull()){
                    row1.is_team_changed = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 38) {
								row1.is_editable = null;
							} else {
		                          
            row1.is_editable = rs_tDBInput_1.getInt(38);
            if(rs_tDBInput_1.wasNull()){
                    row1.is_editable = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 39) {
								row1.freezing_date = null;
							} else {
										
				if(rs_tDBInput_1.getString(39) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(39);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.freezing_date = rs_tDBInput_1.getTimestamp(39);
					} else {
						row1.freezing_date = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.freezing_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 40) {
								row1.recalculation = null;
							} else {
		                          
            row1.recalculation = rs_tDBInput_1.getInt(40);
            if(rs_tDBInput_1.wasNull()){
                    row1.recalculation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 41) {
								row1.as_on = null;
							} else {
										
				if(rs_tDBInput_1.getString(41) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(41);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.as_on = rs_tDBInput_1.getTimestamp(41);
					} else {
						row1.as_on = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					

 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_commencement_info\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_commencement_info\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tDBInput_1","\"audit_commencement_info\"","tMysqlInput","tAsyncOut_tDBOutput_1","tAsyncOut_tDBOutput_1","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_1=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_1[0] = String.valueOf(row1.id); 
	if(row1.region != null){
		row_tAsyncOut_tDBOutput_1[1] = row1.region;                			    
	}
	if(row1.division != null){
		row_tAsyncOut_tDBOutput_1[2] = row1.division;                			    
	}
	if(row1.branch_id != null){
		row_tAsyncOut_tDBOutput_1[3] = row1.branch_id;                			    
	}
	if(row1.branch != null){
		row_tAsyncOut_tDBOutput_1[4] = row1.branch;                			    
	}
	if(row1.month != null){
		row_tAsyncOut_tDBOutput_1[5] = String.valueOf(row1.month);                			    
	}
	if(row1.year != null){
		row_tAsyncOut_tDBOutput_1[6] = String.valueOf(row1.year);                			    
	}
	if(row1.tentative_from_date != null){
		row_tAsyncOut_tDBOutput_1[7] = row1.tentative_from_date;                			    
	}
	if(row1.tentative_to_date != null){
		row_tAsyncOut_tDBOutput_1[8] = row1.tentative_to_date;                			    
	}
	if(row1.cutoff_date != null){
		row_tAsyncOut_tDBOutput_1[9] = row1.cutoff_date;                			    
	}
	if(row1.auditor_id != null){
		row_tAsyncOut_tDBOutput_1[10] = String.valueOf(row1.auditor_id);                			    
	}
	if(row1.auditor != null){
		row_tAsyncOut_tDBOutput_1[11] = row1.auditor;                			    
	}
	if(row1.des != null){
		row_tAsyncOut_tDBOutput_1[12] = row1.des;                			    
	}
	if(row1.audit_commencement_date != null){
		row_tAsyncOut_tDBOutput_1[13] = row1.audit_commencement_date;                			    
	}
	if(row1.closed_date != null){
		row_tAsyncOut_tDBOutput_1[14] = row1.closed_date;                			    
	}
	if(row1.comments_by_auditor != null){
		row_tAsyncOut_tDBOutput_1[15] = row1.comments_by_auditor;                			    
	}
	if(row1.branch_audit_id != null){
		row_tAsyncOut_tDBOutput_1[16] = String.valueOf(row1.branch_audit_id);                			    
	}
	if(row1.tat_requested_date != null){
		row_tAsyncOut_tDBOutput_1[17] = row1.tat_requested_date;                			    
	}
	if(row1.tat_reason != null){
		row_tAsyncOut_tDBOutput_1[18] = row1.tat_reason;                			    
	}
	if(row1.tat_status != null){
		row_tAsyncOut_tDBOutput_1[19] = String.valueOf(row1.tat_status);                			    
	}
	if(row1.final_comments != null){
		row_tAsyncOut_tDBOutput_1[20] = row1.final_comments;                			    
	}
	if(row1.checklist_id != null){
		row_tAsyncOut_tDBOutput_1[21] = String.valueOf(row1.checklist_id);                			    
	}
	if(row1.longitude != null){
		row_tAsyncOut_tDBOutput_1[22] = row1.longitude;                			    
	}
	if(row1.latitude != null){
		row_tAsyncOut_tDBOutput_1[23] = row1.latitude;                			    
	}
	if(row1.created_by != null){
		row_tAsyncOut_tDBOutput_1[24] = String.valueOf(row1.created_by);                			    
	}
	if(row1.created_date != null){
		row_tAsyncOut_tDBOutput_1[25] = row1.created_date;                			    
	}
	if(row1.is_active != null){
		row_tAsyncOut_tDBOutput_1[26] = String.valueOf(row1.is_active);                			    
	}
	if(row1.is_deleted != null){
		row_tAsyncOut_tDBOutput_1[27] = String.valueOf(row1.is_deleted);                			    
	}
	if(row1.updated_by != null){
		row_tAsyncOut_tDBOutput_1[28] = String.valueOf(row1.updated_by);                			    
	}
	if(row1.updated_on != null){
		row_tAsyncOut_tDBOutput_1[29] = row1.updated_on;                			    
	}
	if(row1.status != null){
		row_tAsyncOut_tDBOutput_1[30] = row1.status;                			    
	}
	if(row1.is_surprised != null){
		row_tAsyncOut_tDBOutput_1[31] = String.valueOf(row1.is_surprised);                			    
	}
	if(row1.audit_commencement_info_id != null){
		row_tAsyncOut_tDBOutput_1[32] = row1.audit_commencement_info_id;                			    
	}
	if(row1.closed_by != null){
		row_tAsyncOut_tDBOutput_1[33] = String.valueOf(row1.closed_by);                			    
	}
	if(row1.allow_forced_submit != null){
		row_tAsyncOut_tDBOutput_1[34] = String.valueOf(row1.allow_forced_submit);                			    
	}
	if(row1.is_sink != null){
		row_tAsyncOut_tDBOutput_1[35] = String.valueOf(row1.is_sink);                			    
	}
	if(row1.is_team_changed != null){
		row_tAsyncOut_tDBOutput_1[36] = String.valueOf(row1.is_team_changed);                			    
	}
	if(row1.is_editable != null){
		row_tAsyncOut_tDBOutput_1[37] = String.valueOf(row1.is_editable);                			    
	}
	if(row1.freezing_date != null){
		row_tAsyncOut_tDBOutput_1[38] = row1.freezing_date;                			    
	}
	if(row1.recalculation != null){
		row_tAsyncOut_tDBOutput_1[39] = String.valueOf(row1.recalculation);                			    
	}
	if(row1.as_on != null){
		row_tAsyncOut_tDBOutput_1[40] = row1.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_1 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_1", buffers_tAsyncOut_tDBOutput_1);
		/*tAsyncIn_tDBOutput_2Process(globalMap);*/
		tAsyncIn_tDBOutput_1Process(globalMap);
		buffers_tAsyncOut_tDBOutput_1 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_1 = 0;
	}
	buffers_tAsyncOut_tDBOutput_1.add(row_tAsyncOut_tDBOutput_1);
	index_tAsyncOut_tDBOutput_1++;
 


	tos_count_tAsyncOut_tDBOutput_1++;

/**
 * [tAsyncOut_tDBOutput_1 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	

 



/**
 * [tAsyncOut_tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	

 



/**
 * [tAsyncOut_tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_commencement_info\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_commencement_info\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}

		   globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
		

	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	


	if (buffers_tAsyncOut_tDBOutput_1.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_1", buffers_tAsyncOut_tDBOutput_1);
	    tAsyncIn_tDBOutput_1Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_1.waitForEnd();
	pool_tAsyncOut_tDBOutput_1.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tDBInput_1","\"audit_commencement_info\"","tMysqlInput","tAsyncOut_tDBOutput_1","tAsyncOut_tDBOutput_1","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_1", true);
end_Hash.put("tAsyncOut_tDBOutput_1", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"audit_commencement_info\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_1";
	
	

 



/**
 * [tAsyncOut_tDBOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String region;

				public String getRegion () {
					return this.region;
				}

				public Boolean regionIsNullable(){
				    return true;
				}
				public Boolean regionIsKey(){
				    return false;
				}
				public Integer regionLength(){
				    return 145;
				}
				public Integer regionPrecision(){
				    return 0;
				}
				public String regionDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String regionComment(){
				
				    return "";
				
				}
				public String regionPattern(){
				
					return "";
				
				}
				public String regionOriginalDbColumnName(){
				
					return "region";
				
				}

				
			    public String division;

				public String getDivision () {
					return this.division;
				}

				public Boolean divisionIsNullable(){
				    return true;
				}
				public Boolean divisionIsKey(){
				    return false;
				}
				public Integer divisionLength(){
				    return 145;
				}
				public Integer divisionPrecision(){
				    return 0;
				}
				public String divisionDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String divisionComment(){
				
				    return "";
				
				}
				public String divisionPattern(){
				
					return "";
				
				}
				public String divisionOriginalDbColumnName(){
				
					return "division";
				
				}

				
			    public String branch_id;

				public String getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return true;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 100;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public String branch;

				public String getBranch () {
					return this.branch;
				}

				public Boolean branchIsNullable(){
				    return true;
				}
				public Boolean branchIsKey(){
				    return false;
				}
				public Integer branchLength(){
				    return 145;
				}
				public Integer branchPrecision(){
				    return 0;
				}
				public String branchDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branchComment(){
				
				    return "";
				
				}
				public String branchPattern(){
				
					return "";
				
				}
				public String branchOriginalDbColumnName(){
				
					return "branch";
				
				}

				
			    public Integer month;

				public Integer getMonth () {
					return this.month;
				}

				public Boolean monthIsNullable(){
				    return true;
				}
				public Boolean monthIsKey(){
				    return false;
				}
				public Integer monthLength(){
				    return 10;
				}
				public Integer monthPrecision(){
				    return 0;
				}
				public String monthDefault(){
				
					return null;
				
				}
				public String monthComment(){
				
				    return "";
				
				}
				public String monthPattern(){
				
					return "";
				
				}
				public String monthOriginalDbColumnName(){
				
					return "month";
				
				}

				
			    public Integer year;

				public Integer getYear () {
					return this.year;
				}

				public Boolean yearIsNullable(){
				    return true;
				}
				public Boolean yearIsKey(){
				    return false;
				}
				public Integer yearLength(){
				    return 10;
				}
				public Integer yearPrecision(){
				    return 0;
				}
				public String yearDefault(){
				
					return null;
				
				}
				public String yearComment(){
				
				    return "";
				
				}
				public String yearPattern(){
				
					return "";
				
				}
				public String yearOriginalDbColumnName(){
				
					return "year";
				
				}

				
			    public java.util.Date tentative_from_date;

				public java.util.Date getTentative_from_date () {
					return this.tentative_from_date;
				}

				public Boolean tentative_from_dateIsNullable(){
				    return true;
				}
				public Boolean tentative_from_dateIsKey(){
				    return false;
				}
				public Integer tentative_from_dateLength(){
				    return 13;
				}
				public Integer tentative_from_datePrecision(){
				    return 0;
				}
				public String tentative_from_dateDefault(){
				
					return null;
				
				}
				public String tentative_from_dateComment(){
				
				    return "";
				
				}
				public String tentative_from_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tentative_from_dateOriginalDbColumnName(){
				
					return "tentative_from_date";
				
				}

				
			    public java.util.Date tentative_to_date;

				public java.util.Date getTentative_to_date () {
					return this.tentative_to_date;
				}

				public Boolean tentative_to_dateIsNullable(){
				    return true;
				}
				public Boolean tentative_to_dateIsKey(){
				    return false;
				}
				public Integer tentative_to_dateLength(){
				    return 13;
				}
				public Integer tentative_to_datePrecision(){
				    return 0;
				}
				public String tentative_to_dateDefault(){
				
					return null;
				
				}
				public String tentative_to_dateComment(){
				
				    return "";
				
				}
				public String tentative_to_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tentative_to_dateOriginalDbColumnName(){
				
					return "tentative_to_date";
				
				}

				
			    public Integer auditor_id;

				public Integer getAuditor_id () {
					return this.auditor_id;
				}

				public Boolean auditor_idIsNullable(){
				    return true;
				}
				public Boolean auditor_idIsKey(){
				    return false;
				}
				public Integer auditor_idLength(){
				    return 10;
				}
				public Integer auditor_idPrecision(){
				    return 0;
				}
				public String auditor_idDefault(){
				
					return null;
				
				}
				public String auditor_idComment(){
				
				    return "";
				
				}
				public String auditor_idPattern(){
				
					return "";
				
				}
				public String auditor_idOriginalDbColumnName(){
				
					return "auditor_id";
				
				}

				
			    public String auditor;

				public String getAuditor () {
					return this.auditor;
				}

				public Boolean auditorIsNullable(){
				    return true;
				}
				public Boolean auditorIsKey(){
				    return false;
				}
				public Integer auditorLength(){
				    return 145;
				}
				public Integer auditorPrecision(){
				    return 0;
				}
				public String auditorDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String auditorComment(){
				
				    return "";
				
				}
				public String auditorPattern(){
				
					return "";
				
				}
				public String auditorOriginalDbColumnName(){
				
					return "auditor";
				
				}

				
			    public String des;

				public String getDes () {
					return this.des;
				}

				public Boolean desIsNullable(){
				    return true;
				}
				public Boolean desIsKey(){
				    return false;
				}
				public Integer desLength(){
				    return 145;
				}
				public Integer desPrecision(){
				    return 0;
				}
				public String desDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String desComment(){
				
				    return "";
				
				}
				public String desPattern(){
				
					return "";
				
				}
				public String desOriginalDbColumnName(){
				
					return "des";
				
				}

				
			    public java.util.Date audit_commencement_date;

				public java.util.Date getAudit_commencement_date () {
					return this.audit_commencement_date;
				}

				public Boolean audit_commencement_dateIsNullable(){
				    return true;
				}
				public Boolean audit_commencement_dateIsKey(){
				    return false;
				}
				public Integer audit_commencement_dateLength(){
				    return 13;
				}
				public Integer audit_commencement_datePrecision(){
				    return 0;
				}
				public String audit_commencement_dateDefault(){
				
					return null;
				
				}
				public String audit_commencement_dateComment(){
				
				    return "";
				
				}
				public String audit_commencement_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audit_commencement_dateOriginalDbColumnName(){
				
					return "audit_commencement_date";
				
				}

				
			    public java.util.Date closed_date;

				public java.util.Date getClosed_date () {
					return this.closed_date;
				}

				public Boolean closed_dateIsNullable(){
				    return true;
				}
				public Boolean closed_dateIsKey(){
				    return false;
				}
				public Integer closed_dateLength(){
				    return 29;
				}
				public Integer closed_datePrecision(){
				    return 6;
				}
				public String closed_dateDefault(){
				
					return null;
				
				}
				public String closed_dateComment(){
				
				    return "";
				
				}
				public String closed_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String closed_dateOriginalDbColumnName(){
				
					return "closed_date";
				
				}

				
			    public String comments_by_auditor;

				public String getComments_by_auditor () {
					return this.comments_by_auditor;
				}

				public Boolean comments_by_auditorIsNullable(){
				    return true;
				}
				public Boolean comments_by_auditorIsKey(){
				    return false;
				}
				public Integer comments_by_auditorLength(){
				    return 2147483647;
				}
				public Integer comments_by_auditorPrecision(){
				    return 0;
				}
				public String comments_by_auditorDefault(){
				
					return null;
				
				}
				public String comments_by_auditorComment(){
				
				    return "";
				
				}
				public String comments_by_auditorPattern(){
				
					return "";
				
				}
				public String comments_by_auditorOriginalDbColumnName(){
				
					return "comments_by_auditor";
				
				}

				
			    public Integer branch_audit_id;

				public Integer getBranch_audit_id () {
					return this.branch_audit_id;
				}

				public Boolean branch_audit_idIsNullable(){
				    return true;
				}
				public Boolean branch_audit_idIsKey(){
				    return false;
				}
				public Integer branch_audit_idLength(){
				    return 10;
				}
				public Integer branch_audit_idPrecision(){
				    return 0;
				}
				public String branch_audit_idDefault(){
				
					return null;
				
				}
				public String branch_audit_idComment(){
				
				    return "";
				
				}
				public String branch_audit_idPattern(){
				
					return "";
				
				}
				public String branch_audit_idOriginalDbColumnName(){
				
					return "branch_audit_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_date;

				public java.util.Date getCreated_date () {
					return this.created_date;
				}

				public Boolean created_dateIsNullable(){
				    return true;
				}
				public Boolean created_dateIsKey(){
				    return false;
				}
				public Integer created_dateLength(){
				    return 13;
				}
				public Integer created_datePrecision(){
				    return 0;
				}
				public String created_dateDefault(){
				
					return null;
				
				}
				public String created_dateComment(){
				
				    return "";
				
				}
				public String created_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_dateOriginalDbColumnName(){
				
					return "created_date";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return null;
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.id = this.id;
	            other.region = this.region;
	            other.division = this.division;
	            other.branch_id = this.branch_id;
	            other.branch = this.branch;
	            other.month = this.month;
	            other.year = this.year;
	            other.tentative_from_date = this.tentative_from_date;
	            other.tentative_to_date = this.tentative_to_date;
	            other.auditor_id = this.auditor_id;
	            other.auditor = this.auditor;
	            other.des = this.des;
	            other.audit_commencement_date = this.audit_commencement_date;
	            other.closed_date = this.closed_date;
	            other.comments_by_auditor = this.comments_by_auditor;
	            other.branch_audit_id = this.branch_audit_id;
	            other.created_by = this.created_by;
	            other.created_date = this.created_date;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
					this.division = readString(dis);
					
					this.branch_id = readString(dis);
					
					this.branch = readString(dis);
					
						this.month = readInteger(dis);
					
						this.year = readInteger(dis);
					
					this.tentative_from_date = readDate(dis);
					
					this.tentative_to_date = readDate(dis);
					
						this.auditor_id = readInteger(dis);
					
					this.auditor = readString(dis);
					
					this.des = readString(dis);
					
					this.audit_commencement_date = readDate(dis);
					
					this.closed_date = readDate(dis);
					
					this.comments_by_auditor = readString(dis);
					
						this.branch_audit_id = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_date = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
					this.division = readString(dis);
					
					this.branch_id = readString(dis);
					
					this.branch = readString(dis);
					
						this.month = readInteger(dis);
					
						this.year = readInteger(dis);
					
					this.tentative_from_date = readDate(dis);
					
					this.tentative_to_date = readDate(dis);
					
						this.auditor_id = readInteger(dis);
					
					this.auditor = readString(dis);
					
					this.des = readString(dis);
					
					this.audit_commencement_date = readDate(dis);
					
					this.closed_date = readDate(dis);
					
					this.comments_by_auditor = readString(dis);
					
						this.branch_audit_id = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_date = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// Integer
				
						writeInteger(this.month,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_to_date,dos);
					
					// Integer
				
						writeInteger(this.auditor_id,dos);
					
					// String
				
						writeString(this.auditor,dos);
					
					// String
				
						writeString(this.des,dos);
					
					// java.util.Date
				
						writeDate(this.audit_commencement_date,dos);
					
					// java.util.Date
				
						writeDate(this.closed_date,dos);
					
					// String
				
						writeString(this.comments_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.branch_audit_id,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_date,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// Integer
				
						writeInteger(this.month,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_to_date,dos);
					
					// Integer
				
						writeInteger(this.auditor_id,dos);
					
					// String
				
						writeString(this.auditor,dos);
					
					// String
				
						writeString(this.des,dos);
					
					// java.util.Date
				
						writeDate(this.audit_commencement_date,dos);
					
					// java.util.Date
				
						writeDate(this.closed_date,dos);
					
					// String
				
						writeString(this.comments_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.branch_audit_id,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_date,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",region="+region);
		sb.append(",division="+division);
		sb.append(",branch_id="+branch_id);
		sb.append(",branch="+branch);
		sb.append(",month="+String.valueOf(month));
		sb.append(",year="+String.valueOf(year));
		sb.append(",tentative_from_date="+String.valueOf(tentative_from_date));
		sb.append(",tentative_to_date="+String.valueOf(tentative_to_date));
		sb.append(",auditor_id="+String.valueOf(auditor_id));
		sb.append(",auditor="+auditor);
		sb.append(",des="+des);
		sb.append(",audit_commencement_date="+String.valueOf(audit_commencement_date));
		sb.append(",closed_date="+String.valueOf(closed_date));
		sb.append(",comments_by_auditor="+comments_by_auditor);
		sb.append(",branch_audit_id="+String.valueOf(branch_audit_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_date="+String.valueOf(created_date));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(region == null){
        					sb.append("<null>");
        				}else{
            				sb.append(region);
            			}
            		
        			sb.append("|");
        		
        				if(division == null){
        					sb.append("<null>");
        				}else{
            				sb.append(division);
            			}
            		
        			sb.append("|");
        		
        				if(branch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_id);
            			}
            		
        			sb.append("|");
        		
        				if(branch == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch);
            			}
            		
        			sb.append("|");
        		
        				if(month == null){
        					sb.append("<null>");
        				}else{
            				sb.append(month);
            			}
            		
        			sb.append("|");
        		
        				if(year == null){
        					sb.append("<null>");
        				}else{
            				sb.append(year);
            			}
            		
        			sb.append("|");
        		
        				if(tentative_from_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tentative_from_date);
            			}
            		
        			sb.append("|");
        		
        				if(tentative_to_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tentative_to_date);
            			}
            		
        			sb.append("|");
        		
        				if(auditor_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor_id);
            			}
            		
        			sb.append("|");
        		
        				if(auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor);
            			}
            		
        			sb.append("|");
        		
        				if(des == null){
        					sb.append("<null>");
        				}else{
            				sb.append(des);
            			}
            		
        			sb.append("|");
        		
        				if(audit_commencement_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_commencement_date);
            			}
            		
        			sb.append("|");
        		
        				if(closed_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(closed_date);
            			}
            		
        			sb.append("|");
        		
        				if(comments_by_auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(comments_by_auditor);
            			}
            		
        			sb.append("|");
        		
        				if(branch_audit_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_audit_id);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_date);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", "I3OjqQ_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_2", false);
		start_Hash.put("tAsyncOut_tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tAsyncOut_tDBOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_2", "tAsyncOut_tDBOutput_2", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_2 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_2 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_2 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_2=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_2 = new ParallelThreadPool(9);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_2", pool_tAsyncOut_tDBOutput_2);
	final Object[] lockWrite_tAsyncOut_tDBOutput_2 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_2", lockWrite_tAsyncOut_tDBOutput_2);
 



/**
 * [tAsyncOut_tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"tbl_audit_commencement_info\"";
		
		int tos_count_tDBInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
                    log4jParamters_tDBInput_2.append("Parameters:");
                            log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"tbl_audit_commencement_info\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERY" + " = " + "\"SELECT    `tbl_audit_commencement_info`.`id`,    `tbl_audit_commencement_info`.`region`,    `tbl_audit_commencement_info`.`division`,    `tbl_audit_commencement_info`.`branch_id`,    `tbl_audit_commencement_info`.`branch`,    `tbl_audit_commencement_info`.`month`,    `tbl_audit_commencement_info`.`year`,    `tbl_audit_commencement_info`.`tentative_from_date`,    `tbl_audit_commencement_info`.`tentative_to_date`,    `tbl_audit_commencement_info`.`auditor_id`,    `tbl_audit_commencement_info`.`auditor`,    `tbl_audit_commencement_info`.`des`,    `tbl_audit_commencement_info`.`audit_commencement_date`,    `tbl_audit_commencement_info`.`closed_date`,    `tbl_audit_commencement_info`.`comments_by_auditor`,    `tbl_audit_commencement_info`.`branch_audit_id`,    `tbl_audit_commencement_info`.`created_by`,    `tbl_audit_commencement_info`.`created_date`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `tbl_audit_commencement_info`\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("region")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("division")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("month")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("year")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tentative_from_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tentative_to_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("auditor_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("auditor")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("des")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audit_commencement_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("closed_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("comments_by_auditor")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("branch_audit_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + (log4jParamters_tDBInput_2) );
                    } 
                } 
            new BytesLimit65535_tDBInput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "\"tbl_audit_commencement_info\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_2 = java.util.Calendar.getInstance();
		    calendar_tDBInput_2.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_2 = calendar_tDBInput_2.getTime();
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_2 != null) {
					if(conn_tDBInput_2.getMetaData() != null) {
						
							log.debug("tDBInput_2 - Uses an existing connection with username '" + conn_tDBInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();
				if(stmt_tDBInput_2 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_2).enableStreamingResults();
				}else if(stmt_tDBInput_2 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_2).enableStreamingResults();
				}

		    String dbquery_tDBInput_2 = "SELECT \n  `tbl_audit_commencement_info`.`id`, \n  `tbl_audit_commencement_info`.`region`, \n  `tbl_audit_commencement_inf"
+"o`.`division`, \n  `tbl_audit_commencement_info`.`branch_id`, \n  `tbl_audit_commencement_info`.`branch`, \n  `tbl_audit_co"
+"mmencement_info`.`month`, \n  `tbl_audit_commencement_info`.`year`, \n  `tbl_audit_commencement_info`.`tentative_from_date"
+"`, \n  `tbl_audit_commencement_info`.`tentative_to_date`, \n  `tbl_audit_commencement_info`.`auditor_id`, \n  `tbl_audit_co"
+"mmencement_info`.`auditor`, \n  `tbl_audit_commencement_info`.`des`, \n  `tbl_audit_commencement_info`.`audit_commencement"
+"_date`, \n  `tbl_audit_commencement_info`.`closed_date`, \n  `tbl_audit_commencement_info`.`comments_by_auditor`, \n  `tbl_"
+"audit_commencement_info`.`branch_audit_id`, \n  `tbl_audit_commencement_info`.`created_by`, \n  `tbl_audit_commencement_in"
+"fo`.`created_date`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `tbl_audit_commencement_info`";
		    
	    		log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    	log.debug("tDBInput_2 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row2.id = 0;
							} else {
		                          
            row2.id = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row2.region = null;
							} else {
	                         		
        	row2.region = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row2.division = null;
							} else {
	                         		
        	row2.division = routines.system.JDBCUtil.getString(rs_tDBInput_2, 3, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row2.branch_id = null;
							} else {
	                         		
        	row2.branch_id = routines.system.JDBCUtil.getString(rs_tDBInput_2, 4, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row2.branch = null;
							} else {
	                         		
        	row2.branch = routines.system.JDBCUtil.getString(rs_tDBInput_2, 5, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row2.month = null;
							} else {
		                          
            row2.month = rs_tDBInput_2.getInt(6);
            if(rs_tDBInput_2.wasNull()){
                    row2.month = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row2.year = null;
							} else {
		                          
            row2.year = rs_tDBInput_2.getInt(7);
            if(rs_tDBInput_2.wasNull()){
                    row2.year = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row2.tentative_from_date = null;
							} else {
										
				if(rs_tDBInput_2.getString(8) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(8);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.tentative_from_date = rs_tDBInput_2.getTimestamp(8);
					} else {
						row2.tentative_from_date = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.tentative_from_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 9) {
								row2.tentative_to_date = null;
							} else {
										
				if(rs_tDBInput_2.getString(9) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(9);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.tentative_to_date = rs_tDBInput_2.getTimestamp(9);
					} else {
						row2.tentative_to_date = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.tentative_to_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 10) {
								row2.auditor_id = null;
							} else {
		                          
            row2.auditor_id = rs_tDBInput_2.getInt(10);
            if(rs_tDBInput_2.wasNull()){
                    row2.auditor_id = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 11) {
								row2.auditor = null;
							} else {
	                         		
        	row2.auditor = routines.system.JDBCUtil.getString(rs_tDBInput_2, 11, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 12) {
								row2.des = null;
							} else {
	                         		
        	row2.des = routines.system.JDBCUtil.getString(rs_tDBInput_2, 12, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 13) {
								row2.audit_commencement_date = null;
							} else {
										
				if(rs_tDBInput_2.getString(13) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(13);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.audit_commencement_date = rs_tDBInput_2.getTimestamp(13);
					} else {
						row2.audit_commencement_date = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.audit_commencement_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 14) {
								row2.closed_date = null;
							} else {
										
				if(rs_tDBInput_2.getString(14) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(14);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.closed_date = rs_tDBInput_2.getTimestamp(14);
					} else {
						row2.closed_date = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.closed_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 15) {
								row2.comments_by_auditor = null;
							} else {
	                         		
        	row2.comments_by_auditor = routines.system.JDBCUtil.getString(rs_tDBInput_2, 15, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 16) {
								row2.branch_audit_id = null;
							} else {
		                          
            row2.branch_audit_id = rs_tDBInput_2.getInt(16);
            if(rs_tDBInput_2.wasNull()){
                    row2.branch_audit_id = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 17) {
								row2.created_by = null;
							} else {
		                          
            row2.created_by = rs_tDBInput_2.getInt(17);
            if(rs_tDBInput_2.wasNull()){
                    row2.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 18) {
								row2.created_date = null;
							} else {
										
				if(rs_tDBInput_2.getString(18) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(18);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.created_date = rs_tDBInput_2.getTimestamp(18);
					} else {
						row2.created_date = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.created_date =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 19) {
								row2.as_on = null;
							} else {
										
				if(rs_tDBInput_2.getString(19) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(19);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.as_on = rs_tDBInput_2.getTimestamp(19);
					} else {
						row2.as_on = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");
					

 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"tbl_audit_commencement_info\"";
		

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"tbl_audit_commencement_info\"";
		

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tDBInput_2","\"tbl_audit_commencement_info\"","tMysqlInput","tAsyncOut_tDBOutput_2","tAsyncOut_tDBOutput_2","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_2=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_2[0] = String.valueOf(row2.id); 
	if(row2.region != null){
		row_tAsyncOut_tDBOutput_2[1] = row2.region;                			    
	}
	if(row2.division != null){
		row_tAsyncOut_tDBOutput_2[2] = row2.division;                			    
	}
	if(row2.branch_id != null){
		row_tAsyncOut_tDBOutput_2[3] = row2.branch_id;                			    
	}
	if(row2.branch != null){
		row_tAsyncOut_tDBOutput_2[4] = row2.branch;                			    
	}
	if(row2.month != null){
		row_tAsyncOut_tDBOutput_2[5] = String.valueOf(row2.month);                			    
	}
	if(row2.year != null){
		row_tAsyncOut_tDBOutput_2[6] = String.valueOf(row2.year);                			    
	}
	if(row2.tentative_from_date != null){
		row_tAsyncOut_tDBOutput_2[7] = row2.tentative_from_date;                			    
	}
	if(row2.tentative_to_date != null){
		row_tAsyncOut_tDBOutput_2[8] = row2.tentative_to_date;                			    
	}
	if(row2.auditor_id != null){
		row_tAsyncOut_tDBOutput_2[9] = String.valueOf(row2.auditor_id);                			    
	}
	if(row2.auditor != null){
		row_tAsyncOut_tDBOutput_2[10] = row2.auditor;                			    
	}
	if(row2.des != null){
		row_tAsyncOut_tDBOutput_2[11] = row2.des;                			    
	}
	if(row2.audit_commencement_date != null){
		row_tAsyncOut_tDBOutput_2[12] = row2.audit_commencement_date;                			    
	}
	if(row2.closed_date != null){
		row_tAsyncOut_tDBOutput_2[13] = row2.closed_date;                			    
	}
	if(row2.comments_by_auditor != null){
		row_tAsyncOut_tDBOutput_2[14] = row2.comments_by_auditor;                			    
	}
	if(row2.branch_audit_id != null){
		row_tAsyncOut_tDBOutput_2[15] = String.valueOf(row2.branch_audit_id);                			    
	}
	if(row2.created_by != null){
		row_tAsyncOut_tDBOutput_2[16] = String.valueOf(row2.created_by);                			    
	}
	if(row2.created_date != null){
		row_tAsyncOut_tDBOutput_2[17] = row2.created_date;                			    
	}
	if(row2.as_on != null){
		row_tAsyncOut_tDBOutput_2[18] = row2.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_2 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_2", buffers_tAsyncOut_tDBOutput_2);
		/*tAsyncIn_tDBOutput_2Process(globalMap);*/
		tAsyncIn_tDBOutput_2Process(globalMap);
		buffers_tAsyncOut_tDBOutput_2 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_2 = 0;
	}
	buffers_tAsyncOut_tDBOutput_2.add(row_tAsyncOut_tDBOutput_2);
	index_tAsyncOut_tDBOutput_2++;
 


	tos_count_tAsyncOut_tDBOutput_2++;

/**
 * [tAsyncOut_tDBOutput_2 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	

 



/**
 * [tAsyncOut_tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	

 



/**
 * [tAsyncOut_tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"tbl_audit_commencement_info\"";
		

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"tbl_audit_commencement_info\"";
		

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}

		   globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
		

	    		log.debug("tDBInput_2 - Retrieved records count: "+nb_line_tDBInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Done.") );

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	


	if (buffers_tAsyncOut_tDBOutput_2.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_2", buffers_tAsyncOut_tDBOutput_2);
	    tAsyncIn_tDBOutput_2Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_2.waitForEnd();
	pool_tAsyncOut_tDBOutput_2.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tDBInput_2","\"tbl_audit_commencement_info\"","tMysqlInput","tAsyncOut_tDBOutput_2","tAsyncOut_tDBOutput_2","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_2", true);
end_Hash.put("tAsyncOut_tDBOutput_2", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"tbl_audit_commencement_info\"";
		

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	

 



/**
 * [tAsyncOut_tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "nSqu5i_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "FmCClL_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"115.124.105.62\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"3306\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"chaitanya_audit\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"chaitanya_auditprd\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:wmJQfhH3sLGxFxL01RpTrTrOdrOcgniE2TmiwMEa0IJ6tgX4").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "Audit_source", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + "115.124.105.62" + ":" + "3306" + "/" + "chaitanya_audit" + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = "chaitanya_auditprd";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:SPsHiCmG5soXjso2dML/z7U2f0lwZss2i8PgUHOh3xZQ/ZCw");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1","chaitanya_audit");
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_2");
		org.slf4j.MDC.put("_subJobPid", "Gb9eGU_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "\"audit_dwh\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "\"audit_user\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:ZYU1/EsFwaNzhpWMN/P66Zxbj+etBiD7skSoo48QFGVQfNPY4SE9").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_2", "Audit_target", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_2 = "";
            String url_tDBConnection_2 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"audit_dwh";
            
            if(dbProperties_tDBConnection_2 != null && !"".equals(dbProperties_tDBConnection_2.trim())) {
                url_tDBConnection_2 = url_tDBConnection_2 + "?" + dbProperties_tDBConnection_2;
            }
	String dbUser_tDBConnection_2 = "audit_user";
	
	
		 
	final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:OvGFxhInWVmdWFDlmfMX4BAE5YUJouqoyboY1WQSDlGkHYfOpYna");
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_2 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_2 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_2.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_2 = drivers_tDBConnection_2.nextElement();
        if (redShiftDriverNames_tDBConnection_2.contains(d_tDBConnection_2.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_2);
                java.sql.DriverManager.registerDriver(d_tDBConnection_2);
            } catch (java.lang.Exception e_tDBConnection_2) {
globalMap.put("tDBConnection_2_ERROR_MESSAGE",e_tDBConnection_2.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_2 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_2","");

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "yxs5u1_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", "I3zDRf_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMysqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
		
	    		log.debug("tDBClose_1 - Closing the connection 'tDBConnection_1' to the database.");
			
			conn_tDBClose_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	    		log.debug("tDBClose_1 - Connection 'tDBConnection_1' to the database closed.");
			
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_2Process(globalMap);



/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_2");
		org.slf4j.MDC.put("_subJobPid", "z5yCnr_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_2", false);
		start_Hash.put("tDBClose_2", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_2";
	
	
		int tos_count_tDBClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_2 = new StringBuilder();
                    log4jParamters_tDBClose_2.append("Parameters:");
                            log4jParamters_tDBClose_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBClose_2.append(" | ");
                            log4jParamters_tDBClose_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + (log4jParamters_tDBClose_2) );
                    } 
                } 
            new BytesLimit65535_tDBClose_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_2", "tDBClose_2", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_2 begin ] stop
 */
	
	/**
	 * [tDBClose_2 main ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	



	java.sql.Connection conn_tDBClose_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	if(conn_tDBClose_2 != null && !conn_tDBClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Closing the connection ")  + ("conn_tDBConnection_2")  + (" to the database.") );
        conn_tDBClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Connection ")  + ("conn_tDBConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_2++;

/**
 * [tDBClose_2 main ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_2 end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Done.") );

ok_Hash.put("tDBClose_2", true);
end_Hash.put("tDBClose_2", System.currentTimeMillis());




/**
 * [tDBClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_2 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_2_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row1Struct implements routines.system.IPersistableRow<pRow_row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String region;

				public String getRegion () {
					return this.region;
				}

				public Boolean regionIsNullable(){
				    return true;
				}
				public Boolean regionIsKey(){
				    return false;
				}
				public Integer regionLength(){
				    return 2147483647;
				}
				public Integer regionPrecision(){
				    return 0;
				}
				public String regionDefault(){
				
					return null;
				
				}
				public String regionComment(){
				
				    return "";
				
				}
				public String regionPattern(){
				
					return "";
				
				}
				public String regionOriginalDbColumnName(){
				
					return "region";
				
				}

				
			    public String division;

				public String getDivision () {
					return this.division;
				}

				public Boolean divisionIsNullable(){
				    return true;
				}
				public Boolean divisionIsKey(){
				    return false;
				}
				public Integer divisionLength(){
				    return 2147483647;
				}
				public Integer divisionPrecision(){
				    return 0;
				}
				public String divisionDefault(){
				
					return null;
				
				}
				public String divisionComment(){
				
				    return "";
				
				}
				public String divisionPattern(){
				
					return "";
				
				}
				public String divisionOriginalDbColumnName(){
				
					return "division";
				
				}

				
			    public String branch_id;

				public String getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return true;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 2147483647;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return null;
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public String branch;

				public String getBranch () {
					return this.branch;
				}

				public Boolean branchIsNullable(){
				    return true;
				}
				public Boolean branchIsKey(){
				    return false;
				}
				public Integer branchLength(){
				    return 2147483647;
				}
				public Integer branchPrecision(){
				    return 0;
				}
				public String branchDefault(){
				
					return null;
				
				}
				public String branchComment(){
				
				    return "";
				
				}
				public String branchPattern(){
				
					return "";
				
				}
				public String branchOriginalDbColumnName(){
				
					return "branch";
				
				}

				
			    public Short month;

				public Short getMonth () {
					return this.month;
				}

				public Boolean monthIsNullable(){
				    return true;
				}
				public Boolean monthIsKey(){
				    return false;
				}
				public Integer monthLength(){
				    return 5;
				}
				public Integer monthPrecision(){
				    return 0;
				}
				public String monthDefault(){
				
					return null;
				
				}
				public String monthComment(){
				
				    return "";
				
				}
				public String monthPattern(){
				
					return "";
				
				}
				public String monthOriginalDbColumnName(){
				
					return "month";
				
				}

				
			    public Integer year;

				public Integer getYear () {
					return this.year;
				}

				public Boolean yearIsNullable(){
				    return true;
				}
				public Boolean yearIsKey(){
				    return false;
				}
				public Integer yearLength(){
				    return 10;
				}
				public Integer yearPrecision(){
				    return 0;
				}
				public String yearDefault(){
				
					return null;
				
				}
				public String yearComment(){
				
				    return "";
				
				}
				public String yearPattern(){
				
					return "";
				
				}
				public String yearOriginalDbColumnName(){
				
					return "year";
				
				}

				
			    public java.util.Date tentative_from_date;

				public java.util.Date getTentative_from_date () {
					return this.tentative_from_date;
				}

				public Boolean tentative_from_dateIsNullable(){
				    return true;
				}
				public Boolean tentative_from_dateIsKey(){
				    return false;
				}
				public Integer tentative_from_dateLength(){
				    return 13;
				}
				public Integer tentative_from_datePrecision(){
				    return 0;
				}
				public String tentative_from_dateDefault(){
				
					return null;
				
				}
				public String tentative_from_dateComment(){
				
				    return "";
				
				}
				public String tentative_from_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tentative_from_dateOriginalDbColumnName(){
				
					return "tentative_from_date";
				
				}

				
			    public java.util.Date tentative_to_date;

				public java.util.Date getTentative_to_date () {
					return this.tentative_to_date;
				}

				public Boolean tentative_to_dateIsNullable(){
				    return true;
				}
				public Boolean tentative_to_dateIsKey(){
				    return false;
				}
				public Integer tentative_to_dateLength(){
				    return 13;
				}
				public Integer tentative_to_datePrecision(){
				    return 0;
				}
				public String tentative_to_dateDefault(){
				
					return null;
				
				}
				public String tentative_to_dateComment(){
				
				    return "";
				
				}
				public String tentative_to_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tentative_to_dateOriginalDbColumnName(){
				
					return "tentative_to_date";
				
				}

				
			    public java.util.Date cutoff_date;

				public java.util.Date getCutoff_date () {
					return this.cutoff_date;
				}

				public Boolean cutoff_dateIsNullable(){
				    return true;
				}
				public Boolean cutoff_dateIsKey(){
				    return false;
				}
				public Integer cutoff_dateLength(){
				    return 13;
				}
				public Integer cutoff_datePrecision(){
				    return 0;
				}
				public String cutoff_dateDefault(){
				
					return null;
				
				}
				public String cutoff_dateComment(){
				
				    return "";
				
				}
				public String cutoff_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String cutoff_dateOriginalDbColumnName(){
				
					return "cutoff_date";
				
				}

				
			    public Integer auditor_id;

				public Integer getAuditor_id () {
					return this.auditor_id;
				}

				public Boolean auditor_idIsNullable(){
				    return true;
				}
				public Boolean auditor_idIsKey(){
				    return false;
				}
				public Integer auditor_idLength(){
				    return 10;
				}
				public Integer auditor_idPrecision(){
				    return 0;
				}
				public String auditor_idDefault(){
				
					return null;
				
				}
				public String auditor_idComment(){
				
				    return "";
				
				}
				public String auditor_idPattern(){
				
					return "";
				
				}
				public String auditor_idOriginalDbColumnName(){
				
					return "auditor_id";
				
				}

				
			    public String auditor;

				public String getAuditor () {
					return this.auditor;
				}

				public Boolean auditorIsNullable(){
				    return true;
				}
				public Boolean auditorIsKey(){
				    return false;
				}
				public Integer auditorLength(){
				    return 2147483647;
				}
				public Integer auditorPrecision(){
				    return 0;
				}
				public String auditorDefault(){
				
					return null;
				
				}
				public String auditorComment(){
				
				    return "";
				
				}
				public String auditorPattern(){
				
					return "";
				
				}
				public String auditorOriginalDbColumnName(){
				
					return "auditor";
				
				}

				
			    public String des;

				public String getDes () {
					return this.des;
				}

				public Boolean desIsNullable(){
				    return true;
				}
				public Boolean desIsKey(){
				    return false;
				}
				public Integer desLength(){
				    return 2147483647;
				}
				public Integer desPrecision(){
				    return 0;
				}
				public String desDefault(){
				
					return null;
				
				}
				public String desComment(){
				
				    return "";
				
				}
				public String desPattern(){
				
					return "";
				
				}
				public String desOriginalDbColumnName(){
				
					return "des";
				
				}

				
			    public java.util.Date audit_commencement_date;

				public java.util.Date getAudit_commencement_date () {
					return this.audit_commencement_date;
				}

				public Boolean audit_commencement_dateIsNullable(){
				    return true;
				}
				public Boolean audit_commencement_dateIsKey(){
				    return false;
				}
				public Integer audit_commencement_dateLength(){
				    return 13;
				}
				public Integer audit_commencement_datePrecision(){
				    return 0;
				}
				public String audit_commencement_dateDefault(){
				
					return null;
				
				}
				public String audit_commencement_dateComment(){
				
				    return "";
				
				}
				public String audit_commencement_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audit_commencement_dateOriginalDbColumnName(){
				
					return "audit_commencement_date";
				
				}

				
			    public java.util.Date closed_date;

				public java.util.Date getClosed_date () {
					return this.closed_date;
				}

				public Boolean closed_dateIsNullable(){
				    return true;
				}
				public Boolean closed_dateIsKey(){
				    return false;
				}
				public Integer closed_dateLength(){
				    return 13;
				}
				public Integer closed_datePrecision(){
				    return 0;
				}
				public String closed_dateDefault(){
				
					return null;
				
				}
				public String closed_dateComment(){
				
				    return "";
				
				}
				public String closed_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String closed_dateOriginalDbColumnName(){
				
					return "closed_date";
				
				}

				
			    public String comments_by_auditor;

				public String getComments_by_auditor () {
					return this.comments_by_auditor;
				}

				public Boolean comments_by_auditorIsNullable(){
				    return true;
				}
				public Boolean comments_by_auditorIsKey(){
				    return false;
				}
				public Integer comments_by_auditorLength(){
				    return 2147483647;
				}
				public Integer comments_by_auditorPrecision(){
				    return 0;
				}
				public String comments_by_auditorDefault(){
				
					return null;
				
				}
				public String comments_by_auditorComment(){
				
				    return "";
				
				}
				public String comments_by_auditorPattern(){
				
					return "";
				
				}
				public String comments_by_auditorOriginalDbColumnName(){
				
					return "comments_by_auditor";
				
				}

				
			    public Integer branch_audit_id;

				public Integer getBranch_audit_id () {
					return this.branch_audit_id;
				}

				public Boolean branch_audit_idIsNullable(){
				    return true;
				}
				public Boolean branch_audit_idIsKey(){
				    return false;
				}
				public Integer branch_audit_idLength(){
				    return 10;
				}
				public Integer branch_audit_idPrecision(){
				    return 0;
				}
				public String branch_audit_idDefault(){
				
					return null;
				
				}
				public String branch_audit_idComment(){
				
				    return "";
				
				}
				public String branch_audit_idPattern(){
				
					return "";
				
				}
				public String branch_audit_idOriginalDbColumnName(){
				
					return "branch_audit_id";
				
				}

				
			    public java.util.Date tat_requested_date;

				public java.util.Date getTat_requested_date () {
					return this.tat_requested_date;
				}

				public Boolean tat_requested_dateIsNullable(){
				    return true;
				}
				public Boolean tat_requested_dateIsKey(){
				    return false;
				}
				public Integer tat_requested_dateLength(){
				    return 13;
				}
				public Integer tat_requested_datePrecision(){
				    return 0;
				}
				public String tat_requested_dateDefault(){
				
					return null;
				
				}
				public String tat_requested_dateComment(){
				
				    return "";
				
				}
				public String tat_requested_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tat_requested_dateOriginalDbColumnName(){
				
					return "tat_requested_date";
				
				}

				
			    public String tat_reason;

				public String getTat_reason () {
					return this.tat_reason;
				}

				public Boolean tat_reasonIsNullable(){
				    return true;
				}
				public Boolean tat_reasonIsKey(){
				    return false;
				}
				public Integer tat_reasonLength(){
				    return 2147483647;
				}
				public Integer tat_reasonPrecision(){
				    return 0;
				}
				public String tat_reasonDefault(){
				
					return null;
				
				}
				public String tat_reasonComment(){
				
				    return "";
				
				}
				public String tat_reasonPattern(){
				
					return "";
				
				}
				public String tat_reasonOriginalDbColumnName(){
				
					return "tat_reason";
				
				}

				
			    public BigDecimal tat_status;

				public BigDecimal getTat_status () {
					return this.tat_status;
				}

				public Boolean tat_statusIsNullable(){
				    return true;
				}
				public Boolean tat_statusIsKey(){
				    return false;
				}
				public Integer tat_statusLength(){
				    return 16;
				}
				public Integer tat_statusPrecision(){
				    return 0;
				}
				public String tat_statusDefault(){
				
					return null;
				
				}
				public String tat_statusComment(){
				
				    return "";
				
				}
				public String tat_statusPattern(){
				
					return "";
				
				}
				public String tat_statusOriginalDbColumnName(){
				
					return "tat_status";
				
				}

				
			    public String final_comments;

				public String getFinal_comments () {
					return this.final_comments;
				}

				public Boolean final_commentsIsNullable(){
				    return true;
				}
				public Boolean final_commentsIsKey(){
				    return false;
				}
				public Integer final_commentsLength(){
				    return 2147483647;
				}
				public Integer final_commentsPrecision(){
				    return 0;
				}
				public String final_commentsDefault(){
				
					return null;
				
				}
				public String final_commentsComment(){
				
				    return "";
				
				}
				public String final_commentsPattern(){
				
					return "";
				
				}
				public String final_commentsOriginalDbColumnName(){
				
					return "final_comments";
				
				}

				
			    public Integer checklist_id;

				public Integer getChecklist_id () {
					return this.checklist_id;
				}

				public Boolean checklist_idIsNullable(){
				    return true;
				}
				public Boolean checklist_idIsKey(){
				    return false;
				}
				public Integer checklist_idLength(){
				    return 10;
				}
				public Integer checklist_idPrecision(){
				    return 0;
				}
				public String checklist_idDefault(){
				
					return null;
				
				}
				public String checklist_idComment(){
				
				    return "";
				
				}
				public String checklist_idPattern(){
				
					return "";
				
				}
				public String checklist_idOriginalDbColumnName(){
				
					return "checklist_id";
				
				}

				
			    public String longitude;

				public String getLongitude () {
					return this.longitude;
				}

				public Boolean longitudeIsNullable(){
				    return true;
				}
				public Boolean longitudeIsKey(){
				    return false;
				}
				public Integer longitudeLength(){
				    return 2147483647;
				}
				public Integer longitudePrecision(){
				    return 0;
				}
				public String longitudeDefault(){
				
					return null;
				
				}
				public String longitudeComment(){
				
				    return "";
				
				}
				public String longitudePattern(){
				
					return "";
				
				}
				public String longitudeOriginalDbColumnName(){
				
					return "longitude";
				
				}

				
			    public String latitude;

				public String getLatitude () {
					return this.latitude;
				}

				public Boolean latitudeIsNullable(){
				    return true;
				}
				public Boolean latitudeIsKey(){
				    return false;
				}
				public Integer latitudeLength(){
				    return 2147483647;
				}
				public Integer latitudePrecision(){
				    return 0;
				}
				public String latitudeDefault(){
				
					return null;
				
				}
				public String latitudeComment(){
				
				    return "";
				
				}
				public String latitudePattern(){
				
					return "";
				
				}
				public String latitudeOriginalDbColumnName(){
				
					return "latitude";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_date;

				public java.util.Date getCreated_date () {
					return this.created_date;
				}

				public Boolean created_dateIsNullable(){
				    return true;
				}
				public Boolean created_dateIsKey(){
				    return false;
				}
				public Integer created_dateLength(){
				    return 13;
				}
				public Integer created_datePrecision(){
				    return 0;
				}
				public String created_dateDefault(){
				
					return null;
				
				}
				public String created_dateComment(){
				
				    return "";
				
				}
				public String created_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_dateOriginalDbColumnName(){
				
					return "created_date";
				
				}

				
			    public Integer is_active;

				public Integer getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return true;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return null;
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public Integer is_deleted;

				public Integer getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return true;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return null;
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return true;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return null;
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public String status;

				public String getStatus () {
					return this.status;
				}

				public Boolean statusIsNullable(){
				    return true;
				}
				public Boolean statusIsKey(){
				    return false;
				}
				public Integer statusLength(){
				    return 2147483647;
				}
				public Integer statusPrecision(){
				    return 0;
				}
				public String statusDefault(){
				
					return null;
				
				}
				public String statusComment(){
				
				    return "";
				
				}
				public String statusPattern(){
				
					return "";
				
				}
				public String statusOriginalDbColumnName(){
				
					return "status";
				
				}

				
			    public Integer is_surprised;

				public Integer getIs_surprised () {
					return this.is_surprised;
				}

				public Boolean is_surprisedIsNullable(){
				    return true;
				}
				public Boolean is_surprisedIsKey(){
				    return false;
				}
				public Integer is_surprisedLength(){
				    return 10;
				}
				public Integer is_surprisedPrecision(){
				    return 0;
				}
				public String is_surprisedDefault(){
				
					return null;
				
				}
				public String is_surprisedComment(){
				
				    return "";
				
				}
				public String is_surprisedPattern(){
				
					return "";
				
				}
				public String is_surprisedOriginalDbColumnName(){
				
					return "is_surprised";
				
				}

				
			    public String audit_commencement_info_id;

				public String getAudit_commencement_info_id () {
					return this.audit_commencement_info_id;
				}

				public Boolean audit_commencement_info_idIsNullable(){
				    return true;
				}
				public Boolean audit_commencement_info_idIsKey(){
				    return false;
				}
				public Integer audit_commencement_info_idLength(){
				    return 2147483647;
				}
				public Integer audit_commencement_info_idPrecision(){
				    return 0;
				}
				public String audit_commencement_info_idDefault(){
				
					return null;
				
				}
				public String audit_commencement_info_idComment(){
				
				    return "";
				
				}
				public String audit_commencement_info_idPattern(){
				
					return "";
				
				}
				public String audit_commencement_info_idOriginalDbColumnName(){
				
					return "audit_commencement_info_id";
				
				}

				
			    public BigDecimal closed_by;

				public BigDecimal getClosed_by () {
					return this.closed_by;
				}

				public Boolean closed_byIsNullable(){
				    return true;
				}
				public Boolean closed_byIsKey(){
				    return false;
				}
				public Integer closed_byLength(){
				    return 0;
				}
				public Integer closed_byPrecision(){
				    return 0;
				}
				public String closed_byDefault(){
				
					return null;
				
				}
				public String closed_byComment(){
				
				    return "";
				
				}
				public String closed_byPattern(){
				
					return "";
				
				}
				public String closed_byOriginalDbColumnName(){
				
					return "closed_by";
				
				}

				
			    public Integer allow_forced_submit;

				public Integer getAllow_forced_submit () {
					return this.allow_forced_submit;
				}

				public Boolean allow_forced_submitIsNullable(){
				    return true;
				}
				public Boolean allow_forced_submitIsKey(){
				    return false;
				}
				public Integer allow_forced_submitLength(){
				    return 10;
				}
				public Integer allow_forced_submitPrecision(){
				    return 0;
				}
				public String allow_forced_submitDefault(){
				
					return null;
				
				}
				public String allow_forced_submitComment(){
				
				    return "";
				
				}
				public String allow_forced_submitPattern(){
				
					return "";
				
				}
				public String allow_forced_submitOriginalDbColumnName(){
				
					return "allow_forced_submit";
				
				}

				
			    public Integer is_sink;

				public Integer getIs_sink () {
					return this.is_sink;
				}

				public Boolean is_sinkIsNullable(){
				    return true;
				}
				public Boolean is_sinkIsKey(){
				    return false;
				}
				public Integer is_sinkLength(){
				    return 10;
				}
				public Integer is_sinkPrecision(){
				    return 0;
				}
				public String is_sinkDefault(){
				
					return null;
				
				}
				public String is_sinkComment(){
				
				    return "";
				
				}
				public String is_sinkPattern(){
				
					return "";
				
				}
				public String is_sinkOriginalDbColumnName(){
				
					return "is_sink";
				
				}

				
			    public Integer is_team_changed;

				public Integer getIs_team_changed () {
					return this.is_team_changed;
				}

				public Boolean is_team_changedIsNullable(){
				    return true;
				}
				public Boolean is_team_changedIsKey(){
				    return false;
				}
				public Integer is_team_changedLength(){
				    return 10;
				}
				public Integer is_team_changedPrecision(){
				    return 0;
				}
				public String is_team_changedDefault(){
				
					return null;
				
				}
				public String is_team_changedComment(){
				
				    return "";
				
				}
				public String is_team_changedPattern(){
				
					return "";
				
				}
				public String is_team_changedOriginalDbColumnName(){
				
					return "is_team_changed";
				
				}

				
			    public Integer is_editable;

				public Integer getIs_editable () {
					return this.is_editable;
				}

				public Boolean is_editableIsNullable(){
				    return true;
				}
				public Boolean is_editableIsKey(){
				    return false;
				}
				public Integer is_editableLength(){
				    return 10;
				}
				public Integer is_editablePrecision(){
				    return 0;
				}
				public String is_editableDefault(){
				
					return null;
				
				}
				public String is_editableComment(){
				
				    return "";
				
				}
				public String is_editablePattern(){
				
					return "";
				
				}
				public String is_editableOriginalDbColumnName(){
				
					return "is_editable";
				
				}

				
			    public java.util.Date freezing_date;

				public java.util.Date getFreezing_date () {
					return this.freezing_date;
				}

				public Boolean freezing_dateIsNullable(){
				    return true;
				}
				public Boolean freezing_dateIsKey(){
				    return false;
				}
				public Integer freezing_dateLength(){
				    return 13;
				}
				public Integer freezing_datePrecision(){
				    return 0;
				}
				public String freezing_dateDefault(){
				
					return null;
				
				}
				public String freezing_dateComment(){
				
				    return "";
				
				}
				public String freezing_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String freezing_dateOriginalDbColumnName(){
				
					return "freezing_date";
				
				}

				
			    public Integer recalculation;

				public Integer getRecalculation () {
					return this.recalculation;
				}

				public Boolean recalculationIsNullable(){
				    return true;
				}
				public Boolean recalculationIsKey(){
				    return false;
				}
				public Integer recalculationLength(){
				    return 10;
				}
				public Integer recalculationPrecision(){
				    return 0;
				}
				public String recalculationDefault(){
				
					return null;
				
				}
				public String recalculationComment(){
				
				    return "";
				
				}
				public String recalculationPattern(){
				
					return "";
				
				}
				public String recalculationOriginalDbColumnName(){
				
					return "recalculation";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row1Struct other = (pRow_row1Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row1Struct other) {

		other.id = this.id;
	            other.region = this.region;
	            other.division = this.division;
	            other.branch_id = this.branch_id;
	            other.branch = this.branch;
	            other.month = this.month;
	            other.year = this.year;
	            other.tentative_from_date = this.tentative_from_date;
	            other.tentative_to_date = this.tentative_to_date;
	            other.cutoff_date = this.cutoff_date;
	            other.auditor_id = this.auditor_id;
	            other.auditor = this.auditor;
	            other.des = this.des;
	            other.audit_commencement_date = this.audit_commencement_date;
	            other.closed_date = this.closed_date;
	            other.comments_by_auditor = this.comments_by_auditor;
	            other.branch_audit_id = this.branch_audit_id;
	            other.tat_requested_date = this.tat_requested_date;
	            other.tat_reason = this.tat_reason;
	            other.tat_status = this.tat_status;
	            other.final_comments = this.final_comments;
	            other.checklist_id = this.checklist_id;
	            other.longitude = this.longitude;
	            other.latitude = this.latitude;
	            other.created_by = this.created_by;
	            other.created_date = this.created_date;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.status = this.status;
	            other.is_surprised = this.is_surprised;
	            other.audit_commencement_info_id = this.audit_commencement_info_id;
	            other.closed_by = this.closed_by;
	            other.allow_forced_submit = this.allow_forced_submit;
	            other.is_sink = this.is_sink;
	            other.is_team_changed = this.is_team_changed;
	            other.is_editable = this.is_editable;
	            other.freezing_date = this.freezing_date;
	            other.recalculation = this.recalculation;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row1Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
					this.division = readString(dis);
					
					this.branch_id = readString(dis);
					
					this.branch = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.month = null;
           				} else {
           			    	this.month = dis.readShort();
           				}
					
						this.year = readInteger(dis);
					
					this.tentative_from_date = readDate(dis);
					
					this.tentative_to_date = readDate(dis);
					
					this.cutoff_date = readDate(dis);
					
						this.auditor_id = readInteger(dis);
					
					this.auditor = readString(dis);
					
					this.des = readString(dis);
					
					this.audit_commencement_date = readDate(dis);
					
					this.closed_date = readDate(dis);
					
					this.comments_by_auditor = readString(dis);
					
						this.branch_audit_id = readInteger(dis);
					
					this.tat_requested_date = readDate(dis);
					
					this.tat_reason = readString(dis);
					
						this.tat_status = (BigDecimal) dis.readObject();
					
					this.final_comments = readString(dis);
					
						this.checklist_id = readInteger(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_date = readDate(dis);
					
						this.is_active = readInteger(dis);
					
						this.is_deleted = readInteger(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
					this.status = readString(dis);
					
						this.is_surprised = readInteger(dis);
					
					this.audit_commencement_info_id = readString(dis);
					
						this.closed_by = (BigDecimal) dis.readObject();
					
						this.allow_forced_submit = readInteger(dis);
					
						this.is_sink = readInteger(dis);
					
						this.is_team_changed = readInteger(dis);
					
						this.is_editable = readInteger(dis);
					
					this.freezing_date = readDate(dis);
					
						this.recalculation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
					this.division = readString(dis);
					
					this.branch_id = readString(dis);
					
					this.branch = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.month = null;
           				} else {
           			    	this.month = dis.readShort();
           				}
					
						this.year = readInteger(dis);
					
					this.tentative_from_date = readDate(dis);
					
					this.tentative_to_date = readDate(dis);
					
					this.cutoff_date = readDate(dis);
					
						this.auditor_id = readInteger(dis);
					
					this.auditor = readString(dis);
					
					this.des = readString(dis);
					
					this.audit_commencement_date = readDate(dis);
					
					this.closed_date = readDate(dis);
					
					this.comments_by_auditor = readString(dis);
					
						this.branch_audit_id = readInteger(dis);
					
					this.tat_requested_date = readDate(dis);
					
					this.tat_reason = readString(dis);
					
						this.tat_status = (BigDecimal) dis.readObject();
					
					this.final_comments = readString(dis);
					
						this.checklist_id = readInteger(dis);
					
					this.longitude = readString(dis);
					
					this.latitude = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_date = readDate(dis);
					
						this.is_active = readInteger(dis);
					
						this.is_deleted = readInteger(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
					this.status = readString(dis);
					
						this.is_surprised = readInteger(dis);
					
					this.audit_commencement_info_id = readString(dis);
					
						this.closed_by = (BigDecimal) dis.readObject();
					
						this.allow_forced_submit = readInteger(dis);
					
						this.is_sink = readInteger(dis);
					
						this.is_team_changed = readInteger(dis);
					
						this.is_editable = readInteger(dis);
					
					this.freezing_date = readDate(dis);
					
						this.recalculation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// Short
				
						if(this.month == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.month);
		            	}
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_to_date,dos);
					
					// java.util.Date
				
						writeDate(this.cutoff_date,dos);
					
					// Integer
				
						writeInteger(this.auditor_id,dos);
					
					// String
				
						writeString(this.auditor,dos);
					
					// String
				
						writeString(this.des,dos);
					
					// java.util.Date
				
						writeDate(this.audit_commencement_date,dos);
					
					// java.util.Date
				
						writeDate(this.closed_date,dos);
					
					// String
				
						writeString(this.comments_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.branch_audit_id,dos);
					
					// java.util.Date
				
						writeDate(this.tat_requested_date,dos);
					
					// String
				
						writeString(this.tat_reason,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.tat_status);
					
					// String
				
						writeString(this.final_comments,dos);
					
					// Integer
				
						writeInteger(this.checklist_id,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_date,dos);
					
					// Integer
				
						writeInteger(this.is_active,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Integer
				
						writeInteger(this.is_surprised,dos);
					
					// String
				
						writeString(this.audit_commencement_info_id,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.closed_by);
					
					// Integer
				
						writeInteger(this.allow_forced_submit,dos);
					
					// Integer
				
						writeInteger(this.is_sink,dos);
					
					// Integer
				
						writeInteger(this.is_team_changed,dos);
					
					// Integer
				
						writeInteger(this.is_editable,dos);
					
					// java.util.Date
				
						writeDate(this.freezing_date,dos);
					
					// Integer
				
						writeInteger(this.recalculation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// Short
				
						if(this.month == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeShort(this.month);
		            	}
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_to_date,dos);
					
					// java.util.Date
				
						writeDate(this.cutoff_date,dos);
					
					// Integer
				
						writeInteger(this.auditor_id,dos);
					
					// String
				
						writeString(this.auditor,dos);
					
					// String
				
						writeString(this.des,dos);
					
					// java.util.Date
				
						writeDate(this.audit_commencement_date,dos);
					
					// java.util.Date
				
						writeDate(this.closed_date,dos);
					
					// String
				
						writeString(this.comments_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.branch_audit_id,dos);
					
					// java.util.Date
				
						writeDate(this.tat_requested_date,dos);
					
					// String
				
						writeString(this.tat_reason,dos);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.tat_status);
					
					// String
				
						writeString(this.final_comments,dos);
					
					// Integer
				
						writeInteger(this.checklist_id,dos);
					
					// String
				
						writeString(this.longitude,dos);
					
					// String
				
						writeString(this.latitude,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_date,dos);
					
					// Integer
				
						writeInteger(this.is_active,dos);
					
					// Integer
				
						writeInteger(this.is_deleted,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Integer
				
						writeInteger(this.is_surprised,dos);
					
					// String
				
						writeString(this.audit_commencement_info_id,dos);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.closed_by);
					
					// Integer
				
						writeInteger(this.allow_forced_submit,dos);
					
					// Integer
				
						writeInteger(this.is_sink,dos);
					
					// Integer
				
						writeInteger(this.is_team_changed,dos);
					
					// Integer
				
						writeInteger(this.is_editable,dos);
					
					// java.util.Date
				
						writeDate(this.freezing_date,dos);
					
					// Integer
				
						writeInteger(this.recalculation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",region="+region);
		sb.append(",division="+division);
		sb.append(",branch_id="+branch_id);
		sb.append(",branch="+branch);
		sb.append(",month="+String.valueOf(month));
		sb.append(",year="+String.valueOf(year));
		sb.append(",tentative_from_date="+String.valueOf(tentative_from_date));
		sb.append(",tentative_to_date="+String.valueOf(tentative_to_date));
		sb.append(",cutoff_date="+String.valueOf(cutoff_date));
		sb.append(",auditor_id="+String.valueOf(auditor_id));
		sb.append(",auditor="+auditor);
		sb.append(",des="+des);
		sb.append(",audit_commencement_date="+String.valueOf(audit_commencement_date));
		sb.append(",closed_date="+String.valueOf(closed_date));
		sb.append(",comments_by_auditor="+comments_by_auditor);
		sb.append(",branch_audit_id="+String.valueOf(branch_audit_id));
		sb.append(",tat_requested_date="+String.valueOf(tat_requested_date));
		sb.append(",tat_reason="+tat_reason);
		sb.append(",tat_status="+String.valueOf(tat_status));
		sb.append(",final_comments="+final_comments);
		sb.append(",checklist_id="+String.valueOf(checklist_id));
		sb.append(",longitude="+longitude);
		sb.append(",latitude="+latitude);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_date="+String.valueOf(created_date));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",status="+status);
		sb.append(",is_surprised="+String.valueOf(is_surprised));
		sb.append(",audit_commencement_info_id="+audit_commencement_info_id);
		sb.append(",closed_by="+String.valueOf(closed_by));
		sb.append(",allow_forced_submit="+String.valueOf(allow_forced_submit));
		sb.append(",is_sink="+String.valueOf(is_sink));
		sb.append(",is_team_changed="+String.valueOf(is_team_changed));
		sb.append(",is_editable="+String.valueOf(is_editable));
		sb.append(",freezing_date="+String.valueOf(freezing_date));
		sb.append(",recalculation="+String.valueOf(recalculation));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(region == null){
        					sb.append("<null>");
        				}else{
            				sb.append(region);
            			}
            		
        			sb.append("|");
        		
        				if(division == null){
        					sb.append("<null>");
        				}else{
            				sb.append(division);
            			}
            		
        			sb.append("|");
        		
        				if(branch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_id);
            			}
            		
        			sb.append("|");
        		
        				if(branch == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch);
            			}
            		
        			sb.append("|");
        		
        				if(month == null){
        					sb.append("<null>");
        				}else{
            				sb.append(month);
            			}
            		
        			sb.append("|");
        		
        				if(year == null){
        					sb.append("<null>");
        				}else{
            				sb.append(year);
            			}
            		
        			sb.append("|");
        		
        				if(tentative_from_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tentative_from_date);
            			}
            		
        			sb.append("|");
        		
        				if(tentative_to_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tentative_to_date);
            			}
            		
        			sb.append("|");
        		
        				if(cutoff_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cutoff_date);
            			}
            		
        			sb.append("|");
        		
        				if(auditor_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor_id);
            			}
            		
        			sb.append("|");
        		
        				if(auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor);
            			}
            		
        			sb.append("|");
        		
        				if(des == null){
        					sb.append("<null>");
        				}else{
            				sb.append(des);
            			}
            		
        			sb.append("|");
        		
        				if(audit_commencement_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_commencement_date);
            			}
            		
        			sb.append("|");
        		
        				if(closed_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(closed_date);
            			}
            		
        			sb.append("|");
        		
        				if(comments_by_auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(comments_by_auditor);
            			}
            		
        			sb.append("|");
        		
        				if(branch_audit_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_audit_id);
            			}
            		
        			sb.append("|");
        		
        				if(tat_requested_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tat_requested_date);
            			}
            		
        			sb.append("|");
        		
        				if(tat_reason == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tat_reason);
            			}
            		
        			sb.append("|");
        		
        				if(tat_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tat_status);
            			}
            		
        			sb.append("|");
        		
        				if(final_comments == null){
        					sb.append("<null>");
        				}else{
            				sb.append(final_comments);
            			}
            		
        			sb.append("|");
        		
        				if(checklist_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(checklist_id);
            			}
            		
        			sb.append("|");
        		
        				if(longitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(longitude);
            			}
            		
        			sb.append("|");
        		
        				if(latitude == null){
        					sb.append("<null>");
        				}else{
            				sb.append(latitude);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_date);
            			}
            		
        			sb.append("|");
        		
        				if(is_active == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_active);
            			}
            		
        			sb.append("|");
        		
        				if(is_deleted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_deleted);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(is_surprised == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_surprised);
            			}
            		
        			sb.append("|");
        		
        				if(audit_commencement_info_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_commencement_info_id);
            			}
            		
        			sb.append("|");
        		
        				if(closed_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(closed_by);
            			}
            		
        			sb.append("|");
        		
        				if(allow_forced_submit == null){
        					sb.append("<null>");
        				}else{
            				sb.append(allow_forced_submit);
            			}
            		
        			sb.append("|");
        		
        				if(is_sink == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_sink);
            			}
            		
        			sb.append("|");
        		
        				if(is_team_changed == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_team_changed);
            			}
            		
        			sb.append("|");
        		
        				if(is_editable == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_editable);
            			}
            		
        			sb.append("|");
        		
        				if(freezing_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(freezing_date);
            			}
            		
        			sb.append("|");
        		
        				if(recalculation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(recalculation);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_1");
		org.slf4j.MDC.put("_subJobPid", "qgS5i3_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_1");
		class tAsyncIn_tDBOutput_1_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_1_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row1Struct pRow_row1 = new pRow_row1Struct();




	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_commencement_info_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row1");
			
		int tos_count_tDBOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
                    log4jParamters_tDBOutput_1.append("Parameters:");
                            log4jParamters_tDBOutput_1.append("PARALLELIZE_NUMBER" + " = " + "9");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"audit_commencement_info_dw\"");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_1.append(" | ");
                            log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + (log4jParamters_tDBOutput_1) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_1", "\"audit_commencement_info_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_1 = null;
	dbschema_tDBOutput_1 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_1 = null;
if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
	tableName_tDBOutput_1 = ("audit_commencement_info_dw");
} else {
	tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "\".\"" + ("audit_commencement_info_dw");
}


int nb_line_tDBOutput_1 = 0;
int nb_line_update_tDBOutput_1 = 0;
int nb_line_inserted_tDBOutput_1 = 0;
int nb_line_deleted_tDBOutput_1 = 0;
int nb_line_rejected_tDBOutput_1 = 0;

int deletedCount_tDBOutput_1=0;
int updatedCount_tDBOutput_1=0;
int insertedCount_tDBOutput_1=0;
int rowsToCommitCount_tDBOutput_1=0;
int rejectedCount_tDBOutput_1=0;

boolean whetherReject_tDBOutput_1 = false;

java.sql.Connection conn_tDBOutput_1 = null;
String dbUser_tDBOutput_1 = null;

	conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_1.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_1.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_1 = 10000;
   int batchSizeCounter_tDBOutput_1=0;

int count_tDBOutput_1=0;
        java.lang.StringBuilder sb_tDBOutput_1 = new java.lang.StringBuilder();
        sb_tDBOutput_1.append("INSERT INTO \"").append(tableName_tDBOutput_1).append("\" (\"id\",\"region\",\"division\",\"branch_id\",\"branch\",\"month\",\"year\",\"tentative_from_date\",\"tentative_to_date\",\"cutoff_date\",\"auditor_id\",\"auditor\",\"des\",\"audit_commencement_date\",\"closed_date\",\"comments_by_auditor\",\"branch_audit_id\",\"tat_requested_date\",\"tat_reason\",\"tat_status\",\"final_comments\",\"checklist_id\",\"longitude\",\"latitude\",\"created_by\",\"created_date\",\"is_active\",\"is_deleted\",\"updated_by\",\"updated_on\",\"status\",\"is_surprised\",\"audit_commencement_info_id\",\"closed_by\",\"allow_forced_submit\",\"is_sink\",\"is_team_changed\",\"is_editable\",\"freezing_date\",\"recalculation\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_1.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"region\" = EXCLUDED.\"region\",\"division\" = EXCLUDED.\"division\",\"branch_id\" = EXCLUDED.\"branch_id\",\"branch\" = EXCLUDED.\"branch\",\"month\" = EXCLUDED.\"month\",\"year\" = EXCLUDED.\"year\",\"tentative_from_date\" = EXCLUDED.\"tentative_from_date\",\"tentative_to_date\" = EXCLUDED.\"tentative_to_date\",\"cutoff_date\" = EXCLUDED.\"cutoff_date\",\"auditor_id\" = EXCLUDED.\"auditor_id\",\"auditor\" = EXCLUDED.\"auditor\",\"des\" = EXCLUDED.\"des\",\"audit_commencement_date\" = EXCLUDED.\"audit_commencement_date\",\"closed_date\" = EXCLUDED.\"closed_date\",\"comments_by_auditor\" = EXCLUDED.\"comments_by_auditor\",\"branch_audit_id\" = EXCLUDED.\"branch_audit_id\",\"tat_requested_date\" = EXCLUDED.\"tat_requested_date\",\"tat_reason\" = EXCLUDED.\"tat_reason\",\"tat_status\" = EXCLUDED.\"tat_status\",\"final_comments\" = EXCLUDED.\"final_comments\",\"checklist_id\" = EXCLUDED.\"checklist_id\",\"longitude\" = EXCLUDED.\"longitude\",\"latitude\" = EXCLUDED.\"latitude\",\"created_by\" = EXCLUDED.\"created_by\",\"created_date\" = EXCLUDED.\"created_date\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"status\" = EXCLUDED.\"status\",\"is_surprised\" = EXCLUDED.\"is_surprised\",\"audit_commencement_info_id\" = EXCLUDED.\"audit_commencement_info_id\",\"closed_by\" = EXCLUDED.\"closed_by\",\"allow_forced_submit\" = EXCLUDED.\"allow_forced_submit\",\"is_sink\" = EXCLUDED.\"is_sink\",\"is_team_changed\" = EXCLUDED.\"is_team_changed\",\"is_editable\" = EXCLUDED.\"is_editable\",\"freezing_date\" = EXCLUDED.\"freezing_date\",\"recalculation\" = EXCLUDED.\"recalculation\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_1 = sb_tDBOutput_1.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing '")  + (insert_tDBOutput_1)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
	    resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
	    

 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_1", false);
		start_Hash.put("tAsyncIn_tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	
		int tos_count_tAsyncIn_tDBOutput_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_1", "tAsyncIn_tDBOutput_1", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_1= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_1 = buffers_tAsyncIn_tDBOutput_1.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_1 != null && buffers_tAsyncIn_tDBOutput_1.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_1 : buffers_tAsyncIn_tDBOutput_1) {
    		pRow_row1 = null;						
			pRow_row1 = new pRow_row1Struct();
		
		
			String temp_tAsyncIn_tDBOutput_1_0 = row_tAsyncIn_tDBOutput_1[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[0]);
			if(temp_tAsyncIn_tDBOutput_1_0 != null) {
		
			pRow_row1.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_1_0);
		} else {						
			pRow_row1.id = 0;
		}
		pRow_row1.region = row_tAsyncIn_tDBOutput_1[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[1]);
		pRow_row1.division = row_tAsyncIn_tDBOutput_1[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[2]);
		pRow_row1.branch_id = row_tAsyncIn_tDBOutput_1[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[3]);
		pRow_row1.branch = row_tAsyncIn_tDBOutput_1[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[4]);
		
		
			String temp_tAsyncIn_tDBOutput_1_5 = row_tAsyncIn_tDBOutput_1[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[5]);
			if(temp_tAsyncIn_tDBOutput_1_5 != null) {
		
			pRow_row1.month = ParserUtils.parseTo_Short(temp_tAsyncIn_tDBOutput_1_5);
		} else {						
			pRow_row1.month = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_6 = row_tAsyncIn_tDBOutput_1[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[6]);
			if(temp_tAsyncIn_tDBOutput_1_6 != null) {
		
			pRow_row1.year = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_6);
		} else {						
			pRow_row1.year = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_7 = row_tAsyncIn_tDBOutput_1[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[7]);
			if(temp_tAsyncIn_tDBOutput_1_7 != null) {
		
			pRow_row1.tentative_from_date = (java.util.Date)(row_tAsyncIn_tDBOutput_1[7]);
		} else {						
			pRow_row1.tentative_from_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_8 = row_tAsyncIn_tDBOutput_1[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[8]);
			if(temp_tAsyncIn_tDBOutput_1_8 != null) {
		
			pRow_row1.tentative_to_date = (java.util.Date)(row_tAsyncIn_tDBOutput_1[8]);
		} else {						
			pRow_row1.tentative_to_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_9 = row_tAsyncIn_tDBOutput_1[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[9]);
			if(temp_tAsyncIn_tDBOutput_1_9 != null) {
		
			pRow_row1.cutoff_date = (java.util.Date)(row_tAsyncIn_tDBOutput_1[9]);
		} else {						
			pRow_row1.cutoff_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_10 = row_tAsyncIn_tDBOutput_1[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[10]);
			if(temp_tAsyncIn_tDBOutput_1_10 != null) {
		
			pRow_row1.auditor_id = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_10);
		} else {						
			pRow_row1.auditor_id = null;
		}
		pRow_row1.auditor = row_tAsyncIn_tDBOutput_1[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[11]);
		pRow_row1.des = row_tAsyncIn_tDBOutput_1[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[12]);
		
		
			String temp_tAsyncIn_tDBOutput_1_13 = row_tAsyncIn_tDBOutput_1[13]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[13]);
			if(temp_tAsyncIn_tDBOutput_1_13 != null) {
		
			pRow_row1.audit_commencement_date = (java.util.Date)(row_tAsyncIn_tDBOutput_1[13]);
		} else {						
			pRow_row1.audit_commencement_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_14 = row_tAsyncIn_tDBOutput_1[14]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[14]);
			if(temp_tAsyncIn_tDBOutput_1_14 != null) {
		
			pRow_row1.closed_date = (java.util.Date)(row_tAsyncIn_tDBOutput_1[14]);
		} else {						
			pRow_row1.closed_date = null;
		}
		pRow_row1.comments_by_auditor = row_tAsyncIn_tDBOutput_1[15]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[15]);
		
		
			String temp_tAsyncIn_tDBOutput_1_16 = row_tAsyncIn_tDBOutput_1[16]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[16]);
			if(temp_tAsyncIn_tDBOutput_1_16 != null) {
		
			pRow_row1.branch_audit_id = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_16);
		} else {						
			pRow_row1.branch_audit_id = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_17 = row_tAsyncIn_tDBOutput_1[17]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[17]);
			if(temp_tAsyncIn_tDBOutput_1_17 != null) {
		
			pRow_row1.tat_requested_date = (java.util.Date)(row_tAsyncIn_tDBOutput_1[17]);
		} else {						
			pRow_row1.tat_requested_date = null;
		}
		pRow_row1.tat_reason = row_tAsyncIn_tDBOutput_1[18]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[18]);
		
		
			String temp_tAsyncIn_tDBOutput_1_19 = row_tAsyncIn_tDBOutput_1[19]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[19]);
			if(temp_tAsyncIn_tDBOutput_1_19 != null) {
		
			pRow_row1.tat_status = ParserUtils.parseTo_BigDecimal(temp_tAsyncIn_tDBOutput_1_19);
		} else {						
			pRow_row1.tat_status = null;
		}
		pRow_row1.final_comments = row_tAsyncIn_tDBOutput_1[20]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[20]);
		
		
			String temp_tAsyncIn_tDBOutput_1_21 = row_tAsyncIn_tDBOutput_1[21]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[21]);
			if(temp_tAsyncIn_tDBOutput_1_21 != null) {
		
			pRow_row1.checklist_id = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_21);
		} else {						
			pRow_row1.checklist_id = null;
		}
		pRow_row1.longitude = row_tAsyncIn_tDBOutput_1[22]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[22]);
		pRow_row1.latitude = row_tAsyncIn_tDBOutput_1[23]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[23]);
		
		
			String temp_tAsyncIn_tDBOutput_1_24 = row_tAsyncIn_tDBOutput_1[24]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[24]);
			if(temp_tAsyncIn_tDBOutput_1_24 != null) {
		
			pRow_row1.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_24);
		} else {						
			pRow_row1.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_25 = row_tAsyncIn_tDBOutput_1[25]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[25]);
			if(temp_tAsyncIn_tDBOutput_1_25 != null) {
		
			pRow_row1.created_date = (java.util.Date)(row_tAsyncIn_tDBOutput_1[25]);
		} else {						
			pRow_row1.created_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_26 = row_tAsyncIn_tDBOutput_1[26]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[26]);
			if(temp_tAsyncIn_tDBOutput_1_26 != null) {
		
			pRow_row1.is_active = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_26);
		} else {						
			pRow_row1.is_active = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_27 = row_tAsyncIn_tDBOutput_1[27]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[27]);
			if(temp_tAsyncIn_tDBOutput_1_27 != null) {
		
			pRow_row1.is_deleted = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_27);
		} else {						
			pRow_row1.is_deleted = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_28 = row_tAsyncIn_tDBOutput_1[28]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[28]);
			if(temp_tAsyncIn_tDBOutput_1_28 != null) {
		
			pRow_row1.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_28);
		} else {						
			pRow_row1.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_29 = row_tAsyncIn_tDBOutput_1[29]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[29]);
			if(temp_tAsyncIn_tDBOutput_1_29 != null) {
		
			pRow_row1.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_1[29]);
		} else {						
			pRow_row1.updated_on = null;
		}
		pRow_row1.status = row_tAsyncIn_tDBOutput_1[30]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[30]);
		
		
			String temp_tAsyncIn_tDBOutput_1_31 = row_tAsyncIn_tDBOutput_1[31]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[31]);
			if(temp_tAsyncIn_tDBOutput_1_31 != null) {
		
			pRow_row1.is_surprised = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_31);
		} else {						
			pRow_row1.is_surprised = null;
		}
		pRow_row1.audit_commencement_info_id = row_tAsyncIn_tDBOutput_1[32]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[32]);
		
		
			String temp_tAsyncIn_tDBOutput_1_33 = row_tAsyncIn_tDBOutput_1[33]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[33]);
			if(temp_tAsyncIn_tDBOutput_1_33 != null) {
		
			pRow_row1.closed_by = ParserUtils.parseTo_BigDecimal(temp_tAsyncIn_tDBOutput_1_33);
		} else {						
			pRow_row1.closed_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_34 = row_tAsyncIn_tDBOutput_1[34]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[34]);
			if(temp_tAsyncIn_tDBOutput_1_34 != null) {
		
			pRow_row1.allow_forced_submit = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_34);
		} else {						
			pRow_row1.allow_forced_submit = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_35 = row_tAsyncIn_tDBOutput_1[35]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[35]);
			if(temp_tAsyncIn_tDBOutput_1_35 != null) {
		
			pRow_row1.is_sink = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_35);
		} else {						
			pRow_row1.is_sink = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_36 = row_tAsyncIn_tDBOutput_1[36]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[36]);
			if(temp_tAsyncIn_tDBOutput_1_36 != null) {
		
			pRow_row1.is_team_changed = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_36);
		} else {						
			pRow_row1.is_team_changed = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_37 = row_tAsyncIn_tDBOutput_1[37]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[37]);
			if(temp_tAsyncIn_tDBOutput_1_37 != null) {
		
			pRow_row1.is_editable = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_37);
		} else {						
			pRow_row1.is_editable = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_38 = row_tAsyncIn_tDBOutput_1[38]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[38]);
			if(temp_tAsyncIn_tDBOutput_1_38 != null) {
		
			pRow_row1.freezing_date = (java.util.Date)(row_tAsyncIn_tDBOutput_1[38]);
		} else {						
			pRow_row1.freezing_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_39 = row_tAsyncIn_tDBOutput_1[39]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[39]);
			if(temp_tAsyncIn_tDBOutput_1_39 != null) {
		
			pRow_row1.recalculation = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_1_39);
		} else {						
			pRow_row1.recalculation = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_1_40 = row_tAsyncIn_tDBOutput_1[40]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_1[40]);
			if(temp_tAsyncIn_tDBOutput_1_40 != null) {
		
			pRow_row1.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_1[40]);
		} else {						
			pRow_row1.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_1 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

 


	tos_count_tAsyncIn_tDBOutput_1++;

/**
 * [tAsyncIn_tDBOutput_1 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

 



/**
 * [tAsyncIn_tDBOutput_1 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_commencement_info_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row1","tAsyncIn_tDBOutput_1","tAsyncIn_tDBOutput_1","tAsyncIn","tDBOutput_1","\"audit_commencement_info_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row1 - " + (pRow_row1==null? "": pRow_row1.toLogString()));
    			}
    		



				batchSize_tDBOutput_1 = buffersSize_tAsyncIn_tDBOutput_1;
        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, pRow_row1.id);

                    if(pRow_row1.region == null) {
pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(2, pRow_row1.region);
}

                    if(pRow_row1.division == null) {
pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(3, pRow_row1.division);
}

                    if(pRow_row1.branch_id == null) {
pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(4, pRow_row1.branch_id);
}

                    if(pRow_row1.branch == null) {
pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(5, pRow_row1.branch);
}

                    if(pRow_row1.month == null) {
pstmt_tDBOutput_1.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setShort(6, pRow_row1.month);
}

                    if(pRow_row1.year == null) {
pstmt_tDBOutput_1.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(7, pRow_row1.year);
}

                    if(pRow_row1.tentative_from_date != null) {
pstmt_tDBOutput_1.setTimestamp(8, new java.sql.Timestamp(pRow_row1.tentative_from_date.getTime()));
} else {
pstmt_tDBOutput_1.setNull(8, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.tentative_to_date != null) {
pstmt_tDBOutput_1.setTimestamp(9, new java.sql.Timestamp(pRow_row1.tentative_to_date.getTime()));
} else {
pstmt_tDBOutput_1.setNull(9, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.cutoff_date != null) {
pstmt_tDBOutput_1.setTimestamp(10, new java.sql.Timestamp(pRow_row1.cutoff_date.getTime()));
} else {
pstmt_tDBOutput_1.setNull(10, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.auditor_id == null) {
pstmt_tDBOutput_1.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(11, pRow_row1.auditor_id);
}

                    if(pRow_row1.auditor == null) {
pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(12, pRow_row1.auditor);
}

                    if(pRow_row1.des == null) {
pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(13, pRow_row1.des);
}

                    if(pRow_row1.audit_commencement_date != null) {
pstmt_tDBOutput_1.setTimestamp(14, new java.sql.Timestamp(pRow_row1.audit_commencement_date.getTime()));
} else {
pstmt_tDBOutput_1.setNull(14, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.closed_date != null) {
pstmt_tDBOutput_1.setTimestamp(15, new java.sql.Timestamp(pRow_row1.closed_date.getTime()));
} else {
pstmt_tDBOutput_1.setNull(15, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.comments_by_auditor == null) {
pstmt_tDBOutput_1.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(16, pRow_row1.comments_by_auditor);
}

                    if(pRow_row1.branch_audit_id == null) {
pstmt_tDBOutput_1.setNull(17, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(17, pRow_row1.branch_audit_id);
}

                    if(pRow_row1.tat_requested_date != null) {
pstmt_tDBOutput_1.setTimestamp(18, new java.sql.Timestamp(pRow_row1.tat_requested_date.getTime()));
} else {
pstmt_tDBOutput_1.setNull(18, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.tat_reason == null) {
pstmt_tDBOutput_1.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(19, pRow_row1.tat_reason);
}

                    pstmt_tDBOutput_1.setBigDecimal(20, pRow_row1.tat_status);

                    if(pRow_row1.final_comments == null) {
pstmt_tDBOutput_1.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(21, pRow_row1.final_comments);
}

                    if(pRow_row1.checklist_id == null) {
pstmt_tDBOutput_1.setNull(22, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(22, pRow_row1.checklist_id);
}

                    if(pRow_row1.longitude == null) {
pstmt_tDBOutput_1.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(23, pRow_row1.longitude);
}

                    if(pRow_row1.latitude == null) {
pstmt_tDBOutput_1.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(24, pRow_row1.latitude);
}

                    if(pRow_row1.created_by == null) {
pstmt_tDBOutput_1.setNull(25, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(25, pRow_row1.created_by);
}

                    if(pRow_row1.created_date != null) {
pstmt_tDBOutput_1.setTimestamp(26, new java.sql.Timestamp(pRow_row1.created_date.getTime()));
} else {
pstmt_tDBOutput_1.setNull(26, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.is_active == null) {
pstmt_tDBOutput_1.setNull(27, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(27, pRow_row1.is_active);
}

                    if(pRow_row1.is_deleted == null) {
pstmt_tDBOutput_1.setNull(28, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(28, pRow_row1.is_deleted);
}

                    if(pRow_row1.updated_by == null) {
pstmt_tDBOutput_1.setNull(29, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(29, pRow_row1.updated_by);
}

                    if(pRow_row1.updated_on != null) {
pstmt_tDBOutput_1.setTimestamp(30, new java.sql.Timestamp(pRow_row1.updated_on.getTime()));
} else {
pstmt_tDBOutput_1.setNull(30, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.status == null) {
pstmt_tDBOutput_1.setNull(31, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(31, pRow_row1.status);
}

                    if(pRow_row1.is_surprised == null) {
pstmt_tDBOutput_1.setNull(32, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(32, pRow_row1.is_surprised);
}

                    if(pRow_row1.audit_commencement_info_id == null) {
pstmt_tDBOutput_1.setNull(33, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_1.setString(33, pRow_row1.audit_commencement_info_id);
}

                    pstmt_tDBOutput_1.setBigDecimal(34, pRow_row1.closed_by);

                    if(pRow_row1.allow_forced_submit == null) {
pstmt_tDBOutput_1.setNull(35, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(35, pRow_row1.allow_forced_submit);
}

                    if(pRow_row1.is_sink == null) {
pstmt_tDBOutput_1.setNull(36, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(36, pRow_row1.is_sink);
}

                    if(pRow_row1.is_team_changed == null) {
pstmt_tDBOutput_1.setNull(37, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(37, pRow_row1.is_team_changed);
}

                    if(pRow_row1.is_editable == null) {
pstmt_tDBOutput_1.setNull(38, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(38, pRow_row1.is_editable);
}

                    if(pRow_row1.freezing_date != null) {
pstmt_tDBOutput_1.setTimestamp(39, new java.sql.Timestamp(pRow_row1.freezing_date.getTime()));
} else {
pstmt_tDBOutput_1.setNull(39, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.recalculation == null) {
pstmt_tDBOutput_1.setNull(40, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_1.setInt(40, pRow_row1.recalculation);
}

                    if(pRow_row1.as_on != null) {
pstmt_tDBOutput_1.setTimestamp(41, new java.sql.Timestamp(pRow_row1.as_on.getTime()));
} else {
pstmt_tDBOutput_1.setNull(41, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_1.addBatch();
    		nb_line_tDBOutput_1++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Adding the record ")  + (nb_line_tDBOutput_1)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_1++;
    		  
    			if ((batchSize_tDBOutput_1 > 0) && (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1)) {
                try {
						int countSum_tDBOutput_1 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            	    	batchSizeCounter_tDBOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
				    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
				    	String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						}else{
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}
				    	
				    	int countSum_tDBOutput_1 = 0;
						for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
						}
						rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
				    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
				    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
				    	System.err.println(errormessage_tDBOutput_1);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_commencement_info_dw\"";
		

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_commencement_info_dw\"";
		

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

 



/**
 * [tAsyncIn_tDBOutput_1 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_1.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_1", true);
end_Hash.put("tAsyncIn_tDBOutput_1", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_1 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_commencement_info_dw\"";
		



	    try {
				int countSum_tDBOutput_1 = 0;
				if (pstmt_tDBOutput_1 != null && batchSizeCounter_tDBOutput_1 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_1: pstmt_tDBOutput_1.executeBatch()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}
					rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_1){
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
	    	java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),sqle_tDBOutput_1=null;
	    	String errormessage_tDBOutput_1;
			if (ne_tDBOutput_1 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_1 = new java.sql.SQLException(e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(), ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
				errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
			}else{
				errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
			}
	    	
	    	int countSum_tDBOutput_1 = 0;
			for(int countEach_tDBOutput_1: e_tDBOutput_1.getUpdateCounts()) {
				countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
			}
			rowsToCommitCount_tDBOutput_1 += countSum_tDBOutput_1;
			
	    		insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
	    	
            log.error("tDBOutput_1 - "  + (errormessage_tDBOutput_1) );
	    	System.err.println(errormessage_tDBOutput_1);
	    	
		}
	    
        if(pstmt_tDBOutput_1 != null) {
        		
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);

	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
    	if (globalMap.get("tDBOutput_1_NB_LINE") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE",(Integer)globalMap.get("tDBOutput_1_NB_LINE") + nb_line_tDBOutput_1);
        }
        if (globalMap.get("tDBOutput_1_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_1_NB_LINE_UPDATED") + nb_line_update_tDBOutput_1);
        }
        if (globalMap.get("tDBOutput_1_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_1_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_1);
        }
        if (globalMap.get("tDBOutput_1_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_1_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_1);
        }
        if (globalMap.get("tDBOutput_1_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_1_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_1);
        } else {
        	globalMap.put("tDBOutput_1_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_1_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_1);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row1",2,0,
			 			"tAsyncIn_tDBOutput_1","tAsyncIn_tDBOutput_1","tAsyncIn","tDBOutput_1","\"audit_commencement_info_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_1 - "  + ("Done.") );

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_1";
	
	

 



/**
 * [tAsyncIn_tDBOutput_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";
	
	
			cLabel="\"audit_commencement_info_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_1");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_1_ParallelThread pt = new tAsyncIn_tDBOutput_1_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_1"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_1_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row2Struct implements routines.system.IPersistableRow<pRow_row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String region;

				public String getRegion () {
					return this.region;
				}

				public Boolean regionIsNullable(){
				    return true;
				}
				public Boolean regionIsKey(){
				    return false;
				}
				public Integer regionLength(){
				    return 145;
				}
				public Integer regionPrecision(){
				    return 0;
				}
				public String regionDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String regionComment(){
				
				    return "";
				
				}
				public String regionPattern(){
				
					return "";
				
				}
				public String regionOriginalDbColumnName(){
				
					return "region";
				
				}

				
			    public String division;

				public String getDivision () {
					return this.division;
				}

				public Boolean divisionIsNullable(){
				    return true;
				}
				public Boolean divisionIsKey(){
				    return false;
				}
				public Integer divisionLength(){
				    return 145;
				}
				public Integer divisionPrecision(){
				    return 0;
				}
				public String divisionDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String divisionComment(){
				
				    return "";
				
				}
				public String divisionPattern(){
				
					return "";
				
				}
				public String divisionOriginalDbColumnName(){
				
					return "division";
				
				}

				
			    public String branch_id;

				public String getBranch_id () {
					return this.branch_id;
				}

				public Boolean branch_idIsNullable(){
				    return true;
				}
				public Boolean branch_idIsKey(){
				    return false;
				}
				public Integer branch_idLength(){
				    return 100;
				}
				public Integer branch_idPrecision(){
				    return 0;
				}
				public String branch_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branch_idComment(){
				
				    return "";
				
				}
				public String branch_idPattern(){
				
					return "";
				
				}
				public String branch_idOriginalDbColumnName(){
				
					return "branch_id";
				
				}

				
			    public String branch;

				public String getBranch () {
					return this.branch;
				}

				public Boolean branchIsNullable(){
				    return true;
				}
				public Boolean branchIsKey(){
				    return false;
				}
				public Integer branchLength(){
				    return 145;
				}
				public Integer branchPrecision(){
				    return 0;
				}
				public String branchDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String branchComment(){
				
				    return "";
				
				}
				public String branchPattern(){
				
					return "";
				
				}
				public String branchOriginalDbColumnName(){
				
					return "branch";
				
				}

				
			    public Integer month;

				public Integer getMonth () {
					return this.month;
				}

				public Boolean monthIsNullable(){
				    return true;
				}
				public Boolean monthIsKey(){
				    return false;
				}
				public Integer monthLength(){
				    return 10;
				}
				public Integer monthPrecision(){
				    return 0;
				}
				public String monthDefault(){
				
					return null;
				
				}
				public String monthComment(){
				
				    return "";
				
				}
				public String monthPattern(){
				
					return "";
				
				}
				public String monthOriginalDbColumnName(){
				
					return "month";
				
				}

				
			    public Integer year;

				public Integer getYear () {
					return this.year;
				}

				public Boolean yearIsNullable(){
				    return true;
				}
				public Boolean yearIsKey(){
				    return false;
				}
				public Integer yearLength(){
				    return 10;
				}
				public Integer yearPrecision(){
				    return 0;
				}
				public String yearDefault(){
				
					return null;
				
				}
				public String yearComment(){
				
				    return "";
				
				}
				public String yearPattern(){
				
					return "";
				
				}
				public String yearOriginalDbColumnName(){
				
					return "year";
				
				}

				
			    public java.util.Date tentative_from_date;

				public java.util.Date getTentative_from_date () {
					return this.tentative_from_date;
				}

				public Boolean tentative_from_dateIsNullable(){
				    return true;
				}
				public Boolean tentative_from_dateIsKey(){
				    return false;
				}
				public Integer tentative_from_dateLength(){
				    return 13;
				}
				public Integer tentative_from_datePrecision(){
				    return 0;
				}
				public String tentative_from_dateDefault(){
				
					return null;
				
				}
				public String tentative_from_dateComment(){
				
				    return "";
				
				}
				public String tentative_from_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tentative_from_dateOriginalDbColumnName(){
				
					return "tentative_from_date";
				
				}

				
			    public java.util.Date tentative_to_date;

				public java.util.Date getTentative_to_date () {
					return this.tentative_to_date;
				}

				public Boolean tentative_to_dateIsNullable(){
				    return true;
				}
				public Boolean tentative_to_dateIsKey(){
				    return false;
				}
				public Integer tentative_to_dateLength(){
				    return 13;
				}
				public Integer tentative_to_datePrecision(){
				    return 0;
				}
				public String tentative_to_dateDefault(){
				
					return null;
				
				}
				public String tentative_to_dateComment(){
				
				    return "";
				
				}
				public String tentative_to_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String tentative_to_dateOriginalDbColumnName(){
				
					return "tentative_to_date";
				
				}

				
			    public Integer auditor_id;

				public Integer getAuditor_id () {
					return this.auditor_id;
				}

				public Boolean auditor_idIsNullable(){
				    return true;
				}
				public Boolean auditor_idIsKey(){
				    return false;
				}
				public Integer auditor_idLength(){
				    return 10;
				}
				public Integer auditor_idPrecision(){
				    return 0;
				}
				public String auditor_idDefault(){
				
					return null;
				
				}
				public String auditor_idComment(){
				
				    return "";
				
				}
				public String auditor_idPattern(){
				
					return "";
				
				}
				public String auditor_idOriginalDbColumnName(){
				
					return "auditor_id";
				
				}

				
			    public String auditor;

				public String getAuditor () {
					return this.auditor;
				}

				public Boolean auditorIsNullable(){
				    return true;
				}
				public Boolean auditorIsKey(){
				    return false;
				}
				public Integer auditorLength(){
				    return 145;
				}
				public Integer auditorPrecision(){
				    return 0;
				}
				public String auditorDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String auditorComment(){
				
				    return "";
				
				}
				public String auditorPattern(){
				
					return "";
				
				}
				public String auditorOriginalDbColumnName(){
				
					return "auditor";
				
				}

				
			    public String des;

				public String getDes () {
					return this.des;
				}

				public Boolean desIsNullable(){
				    return true;
				}
				public Boolean desIsKey(){
				    return false;
				}
				public Integer desLength(){
				    return 145;
				}
				public Integer desPrecision(){
				    return 0;
				}
				public String desDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String desComment(){
				
				    return "";
				
				}
				public String desPattern(){
				
					return "";
				
				}
				public String desOriginalDbColumnName(){
				
					return "des";
				
				}

				
			    public java.util.Date audit_commencement_date;

				public java.util.Date getAudit_commencement_date () {
					return this.audit_commencement_date;
				}

				public Boolean audit_commencement_dateIsNullable(){
				    return true;
				}
				public Boolean audit_commencement_dateIsKey(){
				    return false;
				}
				public Integer audit_commencement_dateLength(){
				    return 13;
				}
				public Integer audit_commencement_datePrecision(){
				    return 0;
				}
				public String audit_commencement_dateDefault(){
				
					return null;
				
				}
				public String audit_commencement_dateComment(){
				
				    return "";
				
				}
				public String audit_commencement_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String audit_commencement_dateOriginalDbColumnName(){
				
					return "audit_commencement_date";
				
				}

				
			    public java.util.Date closed_date;

				public java.util.Date getClosed_date () {
					return this.closed_date;
				}

				public Boolean closed_dateIsNullable(){
				    return true;
				}
				public Boolean closed_dateIsKey(){
				    return false;
				}
				public Integer closed_dateLength(){
				    return 29;
				}
				public Integer closed_datePrecision(){
				    return 6;
				}
				public String closed_dateDefault(){
				
					return null;
				
				}
				public String closed_dateComment(){
				
				    return "";
				
				}
				public String closed_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String closed_dateOriginalDbColumnName(){
				
					return "closed_date";
				
				}

				
			    public String comments_by_auditor;

				public String getComments_by_auditor () {
					return this.comments_by_auditor;
				}

				public Boolean comments_by_auditorIsNullable(){
				    return true;
				}
				public Boolean comments_by_auditorIsKey(){
				    return false;
				}
				public Integer comments_by_auditorLength(){
				    return 2147483647;
				}
				public Integer comments_by_auditorPrecision(){
				    return 0;
				}
				public String comments_by_auditorDefault(){
				
					return null;
				
				}
				public String comments_by_auditorComment(){
				
				    return "";
				
				}
				public String comments_by_auditorPattern(){
				
					return "";
				
				}
				public String comments_by_auditorOriginalDbColumnName(){
				
					return "comments_by_auditor";
				
				}

				
			    public Integer branch_audit_id;

				public Integer getBranch_audit_id () {
					return this.branch_audit_id;
				}

				public Boolean branch_audit_idIsNullable(){
				    return true;
				}
				public Boolean branch_audit_idIsKey(){
				    return false;
				}
				public Integer branch_audit_idLength(){
				    return 10;
				}
				public Integer branch_audit_idPrecision(){
				    return 0;
				}
				public String branch_audit_idDefault(){
				
					return null;
				
				}
				public String branch_audit_idComment(){
				
				    return "";
				
				}
				public String branch_audit_idPattern(){
				
					return "";
				
				}
				public String branch_audit_idOriginalDbColumnName(){
				
					return "branch_audit_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_date;

				public java.util.Date getCreated_date () {
					return this.created_date;
				}

				public Boolean created_dateIsNullable(){
				    return true;
				}
				public Boolean created_dateIsKey(){
				    return false;
				}
				public Integer created_dateLength(){
				    return 13;
				}
				public Integer created_datePrecision(){
				    return 0;
				}
				public String created_dateDefault(){
				
					return null;
				
				}
				public String created_dateComment(){
				
				    return "";
				
				}
				public String created_datePattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_dateOriginalDbColumnName(){
				
					return "created_date";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return null;
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row2Struct other = (pRow_row2Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row2Struct other) {

		other.id = this.id;
	            other.region = this.region;
	            other.division = this.division;
	            other.branch_id = this.branch_id;
	            other.branch = this.branch;
	            other.month = this.month;
	            other.year = this.year;
	            other.tentative_from_date = this.tentative_from_date;
	            other.tentative_to_date = this.tentative_to_date;
	            other.auditor_id = this.auditor_id;
	            other.auditor = this.auditor;
	            other.des = this.des;
	            other.audit_commencement_date = this.audit_commencement_date;
	            other.closed_date = this.closed_date;
	            other.comments_by_auditor = this.comments_by_auditor;
	            other.branch_audit_id = this.branch_audit_id;
	            other.created_by = this.created_by;
	            other.created_date = this.created_date;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row2Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_2_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
					this.division = readString(dis);
					
					this.branch_id = readString(dis);
					
					this.branch = readString(dis);
					
						this.month = readInteger(dis);
					
						this.year = readInteger(dis);
					
					this.tentative_from_date = readDate(dis);
					
					this.tentative_to_date = readDate(dis);
					
						this.auditor_id = readInteger(dis);
					
					this.auditor = readString(dis);
					
					this.des = readString(dis);
					
					this.audit_commencement_date = readDate(dis);
					
					this.closed_date = readDate(dis);
					
					this.comments_by_auditor = readString(dis);
					
						this.branch_audit_id = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_date = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_2_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
					this.division = readString(dis);
					
					this.branch_id = readString(dis);
					
					this.branch = readString(dis);
					
						this.month = readInteger(dis);
					
						this.year = readInteger(dis);
					
					this.tentative_from_date = readDate(dis);
					
					this.tentative_to_date = readDate(dis);
					
						this.auditor_id = readInteger(dis);
					
					this.auditor = readString(dis);
					
					this.des = readString(dis);
					
					this.audit_commencement_date = readDate(dis);
					
					this.closed_date = readDate(dis);
					
					this.comments_by_auditor = readString(dis);
					
						this.branch_audit_id = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_date = readDate(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// Integer
				
						writeInteger(this.month,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_to_date,dos);
					
					// Integer
				
						writeInteger(this.auditor_id,dos);
					
					// String
				
						writeString(this.auditor,dos);
					
					// String
				
						writeString(this.des,dos);
					
					// java.util.Date
				
						writeDate(this.audit_commencement_date,dos);
					
					// java.util.Date
				
						writeDate(this.closed_date,dos);
					
					// String
				
						writeString(this.comments_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.branch_audit_id,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_date,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// String
				
						writeString(this.division,dos);
					
					// String
				
						writeString(this.branch_id,dos);
					
					// String
				
						writeString(this.branch,dos);
					
					// Integer
				
						writeInteger(this.month,dos);
					
					// Integer
				
						writeInteger(this.year,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_from_date,dos);
					
					// java.util.Date
				
						writeDate(this.tentative_to_date,dos);
					
					// Integer
				
						writeInteger(this.auditor_id,dos);
					
					// String
				
						writeString(this.auditor,dos);
					
					// String
				
						writeString(this.des,dos);
					
					// java.util.Date
				
						writeDate(this.audit_commencement_date,dos);
					
					// java.util.Date
				
						writeDate(this.closed_date,dos);
					
					// String
				
						writeString(this.comments_by_auditor,dos);
					
					// Integer
				
						writeInteger(this.branch_audit_id,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_date,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",region="+region);
		sb.append(",division="+division);
		sb.append(",branch_id="+branch_id);
		sb.append(",branch="+branch);
		sb.append(",month="+String.valueOf(month));
		sb.append(",year="+String.valueOf(year));
		sb.append(",tentative_from_date="+String.valueOf(tentative_from_date));
		sb.append(",tentative_to_date="+String.valueOf(tentative_to_date));
		sb.append(",auditor_id="+String.valueOf(auditor_id));
		sb.append(",auditor="+auditor);
		sb.append(",des="+des);
		sb.append(",audit_commencement_date="+String.valueOf(audit_commencement_date));
		sb.append(",closed_date="+String.valueOf(closed_date));
		sb.append(",comments_by_auditor="+comments_by_auditor);
		sb.append(",branch_audit_id="+String.valueOf(branch_audit_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_date="+String.valueOf(created_date));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(region == null){
        					sb.append("<null>");
        				}else{
            				sb.append(region);
            			}
            		
        			sb.append("|");
        		
        				if(division == null){
        					sb.append("<null>");
        				}else{
            				sb.append(division);
            			}
            		
        			sb.append("|");
        		
        				if(branch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_id);
            			}
            		
        			sb.append("|");
        		
        				if(branch == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch);
            			}
            		
        			sb.append("|");
        		
        				if(month == null){
        					sb.append("<null>");
        				}else{
            				sb.append(month);
            			}
            		
        			sb.append("|");
        		
        				if(year == null){
        					sb.append("<null>");
        				}else{
            				sb.append(year);
            			}
            		
        			sb.append("|");
        		
        				if(tentative_from_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tentative_from_date);
            			}
            		
        			sb.append("|");
        		
        				if(tentative_to_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tentative_to_date);
            			}
            		
        			sb.append("|");
        		
        				if(auditor_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor_id);
            			}
            		
        			sb.append("|");
        		
        				if(auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(auditor);
            			}
            		
        			sb.append("|");
        		
        				if(des == null){
        					sb.append("<null>");
        				}else{
            				sb.append(des);
            			}
            		
        			sb.append("|");
        		
        				if(audit_commencement_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_commencement_date);
            			}
            		
        			sb.append("|");
        		
        				if(closed_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(closed_date);
            			}
            		
        			sb.append("|");
        		
        				if(comments_by_auditor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(comments_by_auditor);
            			}
            		
        			sb.append("|");
        		
        				if(branch_audit_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(branch_audit_id);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_date);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_2");
		org.slf4j.MDC.put("_subJobPid", "cBLMbz_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_2");
		class tAsyncIn_tDBOutput_2_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_2_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row2Struct pRow_row2 = new pRow_row2Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"tbl_audit_commencement_info_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row2");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("PARALLELIZE_NUMBER" + " = " + "9");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"tbl_audit_commencement_info_dw\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "\"tbl_audit_commencement_info_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("tbl_audit_commencement_info_dw");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("tbl_audit_commencement_info_dw");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
        java.lang.StringBuilder sb_tDBOutput_2 = new java.lang.StringBuilder();
        sb_tDBOutput_2.append("INSERT INTO \"").append(tableName_tDBOutput_2).append("\" (\"id\",\"region\",\"division\",\"branch_id\",\"branch\",\"month\",\"year\",\"tentative_from_date\",\"tentative_to_date\",\"auditor_id\",\"auditor\",\"des\",\"audit_commencement_date\",\"closed_date\",\"comments_by_auditor\",\"branch_audit_id\",\"created_by\",\"created_date\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_2.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"region\" = EXCLUDED.\"region\",\"division\" = EXCLUDED.\"division\",\"branch_id\" = EXCLUDED.\"branch_id\",\"branch\" = EXCLUDED.\"branch\",\"month\" = EXCLUDED.\"month\",\"year\" = EXCLUDED.\"year\",\"tentative_from_date\" = EXCLUDED.\"tentative_from_date\",\"tentative_to_date\" = EXCLUDED.\"tentative_to_date\",\"auditor_id\" = EXCLUDED.\"auditor_id\",\"auditor\" = EXCLUDED.\"auditor\",\"des\" = EXCLUDED.\"des\",\"audit_commencement_date\" = EXCLUDED.\"audit_commencement_date\",\"closed_date\" = EXCLUDED.\"closed_date\",\"comments_by_auditor\" = EXCLUDED.\"comments_by_auditor\",\"branch_audit_id\" = EXCLUDED.\"branch_audit_id\",\"created_by\" = EXCLUDED.\"created_by\",\"created_date\" = EXCLUDED.\"created_date\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_2 = sb_tDBOutput_2.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing '")  + (insert_tDBOutput_2)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_2", false);
		start_Hash.put("tAsyncIn_tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	
		int tos_count_tAsyncIn_tDBOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_2", "tAsyncIn_tDBOutput_2", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_2= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_2 = buffers_tAsyncIn_tDBOutput_2.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_2 != null && buffers_tAsyncIn_tDBOutput_2.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_2 : buffers_tAsyncIn_tDBOutput_2) {
    		pRow_row2 = null;						
			pRow_row2 = new pRow_row2Struct();
		
		
			String temp_tAsyncIn_tDBOutput_2_0 = row_tAsyncIn_tDBOutput_2[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[0]);
			if(temp_tAsyncIn_tDBOutput_2_0 != null) {
		
			pRow_row2.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_0);
		} else {						
			pRow_row2.id = 0;
		}
		pRow_row2.region = row_tAsyncIn_tDBOutput_2[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[1]);
		pRow_row2.division = row_tAsyncIn_tDBOutput_2[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[2]);
		pRow_row2.branch_id = row_tAsyncIn_tDBOutput_2[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[3]);
		pRow_row2.branch = row_tAsyncIn_tDBOutput_2[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[4]);
		
		
			String temp_tAsyncIn_tDBOutput_2_5 = row_tAsyncIn_tDBOutput_2[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[5]);
			if(temp_tAsyncIn_tDBOutput_2_5 != null) {
		
			pRow_row2.month = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_5);
		} else {						
			pRow_row2.month = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_6 = row_tAsyncIn_tDBOutput_2[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[6]);
			if(temp_tAsyncIn_tDBOutput_2_6 != null) {
		
			pRow_row2.year = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_6);
		} else {						
			pRow_row2.year = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_7 = row_tAsyncIn_tDBOutput_2[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[7]);
			if(temp_tAsyncIn_tDBOutput_2_7 != null) {
		
			pRow_row2.tentative_from_date = (java.util.Date)(row_tAsyncIn_tDBOutput_2[7]);
		} else {						
			pRow_row2.tentative_from_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_8 = row_tAsyncIn_tDBOutput_2[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[8]);
			if(temp_tAsyncIn_tDBOutput_2_8 != null) {
		
			pRow_row2.tentative_to_date = (java.util.Date)(row_tAsyncIn_tDBOutput_2[8]);
		} else {						
			pRow_row2.tentative_to_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_9 = row_tAsyncIn_tDBOutput_2[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[9]);
			if(temp_tAsyncIn_tDBOutput_2_9 != null) {
		
			pRow_row2.auditor_id = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_9);
		} else {						
			pRow_row2.auditor_id = null;
		}
		pRow_row2.auditor = row_tAsyncIn_tDBOutput_2[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[10]);
		pRow_row2.des = row_tAsyncIn_tDBOutput_2[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[11]);
		
		
			String temp_tAsyncIn_tDBOutput_2_12 = row_tAsyncIn_tDBOutput_2[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[12]);
			if(temp_tAsyncIn_tDBOutput_2_12 != null) {
		
			pRow_row2.audit_commencement_date = (java.util.Date)(row_tAsyncIn_tDBOutput_2[12]);
		} else {						
			pRow_row2.audit_commencement_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_13 = row_tAsyncIn_tDBOutput_2[13]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[13]);
			if(temp_tAsyncIn_tDBOutput_2_13 != null) {
		
			pRow_row2.closed_date = (java.util.Date)(row_tAsyncIn_tDBOutput_2[13]);
		} else {						
			pRow_row2.closed_date = null;
		}
		pRow_row2.comments_by_auditor = row_tAsyncIn_tDBOutput_2[14]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[14]);
		
		
			String temp_tAsyncIn_tDBOutput_2_15 = row_tAsyncIn_tDBOutput_2[15]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[15]);
			if(temp_tAsyncIn_tDBOutput_2_15 != null) {
		
			pRow_row2.branch_audit_id = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_15);
		} else {						
			pRow_row2.branch_audit_id = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_16 = row_tAsyncIn_tDBOutput_2[16]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[16]);
			if(temp_tAsyncIn_tDBOutput_2_16 != null) {
		
			pRow_row2.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_16);
		} else {						
			pRow_row2.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_17 = row_tAsyncIn_tDBOutput_2[17]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[17]);
			if(temp_tAsyncIn_tDBOutput_2_17 != null) {
		
			pRow_row2.created_date = (java.util.Date)(row_tAsyncIn_tDBOutput_2[17]);
		} else {						
			pRow_row2.created_date = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_18 = row_tAsyncIn_tDBOutput_2[18]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[18]);
			if(temp_tAsyncIn_tDBOutput_2_18 != null) {
		
			pRow_row2.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_2[18]);
		} else {						
			pRow_row2.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_2 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 


	tos_count_tAsyncIn_tDBOutput_2++;

/**
 * [tAsyncIn_tDBOutput_2 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 



/**
 * [tAsyncIn_tDBOutput_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"tbl_audit_commencement_info_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row2","tAsyncIn_tDBOutput_2","tAsyncIn_tDBOutput_2","tAsyncIn","tDBOutput_2","\"tbl_audit_commencement_info_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row2 - " + (pRow_row2==null? "": pRow_row2.toLogString()));
    			}
    		



				batchSize_tDBOutput_2 = buffersSize_tAsyncIn_tDBOutput_2;
        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, pRow_row2.id);

                    if(pRow_row2.region == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, pRow_row2.region);
}

                    if(pRow_row2.division == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(3, pRow_row2.division);
}

                    if(pRow_row2.branch_id == null) {
pstmt_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(4, pRow_row2.branch_id);
}

                    if(pRow_row2.branch == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(5, pRow_row2.branch);
}

                    if(pRow_row2.month == null) {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(6, pRow_row2.month);
}

                    if(pRow_row2.year == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(7, pRow_row2.year);
}

                    if(pRow_row2.tentative_from_date != null) {
pstmt_tDBOutput_2.setTimestamp(8, new java.sql.Timestamp(pRow_row2.tentative_from_date.getTime()));
} else {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row2.tentative_to_date != null) {
pstmt_tDBOutput_2.setTimestamp(9, new java.sql.Timestamp(pRow_row2.tentative_to_date.getTime()));
} else {
pstmt_tDBOutput_2.setNull(9, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row2.auditor_id == null) {
pstmt_tDBOutput_2.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(10, pRow_row2.auditor_id);
}

                    if(pRow_row2.auditor == null) {
pstmt_tDBOutput_2.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(11, pRow_row2.auditor);
}

                    if(pRow_row2.des == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(12, pRow_row2.des);
}

                    if(pRow_row2.audit_commencement_date != null) {
pstmt_tDBOutput_2.setTimestamp(13, new java.sql.Timestamp(pRow_row2.audit_commencement_date.getTime()));
} else {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row2.closed_date != null) {
pstmt_tDBOutput_2.setTimestamp(14, new java.sql.Timestamp(pRow_row2.closed_date.getTime()));
} else {
pstmt_tDBOutput_2.setNull(14, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row2.comments_by_auditor == null) {
pstmt_tDBOutput_2.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(15, pRow_row2.comments_by_auditor);
}

                    if(pRow_row2.branch_audit_id == null) {
pstmt_tDBOutput_2.setNull(16, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(16, pRow_row2.branch_audit_id);
}

                    if(pRow_row2.created_by == null) {
pstmt_tDBOutput_2.setNull(17, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(17, pRow_row2.created_by);
}

                    if(pRow_row2.created_date != null) {
pstmt_tDBOutput_2.setTimestamp(18, new java.sql.Timestamp(pRow_row2.created_date.getTime()));
} else {
pstmt_tDBOutput_2.setNull(18, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row2.as_on != null) {
pstmt_tDBOutput_2.setTimestamp(19, new java.sql.Timestamp(pRow_row2.as_on.getTime()));
} else {
pstmt_tDBOutput_2.setNull(19, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"tbl_audit_commencement_info_dw\"";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"tbl_audit_commencement_info_dw\"";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 



/**
 * [tAsyncIn_tDBOutput_2 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_2.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_2", true);
end_Hash.put("tAsyncIn_tDBOutput_2", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"tbl_audit_commencement_info_dw\"";
		



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
    	if (globalMap.get("tDBOutput_2_NB_LINE") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE",(Integer)globalMap.get("tDBOutput_2_NB_LINE") + nb_line_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_UPDATED") + nb_line_update_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_2);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row2",2,0,
			 			"tAsyncIn_tDBOutput_2","tAsyncIn_tDBOutput_2","tAsyncIn","tDBOutput_2","\"tbl_audit_commencement_info_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 



/**
 * [tAsyncIn_tDBOutput_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"tbl_audit_commencement_info_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_2");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_2_ParallelThread pt = new tAsyncIn_tDBOutput_2_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_2"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_2_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "qwPFya_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final Audit_incremental_2_tables Audit_incremental_2_tablesClass = new Audit_incremental_2_tables();

        int exitCode = Audit_incremental_2_tablesClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'Audit_incremental_2_tables' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230612_1054-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'Audit_incremental_2_tables' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_bj4kQNnzEe2z1bmRttdHBw");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-08-02T11:49:56.778250300Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = Audit_incremental_2_tables.class.getClassLoader().getResourceAsStream("talend_tac2_repo/audit_incremental_2_tables_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = Audit_incremental_2_tables.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'Audit_incremental_2_tables' - Started.");
            mdcInfo.putAll(org.slf4j.MDC.getCopyOfContextMap());

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}
try {
errorCode = null;tDBInput_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_2) {
globalMap.put("tDBInput_2_SUBPROCESS_STATE", -1);

e_tDBInput_2.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : Audit_incremental_2_tables");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'Audit_incremental_2_tables' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     406264 characters generated by Talend Data Integration 
 *     on the August 2, 2023 at 5:19:56 PM IST
 ************************************************************************************************/