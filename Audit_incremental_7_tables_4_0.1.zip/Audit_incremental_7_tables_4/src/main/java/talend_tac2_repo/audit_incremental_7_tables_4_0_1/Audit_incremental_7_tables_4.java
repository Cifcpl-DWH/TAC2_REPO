
package talend_tac2_repo.audit_incremental_7_tables_4_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: Audit_incremental_7_tables_4 Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230612_1054-patch
 * @status 
 */
public class Audit_incremental_7_tables_4 implements TalendJob {
	static {System.setProperty("TalendJob.log", "Audit_incremental_7_tables_4.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(Audit_incremental_7_tables_4.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "Audit_incremental_7_tables_4";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_InvzwNnaEe2k6LMINsbvIw", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				Audit_incremental_7_tables_4.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(Audit_incremental_7_tables_4.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tDBInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_2_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_3_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_4_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_5_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_6_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_7_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_8_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_9_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAsyncIn_tDBOutput_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
					tAsyncOut_tDBOutput_10_error(exception, errorComponent, globalMap);
					}
				
			public void tAsyncOut_tDBOutput_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAsyncIn_tDBOutput_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	



public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String option_name;

				public String getOption_name () {
					return this.option_name;
				}

				public Boolean option_nameIsNullable(){
				    return false;
				}
				public Boolean option_nameIsKey(){
				    return false;
				}
				public Integer option_nameLength(){
				    return 50;
				}
				public Integer option_namePrecision(){
				    return 0;
				}
				public String option_nameDefault(){
				
					return null;
				
				}
				public String option_nameComment(){
				
				    return "";
				
				}
				public String option_namePattern(){
				
					return "";
				
				}
				public String option_nameOriginalDbColumnName(){
				
					return "option_name";
				
				}

				
			    public Float option_marks;

				public Float getOption_marks () {
					return this.option_marks;
				}

				public Boolean option_marksIsNullable(){
				    return true;
				}
				public Boolean option_marksIsKey(){
				    return false;
				}
				public Integer option_marksLength(){
				    return 8;
				}
				public Integer option_marksPrecision(){
				    return 8;
				}
				public String option_marksDefault(){
				
					return "'0'::real";
				
				}
				public String option_marksComment(){
				
				    return "";
				
				}
				public String option_marksPattern(){
				
					return "";
				
				}
				public String option_marksOriginalDbColumnName(){
				
					return "option_marks";
				
				}

				
			    public int question_id;

				public int getQuestion_id () {
					return this.question_id;
				}

				public Boolean question_idIsNullable(){
				    return false;
				}
				public Boolean question_idIsKey(){
				    return false;
				}
				public Integer question_idLength(){
				    return 10;
				}
				public Integer question_idPrecision(){
				    return 0;
				}
				public String question_idDefault(){
				
					return null;
				
				}
				public String question_idComment(){
				
				    return "";
				
				}
				public String question_idPattern(){
				
					return "";
				
				}
				public String question_idOriginalDbColumnName(){
				
					return "question_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String option_id;

				public String getOption_id () {
					return this.option_id;
				}

				public Boolean option_idIsNullable(){
				    return true;
				}
				public Boolean option_idIsKey(){
				    return false;
				}
				public Integer option_idLength(){
				    return 32;
				}
				public Integer option_idPrecision(){
				    return 0;
				}
				public String option_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String option_idComment(){
				
				    return "";
				
				}
				public String option_idPattern(){
				
					return "";
				
				}
				public String option_idOriginalDbColumnName(){
				
					return "option_id";
				
				}

				
			    public Integer observation;

				public Integer getObservation () {
					return this.observation;
				}

				public Boolean observationIsNullable(){
				    return true;
				}
				public Boolean observationIsKey(){
				    return false;
				}
				public Integer observationLength(){
				    return 10;
				}
				public Integer observationPrecision(){
				    return 0;
				}
				public String observationDefault(){
				
					return "0";
				
				}
				public String observationComment(){
				
				    return "";
				
				}
				public String observationPattern(){
				
					return "";
				
				}
				public String observationOriginalDbColumnName(){
				
					return "observation";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row2Struct other = (row2Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row2Struct other) {

		other.id = this.id;
	            other.option_name = this.option_name;
	            other.option_marks = this.option_marks;
	            other.question_id = this.question_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.option_id = this.option_id;
	            other.observation = this.observation;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row2Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.option_marks = null;
           				} else {
           			    	this.option_marks = dis.readFloat();
           				}
					
			        this.question_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_id = readString(dis);
					
						this.observation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.option_marks = null;
           				} else {
           			    	this.option_marks = dis.readFloat();
           				}
					
			        this.question_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_id = readString(dis);
					
						this.observation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.option_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.option_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.question_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_id,dos);
					
					// Integer
				
						writeInteger(this.observation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.option_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.option_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.question_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_id,dos);
					
					// Integer
				
						writeInteger(this.observation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",option_name="+option_name);
		sb.append(",option_marks="+String.valueOf(option_marks));
		sb.append(",question_id="+String.valueOf(question_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",option_id="+option_id);
		sb.append(",observation="+String.valueOf(observation));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(option_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_name);
            			}
            		
        			sb.append("|");
        		
        				if(option_marks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_marks);
            			}
            		
        			sb.append("|");
        		
        				sb.append(question_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(option_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_id);
            			}
            		
        			sb.append("|");
        		
        				if(observation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", "OxD9QT_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_2", false);
		start_Hash.put("tAsyncOut_tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row2");
			
		int tos_count_tAsyncOut_tDBOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_2", "tAsyncOut_tDBOutput_2", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_2 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_2 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_2 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_2=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_2 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_2", pool_tAsyncOut_tDBOutput_2);
	final Object[] lockWrite_tAsyncOut_tDBOutput_2 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_2", lockWrite_tAsyncOut_tDBOutput_2);
 



/**
 * [tAsyncOut_tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tDBInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_2", false);
		start_Hash.put("tDBInput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"mst_option\"";
		
		int tos_count_tDBInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
                    log4jParamters_tDBInput_2.append("Parameters:");
                            log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TABLE" + " = " + "\"mst_option\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("QUERY" + " = " + "\"SELECT    `mst_option`.`id`,    `mst_option`.`option_name`,    `mst_option`.`option_marks`,    `mst_option`.`question_id`,    `mst_option`.`created_by`,    `mst_option`.`created_on`,    `mst_option`.`updated_by`,    `mst_option`.`updated_on`,    `mst_option`.`is_active`,    `mst_option`.`is_deleted`,    `mst_option`.`option_id`,    `mst_option`.`observation`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_option`\"");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_marks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("question_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("observation")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_2.append(" | ");
                            log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + (log4jParamters_tDBInput_2) );
                    } 
                } 
            new BytesLimit65535_tDBInput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_2", "\"mst_option\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_2 = java.util.Calendar.getInstance();
		    calendar_tDBInput_2.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_2 = calendar_tDBInput_2.getTime();
		    int nb_line_tDBInput_2 = 0;
		    java.sql.Connection conn_tDBInput_2 = null;
				conn_tDBInput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_2 != null) {
					if(conn_tDBInput_2.getMetaData() != null) {
						
							log.debug("tDBInput_2 - Uses an existing connection with username '" + conn_tDBInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();
				if(stmt_tDBInput_2 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_2).enableStreamingResults();
				}else if(stmt_tDBInput_2 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_2).enableStreamingResults();
				}

		    String dbquery_tDBInput_2 = "SELECT \n  `mst_option`.`id`, \n  `mst_option`.`option_name`, \n  `mst_option`.`option_marks`, \n  `mst_option`.`question_i"
+"d`, \n  `mst_option`.`created_by`, \n  `mst_option`.`created_on`, \n  `mst_option`.`updated_by`, \n  `mst_option`.`updated_o"
+"n`, \n  `mst_option`.`is_active`, \n  `mst_option`.`is_deleted`, \n  `mst_option`.`option_id`, \n  `mst_option`.`observation"
+"`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_option`";
		    
	    		log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");
			

            	globalMap.put("tDBInput_2_QUERY",dbquery_tDBInput_2);
		    java.sql.ResultSet rs_tDBInput_2 = null;

		    try {
		    	rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
		    	int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

		    String tmpContent_tDBInput_2 = null;
		    
		    
		    	log.debug("tDBInput_2 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_2.next()) {
		        nb_line_tDBInput_2++;
		        
							if(colQtyInRs_tDBInput_2 < 1) {
								row2.id = 0;
							} else {
		                          
            row2.id = rs_tDBInput_2.getInt(1);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 2) {
								row2.option_name = null;
							} else {
	                         		
        	row2.option_name = routines.system.JDBCUtil.getString(rs_tDBInput_2, 2, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 3) {
								row2.option_marks = null;
							} else {
		                          
            row2.option_marks = rs_tDBInput_2.getFloat(3);
            if(rs_tDBInput_2.wasNull()){
                    row2.option_marks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 4) {
								row2.question_id = 0;
							} else {
		                          
            row2.question_id = rs_tDBInput_2.getInt(4);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 5) {
								row2.created_by = null;
							} else {
		                          
            row2.created_by = rs_tDBInput_2.getInt(5);
            if(rs_tDBInput_2.wasNull()){
                    row2.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 6) {
								row2.created_on = null;
							} else {
										
				if(rs_tDBInput_2.getString(6) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(6);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.created_on = rs_tDBInput_2.getTimestamp(6);
					} else {
						row2.created_on = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 7) {
								row2.updated_by = null;
							} else {
		                          
            row2.updated_by = rs_tDBInput_2.getInt(7);
            if(rs_tDBInput_2.wasNull()){
                    row2.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 8) {
								row2.updated_on = null;
							} else {
										
				if(rs_tDBInput_2.getString(8) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(8);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.updated_on = rs_tDBInput_2.getTimestamp(8);
					} else {
						row2.updated_on = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_2 < 9) {
								row2.is_active = 0;
							} else {
		                          
            row2.is_active = rs_tDBInput_2.getInt(9);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 10) {
								row2.is_deleted = 0;
							} else {
		                          
            row2.is_deleted = rs_tDBInput_2.getInt(10);
            if(rs_tDBInput_2.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 11) {
								row2.option_id = null;
							} else {
	                         		
        	row2.option_id = routines.system.JDBCUtil.getString(rs_tDBInput_2, 11, false);
		                    }
							if(colQtyInRs_tDBInput_2 < 12) {
								row2.observation = null;
							} else {
		                          
            row2.observation = rs_tDBInput_2.getInt(12);
            if(rs_tDBInput_2.wasNull()){
                    row2.observation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_2 < 13) {
								row2.as_on = null;
							} else {
										
				if(rs_tDBInput_2.getString(13) != null) {
					String dateString_tDBInput_2 = rs_tDBInput_2.getString(13);
					if (!("0000-00-00").equals(dateString_tDBInput_2) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
						row2.as_on = rs_tDBInput_2.getTimestamp(13);
					} else {
						row2.as_on = (java.util.Date) year0_tDBInput_2.clone();
					}
				} else {
					row2.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");
					

 



/**
 * [tDBInput_2 begin ] stop
 */
	
	/**
	 * [tDBInput_2 main ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"mst_option\"";
		

 


	tos_count_tDBInput_2++;

/**
 * [tDBInput_2 main ] stop
 */
	
	/**
	 * [tDBInput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"mst_option\"";
		

 



/**
 * [tDBInput_2 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row2","tDBInput_2","\"mst_option\"","tMysqlInput","tAsyncOut_tDBOutput_2","tAsyncOut_tDBOutput_2","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_2=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_2[0] = String.valueOf(row2.id); 
	if(row2.option_name != null){
		row_tAsyncOut_tDBOutput_2[1] = row2.option_name;                			    
	}
	if(row2.option_marks != null){
		row_tAsyncOut_tDBOutput_2[2] = String.valueOf(row2.option_marks);                			    
	}
	row_tAsyncOut_tDBOutput_2[3] = String.valueOf(row2.question_id); 
	if(row2.created_by != null){
		row_tAsyncOut_tDBOutput_2[4] = String.valueOf(row2.created_by);                			    
	}
	if(row2.created_on != null){
		row_tAsyncOut_tDBOutput_2[5] = row2.created_on;                			    
	}
	if(row2.updated_by != null){
		row_tAsyncOut_tDBOutput_2[6] = String.valueOf(row2.updated_by);                			    
	}
	if(row2.updated_on != null){
		row_tAsyncOut_tDBOutput_2[7] = row2.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_2[8] = String.valueOf(row2.is_active); 
	row_tAsyncOut_tDBOutput_2[9] = String.valueOf(row2.is_deleted); 
	if(row2.option_id != null){
		row_tAsyncOut_tDBOutput_2[10] = row2.option_id;                			    
	}
	if(row2.observation != null){
		row_tAsyncOut_tDBOutput_2[11] = String.valueOf(row2.observation);                			    
	}
	if(row2.as_on != null){
		row_tAsyncOut_tDBOutput_2[12] = row2.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_2 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_2", buffers_tAsyncOut_tDBOutput_2);
		/*tAsyncIn_tDBOutput_10Process(globalMap);*/
		tAsyncIn_tDBOutput_2Process(globalMap);
		buffers_tAsyncOut_tDBOutput_2 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_2 = 0;
	}
	buffers_tAsyncOut_tDBOutput_2.add(row_tAsyncOut_tDBOutput_2);
	index_tAsyncOut_tDBOutput_2++;
 


	tos_count_tAsyncOut_tDBOutput_2++;

/**
 * [tAsyncOut_tDBOutput_2 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	

 



/**
 * [tAsyncOut_tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	

 



/**
 * [tAsyncOut_tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"mst_option\"";
		

 



/**
 * [tDBInput_2 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_2 end ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"mst_option\"";
		

	}
}finally{
	if (rs_tDBInput_2 != null) {
		rs_tDBInput_2.close();
	}
	if (stmt_tDBInput_2 != null) {
		stmt_tDBInput_2.close();
	}
}

		   globalMap.put("tDBInput_2_NB_LINE",nb_line_tDBInput_2);
		

	    		log.debug("tDBInput_2 - Retrieved records count: "+nb_line_tDBInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_2 - "  + ("Done.") );

ok_Hash.put("tDBInput_2", true);
end_Hash.put("tDBInput_2", System.currentTimeMillis());




/**
 * [tDBInput_2 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	


	if (buffers_tAsyncOut_tDBOutput_2.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_2", buffers_tAsyncOut_tDBOutput_2);
	    tAsyncIn_tDBOutput_2Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_2.waitForEnd();
	pool_tAsyncOut_tDBOutput_2.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row2",2,0,
			 			"tDBInput_2","\"mst_option\"","tMysqlInput","tAsyncOut_tDBOutput_2","tAsyncOut_tDBOutput_2","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_2", true);
end_Hash.put("tAsyncOut_tDBOutput_2", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_2";
	
	
			cLabel="\"mst_option\"";
		

 



/**
 * [tDBInput_2 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_2";
	
	

 



/**
 * [tAsyncOut_tDBOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String option_group_name;

				public String getOption_group_name () {
					return this.option_group_name;
				}

				public Boolean option_group_nameIsNullable(){
				    return false;
				}
				public Boolean option_group_nameIsKey(){
				    return false;
				}
				public Integer option_group_nameLength(){
				    return 50;
				}
				public Integer option_group_namePrecision(){
				    return 0;
				}
				public String option_group_nameDefault(){
				
					return null;
				
				}
				public String option_group_nameComment(){
				
				    return "";
				
				}
				public String option_group_namePattern(){
				
					return "";
				
				}
				public String option_group_nameOriginalDbColumnName(){
				
					return "option_group_name";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String option_group_id;

				public String getOption_group_id () {
					return this.option_group_id;
				}

				public Boolean option_group_idIsNullable(){
				    return true;
				}
				public Boolean option_group_idIsKey(){
				    return false;
				}
				public Integer option_group_idLength(){
				    return 32;
				}
				public Integer option_group_idPrecision(){
				    return 0;
				}
				public String option_group_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String option_group_idComment(){
				
				    return "";
				
				}
				public String option_group_idPattern(){
				
					return "";
				
				}
				public String option_group_idOriginalDbColumnName(){
				
					return "option_group_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.id = this.id;
	            other.option_group_name = this.option_group_name;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.option_group_id = this.option_group_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_group_name = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_group_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_group_name = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_group_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_group_name,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_group_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_group_name,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_group_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",option_group_name="+option_group_name);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",option_group_id="+option_group_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(option_group_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_group_name);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(option_group_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_group_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", "LczByk_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_3", false);
		start_Hash.put("tAsyncOut_tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tAsyncOut_tDBOutput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_3", "tAsyncOut_tDBOutput_3", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_3 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_3 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_3 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_3=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_3 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_3", pool_tAsyncOut_tDBOutput_3);
	final Object[] lockWrite_tAsyncOut_tDBOutput_3 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_3", lockWrite_tAsyncOut_tDBOutput_3);
 



/**
 * [tAsyncOut_tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tDBInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_3", false);
		start_Hash.put("tDBInput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_option_group\"";
		
		int tos_count_tDBInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
                    log4jParamters_tDBInput_3.append("Parameters:");
                            log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"mst_option_group\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("QUERY" + " = " + "\"SELECT    `mst_option_group`.`id`,    `mst_option_group`.`option_group_name`,    `mst_option_group`.`created_by`,    `mst_option_group`.`created_on`,    `mst_option_group`.`updated_by`,    `mst_option_group`.`updated_on`,    `mst_option_group`.`is_active`,    `mst_option_group`.`is_deleted`,    `mst_option_group`.`option_group_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_option_group`\"");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_group_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_group_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_3.append(" | ");
                            log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + (log4jParamters_tDBInput_3) );
                    } 
                } 
            new BytesLimit65535_tDBInput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_3", "\"mst_option_group\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_3 = java.util.Calendar.getInstance();
		    calendar_tDBInput_3.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_3 = calendar_tDBInput_3.getTime();
		    int nb_line_tDBInput_3 = 0;
		    java.sql.Connection conn_tDBInput_3 = null;
				conn_tDBInput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_3 != null) {
					if(conn_tDBInput_3.getMetaData() != null) {
						
							log.debug("tDBInput_3 - Uses an existing connection with username '" + conn_tDBInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();
				if(stmt_tDBInput_3 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_3).enableStreamingResults();
				}else if(stmt_tDBInput_3 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_3).enableStreamingResults();
				}

		    String dbquery_tDBInput_3 = "SELECT \n  `mst_option_group`.`id`, \n  `mst_option_group`.`option_group_name`, \n  `mst_option_group`.`created_by`, \n  `m"
+"st_option_group`.`created_on`, \n  `mst_option_group`.`updated_by`, \n  `mst_option_group`.`updated_on`, \n  `mst_option_gr"
+"oup`.`is_active`, \n  `mst_option_group`.`is_deleted`, \n  `mst_option_group`.`option_group_id`,\n	DATE_SUB(CURRENT_TIMEST"
+"AMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_option_group`";
		    
	    		log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");
			

            	globalMap.put("tDBInput_3_QUERY",dbquery_tDBInput_3);
		    java.sql.ResultSet rs_tDBInput_3 = null;

		    try {
		    	rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
		    	int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

		    String tmpContent_tDBInput_3 = null;
		    
		    
		    	log.debug("tDBInput_3 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_3.next()) {
		        nb_line_tDBInput_3++;
		        
							if(colQtyInRs_tDBInput_3 < 1) {
								row3.id = 0;
							} else {
		                          
            row3.id = rs_tDBInput_3.getInt(1);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 2) {
								row3.option_group_name = null;
							} else {
	                         		
        	row3.option_group_name = routines.system.JDBCUtil.getString(rs_tDBInput_3, 2, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 3) {
								row3.created_by = null;
							} else {
		                          
            row3.created_by = rs_tDBInput_3.getInt(3);
            if(rs_tDBInput_3.wasNull()){
                    row3.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 4) {
								row3.created_on = null;
							} else {
										
				if(rs_tDBInput_3.getString(4) != null) {
					String dateString_tDBInput_3 = rs_tDBInput_3.getString(4);
					if (!("0000-00-00").equals(dateString_tDBInput_3) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_3)) {
						row3.created_on = rs_tDBInput_3.getTimestamp(4);
					} else {
						row3.created_on = (java.util.Date) year0_tDBInput_3.clone();
					}
				} else {
					row3.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_3 < 5) {
								row3.updated_by = null;
							} else {
		                          
            row3.updated_by = rs_tDBInput_3.getInt(5);
            if(rs_tDBInput_3.wasNull()){
                    row3.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 6) {
								row3.updated_on = null;
							} else {
										
				if(rs_tDBInput_3.getString(6) != null) {
					String dateString_tDBInput_3 = rs_tDBInput_3.getString(6);
					if (!("0000-00-00").equals(dateString_tDBInput_3) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_3)) {
						row3.updated_on = rs_tDBInput_3.getTimestamp(6);
					} else {
						row3.updated_on = (java.util.Date) year0_tDBInput_3.clone();
					}
				} else {
					row3.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_3 < 7) {
								row3.is_active = 0;
							} else {
		                          
            row3.is_active = rs_tDBInput_3.getInt(7);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 8) {
								row3.is_deleted = 0;
							} else {
		                          
            row3.is_deleted = rs_tDBInput_3.getInt(8);
            if(rs_tDBInput_3.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_3 < 9) {
								row3.option_group_id = null;
							} else {
	                         		
        	row3.option_group_id = routines.system.JDBCUtil.getString(rs_tDBInput_3, 9, false);
		                    }
							if(colQtyInRs_tDBInput_3 < 10) {
								row3.as_on = null;
							} else {
										
				if(rs_tDBInput_3.getString(10) != null) {
					String dateString_tDBInput_3 = rs_tDBInput_3.getString(10);
					if (!("0000-00-00").equals(dateString_tDBInput_3) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_3)) {
						row3.as_on = rs_tDBInput_3.getTimestamp(10);
					} else {
						row3.as_on = (java.util.Date) year0_tDBInput_3.clone();
					}
				} else {
					row3.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");
					

 



/**
 * [tDBInput_3 begin ] stop
 */
	
	/**
	 * [tDBInput_3 main ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_option_group\"";
		

 


	tos_count_tDBInput_3++;

/**
 * [tDBInput_3 main ] stop
 */
	
	/**
	 * [tDBInput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_option_group\"";
		

 



/**
 * [tDBInput_3 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tDBInput_3","\"mst_option_group\"","tMysqlInput","tAsyncOut_tDBOutput_3","tAsyncOut_tDBOutput_3","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_3=new Object[]{null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_3[0] = String.valueOf(row3.id); 
	if(row3.option_group_name != null){
		row_tAsyncOut_tDBOutput_3[1] = row3.option_group_name;                			    
	}
	if(row3.created_by != null){
		row_tAsyncOut_tDBOutput_3[2] = String.valueOf(row3.created_by);                			    
	}
	if(row3.created_on != null){
		row_tAsyncOut_tDBOutput_3[3] = row3.created_on;                			    
	}
	if(row3.updated_by != null){
		row_tAsyncOut_tDBOutput_3[4] = String.valueOf(row3.updated_by);                			    
	}
	if(row3.updated_on != null){
		row_tAsyncOut_tDBOutput_3[5] = row3.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_3[6] = String.valueOf(row3.is_active); 
	row_tAsyncOut_tDBOutput_3[7] = String.valueOf(row3.is_deleted); 
	if(row3.option_group_id != null){
		row_tAsyncOut_tDBOutput_3[8] = row3.option_group_id;                			    
	}
	if(row3.as_on != null){
		row_tAsyncOut_tDBOutput_3[9] = row3.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_3 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_3", buffers_tAsyncOut_tDBOutput_3);
		/*tAsyncIn_tDBOutput_10Process(globalMap);*/
		tAsyncIn_tDBOutput_3Process(globalMap);
		buffers_tAsyncOut_tDBOutput_3 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_3 = 0;
	}
	buffers_tAsyncOut_tDBOutput_3.add(row_tAsyncOut_tDBOutput_3);
	index_tAsyncOut_tDBOutput_3++;
 


	tos_count_tAsyncOut_tDBOutput_3++;

/**
 * [tAsyncOut_tDBOutput_3 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	

 



/**
 * [tAsyncOut_tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	

 



/**
 * [tAsyncOut_tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_option_group\"";
		

 



/**
 * [tDBInput_3 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_3 end ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_option_group\"";
		

	}
}finally{
	if (rs_tDBInput_3 != null) {
		rs_tDBInput_3.close();
	}
	if (stmt_tDBInput_3 != null) {
		stmt_tDBInput_3.close();
	}
}

		   globalMap.put("tDBInput_3_NB_LINE",nb_line_tDBInput_3);
		

	    		log.debug("tDBInput_3 - Retrieved records count: "+nb_line_tDBInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_3 - "  + ("Done.") );

ok_Hash.put("tDBInput_3", true);
end_Hash.put("tDBInput_3", System.currentTimeMillis());




/**
 * [tDBInput_3 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	


	if (buffers_tAsyncOut_tDBOutput_3.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_3", buffers_tAsyncOut_tDBOutput_3);
	    tAsyncIn_tDBOutput_3Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_3.waitForEnd();
	pool_tAsyncOut_tDBOutput_3.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tDBInput_3","\"mst_option_group\"","tMysqlInput","tAsyncOut_tDBOutput_3","tAsyncOut_tDBOutput_3","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_3", true);
end_Hash.put("tAsyncOut_tDBOutput_3", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_3";
	
	
			cLabel="\"mst_option_group\"";
		

 



/**
 * [tDBInput_3 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_3";
	
	

 



/**
 * [tAsyncOut_tDBOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String option_name;

				public String getOption_name () {
					return this.option_name;
				}

				public Boolean option_nameIsNullable(){
				    return false;
				}
				public Boolean option_nameIsKey(){
				    return false;
				}
				public Integer option_nameLength(){
				    return 50;
				}
				public Integer option_namePrecision(){
				    return 0;
				}
				public String option_nameDefault(){
				
					return null;
				
				}
				public String option_nameComment(){
				
				    return "";
				
				}
				public String option_namePattern(){
				
					return "";
				
				}
				public String option_nameOriginalDbColumnName(){
				
					return "option_name";
				
				}

				
			    public Float option_marks;

				public Float getOption_marks () {
					return this.option_marks;
				}

				public Boolean option_marksIsNullable(){
				    return true;
				}
				public Boolean option_marksIsKey(){
				    return false;
				}
				public Integer option_marksLength(){
				    return 8;
				}
				public Integer option_marksPrecision(){
				    return 8;
				}
				public String option_marksDefault(){
				
					return "'0'::real";
				
				}
				public String option_marksComment(){
				
				    return "";
				
				}
				public String option_marksPattern(){
				
					return "";
				
				}
				public String option_marksOriginalDbColumnName(){
				
					return "option_marks";
				
				}

				
			    public int option_group_id;

				public int getOption_group_id () {
					return this.option_group_id;
				}

				public Boolean option_group_idIsNullable(){
				    return false;
				}
				public Boolean option_group_idIsKey(){
				    return false;
				}
				public Integer option_group_idLength(){
				    return 10;
				}
				public Integer option_group_idPrecision(){
				    return 0;
				}
				public String option_group_idDefault(){
				
					return null;
				
				}
				public String option_group_idComment(){
				
				    return "";
				
				}
				public String option_group_idPattern(){
				
					return "";
				
				}
				public String option_group_idOriginalDbColumnName(){
				
					return "option_group_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String option_group_lines_id;

				public String getOption_group_lines_id () {
					return this.option_group_lines_id;
				}

				public Boolean option_group_lines_idIsNullable(){
				    return true;
				}
				public Boolean option_group_lines_idIsKey(){
				    return false;
				}
				public Integer option_group_lines_idLength(){
				    return 32;
				}
				public Integer option_group_lines_idPrecision(){
				    return 0;
				}
				public String option_group_lines_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String option_group_lines_idComment(){
				
				    return "";
				
				}
				public String option_group_lines_idPattern(){
				
					return "";
				
				}
				public String option_group_lines_idOriginalDbColumnName(){
				
					return "option_group_lines_id";
				
				}

				
			    public Integer observation;

				public Integer getObservation () {
					return this.observation;
				}

				public Boolean observationIsNullable(){
				    return true;
				}
				public Boolean observationIsKey(){
				    return false;
				}
				public Integer observationLength(){
				    return 10;
				}
				public Integer observationPrecision(){
				    return 0;
				}
				public String observationDefault(){
				
					return "0";
				
				}
				public String observationComment(){
				
				    return "";
				
				}
				public String observationPattern(){
				
					return "";
				
				}
				public String observationOriginalDbColumnName(){
				
					return "observation";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row4Struct other = (row4Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row4Struct other) {

		other.id = this.id;
	            other.option_name = this.option_name;
	            other.option_marks = this.option_marks;
	            other.option_group_id = this.option_group_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.option_group_lines_id = this.option_group_lines_id;
	            other.observation = this.observation;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row4Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.option_marks = null;
           				} else {
           			    	this.option_marks = dis.readFloat();
           				}
					
			        this.option_group_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_group_lines_id = readString(dis);
					
						this.observation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.option_marks = null;
           				} else {
           			    	this.option_marks = dis.readFloat();
           				}
					
			        this.option_group_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_group_lines_id = readString(dis);
					
						this.observation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.option_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.option_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.option_group_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_group_lines_id,dos);
					
					// Integer
				
						writeInteger(this.observation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.option_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.option_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.option_group_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_group_lines_id,dos);
					
					// Integer
				
						writeInteger(this.observation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",option_name="+option_name);
		sb.append(",option_marks="+String.valueOf(option_marks));
		sb.append(",option_group_id="+String.valueOf(option_group_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",option_group_lines_id="+option_group_lines_id);
		sb.append(",observation="+String.valueOf(observation));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(option_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_name);
            			}
            		
        			sb.append("|");
        		
        				if(option_marks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_marks);
            			}
            		
        			sb.append("|");
        		
        				sb.append(option_group_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(option_group_lines_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_group_lines_id);
            			}
            		
        			sb.append("|");
        		
        				if(observation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_4");
		org.slf4j.MDC.put("_subJobPid", "EpEM3r_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_4", false);
		start_Hash.put("tAsyncOut_tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row4");
			
		int tos_count_tAsyncOut_tDBOutput_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_4", "tAsyncOut_tDBOutput_4", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_4 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_4 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_4 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_4=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_4 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_4", pool_tAsyncOut_tDBOutput_4);
	final Object[] lockWrite_tAsyncOut_tDBOutput_4 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_4", lockWrite_tAsyncOut_tDBOutput_4);
 



/**
 * [tAsyncOut_tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tDBInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_4", false);
		start_Hash.put("tDBInput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_option_group_lines\"";
		
		int tos_count_tDBInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_4 = new StringBuilder();
                    log4jParamters_tDBInput_4.append("Parameters:");
                            log4jParamters_tDBInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TABLE" + " = " + "\"mst_option_group_lines\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("QUERY" + " = " + "\"SELECT    `mst_option_group_lines`.`id`,    `mst_option_group_lines`.`option_name`,    `mst_option_group_lines`.`option_marks`,    `mst_option_group_lines`.`option_group_id`,    `mst_option_group_lines`.`created_by`,    `mst_option_group_lines`.`created_on`,    `mst_option_group_lines`.`updated_by`,    `mst_option_group_lines`.`updated_on`,    `mst_option_group_lines`.`is_active`,    `mst_option_group_lines`.`is_deleted`,    `mst_option_group_lines`.`option_group_lines_id`,    `mst_option_group_lines`.`observation`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_option_group_lines`\"");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_marks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_group_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_group_lines_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("observation")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_4.append(" | ");
                            log4jParamters_tDBInput_4.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + (log4jParamters_tDBInput_4) );
                    } 
                } 
            new BytesLimit65535_tDBInput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_4", "\"mst_option_group_lines\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_4 = java.util.Calendar.getInstance();
		    calendar_tDBInput_4.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_4 = calendar_tDBInput_4.getTime();
		    int nb_line_tDBInput_4 = 0;
		    java.sql.Connection conn_tDBInput_4 = null;
				conn_tDBInput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_4 != null) {
					if(conn_tDBInput_4.getMetaData() != null) {
						
							log.debug("tDBInput_4 - Uses an existing connection with username '" + conn_tDBInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_4 = conn_tDBInput_4.createStatement();
				if(stmt_tDBInput_4 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_4).enableStreamingResults();
				}else if(stmt_tDBInput_4 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_4).enableStreamingResults();
				}

		    String dbquery_tDBInput_4 = "SELECT \n  `mst_option_group_lines`.`id`, \n  `mst_option_group_lines`.`option_name`, \n  `mst_option_group_lines`.`option"
+"_marks`, \n  `mst_option_group_lines`.`option_group_id`, \n  `mst_option_group_lines`.`created_by`, \n  `mst_option_group_l"
+"ines`.`created_on`, \n  `mst_option_group_lines`.`updated_by`, \n  `mst_option_group_lines`.`updated_on`, \n  `mst_option_g"
+"roup_lines`.`is_active`, \n  `mst_option_group_lines`.`is_deleted`, \n  `mst_option_group_lines`.`option_group_lines_id`, "
+"\n  `mst_option_group_lines`.`observation`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_option_gro"
+"up_lines`";
		    
	    		log.debug("tDBInput_4 - Executing the query: '" + dbquery_tDBInput_4 + "'.");
			

            	globalMap.put("tDBInput_4_QUERY",dbquery_tDBInput_4);
		    java.sql.ResultSet rs_tDBInput_4 = null;

		    try {
		    	rs_tDBInput_4 = stmt_tDBInput_4.executeQuery(dbquery_tDBInput_4);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_4 = rs_tDBInput_4.getMetaData();
		    	int colQtyInRs_tDBInput_4 = rsmd_tDBInput_4.getColumnCount();

		    String tmpContent_tDBInput_4 = null;
		    
		    
		    	log.debug("tDBInput_4 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_4.next()) {
		        nb_line_tDBInput_4++;
		        
							if(colQtyInRs_tDBInput_4 < 1) {
								row4.id = 0;
							} else {
		                          
            row4.id = rs_tDBInput_4.getInt(1);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 2) {
								row4.option_name = null;
							} else {
	                         		
        	row4.option_name = routines.system.JDBCUtil.getString(rs_tDBInput_4, 2, false);
		                    }
							if(colQtyInRs_tDBInput_4 < 3) {
								row4.option_marks = null;
							} else {
		                          
            row4.option_marks = rs_tDBInput_4.getFloat(3);
            if(rs_tDBInput_4.wasNull()){
                    row4.option_marks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 4) {
								row4.option_group_id = 0;
							} else {
		                          
            row4.option_group_id = rs_tDBInput_4.getInt(4);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 5) {
								row4.created_by = null;
							} else {
		                          
            row4.created_by = rs_tDBInput_4.getInt(5);
            if(rs_tDBInput_4.wasNull()){
                    row4.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 6) {
								row4.created_on = null;
							} else {
										
				if(rs_tDBInput_4.getString(6) != null) {
					String dateString_tDBInput_4 = rs_tDBInput_4.getString(6);
					if (!("0000-00-00").equals(dateString_tDBInput_4) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_4)) {
						row4.created_on = rs_tDBInput_4.getTimestamp(6);
					} else {
						row4.created_on = (java.util.Date) year0_tDBInput_4.clone();
					}
				} else {
					row4.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_4 < 7) {
								row4.updated_by = null;
							} else {
		                          
            row4.updated_by = rs_tDBInput_4.getInt(7);
            if(rs_tDBInput_4.wasNull()){
                    row4.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 8) {
								row4.updated_on = null;
							} else {
										
				if(rs_tDBInput_4.getString(8) != null) {
					String dateString_tDBInput_4 = rs_tDBInput_4.getString(8);
					if (!("0000-00-00").equals(dateString_tDBInput_4) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_4)) {
						row4.updated_on = rs_tDBInput_4.getTimestamp(8);
					} else {
						row4.updated_on = (java.util.Date) year0_tDBInput_4.clone();
					}
				} else {
					row4.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_4 < 9) {
								row4.is_active = 0;
							} else {
		                          
            row4.is_active = rs_tDBInput_4.getInt(9);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 10) {
								row4.is_deleted = 0;
							} else {
		                          
            row4.is_deleted = rs_tDBInput_4.getInt(10);
            if(rs_tDBInput_4.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 11) {
								row4.option_group_lines_id = null;
							} else {
	                         		
        	row4.option_group_lines_id = routines.system.JDBCUtil.getString(rs_tDBInput_4, 11, false);
		                    }
							if(colQtyInRs_tDBInput_4 < 12) {
								row4.observation = null;
							} else {
		                          
            row4.observation = rs_tDBInput_4.getInt(12);
            if(rs_tDBInput_4.wasNull()){
                    row4.observation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_4 < 13) {
								row4.as_on = null;
							} else {
										
				if(rs_tDBInput_4.getString(13) != null) {
					String dateString_tDBInput_4 = rs_tDBInput_4.getString(13);
					if (!("0000-00-00").equals(dateString_tDBInput_4) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_4)) {
						row4.as_on = rs_tDBInput_4.getTimestamp(13);
					} else {
						row4.as_on = (java.util.Date) year0_tDBInput_4.clone();
					}
				} else {
					row4.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_4 - Retrieving the record " + nb_line_tDBInput_4 + ".");
					

 



/**
 * [tDBInput_4 begin ] stop
 */
	
	/**
	 * [tDBInput_4 main ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_option_group_lines\"";
		

 


	tos_count_tDBInput_4++;

/**
 * [tDBInput_4 main ] stop
 */
	
	/**
	 * [tDBInput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_option_group_lines\"";
		

 



/**
 * [tDBInput_4 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row4","tDBInput_4","\"mst_option_group_lines\"","tMysqlInput","tAsyncOut_tDBOutput_4","tAsyncOut_tDBOutput_4","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_4=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_4[0] = String.valueOf(row4.id); 
	if(row4.option_name != null){
		row_tAsyncOut_tDBOutput_4[1] = row4.option_name;                			    
	}
	if(row4.option_marks != null){
		row_tAsyncOut_tDBOutput_4[2] = String.valueOf(row4.option_marks);                			    
	}
	row_tAsyncOut_tDBOutput_4[3] = String.valueOf(row4.option_group_id); 
	if(row4.created_by != null){
		row_tAsyncOut_tDBOutput_4[4] = String.valueOf(row4.created_by);                			    
	}
	if(row4.created_on != null){
		row_tAsyncOut_tDBOutput_4[5] = row4.created_on;                			    
	}
	if(row4.updated_by != null){
		row_tAsyncOut_tDBOutput_4[6] = String.valueOf(row4.updated_by);                			    
	}
	if(row4.updated_on != null){
		row_tAsyncOut_tDBOutput_4[7] = row4.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_4[8] = String.valueOf(row4.is_active); 
	row_tAsyncOut_tDBOutput_4[9] = String.valueOf(row4.is_deleted); 
	if(row4.option_group_lines_id != null){
		row_tAsyncOut_tDBOutput_4[10] = row4.option_group_lines_id;                			    
	}
	if(row4.observation != null){
		row_tAsyncOut_tDBOutput_4[11] = String.valueOf(row4.observation);                			    
	}
	if(row4.as_on != null){
		row_tAsyncOut_tDBOutput_4[12] = row4.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_4 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_4", buffers_tAsyncOut_tDBOutput_4);
		/*tAsyncIn_tDBOutput_10Process(globalMap);*/
		tAsyncIn_tDBOutput_4Process(globalMap);
		buffers_tAsyncOut_tDBOutput_4 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_4 = 0;
	}
	buffers_tAsyncOut_tDBOutput_4.add(row_tAsyncOut_tDBOutput_4);
	index_tAsyncOut_tDBOutput_4++;
 


	tos_count_tAsyncOut_tDBOutput_4++;

/**
 * [tAsyncOut_tDBOutput_4 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	

 



/**
 * [tAsyncOut_tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	

 



/**
 * [tAsyncOut_tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_option_group_lines\"";
		

 



/**
 * [tDBInput_4 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_4 end ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_option_group_lines\"";
		

	}
}finally{
	if (rs_tDBInput_4 != null) {
		rs_tDBInput_4.close();
	}
	if (stmt_tDBInput_4 != null) {
		stmt_tDBInput_4.close();
	}
}

		   globalMap.put("tDBInput_4_NB_LINE",nb_line_tDBInput_4);
		

	    		log.debug("tDBInput_4 - Retrieved records count: "+nb_line_tDBInput_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_4 - "  + ("Done.") );

ok_Hash.put("tDBInput_4", true);
end_Hash.put("tDBInput_4", System.currentTimeMillis());




/**
 * [tDBInput_4 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	


	if (buffers_tAsyncOut_tDBOutput_4.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_4", buffers_tAsyncOut_tDBOutput_4);
	    tAsyncIn_tDBOutput_4Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_4.waitForEnd();
	pool_tAsyncOut_tDBOutput_4.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row4",2,0,
			 			"tDBInput_4","\"mst_option_group_lines\"","tMysqlInput","tAsyncOut_tDBOutput_4","tAsyncOut_tDBOutput_4","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_4", true);
end_Hash.put("tAsyncOut_tDBOutput_4", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_4";
	
	
			cLabel="\"mst_option_group_lines\"";
		

 



/**
 * [tDBInput_4 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_4";
	
	

 



/**
 * [tAsyncOut_tDBOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_4_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String process_name;

				public String getProcess_name () {
					return this.process_name;
				}

				public Boolean process_nameIsNullable(){
				    return false;
				}
				public Boolean process_nameIsKey(){
				    return false;
				}
				public Integer process_nameLength(){
				    return 150;
				}
				public Integer process_namePrecision(){
				    return 0;
				}
				public String process_nameDefault(){
				
					return null;
				
				}
				public String process_nameComment(){
				
				    return "";
				
				}
				public String process_namePattern(){
				
					return "";
				
				}
				public String process_nameOriginalDbColumnName(){
				
					return "process_name";
				
				}

				
			    public Float parent_process;

				public Float getParent_process () {
					return this.parent_process;
				}

				public Boolean parent_processIsNullable(){
				    return true;
				}
				public Boolean parent_processIsKey(){
				    return false;
				}
				public Integer parent_processLength(){
				    return 8;
				}
				public Integer parent_processPrecision(){
				    return 8;
				}
				public String parent_processDefault(){
				
					return null;
				
				}
				public String parent_processComment(){
				
				    return "";
				
				}
				public String parent_processPattern(){
				
					return "";
				
				}
				public String parent_processOriginalDbColumnName(){
				
					return "parent_process";
				
				}

				
			    public String tagging_type;

				public String getTagging_type () {
					return this.tagging_type;
				}

				public Boolean tagging_typeIsNullable(){
				    return true;
				}
				public Boolean tagging_typeIsKey(){
				    return false;
				}
				public Integer tagging_typeLength(){
				    return 2;
				}
				public Integer tagging_typePrecision(){
				    return 0;
				}
				public String tagging_typeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String tagging_typeComment(){
				
				    return "";
				
				}
				public String tagging_typePattern(){
				
					return "";
				
				}
				public String tagging_typeOriginalDbColumnName(){
				
					return "tagging_type";
				
				}

				
			    public Integer process_order;

				public Integer getProcess_order () {
					return this.process_order;
				}

				public Boolean process_orderIsNullable(){
				    return true;
				}
				public Boolean process_orderIsKey(){
				    return false;
				}
				public Integer process_orderLength(){
				    return 10;
				}
				public Integer process_orderPrecision(){
				    return 0;
				}
				public String process_orderDefault(){
				
					return "0";
				
				}
				public String process_orderComment(){
				
				    return "";
				
				}
				public String process_orderPattern(){
				
					return "";
				
				}
				public String process_orderOriginalDbColumnName(){
				
					return "process_order";
				
				}

				
			    public Integer subprocess_order;

				public Integer getSubprocess_order () {
					return this.subprocess_order;
				}

				public Boolean subprocess_orderIsNullable(){
				    return true;
				}
				public Boolean subprocess_orderIsKey(){
				    return false;
				}
				public Integer subprocess_orderLength(){
				    return 10;
				}
				public Integer subprocess_orderPrecision(){
				    return 0;
				}
				public String subprocess_orderDefault(){
				
					return "0";
				
				}
				public String subprocess_orderComment(){
				
				    return "";
				
				}
				public String subprocess_orderPattern(){
				
					return "";
				
				}
				public String subprocess_orderOriginalDbColumnName(){
				
					return "subprocess_order";
				
				}

				
			    public Integer weightage;

				public Integer getWeightage () {
					return this.weightage;
				}

				public Boolean weightageIsNullable(){
				    return true;
				}
				public Boolean weightageIsKey(){
				    return false;
				}
				public Integer weightageLength(){
				    return 10;
				}
				public Integer weightagePrecision(){
				    return 0;
				}
				public String weightageDefault(){
				
					return "0";
				
				}
				public String weightageComment(){
				
				    return "";
				
				}
				public String weightagePattern(){
				
					return "";
				
				}
				public String weightageOriginalDbColumnName(){
				
					return "weightage";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String process_id;

				public String getProcess_id () {
					return this.process_id;
				}

				public Boolean process_idIsNullable(){
				    return true;
				}
				public Boolean process_idIsKey(){
				    return false;
				}
				public Integer process_idLength(){
				    return 32;
				}
				public Integer process_idPrecision(){
				    return 0;
				}
				public String process_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String process_idComment(){
				
				    return "";
				
				}
				public String process_idPattern(){
				
					return "";
				
				}
				public String process_idOriginalDbColumnName(){
				
					return "process_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row5Struct other = (row5Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row5Struct other) {

		other.id = this.id;
	            other.process_name = this.process_name;
	            other.parent_process = this.parent_process;
	            other.tagging_type = this.tagging_type;
	            other.process_order = this.process_order;
	            other.subprocess_order = this.subprocess_order;
	            other.weightage = this.weightage;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.process_id = this.process_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row5Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.process_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.parent_process = null;
           				} else {
           			    	this.parent_process = dis.readFloat();
           				}
					
					this.tagging_type = readString(dis);
					
						this.process_order = readInteger(dis);
					
						this.subprocess_order = readInteger(dis);
					
						this.weightage = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.process_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.process_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.parent_process = null;
           				} else {
           			    	this.parent_process = dis.readFloat();
           				}
					
					this.tagging_type = readString(dis);
					
						this.process_order = readInteger(dis);
					
						this.subprocess_order = readInteger(dis);
					
						this.weightage = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.process_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.process_name,dos);
					
					// Float
				
						if(this.parent_process == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.parent_process);
		            	}
					
					// String
				
						writeString(this.tagging_type,dos);
					
					// Integer
				
						writeInteger(this.process_order,dos);
					
					// Integer
				
						writeInteger(this.subprocess_order,dos);
					
					// Integer
				
						writeInteger(this.weightage,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.process_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.process_name,dos);
					
					// Float
				
						if(this.parent_process == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.parent_process);
		            	}
					
					// String
				
						writeString(this.tagging_type,dos);
					
					// Integer
				
						writeInteger(this.process_order,dos);
					
					// Integer
				
						writeInteger(this.subprocess_order,dos);
					
					// Integer
				
						writeInteger(this.weightage,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.process_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",process_name="+process_name);
		sb.append(",parent_process="+String.valueOf(parent_process));
		sb.append(",tagging_type="+tagging_type);
		sb.append(",process_order="+String.valueOf(process_order));
		sb.append(",subprocess_order="+String.valueOf(subprocess_order));
		sb.append(",weightage="+String.valueOf(weightage));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",process_id="+process_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(process_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_name);
            			}
            		
        			sb.append("|");
        		
        				if(parent_process == null){
        					sb.append("<null>");
        				}else{
            				sb.append(parent_process);
            			}
            		
        			sb.append("|");
        		
        				if(tagging_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tagging_type);
            			}
            		
        			sb.append("|");
        		
        				if(process_order == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_order);
            			}
            		
        			sb.append("|");
        		
        				if(subprocess_order == null){
        					sb.append("<null>");
        				}else{
            				sb.append(subprocess_order);
            			}
            		
        			sb.append("|");
        		
        				if(weightage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(weightage);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(process_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_5");
		org.slf4j.MDC.put("_subJobPid", "MnZPgo_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_5", false);
		start_Hash.put("tAsyncOut_tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row5");
			
		int tos_count_tAsyncOut_tDBOutput_5 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_5", "tAsyncOut_tDBOutput_5", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_5 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_5 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_5 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_5=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_5 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_5", pool_tAsyncOut_tDBOutput_5);
	final Object[] lockWrite_tAsyncOut_tDBOutput_5 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_5", lockWrite_tAsyncOut_tDBOutput_5);
 



/**
 * [tAsyncOut_tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tDBInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_5", false);
		start_Hash.put("tDBInput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_process\"";
		
		int tos_count_tDBInput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_5 = new StringBuilder();
                    log4jParamters_tDBInput_5.append("Parameters:");
                            log4jParamters_tDBInput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TABLE" + " = " + "\"mst_process\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("QUERY" + " = " + "\"SELECT    `mst_process`.`id`,    `mst_process`.`process_name`,    `mst_process`.`parent_process`,    `mst_process`.`tagging_type`,    `mst_process`.`process_order`,    `mst_process`.`subprocess_order`,    `mst_process`.`weightage`,    `mst_process`.`created_by`,    `mst_process`.`created_on`,    `mst_process`.`updated_by`,    `mst_process`.`updated_on`,    `mst_process`.`is_active`,    `mst_process`.`is_deleted`,    `mst_process`.`process_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_process`\"");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("process_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("parent_process")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("tagging_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("process_order")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("subprocess_order")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("weightage")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("process_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_5.append(" | ");
                            log4jParamters_tDBInput_5.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + (log4jParamters_tDBInput_5) );
                    } 
                } 
            new BytesLimit65535_tDBInput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_5", "\"mst_process\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_5 = java.util.Calendar.getInstance();
		    calendar_tDBInput_5.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_5 = calendar_tDBInput_5.getTime();
		    int nb_line_tDBInput_5 = 0;
		    java.sql.Connection conn_tDBInput_5 = null;
				conn_tDBInput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_5 != null) {
					if(conn_tDBInput_5.getMetaData() != null) {
						
							log.debug("tDBInput_5 - Uses an existing connection with username '" + conn_tDBInput_5.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_5.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_5 = conn_tDBInput_5.createStatement();
				if(stmt_tDBInput_5 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_5).enableStreamingResults();
				}else if(stmt_tDBInput_5 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_5).enableStreamingResults();
				}

		    String dbquery_tDBInput_5 = "SELECT \n  `mst_process`.`id`, \n  `mst_process`.`process_name`, \n  `mst_process`.`parent_process`, \n  `mst_process`.`tag"
+"ging_type`, \n  `mst_process`.`process_order`, \n  `mst_process`.`subprocess_order`, \n  `mst_process`.`weightage`, \n  `mst"
+"_process`.`created_by`, \n  `mst_process`.`created_on`, \n  `mst_process`.`updated_by`, \n  `mst_process`.`updated_on`, \n  "
+"`mst_process`.`is_active`, \n  `mst_process`.`is_deleted`, \n  `mst_process`.`process_id`,\n	DATE_SUB(CURRENT_TIMESTAMP, I"
+"NTERVAL 1 DAY) AS `as_on`\nFROM `mst_process`";
		    
	    		log.debug("tDBInput_5 - Executing the query: '" + dbquery_tDBInput_5 + "'.");
			

            	globalMap.put("tDBInput_5_QUERY",dbquery_tDBInput_5);
		    java.sql.ResultSet rs_tDBInput_5 = null;

		    try {
		    	rs_tDBInput_5 = stmt_tDBInput_5.executeQuery(dbquery_tDBInput_5);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_5 = rs_tDBInput_5.getMetaData();
		    	int colQtyInRs_tDBInput_5 = rsmd_tDBInput_5.getColumnCount();

		    String tmpContent_tDBInput_5 = null;
		    
		    
		    	log.debug("tDBInput_5 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_5.next()) {
		        nb_line_tDBInput_5++;
		        
							if(colQtyInRs_tDBInput_5 < 1) {
								row5.id = 0;
							} else {
		                          
            row5.id = rs_tDBInput_5.getInt(1);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 2) {
								row5.process_name = null;
							} else {
	                         		
        	row5.process_name = routines.system.JDBCUtil.getString(rs_tDBInput_5, 2, false);
		                    }
							if(colQtyInRs_tDBInput_5 < 3) {
								row5.parent_process = null;
							} else {
		                          
            row5.parent_process = rs_tDBInput_5.getFloat(3);
            if(rs_tDBInput_5.wasNull()){
                    row5.parent_process = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 4) {
								row5.tagging_type = null;
							} else {
	                         		
        	row5.tagging_type = routines.system.JDBCUtil.getString(rs_tDBInput_5, 4, false);
		                    }
							if(colQtyInRs_tDBInput_5 < 5) {
								row5.process_order = null;
							} else {
		                          
            row5.process_order = rs_tDBInput_5.getInt(5);
            if(rs_tDBInput_5.wasNull()){
                    row5.process_order = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 6) {
								row5.subprocess_order = null;
							} else {
		                          
            row5.subprocess_order = rs_tDBInput_5.getInt(6);
            if(rs_tDBInput_5.wasNull()){
                    row5.subprocess_order = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 7) {
								row5.weightage = null;
							} else {
		                          
            row5.weightage = rs_tDBInput_5.getInt(7);
            if(rs_tDBInput_5.wasNull()){
                    row5.weightage = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 8) {
								row5.created_by = null;
							} else {
		                          
            row5.created_by = rs_tDBInput_5.getInt(8);
            if(rs_tDBInput_5.wasNull()){
                    row5.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 9) {
								row5.created_on = null;
							} else {
										
				if(rs_tDBInput_5.getString(9) != null) {
					String dateString_tDBInput_5 = rs_tDBInput_5.getString(9);
					if (!("0000-00-00").equals(dateString_tDBInput_5) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_5)) {
						row5.created_on = rs_tDBInput_5.getTimestamp(9);
					} else {
						row5.created_on = (java.util.Date) year0_tDBInput_5.clone();
					}
				} else {
					row5.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_5 < 10) {
								row5.updated_by = null;
							} else {
		                          
            row5.updated_by = rs_tDBInput_5.getInt(10);
            if(rs_tDBInput_5.wasNull()){
                    row5.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 11) {
								row5.updated_on = null;
							} else {
										
				if(rs_tDBInput_5.getString(11) != null) {
					String dateString_tDBInput_5 = rs_tDBInput_5.getString(11);
					if (!("0000-00-00").equals(dateString_tDBInput_5) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_5)) {
						row5.updated_on = rs_tDBInput_5.getTimestamp(11);
					} else {
						row5.updated_on = (java.util.Date) year0_tDBInput_5.clone();
					}
				} else {
					row5.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_5 < 12) {
								row5.is_active = 0;
							} else {
		                          
            row5.is_active = rs_tDBInput_5.getInt(12);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 13) {
								row5.is_deleted = 0;
							} else {
		                          
            row5.is_deleted = rs_tDBInput_5.getInt(13);
            if(rs_tDBInput_5.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_5 < 14) {
								row5.process_id = null;
							} else {
	                         		
        	row5.process_id = routines.system.JDBCUtil.getString(rs_tDBInput_5, 14, false);
		                    }
							if(colQtyInRs_tDBInput_5 < 15) {
								row5.as_on = null;
							} else {
										
				if(rs_tDBInput_5.getString(15) != null) {
					String dateString_tDBInput_5 = rs_tDBInput_5.getString(15);
					if (!("0000-00-00").equals(dateString_tDBInput_5) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_5)) {
						row5.as_on = rs_tDBInput_5.getTimestamp(15);
					} else {
						row5.as_on = (java.util.Date) year0_tDBInput_5.clone();
					}
				} else {
					row5.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_5 - Retrieving the record " + nb_line_tDBInput_5 + ".");
					

 



/**
 * [tDBInput_5 begin ] stop
 */
	
	/**
	 * [tDBInput_5 main ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_process\"";
		

 


	tos_count_tDBInput_5++;

/**
 * [tDBInput_5 main ] stop
 */
	
	/**
	 * [tDBInput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_process\"";
		

 



/**
 * [tDBInput_5 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row5","tDBInput_5","\"mst_process\"","tMysqlInput","tAsyncOut_tDBOutput_5","tAsyncOut_tDBOutput_5","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_5=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_5[0] = String.valueOf(row5.id); 
	if(row5.process_name != null){
		row_tAsyncOut_tDBOutput_5[1] = row5.process_name;                			    
	}
	if(row5.parent_process != null){
		row_tAsyncOut_tDBOutput_5[2] = String.valueOf(row5.parent_process);                			    
	}
	if(row5.tagging_type != null){
		row_tAsyncOut_tDBOutput_5[3] = row5.tagging_type;                			    
	}
	if(row5.process_order != null){
		row_tAsyncOut_tDBOutput_5[4] = String.valueOf(row5.process_order);                			    
	}
	if(row5.subprocess_order != null){
		row_tAsyncOut_tDBOutput_5[5] = String.valueOf(row5.subprocess_order);                			    
	}
	if(row5.weightage != null){
		row_tAsyncOut_tDBOutput_5[6] = String.valueOf(row5.weightage);                			    
	}
	if(row5.created_by != null){
		row_tAsyncOut_tDBOutput_5[7] = String.valueOf(row5.created_by);                			    
	}
	if(row5.created_on != null){
		row_tAsyncOut_tDBOutput_5[8] = row5.created_on;                			    
	}
	if(row5.updated_by != null){
		row_tAsyncOut_tDBOutput_5[9] = String.valueOf(row5.updated_by);                			    
	}
	if(row5.updated_on != null){
		row_tAsyncOut_tDBOutput_5[10] = row5.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_5[11] = String.valueOf(row5.is_active); 
	row_tAsyncOut_tDBOutput_5[12] = String.valueOf(row5.is_deleted); 
	if(row5.process_id != null){
		row_tAsyncOut_tDBOutput_5[13] = row5.process_id;                			    
	}
	if(row5.as_on != null){
		row_tAsyncOut_tDBOutput_5[14] = row5.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_5 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_5", buffers_tAsyncOut_tDBOutput_5);
		/*tAsyncIn_tDBOutput_10Process(globalMap);*/
		tAsyncIn_tDBOutput_5Process(globalMap);
		buffers_tAsyncOut_tDBOutput_5 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_5 = 0;
	}
	buffers_tAsyncOut_tDBOutput_5.add(row_tAsyncOut_tDBOutput_5);
	index_tAsyncOut_tDBOutput_5++;
 


	tos_count_tAsyncOut_tDBOutput_5++;

/**
 * [tAsyncOut_tDBOutput_5 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	

 



/**
 * [tAsyncOut_tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	

 



/**
 * [tAsyncOut_tDBOutput_5 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_process\"";
		

 



/**
 * [tDBInput_5 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_5 end ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_process\"";
		

	}
}finally{
	if (rs_tDBInput_5 != null) {
		rs_tDBInput_5.close();
	}
	if (stmt_tDBInput_5 != null) {
		stmt_tDBInput_5.close();
	}
}

		   globalMap.put("tDBInput_5_NB_LINE",nb_line_tDBInput_5);
		

	    		log.debug("tDBInput_5 - Retrieved records count: "+nb_line_tDBInput_5 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_5 - "  + ("Done.") );

ok_Hash.put("tDBInput_5", true);
end_Hash.put("tDBInput_5", System.currentTimeMillis());




/**
 * [tDBInput_5 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	


	if (buffers_tAsyncOut_tDBOutput_5.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_5", buffers_tAsyncOut_tDBOutput_5);
	    tAsyncIn_tDBOutput_5Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_5.waitForEnd();
	pool_tAsyncOut_tDBOutput_5.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row5",2,0,
			 			"tDBInput_5","\"mst_process\"","tMysqlInput","tAsyncOut_tDBOutput_5","tAsyncOut_tDBOutput_5","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_5", true);
end_Hash.put("tAsyncOut_tDBOutput_5", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_5";
	
	
			cLabel="\"mst_process\"";
		

 



/**
 * [tDBInput_5 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_5";
	
	

 



/**
 * [tAsyncOut_tDBOutput_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_5_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String question;

				public String getQuestion () {
					return this.question;
				}

				public Boolean questionIsNullable(){
				    return false;
				}
				public Boolean questionIsKey(){
				    return false;
				}
				public Integer questionLength(){
				    return 2147483647;
				}
				public Integer questionPrecision(){
				    return 0;
				}
				public String questionDefault(){
				
					return null;
				
				}
				public String questionComment(){
				
				    return "";
				
				}
				public String questionPattern(){
				
					return "";
				
				}
				public String questionOriginalDbColumnName(){
				
					return "question";
				
				}

				
			    public int option_group_id;

				public int getOption_group_id () {
					return this.option_group_id;
				}

				public Boolean option_group_idIsNullable(){
				    return false;
				}
				public Boolean option_group_idIsKey(){
				    return false;
				}
				public Integer option_group_idLength(){
				    return 10;
				}
				public Integer option_group_idPrecision(){
				    return 0;
				}
				public String option_group_idDefault(){
				
					return null;
				
				}
				public String option_group_idComment(){
				
				    return "";
				
				}
				public String option_group_idPattern(){
				
					return "";
				
				}
				public String option_group_idOriginalDbColumnName(){
				
					return "option_group_id";
				
				}

				
			    public Float min_marks;

				public Float getMin_marks () {
					return this.min_marks;
				}

				public Boolean min_marksIsNullable(){
				    return true;
				}
				public Boolean min_marksIsKey(){
				    return false;
				}
				public Integer min_marksLength(){
				    return 8;
				}
				public Integer min_marksPrecision(){
				    return 8;
				}
				public String min_marksDefault(){
				
					return "'0'::real";
				
				}
				public String min_marksComment(){
				
				    return "";
				
				}
				public String min_marksPattern(){
				
					return "";
				
				}
				public String min_marksOriginalDbColumnName(){
				
					return "min_marks";
				
				}

				
			    public Float max_marks;

				public Float getMax_marks () {
					return this.max_marks;
				}

				public Boolean max_marksIsNullable(){
				    return true;
				}
				public Boolean max_marksIsKey(){
				    return false;
				}
				public Integer max_marksLength(){
				    return 8;
				}
				public Integer max_marksPrecision(){
				    return 8;
				}
				public String max_marksDefault(){
				
					return "'0'::real";
				
				}
				public String max_marksComment(){
				
				    return "";
				
				}
				public String max_marksPattern(){
				
					return "";
				
				}
				public String max_marksOriginalDbColumnName(){
				
					return "max_marks";
				
				}

				
			    public int checklist_id;

				public int getChecklist_id () {
					return this.checklist_id;
				}

				public Boolean checklist_idIsNullable(){
				    return false;
				}
				public Boolean checklist_idIsKey(){
				    return false;
				}
				public Integer checklist_idLength(){
				    return 10;
				}
				public Integer checklist_idPrecision(){
				    return 0;
				}
				public String checklist_idDefault(){
				
					return null;
				
				}
				public String checklist_idComment(){
				
				    return "";
				
				}
				public String checklist_idPattern(){
				
					return "";
				
				}
				public String checklist_idOriginalDbColumnName(){
				
					return "checklist_id";
				
				}

				
			    public int category_id;

				public int getCategory_id () {
					return this.category_id;
				}

				public Boolean category_idIsNullable(){
				    return false;
				}
				public Boolean category_idIsKey(){
				    return false;
				}
				public Integer category_idLength(){
				    return 10;
				}
				public Integer category_idPrecision(){
				    return 0;
				}
				public String category_idDefault(){
				
					return null;
				
				}
				public String category_idComment(){
				
				    return "";
				
				}
				public String category_idPattern(){
				
					return "";
				
				}
				public String category_idOriginalDbColumnName(){
				
					return "category_id";
				
				}

				
			    public Integer process_id;

				public Integer getProcess_id () {
					return this.process_id;
				}

				public Boolean process_idIsNullable(){
				    return true;
				}
				public Boolean process_idIsKey(){
				    return false;
				}
				public Integer process_idLength(){
				    return 10;
				}
				public Integer process_idPrecision(){
				    return 0;
				}
				public String process_idDefault(){
				
					return null;
				
				}
				public String process_idComment(){
				
				    return "";
				
				}
				public String process_idPattern(){
				
					return "";
				
				}
				public String process_idOriginalDbColumnName(){
				
					return "process_id";
				
				}

				
			    public Integer subprocess_id;

				public Integer getSubprocess_id () {
					return this.subprocess_id;
				}

				public Boolean subprocess_idIsNullable(){
				    return true;
				}
				public Boolean subprocess_idIsKey(){
				    return false;
				}
				public Integer subprocess_idLength(){
				    return 10;
				}
				public Integer subprocess_idPrecision(){
				    return 0;
				}
				public String subprocess_idDefault(){
				
					return null;
				
				}
				public String subprocess_idComment(){
				
				    return "";
				
				}
				public String subprocess_idPattern(){
				
					return "";
				
				}
				public String subprocess_idOriginalDbColumnName(){
				
					return "subprocess_id";
				
				}

				
			    public int is_mandatory;

				public int getIs_mandatory () {
					return this.is_mandatory;
				}

				public Boolean is_mandatoryIsNullable(){
				    return false;
				}
				public Boolean is_mandatoryIsKey(){
				    return false;
				}
				public Integer is_mandatoryLength(){
				    return 10;
				}
				public Integer is_mandatoryPrecision(){
				    return 0;
				}
				public String is_mandatoryDefault(){
				
					return "1";
				
				}
				public String is_mandatoryComment(){
				
				    return "";
				
				}
				public String is_mandatoryPattern(){
				
					return "";
				
				}
				public String is_mandatoryOriginalDbColumnName(){
				
					return "is_mandatory";
				
				}

				
			    public Integer question_order;

				public Integer getQuestion_order () {
					return this.question_order;
				}

				public Boolean question_orderIsNullable(){
				    return true;
				}
				public Boolean question_orderIsKey(){
				    return false;
				}
				public Integer question_orderLength(){
				    return 10;
				}
				public Integer question_orderPrecision(){
				    return 0;
				}
				public String question_orderDefault(){
				
					return "0";
				
				}
				public String question_orderComment(){
				
				    return "";
				
				}
				public String question_orderPattern(){
				
					return "";
				
				}
				public String question_orderOriginalDbColumnName(){
				
					return "question_order";
				
				}

				
			    public String risk_type;

				public String getRisk_type () {
					return this.risk_type;
				}

				public Boolean risk_typeIsNullable(){
				    return true;
				}
				public Boolean risk_typeIsKey(){
				    return false;
				}
				public Integer risk_typeLength(){
				    return 45;
				}
				public Integer risk_typePrecision(){
				    return 0;
				}
				public String risk_typeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String risk_typeComment(){
				
				    return "";
				
				}
				public String risk_typePattern(){
				
					return "";
				
				}
				public String risk_typeOriginalDbColumnName(){
				
					return "risk_type";
				
				}

				
			    public Integer is_fraud;

				public Integer getIs_fraud () {
					return this.is_fraud;
				}

				public Boolean is_fraudIsNullable(){
				    return true;
				}
				public Boolean is_fraudIsKey(){
				    return false;
				}
				public Integer is_fraudLength(){
				    return 10;
				}
				public Integer is_fraudPrecision(){
				    return 0;
				}
				public String is_fraudDefault(){
				
					return "0";
				
				}
				public String is_fraudComment(){
				
				    return "";
				
				}
				public String is_fraudPattern(){
				
					return "";
				
				}
				public String is_fraudOriginalDbColumnName(){
				
					return "is_fraud";
				
				}

				
			    public Integer is_linked;

				public Integer getIs_linked () {
					return this.is_linked;
				}

				public Boolean is_linkedIsNullable(){
				    return true;
				}
				public Boolean is_linkedIsKey(){
				    return false;
				}
				public Integer is_linkedLength(){
				    return 10;
				}
				public Integer is_linkedPrecision(){
				    return 0;
				}
				public String is_linkedDefault(){
				
					return "0";
				
				}
				public String is_linkedComment(){
				
				    return "";
				
				}
				public String is_linkedPattern(){
				
					return "";
				
				}
				public String is_linkedOriginalDbColumnName(){
				
					return "is_linked";
				
				}

				
			    public Integer is_primary;

				public Integer getIs_primary () {
					return this.is_primary;
				}

				public Boolean is_primaryIsNullable(){
				    return true;
				}
				public Boolean is_primaryIsKey(){
				    return false;
				}
				public Integer is_primaryLength(){
				    return 10;
				}
				public Integer is_primaryPrecision(){
				    return 0;
				}
				public String is_primaryDefault(){
				
					return "0";
				
				}
				public String is_primaryComment(){
				
				    return "";
				
				}
				public String is_primaryPattern(){
				
					return "";
				
				}
				public String is_primaryOriginalDbColumnName(){
				
					return "is_primary";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String question_id;

				public String getQuestion_id () {
					return this.question_id;
				}

				public Boolean question_idIsNullable(){
				    return true;
				}
				public Boolean question_idIsKey(){
				    return false;
				}
				public Integer question_idLength(){
				    return 32;
				}
				public Integer question_idPrecision(){
				    return 0;
				}
				public String question_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String question_idComment(){
				
				    return "";
				
				}
				public String question_idPattern(){
				
					return "";
				
				}
				public String question_idOriginalDbColumnName(){
				
					return "question_id";
				
				}

				
			    public String linking_id;

				public String getLinking_id () {
					return this.linking_id;
				}

				public Boolean linking_idIsNullable(){
				    return true;
				}
				public Boolean linking_idIsKey(){
				    return false;
				}
				public Integer linking_idLength(){
				    return 32;
				}
				public Integer linking_idPrecision(){
				    return 0;
				}
				public String linking_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String linking_idComment(){
				
				    return "";
				
				}
				public String linking_idPattern(){
				
					return "";
				
				}
				public String linking_idOriginalDbColumnName(){
				
					return "linking_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row6Struct other = (row6Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row6Struct other) {

		other.id = this.id;
	            other.question = this.question;
	            other.option_group_id = this.option_group_id;
	            other.min_marks = this.min_marks;
	            other.max_marks = this.max_marks;
	            other.checklist_id = this.checklist_id;
	            other.category_id = this.category_id;
	            other.process_id = this.process_id;
	            other.subprocess_id = this.subprocess_id;
	            other.is_mandatory = this.is_mandatory;
	            other.question_order = this.question_order;
	            other.risk_type = this.risk_type;
	            other.is_fraud = this.is_fraud;
	            other.is_linked = this.is_linked;
	            other.is_primary = this.is_primary;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.question_id = this.question_id;
	            other.linking_id = this.linking_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row6Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.question = readString(dis);
					
			        this.option_group_id = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.min_marks = null;
           				} else {
           			    	this.min_marks = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.max_marks = null;
           				} else {
           			    	this.max_marks = dis.readFloat();
           				}
					
			        this.checklist_id = dis.readInt();
					
			        this.category_id = dis.readInt();
					
						this.process_id = readInteger(dis);
					
						this.subprocess_id = readInteger(dis);
					
			        this.is_mandatory = dis.readInt();
					
						this.question_order = readInteger(dis);
					
					this.risk_type = readString(dis);
					
						this.is_fraud = readInteger(dis);
					
						this.is_linked = readInteger(dis);
					
						this.is_primary = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.question_id = readString(dis);
					
					this.linking_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.question = readString(dis);
					
			        this.option_group_id = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.min_marks = null;
           				} else {
           			    	this.min_marks = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.max_marks = null;
           				} else {
           			    	this.max_marks = dis.readFloat();
           				}
					
			        this.checklist_id = dis.readInt();
					
			        this.category_id = dis.readInt();
					
						this.process_id = readInteger(dis);
					
						this.subprocess_id = readInteger(dis);
					
			        this.is_mandatory = dis.readInt();
					
						this.question_order = readInteger(dis);
					
					this.risk_type = readString(dis);
					
						this.is_fraud = readInteger(dis);
					
						this.is_linked = readInteger(dis);
					
						this.is_primary = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.question_id = readString(dis);
					
					this.linking_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.question,dos);
					
					// int
				
		            	dos.writeInt(this.option_group_id);
					
					// Float
				
						if(this.min_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.min_marks);
		            	}
					
					// Float
				
						if(this.max_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.max_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.checklist_id);
					
					// int
				
		            	dos.writeInt(this.category_id);
					
					// Integer
				
						writeInteger(this.process_id,dos);
					
					// Integer
				
						writeInteger(this.subprocess_id,dos);
					
					// int
				
		            	dos.writeInt(this.is_mandatory);
					
					// Integer
				
						writeInteger(this.question_order,dos);
					
					// String
				
						writeString(this.risk_type,dos);
					
					// Integer
				
						writeInteger(this.is_fraud,dos);
					
					// Integer
				
						writeInteger(this.is_linked,dos);
					
					// Integer
				
						writeInteger(this.is_primary,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.question_id,dos);
					
					// String
				
						writeString(this.linking_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.question,dos);
					
					// int
				
		            	dos.writeInt(this.option_group_id);
					
					// Float
				
						if(this.min_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.min_marks);
		            	}
					
					// Float
				
						if(this.max_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.max_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.checklist_id);
					
					// int
				
		            	dos.writeInt(this.category_id);
					
					// Integer
				
						writeInteger(this.process_id,dos);
					
					// Integer
				
						writeInteger(this.subprocess_id,dos);
					
					// int
				
		            	dos.writeInt(this.is_mandatory);
					
					// Integer
				
						writeInteger(this.question_order,dos);
					
					// String
				
						writeString(this.risk_type,dos);
					
					// Integer
				
						writeInteger(this.is_fraud,dos);
					
					// Integer
				
						writeInteger(this.is_linked,dos);
					
					// Integer
				
						writeInteger(this.is_primary,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.question_id,dos);
					
					// String
				
						writeString(this.linking_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",question="+question);
		sb.append(",option_group_id="+String.valueOf(option_group_id));
		sb.append(",min_marks="+String.valueOf(min_marks));
		sb.append(",max_marks="+String.valueOf(max_marks));
		sb.append(",checklist_id="+String.valueOf(checklist_id));
		sb.append(",category_id="+String.valueOf(category_id));
		sb.append(",process_id="+String.valueOf(process_id));
		sb.append(",subprocess_id="+String.valueOf(subprocess_id));
		sb.append(",is_mandatory="+String.valueOf(is_mandatory));
		sb.append(",question_order="+String.valueOf(question_order));
		sb.append(",risk_type="+risk_type);
		sb.append(",is_fraud="+String.valueOf(is_fraud));
		sb.append(",is_linked="+String.valueOf(is_linked));
		sb.append(",is_primary="+String.valueOf(is_primary));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",question_id="+question_id);
		sb.append(",linking_id="+linking_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(question == null){
        					sb.append("<null>");
        				}else{
            				sb.append(question);
            			}
            		
        			sb.append("|");
        		
        				sb.append(option_group_id);
        			
        			sb.append("|");
        		
        				if(min_marks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(min_marks);
            			}
            		
        			sb.append("|");
        		
        				if(max_marks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(max_marks);
            			}
            		
        			sb.append("|");
        		
        				sb.append(checklist_id);
        			
        			sb.append("|");
        		
        				sb.append(category_id);
        			
        			sb.append("|");
        		
        				if(process_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_id);
            			}
            		
        			sb.append("|");
        		
        				if(subprocess_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(subprocess_id);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_mandatory);
        			
        			sb.append("|");
        		
        				if(question_order == null){
        					sb.append("<null>");
        				}else{
            				sb.append(question_order);
            			}
            		
        			sb.append("|");
        		
        				if(risk_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(risk_type);
            			}
            		
        			sb.append("|");
        		
        				if(is_fraud == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_fraud);
            			}
            		
        			sb.append("|");
        		
        				if(is_linked == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_linked);
            			}
            		
        			sb.append("|");
        		
        				if(is_primary == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_primary);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(question_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(question_id);
            			}
            		
        			sb.append("|");
        		
        				if(linking_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(linking_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_6");
		org.slf4j.MDC.put("_subJobPid", "htgaKa_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_6", false);
		start_Hash.put("tAsyncOut_tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row6");
			
		int tos_count_tAsyncOut_tDBOutput_6 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_6", "tAsyncOut_tDBOutput_6", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_6 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_6 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_6 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_6=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_6 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_6", pool_tAsyncOut_tDBOutput_6);
	final Object[] lockWrite_tAsyncOut_tDBOutput_6 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_6", lockWrite_tAsyncOut_tDBOutput_6);
 



/**
 * [tAsyncOut_tDBOutput_6 begin ] stop
 */



	
	/**
	 * [tDBInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_6", false);
		start_Hash.put("tDBInput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_questions\"";
		
		int tos_count_tDBInput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_6 = new StringBuilder();
                    log4jParamters_tDBInput_6.append("Parameters:");
                            log4jParamters_tDBInput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TABLE" + " = " + "\"mst_questions\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("QUERY" + " = " + "\"SELECT    `mst_questions`.`id`,    `mst_questions`.`question`,    `mst_questions`.`option_group_id`,    `mst_questions`.`min_marks`,    `mst_questions`.`max_marks`,    `mst_questions`.`checklist_id`,    `mst_questions`.`category_id`,    `mst_questions`.`process_id`,    `mst_questions`.`subprocess_id`,    `mst_questions`.`is_mandatory`,    `mst_questions`.`question_order`,    `mst_questions`.`risk_type`,    `mst_questions`.`is_fraud`,    `mst_questions`.`is_linked`,    `mst_questions`.`is_primary`,    `mst_questions`.`created_by`,    `mst_questions`.`created_on`,    `mst_questions`.`updated_by`,    `mst_questions`.`updated_on`,    `mst_questions`.`is_active`,    `mst_questions`.`is_deleted`,    `mst_questions`.`question_id`,    `mst_questions`.`linking_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_questions`\"");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("question")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_group_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("min_marks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("max_marks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("checklist_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("category_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("process_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("subprocess_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_mandatory")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("question_order")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("risk_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_fraud")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_linked")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_primary")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("question_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("linking_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_6.append(" | ");
                            log4jParamters_tDBInput_6.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + (log4jParamters_tDBInput_6) );
                    } 
                } 
            new BytesLimit65535_tDBInput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_6", "\"mst_questions\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_6 = java.util.Calendar.getInstance();
		    calendar_tDBInput_6.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_6 = calendar_tDBInput_6.getTime();
		    int nb_line_tDBInput_6 = 0;
		    java.sql.Connection conn_tDBInput_6 = null;
				conn_tDBInput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_6 != null) {
					if(conn_tDBInput_6.getMetaData() != null) {
						
							log.debug("tDBInput_6 - Uses an existing connection with username '" + conn_tDBInput_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_6.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_6 = conn_tDBInput_6.createStatement();
				if(stmt_tDBInput_6 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_6).enableStreamingResults();
				}else if(stmt_tDBInput_6 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_6).enableStreamingResults();
				}

		    String dbquery_tDBInput_6 = "SELECT \n  `mst_questions`.`id`, \n  `mst_questions`.`question`, \n  `mst_questions`.`option_group_id`, \n  `mst_questions`"
+".`min_marks`, \n  `mst_questions`.`max_marks`, \n  `mst_questions`.`checklist_id`, \n  `mst_questions`.`category_id`, \n  `m"
+"st_questions`.`process_id`, \n  `mst_questions`.`subprocess_id`, \n  `mst_questions`.`is_mandatory`, \n  `mst_questions`.`q"
+"uestion_order`, \n  `mst_questions`.`risk_type`, \n  `mst_questions`.`is_fraud`, \n  `mst_questions`.`is_linked`, \n  `mst_q"
+"uestions`.`is_primary`, \n  `mst_questions`.`created_by`, \n  `mst_questions`.`created_on`, \n  `mst_questions`.`updated_by"
+"`, \n  `mst_questions`.`updated_on`, \n  `mst_questions`.`is_active`, \n  `mst_questions`.`is_deleted`, \n  `mst_questions`."
+"`question_id`, \n  `mst_questions`.`linking_id`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_quest"
+"ions`";
		    
	    		log.debug("tDBInput_6 - Executing the query: '" + dbquery_tDBInput_6 + "'.");
			

            	globalMap.put("tDBInput_6_QUERY",dbquery_tDBInput_6);
		    java.sql.ResultSet rs_tDBInput_6 = null;

		    try {
		    	rs_tDBInput_6 = stmt_tDBInput_6.executeQuery(dbquery_tDBInput_6);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_6 = rs_tDBInput_6.getMetaData();
		    	int colQtyInRs_tDBInput_6 = rsmd_tDBInput_6.getColumnCount();

		    String tmpContent_tDBInput_6 = null;
		    
		    
		    	log.debug("tDBInput_6 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_6.next()) {
		        nb_line_tDBInput_6++;
		        
							if(colQtyInRs_tDBInput_6 < 1) {
								row6.id = 0;
							} else {
		                          
            row6.id = rs_tDBInput_6.getInt(1);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 2) {
								row6.question = null;
							} else {
	                         		
        	row6.question = routines.system.JDBCUtil.getString(rs_tDBInput_6, 2, false);
		                    }
							if(colQtyInRs_tDBInput_6 < 3) {
								row6.option_group_id = 0;
							} else {
		                          
            row6.option_group_id = rs_tDBInput_6.getInt(3);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 4) {
								row6.min_marks = null;
							} else {
		                          
            row6.min_marks = rs_tDBInput_6.getFloat(4);
            if(rs_tDBInput_6.wasNull()){
                    row6.min_marks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 5) {
								row6.max_marks = null;
							} else {
		                          
            row6.max_marks = rs_tDBInput_6.getFloat(5);
            if(rs_tDBInput_6.wasNull()){
                    row6.max_marks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 6) {
								row6.checklist_id = 0;
							} else {
		                          
            row6.checklist_id = rs_tDBInput_6.getInt(6);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 7) {
								row6.category_id = 0;
							} else {
		                          
            row6.category_id = rs_tDBInput_6.getInt(7);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 8) {
								row6.process_id = null;
							} else {
		                          
            row6.process_id = rs_tDBInput_6.getInt(8);
            if(rs_tDBInput_6.wasNull()){
                    row6.process_id = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 9) {
								row6.subprocess_id = null;
							} else {
		                          
            row6.subprocess_id = rs_tDBInput_6.getInt(9);
            if(rs_tDBInput_6.wasNull()){
                    row6.subprocess_id = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 10) {
								row6.is_mandatory = 0;
							} else {
		                          
            row6.is_mandatory = rs_tDBInput_6.getInt(10);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 11) {
								row6.question_order = null;
							} else {
		                          
            row6.question_order = rs_tDBInput_6.getInt(11);
            if(rs_tDBInput_6.wasNull()){
                    row6.question_order = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 12) {
								row6.risk_type = null;
							} else {
	                         		
        	row6.risk_type = routines.system.JDBCUtil.getString(rs_tDBInput_6, 12, false);
		                    }
							if(colQtyInRs_tDBInput_6 < 13) {
								row6.is_fraud = null;
							} else {
		                          
            row6.is_fraud = rs_tDBInput_6.getInt(13);
            if(rs_tDBInput_6.wasNull()){
                    row6.is_fraud = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 14) {
								row6.is_linked = null;
							} else {
		                          
            row6.is_linked = rs_tDBInput_6.getInt(14);
            if(rs_tDBInput_6.wasNull()){
                    row6.is_linked = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 15) {
								row6.is_primary = null;
							} else {
		                          
            row6.is_primary = rs_tDBInput_6.getInt(15);
            if(rs_tDBInput_6.wasNull()){
                    row6.is_primary = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 16) {
								row6.created_by = null;
							} else {
		                          
            row6.created_by = rs_tDBInput_6.getInt(16);
            if(rs_tDBInput_6.wasNull()){
                    row6.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 17) {
								row6.created_on = null;
							} else {
										
				if(rs_tDBInput_6.getString(17) != null) {
					String dateString_tDBInput_6 = rs_tDBInput_6.getString(17);
					if (!("0000-00-00").equals(dateString_tDBInput_6) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_6)) {
						row6.created_on = rs_tDBInput_6.getTimestamp(17);
					} else {
						row6.created_on = (java.util.Date) year0_tDBInput_6.clone();
					}
				} else {
					row6.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_6 < 18) {
								row6.updated_by = null;
							} else {
		                          
            row6.updated_by = rs_tDBInput_6.getInt(18);
            if(rs_tDBInput_6.wasNull()){
                    row6.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 19) {
								row6.updated_on = null;
							} else {
										
				if(rs_tDBInput_6.getString(19) != null) {
					String dateString_tDBInput_6 = rs_tDBInput_6.getString(19);
					if (!("0000-00-00").equals(dateString_tDBInput_6) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_6)) {
						row6.updated_on = rs_tDBInput_6.getTimestamp(19);
					} else {
						row6.updated_on = (java.util.Date) year0_tDBInput_6.clone();
					}
				} else {
					row6.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_6 < 20) {
								row6.is_active = 0;
							} else {
		                          
            row6.is_active = rs_tDBInput_6.getInt(20);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 21) {
								row6.is_deleted = 0;
							} else {
		                          
            row6.is_deleted = rs_tDBInput_6.getInt(21);
            if(rs_tDBInput_6.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_6 < 22) {
								row6.question_id = null;
							} else {
	                         		
        	row6.question_id = routines.system.JDBCUtil.getString(rs_tDBInput_6, 22, false);
		                    }
							if(colQtyInRs_tDBInput_6 < 23) {
								row6.linking_id = null;
							} else {
	                         		
        	row6.linking_id = routines.system.JDBCUtil.getString(rs_tDBInput_6, 23, false);
		                    }
							if(colQtyInRs_tDBInput_6 < 24) {
								row6.as_on = null;
							} else {
										
				if(rs_tDBInput_6.getString(24) != null) {
					String dateString_tDBInput_6 = rs_tDBInput_6.getString(24);
					if (!("0000-00-00").equals(dateString_tDBInput_6) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_6)) {
						row6.as_on = rs_tDBInput_6.getTimestamp(24);
					} else {
						row6.as_on = (java.util.Date) year0_tDBInput_6.clone();
					}
				} else {
					row6.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_6 - Retrieving the record " + nb_line_tDBInput_6 + ".");
					

 



/**
 * [tDBInput_6 begin ] stop
 */
	
	/**
	 * [tDBInput_6 main ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_questions\"";
		

 


	tos_count_tDBInput_6++;

/**
 * [tDBInput_6 main ] stop
 */
	
	/**
	 * [tDBInput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_questions\"";
		

 



/**
 * [tDBInput_6 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row6","tDBInput_6","\"mst_questions\"","tMysqlInput","tAsyncOut_tDBOutput_6","tAsyncOut_tDBOutput_6","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_6=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_6[0] = String.valueOf(row6.id); 
	if(row6.question != null){
		row_tAsyncOut_tDBOutput_6[1] = row6.question;                			    
	}
	row_tAsyncOut_tDBOutput_6[2] = String.valueOf(row6.option_group_id); 
	if(row6.min_marks != null){
		row_tAsyncOut_tDBOutput_6[3] = String.valueOf(row6.min_marks);                			    
	}
	if(row6.max_marks != null){
		row_tAsyncOut_tDBOutput_6[4] = String.valueOf(row6.max_marks);                			    
	}
	row_tAsyncOut_tDBOutput_6[5] = String.valueOf(row6.checklist_id); 
	row_tAsyncOut_tDBOutput_6[6] = String.valueOf(row6.category_id); 
	if(row6.process_id != null){
		row_tAsyncOut_tDBOutput_6[7] = String.valueOf(row6.process_id);                			    
	}
	if(row6.subprocess_id != null){
		row_tAsyncOut_tDBOutput_6[8] = String.valueOf(row6.subprocess_id);                			    
	}
	row_tAsyncOut_tDBOutput_6[9] = String.valueOf(row6.is_mandatory); 
	if(row6.question_order != null){
		row_tAsyncOut_tDBOutput_6[10] = String.valueOf(row6.question_order);                			    
	}
	if(row6.risk_type != null){
		row_tAsyncOut_tDBOutput_6[11] = row6.risk_type;                			    
	}
	if(row6.is_fraud != null){
		row_tAsyncOut_tDBOutput_6[12] = String.valueOf(row6.is_fraud);                			    
	}
	if(row6.is_linked != null){
		row_tAsyncOut_tDBOutput_6[13] = String.valueOf(row6.is_linked);                			    
	}
	if(row6.is_primary != null){
		row_tAsyncOut_tDBOutput_6[14] = String.valueOf(row6.is_primary);                			    
	}
	if(row6.created_by != null){
		row_tAsyncOut_tDBOutput_6[15] = String.valueOf(row6.created_by);                			    
	}
	if(row6.created_on != null){
		row_tAsyncOut_tDBOutput_6[16] = row6.created_on;                			    
	}
	if(row6.updated_by != null){
		row_tAsyncOut_tDBOutput_6[17] = String.valueOf(row6.updated_by);                			    
	}
	if(row6.updated_on != null){
		row_tAsyncOut_tDBOutput_6[18] = row6.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_6[19] = String.valueOf(row6.is_active); 
	row_tAsyncOut_tDBOutput_6[20] = String.valueOf(row6.is_deleted); 
	if(row6.question_id != null){
		row_tAsyncOut_tDBOutput_6[21] = row6.question_id;                			    
	}
	if(row6.linking_id != null){
		row_tAsyncOut_tDBOutput_6[22] = row6.linking_id;                			    
	}
	if(row6.as_on != null){
		row_tAsyncOut_tDBOutput_6[23] = row6.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_6 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_6", buffers_tAsyncOut_tDBOutput_6);
		/*tAsyncIn_tDBOutput_10Process(globalMap);*/
		tAsyncIn_tDBOutput_6Process(globalMap);
		buffers_tAsyncOut_tDBOutput_6 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_6 = 0;
	}
	buffers_tAsyncOut_tDBOutput_6.add(row_tAsyncOut_tDBOutput_6);
	index_tAsyncOut_tDBOutput_6++;
 


	tos_count_tAsyncOut_tDBOutput_6++;

/**
 * [tAsyncOut_tDBOutput_6 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	

 



/**
 * [tAsyncOut_tDBOutput_6 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	

 



/**
 * [tAsyncOut_tDBOutput_6 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_questions\"";
		

 



/**
 * [tDBInput_6 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_6 end ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_questions\"";
		

	}
}finally{
	if (rs_tDBInput_6 != null) {
		rs_tDBInput_6.close();
	}
	if (stmt_tDBInput_6 != null) {
		stmt_tDBInput_6.close();
	}
}

		   globalMap.put("tDBInput_6_NB_LINE",nb_line_tDBInput_6);
		

	    		log.debug("tDBInput_6 - Retrieved records count: "+nb_line_tDBInput_6 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_6 - "  + ("Done.") );

ok_Hash.put("tDBInput_6", true);
end_Hash.put("tDBInput_6", System.currentTimeMillis());




/**
 * [tDBInput_6 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	


	if (buffers_tAsyncOut_tDBOutput_6.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_6", buffers_tAsyncOut_tDBOutput_6);
	    tAsyncIn_tDBOutput_6Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_6.waitForEnd();
	pool_tAsyncOut_tDBOutput_6.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row6",2,0,
			 			"tDBInput_6","\"mst_questions\"","tMysqlInput","tAsyncOut_tDBOutput_6","tAsyncOut_tDBOutput_6","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_6", true);
end_Hash.put("tAsyncOut_tDBOutput_6", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_6 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_6";
	
	
			cLabel="\"mst_questions\"";
		

 



/**
 * [tDBInput_6 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_6";
	
	

 



/**
 * [tAsyncOut_tDBOutput_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_6_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String region;

				public String getRegion () {
					return this.region;
				}

				public Boolean regionIsNullable(){
				    return false;
				}
				public Boolean regionIsKey(){
				    return false;
				}
				public Integer regionLength(){
				    return 45;
				}
				public Integer regionPrecision(){
				    return 0;
				}
				public String regionDefault(){
				
					return null;
				
				}
				public String regionComment(){
				
				    return "";
				
				}
				public String regionPattern(){
				
					return "";
				
				}
				public String regionOriginalDbColumnName(){
				
					return "region";
				
				}

				
			    public int division_id;

				public int getDivision_id () {
					return this.division_id;
				}

				public Boolean division_idIsNullable(){
				    return false;
				}
				public Boolean division_idIsKey(){
				    return false;
				}
				public Integer division_idLength(){
				    return 10;
				}
				public Integer division_idPrecision(){
				    return 0;
				}
				public String division_idDefault(){
				
					return null;
				
				}
				public String division_idComment(){
				
				    return "";
				
				}
				public String division_idPattern(){
				
					return "";
				
				}
				public String division_idOriginalDbColumnName(){
				
					return "division_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String region_id;

				public String getRegion_id () {
					return this.region_id;
				}

				public Boolean region_idIsNullable(){
				    return true;
				}
				public Boolean region_idIsKey(){
				    return false;
				}
				public Integer region_idLength(){
				    return 32;
				}
				public Integer region_idPrecision(){
				    return 0;
				}
				public String region_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String region_idComment(){
				
				    return "";
				
				}
				public String region_idPattern(){
				
					return "";
				
				}
				public String region_idOriginalDbColumnName(){
				
					return "region_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row7Struct other = (row7Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row7Struct other) {

		other.id = this.id;
	            other.region = this.region;
	            other.division_id = this.division_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.region_id = this.region_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row7Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
			        this.division_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.region_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
			        this.division_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.region_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// int
				
		            	dos.writeInt(this.division_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.region_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// int
				
		            	dos.writeInt(this.division_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.region_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",region="+region);
		sb.append(",division_id="+String.valueOf(division_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",region_id="+region_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(region == null){
        					sb.append("<null>");
        				}else{
            				sb.append(region);
            			}
            		
        			sb.append("|");
        		
        				sb.append(division_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(region_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(region_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_7");
		org.slf4j.MDC.put("_subJobPid", "z9NzPn_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_7", false);
		start_Hash.put("tAsyncOut_tDBOutput_7", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row7");
			
		int tos_count_tAsyncOut_tDBOutput_7 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_7", "tAsyncOut_tDBOutput_7", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_7 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_7 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_7 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_7=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_7 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_7", pool_tAsyncOut_tDBOutput_7);
	final Object[] lockWrite_tAsyncOut_tDBOutput_7 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_7", lockWrite_tAsyncOut_tDBOutput_7);
 



/**
 * [tAsyncOut_tDBOutput_7 begin ] stop
 */



	
	/**
	 * [tDBInput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_7", false);
		start_Hash.put("tDBInput_7", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_region\"";
		
		int tos_count_tDBInput_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_7 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_7{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_7 = new StringBuilder();
                    log4jParamters_tDBInput_7.append("Parameters:");
                            log4jParamters_tDBInput_7.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("TABLE" + " = " + "\"mst_region\"");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("QUERY" + " = " + "\"SELECT    `mst_region`.`id`,    `mst_region`.`region`,    `mst_region`.`division_id`,    `mst_region`.`created_by`,    `mst_region`.`created_on`,    `mst_region`.`updated_by`,    `mst_region`.`updated_on`,    `mst_region`.`is_active`,    `mst_region`.`is_deleted`,    `mst_region`.`region_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_region`\"");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("region")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("division_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("region_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_7 - "  + (log4jParamters_tDBInput_7) );
                    } 
                } 
            new BytesLimit65535_tDBInput_7().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_7", "\"mst_region\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_7 = java.util.Calendar.getInstance();
		    calendar_tDBInput_7.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_7 = calendar_tDBInput_7.getTime();
		    int nb_line_tDBInput_7 = 0;
		    java.sql.Connection conn_tDBInput_7 = null;
				conn_tDBInput_7 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_7 != null) {
					if(conn_tDBInput_7.getMetaData() != null) {
						
							log.debug("tDBInput_7 - Uses an existing connection with username '" + conn_tDBInput_7.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_7.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_7 = conn_tDBInput_7.createStatement();
				if(stmt_tDBInput_7 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_7).enableStreamingResults();
				}else if(stmt_tDBInput_7 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_7).enableStreamingResults();
				}

		    String dbquery_tDBInput_7 = "SELECT \n  `mst_region`.`id`, \n  `mst_region`.`region`, \n  `mst_region`.`division_id`, \n  `mst_region`.`created_by`, \n  "
+"`mst_region`.`created_on`, \n  `mst_region`.`updated_by`, \n  `mst_region`.`updated_on`, \n  `mst_region`.`is_active`, \n  `"
+"mst_region`.`is_deleted`, \n  `mst_region`.`region_id`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `ms"
+"t_region`";
		    
	    		log.debug("tDBInput_7 - Executing the query: '" + dbquery_tDBInput_7 + "'.");
			

            	globalMap.put("tDBInput_7_QUERY",dbquery_tDBInput_7);
		    java.sql.ResultSet rs_tDBInput_7 = null;

		    try {
		    	rs_tDBInput_7 = stmt_tDBInput_7.executeQuery(dbquery_tDBInput_7);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_7 = rs_tDBInput_7.getMetaData();
		    	int colQtyInRs_tDBInput_7 = rsmd_tDBInput_7.getColumnCount();

		    String tmpContent_tDBInput_7 = null;
		    
		    
		    	log.debug("tDBInput_7 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_7.next()) {
		        nb_line_tDBInput_7++;
		        
							if(colQtyInRs_tDBInput_7 < 1) {
								row7.id = 0;
							} else {
		                          
            row7.id = rs_tDBInput_7.getInt(1);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 2) {
								row7.region = null;
							} else {
	                         		
        	row7.region = routines.system.JDBCUtil.getString(rs_tDBInput_7, 2, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 3) {
								row7.division_id = 0;
							} else {
		                          
            row7.division_id = rs_tDBInput_7.getInt(3);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 4) {
								row7.created_by = null;
							} else {
		                          
            row7.created_by = rs_tDBInput_7.getInt(4);
            if(rs_tDBInput_7.wasNull()){
                    row7.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 5) {
								row7.created_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(5) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(5);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row7.created_on = rs_tDBInput_7.getTimestamp(5);
					} else {
						row7.created_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row7.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_7 < 6) {
								row7.updated_by = null;
							} else {
		                          
            row7.updated_by = rs_tDBInput_7.getInt(6);
            if(rs_tDBInput_7.wasNull()){
                    row7.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 7) {
								row7.updated_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(7) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(7);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row7.updated_on = rs_tDBInput_7.getTimestamp(7);
					} else {
						row7.updated_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row7.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_7 < 8) {
								row7.is_active = 0;
							} else {
		                          
            row7.is_active = rs_tDBInput_7.getInt(8);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 9) {
								row7.is_deleted = 0;
							} else {
		                          
            row7.is_deleted = rs_tDBInput_7.getInt(9);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 10) {
								row7.region_id = null;
							} else {
	                         		
        	row7.region_id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 10, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 11) {
								row7.as_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(11) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(11);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row7.as_on = rs_tDBInput_7.getTimestamp(11);
					} else {
						row7.as_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row7.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_7 - Retrieving the record " + nb_line_tDBInput_7 + ".");
					

 



/**
 * [tDBInput_7 begin ] stop
 */
	
	/**
	 * [tDBInput_7 main ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_region\"";
		

 


	tos_count_tDBInput_7++;

/**
 * [tDBInput_7 main ] stop
 */
	
	/**
	 * [tDBInput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_region\"";
		

 



/**
 * [tDBInput_7 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_7 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row7","tDBInput_7","\"mst_region\"","tMysqlInput","tAsyncOut_tDBOutput_7","tAsyncOut_tDBOutput_7","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_7=new Object[]{null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_7[0] = String.valueOf(row7.id); 
	if(row7.region != null){
		row_tAsyncOut_tDBOutput_7[1] = row7.region;                			    
	}
	row_tAsyncOut_tDBOutput_7[2] = String.valueOf(row7.division_id); 
	if(row7.created_by != null){
		row_tAsyncOut_tDBOutput_7[3] = String.valueOf(row7.created_by);                			    
	}
	if(row7.created_on != null){
		row_tAsyncOut_tDBOutput_7[4] = row7.created_on;                			    
	}
	if(row7.updated_by != null){
		row_tAsyncOut_tDBOutput_7[5] = String.valueOf(row7.updated_by);                			    
	}
	if(row7.updated_on != null){
		row_tAsyncOut_tDBOutput_7[6] = row7.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_7[7] = String.valueOf(row7.is_active); 
	row_tAsyncOut_tDBOutput_7[8] = String.valueOf(row7.is_deleted); 
	if(row7.region_id != null){
		row_tAsyncOut_tDBOutput_7[9] = row7.region_id;                			    
	}
	if(row7.as_on != null){
		row_tAsyncOut_tDBOutput_7[10] = row7.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_7 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_7", buffers_tAsyncOut_tDBOutput_7);
		/*tAsyncIn_tDBOutput_10Process(globalMap);*/
		tAsyncIn_tDBOutput_7Process(globalMap);
		buffers_tAsyncOut_tDBOutput_7 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_7 = 0;
	}
	buffers_tAsyncOut_tDBOutput_7.add(row_tAsyncOut_tDBOutput_7);
	index_tAsyncOut_tDBOutput_7++;
 


	tos_count_tAsyncOut_tDBOutput_7++;

/**
 * [tAsyncOut_tDBOutput_7 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	

 



/**
 * [tAsyncOut_tDBOutput_7 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	

 



/**
 * [tAsyncOut_tDBOutput_7 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_region\"";
		

 



/**
 * [tDBInput_7 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_7 end ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_region\"";
		

	}
}finally{
	if (rs_tDBInput_7 != null) {
		rs_tDBInput_7.close();
	}
	if (stmt_tDBInput_7 != null) {
		stmt_tDBInput_7.close();
	}
}

		   globalMap.put("tDBInput_7_NB_LINE",nb_line_tDBInput_7);
		

	    		log.debug("tDBInput_7 - Retrieved records count: "+nb_line_tDBInput_7 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_7 - "  + ("Done.") );

ok_Hash.put("tDBInput_7", true);
end_Hash.put("tDBInput_7", System.currentTimeMillis());




/**
 * [tDBInput_7 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_7 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	


	if (buffers_tAsyncOut_tDBOutput_7.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_7", buffers_tAsyncOut_tDBOutput_7);
	    tAsyncIn_tDBOutput_7Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_7.waitForEnd();
	pool_tAsyncOut_tDBOutput_7.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row7",2,0,
			 			"tDBInput_7","\"mst_region\"","tMysqlInput","tAsyncOut_tDBOutput_7","tAsyncOut_tDBOutput_7","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_7", true);
end_Hash.put("tAsyncOut_tDBOutput_7", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_7 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_7 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"mst_region\"";
		

 



/**
 * [tDBInput_7 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_7 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_7";
	
	

 



/**
 * [tAsyncOut_tDBOutput_7 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_7_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return false;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 45;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				
			    public String description;

				public String getDescription () {
					return this.description;
				}

				public Boolean descriptionIsNullable(){
				    return true;
				}
				public Boolean descriptionIsKey(){
				    return false;
				}
				public Integer descriptionLength(){
				    return 2147483647;
				}
				public Integer descriptionPrecision(){
				    return 0;
				}
				public String descriptionDefault(){
				
					return null;
				
				}
				public String descriptionComment(){
				
				    return "";
				
				}
				public String descriptionPattern(){
				
					return "";
				
				}
				public String descriptionOriginalDbColumnName(){
				
					return "description";
				
				}

				
			    public int user_type;

				public int getUser_type () {
					return this.user_type;
				}

				public Boolean user_typeIsNullable(){
				    return false;
				}
				public Boolean user_typeIsKey(){
				    return false;
				}
				public Integer user_typeLength(){
				    return 10;
				}
				public Integer user_typePrecision(){
				    return 0;
				}
				public String user_typeDefault(){
				
					return "0";
				
				}
				public String user_typeComment(){
				
				    return "";
				
				}
				public String user_typePattern(){
				
					return "";
				
				}
				public String user_typeOriginalDbColumnName(){
				
					return "user_type";
				
				}

				
			    public String access_level;

				public String getAccess_level () {
					return this.access_level;
				}

				public Boolean access_levelIsNullable(){
				    return true;
				}
				public Boolean access_levelIsKey(){
				    return false;
				}
				public Integer access_levelLength(){
				    return 45;
				}
				public Integer access_levelPrecision(){
				    return 0;
				}
				public String access_levelDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String access_levelComment(){
				
				    return "";
				
				}
				public String access_levelPattern(){
				
					return "";
				
				}
				public String access_levelOriginalDbColumnName(){
				
					return "access_level";
				
				}

				
			    public Integer role_code;

				public Integer getRole_code () {
					return this.role_code;
				}

				public Boolean role_codeIsNullable(){
				    return true;
				}
				public Boolean role_codeIsKey(){
				    return false;
				}
				public Integer role_codeLength(){
				    return 10;
				}
				public Integer role_codePrecision(){
				    return 0;
				}
				public String role_codeDefault(){
				
					return null;
				
				}
				public String role_codeComment(){
				
				    return "";
				
				}
				public String role_codePattern(){
				
					return "";
				
				}
				public String role_codeOriginalDbColumnName(){
				
					return "role_code";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'now()'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'now()'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String role_id;

				public String getRole_id () {
					return this.role_id;
				}

				public Boolean role_idIsNullable(){
				    return true;
				}
				public Boolean role_idIsKey(){
				    return false;
				}
				public Integer role_idLength(){
				    return 32;
				}
				public Integer role_idPrecision(){
				    return 0;
				}
				public String role_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String role_idComment(){
				
				    return "";
				
				}
				public String role_idPattern(){
				
					return "";
				
				}
				public String role_idOriginalDbColumnName(){
				
					return "role_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row8Struct other = (row8Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row8Struct other) {

		other.id = this.id;
	            other.name = this.name;
	            other.description = this.description;
	            other.user_type = this.user_type;
	            other.access_level = this.access_level;
	            other.role_code = this.role_code;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.role_id = this.role_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row8Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.name = readString(dis);
					
					this.description = readString(dis);
					
			        this.user_type = dis.readInt();
					
					this.access_level = readString(dis);
					
						this.role_code = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.role_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.name = readString(dis);
					
					this.description = readString(dis);
					
			        this.user_type = dis.readInt();
					
					this.access_level = readString(dis);
					
						this.role_code = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.role_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// int
				
		            	dos.writeInt(this.user_type);
					
					// String
				
						writeString(this.access_level,dos);
					
					// Integer
				
						writeInteger(this.role_code,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.role_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// int
				
		            	dos.writeInt(this.user_type);
					
					// String
				
						writeString(this.access_level,dos);
					
					// Integer
				
						writeInteger(this.role_code,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.role_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",name="+name);
		sb.append(",description="+description);
		sb.append(",user_type="+String.valueOf(user_type));
		sb.append(",access_level="+access_level);
		sb.append(",role_code="+String.valueOf(role_code));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",role_id="+role_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        				if(description == null){
        					sb.append("<null>");
        				}else{
            				sb.append(description);
            			}
            		
        			sb.append("|");
        		
        				sb.append(user_type);
        			
        			sb.append("|");
        		
        				if(access_level == null){
        					sb.append("<null>");
        				}else{
            				sb.append(access_level);
            			}
            		
        			sb.append("|");
        		
        				if(role_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(role_code);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(role_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(role_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_8");
		org.slf4j.MDC.put("_subJobPid", "vEVZU5_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row8Struct row8 = new row8Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_8", false);
		start_Hash.put("tAsyncOut_tDBOutput_8", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_8";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row8");
			
		int tos_count_tAsyncOut_tDBOutput_8 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_8", "tAsyncOut_tDBOutput_8", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_8 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_8 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_8 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_8=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_8 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_8", pool_tAsyncOut_tDBOutput_8);
	final Object[] lockWrite_tAsyncOut_tDBOutput_8 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_8", lockWrite_tAsyncOut_tDBOutput_8);
 



/**
 * [tAsyncOut_tDBOutput_8 begin ] stop
 */



	
	/**
	 * [tDBInput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_8", false);
		start_Hash.put("tDBInput_8", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_8";
	
	
			cLabel="\"mst_role\"";
		
		int tos_count_tDBInput_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_8 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_8{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_8 = new StringBuilder();
                    log4jParamters_tDBInput_8.append("Parameters:");
                            log4jParamters_tDBInput_8.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_8.append(" | ");
                            log4jParamters_tDBInput_8.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_8.append(" | ");
                            log4jParamters_tDBInput_8.append("TABLE" + " = " + "\"mst_role\"");
                        log4jParamters_tDBInput_8.append(" | ");
                            log4jParamters_tDBInput_8.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_8.append(" | ");
                            log4jParamters_tDBInput_8.append("QUERY" + " = " + "\"SELECT    `mst_role`.`id`,    `mst_role`.`name`,    `mst_role`.`description`,    `mst_role`.`user_type`,    `mst_role`.`access_level`,    `mst_role`.`role_code`,    `mst_role`.`created_by`,    `mst_role`.`created_on`,    `mst_role`.`updated_by`,    `mst_role`.`updated_on`,    `mst_role`.`is_active`,    `mst_role`.`is_deleted`,    `mst_role`.`role_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_role`\"");
                        log4jParamters_tDBInput_8.append(" | ");
                            log4jParamters_tDBInput_8.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_8.append(" | ");
                            log4jParamters_tDBInput_8.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_8.append(" | ");
                            log4jParamters_tDBInput_8.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("description")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("user_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("access_level")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("role_code")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("role_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_8.append(" | ");
                            log4jParamters_tDBInput_8.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_8 - "  + (log4jParamters_tDBInput_8) );
                    } 
                } 
            new BytesLimit65535_tDBInput_8().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_8", "\"mst_role\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_8 = java.util.Calendar.getInstance();
		    calendar_tDBInput_8.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_8 = calendar_tDBInput_8.getTime();
		    int nb_line_tDBInput_8 = 0;
		    java.sql.Connection conn_tDBInput_8 = null;
				conn_tDBInput_8 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_8 != null) {
					if(conn_tDBInput_8.getMetaData() != null) {
						
							log.debug("tDBInput_8 - Uses an existing connection with username '" + conn_tDBInput_8.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_8.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_8 = conn_tDBInput_8.createStatement();
				if(stmt_tDBInput_8 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_8).enableStreamingResults();
				}else if(stmt_tDBInput_8 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_8).enableStreamingResults();
				}

		    String dbquery_tDBInput_8 = "SELECT \n  `mst_role`.`id`, \n  `mst_role`.`name`, \n  `mst_role`.`description`, \n  `mst_role`.`user_type`, \n  `mst_role`."
+"`access_level`, \n  `mst_role`.`role_code`, \n  `mst_role`.`created_by`, \n  `mst_role`.`created_on`, \n  `mst_role`.`update"
+"d_by`, \n  `mst_role`.`updated_on`, \n  `mst_role`.`is_active`, \n  `mst_role`.`is_deleted`, \n  `mst_role`.`role_id`,\n	DAT"
+"E_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_role`";
		    
	    		log.debug("tDBInput_8 - Executing the query: '" + dbquery_tDBInput_8 + "'.");
			

            	globalMap.put("tDBInput_8_QUERY",dbquery_tDBInput_8);
		    java.sql.ResultSet rs_tDBInput_8 = null;

		    try {
		    	rs_tDBInput_8 = stmt_tDBInput_8.executeQuery(dbquery_tDBInput_8);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_8 = rs_tDBInput_8.getMetaData();
		    	int colQtyInRs_tDBInput_8 = rsmd_tDBInput_8.getColumnCount();

		    String tmpContent_tDBInput_8 = null;
		    
		    
		    	log.debug("tDBInput_8 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_8.next()) {
		        nb_line_tDBInput_8++;
		        
							if(colQtyInRs_tDBInput_8 < 1) {
								row8.id = 0;
							} else {
		                          
            row8.id = rs_tDBInput_8.getInt(1);
            if(rs_tDBInput_8.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 2) {
								row8.name = null;
							} else {
	                         		
        	row8.name = routines.system.JDBCUtil.getString(rs_tDBInput_8, 2, false);
		                    }
							if(colQtyInRs_tDBInput_8 < 3) {
								row8.description = null;
							} else {
	                         		
        	row8.description = routines.system.JDBCUtil.getString(rs_tDBInput_8, 3, false);
		                    }
							if(colQtyInRs_tDBInput_8 < 4) {
								row8.user_type = 0;
							} else {
		                          
            row8.user_type = rs_tDBInput_8.getInt(4);
            if(rs_tDBInput_8.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 5) {
								row8.access_level = null;
							} else {
	                         		
        	row8.access_level = routines.system.JDBCUtil.getString(rs_tDBInput_8, 5, false);
		                    }
							if(colQtyInRs_tDBInput_8 < 6) {
								row8.role_code = null;
							} else {
		                          
            row8.role_code = rs_tDBInput_8.getInt(6);
            if(rs_tDBInput_8.wasNull()){
                    row8.role_code = null;
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 7) {
								row8.created_by = null;
							} else {
		                          
            row8.created_by = rs_tDBInput_8.getInt(7);
            if(rs_tDBInput_8.wasNull()){
                    row8.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 8) {
								row8.created_on = null;
							} else {
										
				if(rs_tDBInput_8.getString(8) != null) {
					String dateString_tDBInput_8 = rs_tDBInput_8.getString(8);
					if (!("0000-00-00").equals(dateString_tDBInput_8) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_8)) {
						row8.created_on = rs_tDBInput_8.getTimestamp(8);
					} else {
						row8.created_on = (java.util.Date) year0_tDBInput_8.clone();
					}
				} else {
					row8.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_8 < 9) {
								row8.updated_by = null;
							} else {
		                          
            row8.updated_by = rs_tDBInput_8.getInt(9);
            if(rs_tDBInput_8.wasNull()){
                    row8.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 10) {
								row8.updated_on = null;
							} else {
										
				if(rs_tDBInput_8.getString(10) != null) {
					String dateString_tDBInput_8 = rs_tDBInput_8.getString(10);
					if (!("0000-00-00").equals(dateString_tDBInput_8) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_8)) {
						row8.updated_on = rs_tDBInput_8.getTimestamp(10);
					} else {
						row8.updated_on = (java.util.Date) year0_tDBInput_8.clone();
					}
				} else {
					row8.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_8 < 11) {
								row8.is_active = 0;
							} else {
		                          
            row8.is_active = rs_tDBInput_8.getInt(11);
            if(rs_tDBInput_8.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 12) {
								row8.is_deleted = 0;
							} else {
		                          
            row8.is_deleted = rs_tDBInput_8.getInt(12);
            if(rs_tDBInput_8.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_8 < 13) {
								row8.role_id = null;
							} else {
	                         		
        	row8.role_id = routines.system.JDBCUtil.getString(rs_tDBInput_8, 13, false);
		                    }
							if(colQtyInRs_tDBInput_8 < 14) {
								row8.as_on = null;
							} else {
										
				if(rs_tDBInput_8.getString(14) != null) {
					String dateString_tDBInput_8 = rs_tDBInput_8.getString(14);
					if (!("0000-00-00").equals(dateString_tDBInput_8) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_8)) {
						row8.as_on = rs_tDBInput_8.getTimestamp(14);
					} else {
						row8.as_on = (java.util.Date) year0_tDBInput_8.clone();
					}
				} else {
					row8.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_8 - Retrieving the record " + nb_line_tDBInput_8 + ".");
					

 



/**
 * [tDBInput_8 begin ] stop
 */
	
	/**
	 * [tDBInput_8 main ] start
	 */

	

	
	
	currentComponent="tDBInput_8";
	
	
			cLabel="\"mst_role\"";
		

 


	tos_count_tDBInput_8++;

/**
 * [tDBInput_8 main ] stop
 */
	
	/**
	 * [tDBInput_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_8";
	
	
			cLabel="\"mst_role\"";
		

 



/**
 * [tDBInput_8 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_8 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_8";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row8","tDBInput_8","\"mst_role\"","tMysqlInput","tAsyncOut_tDBOutput_8","tAsyncOut_tDBOutput_8","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_8=new Object[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_8[0] = String.valueOf(row8.id); 
	if(row8.name != null){
		row_tAsyncOut_tDBOutput_8[1] = row8.name;                			    
	}
	if(row8.description != null){
		row_tAsyncOut_tDBOutput_8[2] = row8.description;                			    
	}
	row_tAsyncOut_tDBOutput_8[3] = String.valueOf(row8.user_type); 
	if(row8.access_level != null){
		row_tAsyncOut_tDBOutput_8[4] = row8.access_level;                			    
	}
	if(row8.role_code != null){
		row_tAsyncOut_tDBOutput_8[5] = String.valueOf(row8.role_code);                			    
	}
	if(row8.created_by != null){
		row_tAsyncOut_tDBOutput_8[6] = String.valueOf(row8.created_by);                			    
	}
	if(row8.created_on != null){
		row_tAsyncOut_tDBOutput_8[7] = row8.created_on;                			    
	}
	if(row8.updated_by != null){
		row_tAsyncOut_tDBOutput_8[8] = String.valueOf(row8.updated_by);                			    
	}
	if(row8.updated_on != null){
		row_tAsyncOut_tDBOutput_8[9] = row8.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_8[10] = String.valueOf(row8.is_active); 
	row_tAsyncOut_tDBOutput_8[11] = String.valueOf(row8.is_deleted); 
	if(row8.role_id != null){
		row_tAsyncOut_tDBOutput_8[12] = row8.role_id;                			    
	}
	if(row8.as_on != null){
		row_tAsyncOut_tDBOutput_8[13] = row8.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_8 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_8", buffers_tAsyncOut_tDBOutput_8);
		/*tAsyncIn_tDBOutput_10Process(globalMap);*/
		tAsyncIn_tDBOutput_8Process(globalMap);
		buffers_tAsyncOut_tDBOutput_8 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_8 = 0;
	}
	buffers_tAsyncOut_tDBOutput_8.add(row_tAsyncOut_tDBOutput_8);
	index_tAsyncOut_tDBOutput_8++;
 


	tos_count_tAsyncOut_tDBOutput_8++;

/**
 * [tAsyncOut_tDBOutput_8 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_8";
	
	

 



/**
 * [tAsyncOut_tDBOutput_8 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_8";
	
	

 



/**
 * [tAsyncOut_tDBOutput_8 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_8";
	
	
			cLabel="\"mst_role\"";
		

 



/**
 * [tDBInput_8 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_8 end ] start
	 */

	

	
	
	currentComponent="tDBInput_8";
	
	
			cLabel="\"mst_role\"";
		

	}
}finally{
	if (rs_tDBInput_8 != null) {
		rs_tDBInput_8.close();
	}
	if (stmt_tDBInput_8 != null) {
		stmt_tDBInput_8.close();
	}
}

		   globalMap.put("tDBInput_8_NB_LINE",nb_line_tDBInput_8);
		

	    		log.debug("tDBInput_8 - Retrieved records count: "+nb_line_tDBInput_8 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_8 - "  + ("Done.") );

ok_Hash.put("tDBInput_8", true);
end_Hash.put("tDBInput_8", System.currentTimeMillis());




/**
 * [tDBInput_8 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_8 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_8";
	
	


	if (buffers_tAsyncOut_tDBOutput_8.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_8", buffers_tAsyncOut_tDBOutput_8);
	    tAsyncIn_tDBOutput_8Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_8.waitForEnd();
	pool_tAsyncOut_tDBOutput_8.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row8",2,0,
			 			"tDBInput_8","\"mst_role\"","tMysqlInput","tAsyncOut_tDBOutput_8","tAsyncOut_tDBOutput_8","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_8", true);
end_Hash.put("tAsyncOut_tDBOutput_8", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_8 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_8 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_8";
	
	
			cLabel="\"mst_role\"";
		

 



/**
 * [tDBInput_8 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_8 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_8";
	
	

 



/**
 * [tAsyncOut_tDBOutput_8 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_8_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String sbu;

				public String getSbu () {
					return this.sbu;
				}

				public Boolean sbuIsNullable(){
				    return false;
				}
				public Boolean sbuIsKey(){
				    return false;
				}
				public Integer sbuLength(){
				    return 45;
				}
				public Integer sbuPrecision(){
				    return 0;
				}
				public String sbuDefault(){
				
					return null;
				
				}
				public String sbuComment(){
				
				    return "";
				
				}
				public String sbuPattern(){
				
					return "";
				
				}
				public String sbuOriginalDbColumnName(){
				
					return "sbu";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String sbu_id;

				public String getSbu_id () {
					return this.sbu_id;
				}

				public Boolean sbu_idIsNullable(){
				    return true;
				}
				public Boolean sbu_idIsKey(){
				    return false;
				}
				public Integer sbu_idLength(){
				    return 32;
				}
				public Integer sbu_idPrecision(){
				    return 0;
				}
				public String sbu_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String sbu_idComment(){
				
				    return "";
				
				}
				public String sbu_idPattern(){
				
					return "";
				
				}
				public String sbu_idOriginalDbColumnName(){
				
					return "sbu_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy_MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row9Struct other = (row9Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row9Struct other) {

		other.id = this.id;
	            other.sbu = this.sbu;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.sbu_id = this.sbu_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row9Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.sbu = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.sbu_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.sbu = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.sbu_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.sbu,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.sbu_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.sbu,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.sbu_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",sbu="+sbu);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",sbu_id="+sbu_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(sbu == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbu);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(sbu_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbu_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_9");
		org.slf4j.MDC.put("_subJobPid", "fQ5Xqj_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row9Struct row9 = new row9Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_9", false);
		start_Hash.put("tAsyncOut_tDBOutput_9", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_9";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row9");
			
		int tos_count_tAsyncOut_tDBOutput_9 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_9", "tAsyncOut_tDBOutput_9", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_9 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_9 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_9 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_9=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_9 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_9", pool_tAsyncOut_tDBOutput_9);
	final Object[] lockWrite_tAsyncOut_tDBOutput_9 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_9", lockWrite_tAsyncOut_tDBOutput_9);
 



/**
 * [tAsyncOut_tDBOutput_9 begin ] stop
 */



	
	/**
	 * [tDBInput_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_9", false);
		start_Hash.put("tDBInput_9", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_9";
	
	
			cLabel="\"mst_sbu\"";
		
		int tos_count_tDBInput_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_9 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_9{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_9 = new StringBuilder();
                    log4jParamters_tDBInput_9.append("Parameters:");
                            log4jParamters_tDBInput_9.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_9.append(" | ");
                            log4jParamters_tDBInput_9.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_9.append(" | ");
                            log4jParamters_tDBInput_9.append("TABLE" + " = " + "\"mst_sbu\"");
                        log4jParamters_tDBInput_9.append(" | ");
                            log4jParamters_tDBInput_9.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_9.append(" | ");
                            log4jParamters_tDBInput_9.append("QUERY" + " = " + "\"SELECT    `mst_sbu`.`id`,    `mst_sbu`.`sbu`,    `mst_sbu`.`created_by`,    `mst_sbu`.`created_on`,    `mst_sbu`.`updated_by`,    `mst_sbu`.`updated_on`,    `mst_sbu`.`is_active`,    `mst_sbu`.`is_deleted`,    `mst_sbu`.`sbu_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_sbu`\"");
                        log4jParamters_tDBInput_9.append(" | ");
                            log4jParamters_tDBInput_9.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_9.append(" | ");
                            log4jParamters_tDBInput_9.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_9.append(" | ");
                            log4jParamters_tDBInput_9.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sbu")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sbu_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_9.append(" | ");
                            log4jParamters_tDBInput_9.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_9 - "  + (log4jParamters_tDBInput_9) );
                    } 
                } 
            new BytesLimit65535_tDBInput_9().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_9", "\"mst_sbu\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_9 = java.util.Calendar.getInstance();
		    calendar_tDBInput_9.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_9 = calendar_tDBInput_9.getTime();
		    int nb_line_tDBInput_9 = 0;
		    java.sql.Connection conn_tDBInput_9 = null;
				conn_tDBInput_9 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_9 != null) {
					if(conn_tDBInput_9.getMetaData() != null) {
						
							log.debug("tDBInput_9 - Uses an existing connection with username '" + conn_tDBInput_9.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_9.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_9 = conn_tDBInput_9.createStatement();
				if(stmt_tDBInput_9 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_9).enableStreamingResults();
				}else if(stmt_tDBInput_9 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_9).enableStreamingResults();
				}

		    String dbquery_tDBInput_9 = "SELECT \n  `mst_sbu`.`id`, \n  `mst_sbu`.`sbu`, \n  `mst_sbu`.`created_by`, \n  `mst_sbu`.`created_on`, \n  `mst_sbu`.`updat"
+"ed_by`, \n  `mst_sbu`.`updated_on`, \n  `mst_sbu`.`is_active`, \n  `mst_sbu`.`is_deleted`, \n  `mst_sbu`.`sbu_id`,\n	DATE_SU"
+"B(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_sbu`";
		    
	    		log.debug("tDBInput_9 - Executing the query: '" + dbquery_tDBInput_9 + "'.");
			

            	globalMap.put("tDBInput_9_QUERY",dbquery_tDBInput_9);
		    java.sql.ResultSet rs_tDBInput_9 = null;

		    try {
		    	rs_tDBInput_9 = stmt_tDBInput_9.executeQuery(dbquery_tDBInput_9);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_9 = rs_tDBInput_9.getMetaData();
		    	int colQtyInRs_tDBInput_9 = rsmd_tDBInput_9.getColumnCount();

		    String tmpContent_tDBInput_9 = null;
		    
		    
		    	log.debug("tDBInput_9 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_9.next()) {
		        nb_line_tDBInput_9++;
		        
							if(colQtyInRs_tDBInput_9 < 1) {
								row9.id = 0;
							} else {
		                          
            row9.id = rs_tDBInput_9.getInt(1);
            if(rs_tDBInput_9.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_9 < 2) {
								row9.sbu = null;
							} else {
	                         		
        	row9.sbu = routines.system.JDBCUtil.getString(rs_tDBInput_9, 2, false);
		                    }
							if(colQtyInRs_tDBInput_9 < 3) {
								row9.created_by = null;
							} else {
		                          
            row9.created_by = rs_tDBInput_9.getInt(3);
            if(rs_tDBInput_9.wasNull()){
                    row9.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_9 < 4) {
								row9.created_on = null;
							} else {
										
				if(rs_tDBInput_9.getString(4) != null) {
					String dateString_tDBInput_9 = rs_tDBInput_9.getString(4);
					if (!("0000-00-00").equals(dateString_tDBInput_9) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_9)) {
						row9.created_on = rs_tDBInput_9.getTimestamp(4);
					} else {
						row9.created_on = (java.util.Date) year0_tDBInput_9.clone();
					}
				} else {
					row9.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_9 < 5) {
								row9.updated_by = null;
							} else {
		                          
            row9.updated_by = rs_tDBInput_9.getInt(5);
            if(rs_tDBInput_9.wasNull()){
                    row9.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_9 < 6) {
								row9.updated_on = null;
							} else {
										
				if(rs_tDBInput_9.getString(6) != null) {
					String dateString_tDBInput_9 = rs_tDBInput_9.getString(6);
					if (!("0000-00-00").equals(dateString_tDBInput_9) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_9)) {
						row9.updated_on = rs_tDBInput_9.getTimestamp(6);
					} else {
						row9.updated_on = (java.util.Date) year0_tDBInput_9.clone();
					}
				} else {
					row9.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_9 < 7) {
								row9.is_active = 0;
							} else {
		                          
            row9.is_active = rs_tDBInput_9.getInt(7);
            if(rs_tDBInput_9.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_9 < 8) {
								row9.is_deleted = 0;
							} else {
		                          
            row9.is_deleted = rs_tDBInput_9.getInt(8);
            if(rs_tDBInput_9.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_9 < 9) {
								row9.sbu_id = null;
							} else {
	                         		
        	row9.sbu_id = routines.system.JDBCUtil.getString(rs_tDBInput_9, 9, false);
		                    }
							if(colQtyInRs_tDBInput_9 < 10) {
								row9.as_on = null;
							} else {
										
				if(rs_tDBInput_9.getString(10) != null) {
					String dateString_tDBInput_9 = rs_tDBInput_9.getString(10);
					if (!("0000-00-00").equals(dateString_tDBInput_9) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_9)) {
						row9.as_on = rs_tDBInput_9.getTimestamp(10);
					} else {
						row9.as_on = (java.util.Date) year0_tDBInput_9.clone();
					}
				} else {
					row9.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_9 - Retrieving the record " + nb_line_tDBInput_9 + ".");
					

 



/**
 * [tDBInput_9 begin ] stop
 */
	
	/**
	 * [tDBInput_9 main ] start
	 */

	

	
	
	currentComponent="tDBInput_9";
	
	
			cLabel="\"mst_sbu\"";
		

 


	tos_count_tDBInput_9++;

/**
 * [tDBInput_9 main ] stop
 */
	
	/**
	 * [tDBInput_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_9";
	
	
			cLabel="\"mst_sbu\"";
		

 



/**
 * [tDBInput_9 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_9 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_9";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row9","tDBInput_9","\"mst_sbu\"","tMysqlInput","tAsyncOut_tDBOutput_9","tAsyncOut_tDBOutput_9","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_9=new Object[]{null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_9[0] = String.valueOf(row9.id); 
	if(row9.sbu != null){
		row_tAsyncOut_tDBOutput_9[1] = row9.sbu;                			    
	}
	if(row9.created_by != null){
		row_tAsyncOut_tDBOutput_9[2] = String.valueOf(row9.created_by);                			    
	}
	if(row9.created_on != null){
		row_tAsyncOut_tDBOutput_9[3] = row9.created_on;                			    
	}
	if(row9.updated_by != null){
		row_tAsyncOut_tDBOutput_9[4] = String.valueOf(row9.updated_by);                			    
	}
	if(row9.updated_on != null){
		row_tAsyncOut_tDBOutput_9[5] = row9.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_9[6] = String.valueOf(row9.is_active); 
	row_tAsyncOut_tDBOutput_9[7] = String.valueOf(row9.is_deleted); 
	if(row9.sbu_id != null){
		row_tAsyncOut_tDBOutput_9[8] = row9.sbu_id;                			    
	}
	if(row9.as_on != null){
		row_tAsyncOut_tDBOutput_9[9] = row9.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_9 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_9", buffers_tAsyncOut_tDBOutput_9);
		/*tAsyncIn_tDBOutput_10Process(globalMap);*/
		tAsyncIn_tDBOutput_9Process(globalMap);
		buffers_tAsyncOut_tDBOutput_9 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_9 = 0;
	}
	buffers_tAsyncOut_tDBOutput_9.add(row_tAsyncOut_tDBOutput_9);
	index_tAsyncOut_tDBOutput_9++;
 


	tos_count_tAsyncOut_tDBOutput_9++;

/**
 * [tAsyncOut_tDBOutput_9 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_9";
	
	

 



/**
 * [tAsyncOut_tDBOutput_9 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_9";
	
	

 



/**
 * [tAsyncOut_tDBOutput_9 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_9";
	
	
			cLabel="\"mst_sbu\"";
		

 



/**
 * [tDBInput_9 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_9 end ] start
	 */

	

	
	
	currentComponent="tDBInput_9";
	
	
			cLabel="\"mst_sbu\"";
		

	}
}finally{
	if (rs_tDBInput_9 != null) {
		rs_tDBInput_9.close();
	}
	if (stmt_tDBInput_9 != null) {
		stmt_tDBInput_9.close();
	}
}

		   globalMap.put("tDBInput_9_NB_LINE",nb_line_tDBInput_9);
		

	    		log.debug("tDBInput_9 - Retrieved records count: "+nb_line_tDBInput_9 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_9 - "  + ("Done.") );

ok_Hash.put("tDBInput_9", true);
end_Hash.put("tDBInput_9", System.currentTimeMillis());




/**
 * [tDBInput_9 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_9 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_9";
	
	


	if (buffers_tAsyncOut_tDBOutput_9.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_9", buffers_tAsyncOut_tDBOutput_9);
	    tAsyncIn_tDBOutput_9Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_9.waitForEnd();
	pool_tAsyncOut_tDBOutput_9.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row9",2,0,
			 			"tDBInput_9","\"mst_sbu\"","tMysqlInput","tAsyncOut_tDBOutput_9","tAsyncOut_tDBOutput_9","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_9", true);
end_Hash.put("tAsyncOut_tDBOutput_9", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_9 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_9 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_9";
	
	
			cLabel="\"mst_sbu\"";
		

 



/**
 * [tDBInput_9 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_9 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_9";
	
	

 



/**
 * [tAsyncOut_tDBOutput_9 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_9_SUBPROCESS_STATE", 1);
	}
	


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "HlfN1c_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "IHHg2C_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"115.124.105.62\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"3306\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"chaitanya_audit\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"chaitanya_auditprd\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:wKJOA8XoDj7mB8MzmwpwNeNN3qTm0zR4WiidQuMO/fS0ceO6").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "Audit_source", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + "115.124.105.62" + ":" + "3306" + "/" + "chaitanya_audit" + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = "chaitanya_auditprd";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:xK+0Yv0viTcfySIYlRz7roxyLL0T1xdFfs6Z1gvaH2YLMza9");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1","chaitanya_audit");
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_2");
		org.slf4j.MDC.put("_subJobPid", "JSMiIs_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "\"audit_dwh\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "\"audit_user\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:hOL+fCSItHaLR04NFy2L23lnoc/4k7nRi220avVjhbOiRUadFq/k").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_2", "Audit_target", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_2 = "";
            String url_tDBConnection_2 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"audit_dwh";
            
            if(dbProperties_tDBConnection_2 != null && !"".equals(dbProperties_tDBConnection_2.trim())) {
                url_tDBConnection_2 = url_tDBConnection_2 + "?" + dbProperties_tDBConnection_2;
            }
	String dbUser_tDBConnection_2 = "audit_user";
	
	
		 
	final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:m6dLYeSCNAf5R4pbQdIdO5OA6HBwt+wecG31jlZNjH0JPcQEcDRj");
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_2 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_2 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_2.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_2 = drivers_tDBConnection_2.nextElement();
        if (redShiftDriverNames_tDBConnection_2.contains(d_tDBConnection_2.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_2);
                java.sql.DriverManager.registerDriver(d_tDBConnection_2);
            } catch (java.lang.Exception e_tDBConnection_2) {
globalMap.put("tDBConnection_2_ERROR_MESSAGE",e_tDBConnection_2.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_2 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_2","");

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "JoiJdX_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", "Yc3pqW_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMysqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
		
	    		log.debug("tDBClose_1 - Closing the connection 'tDBConnection_1' to the database.");
			
			conn_tDBClose_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	    		log.debug("tDBClose_1 - Connection 'tDBConnection_1' to the database closed.");
			
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_2Process(globalMap);



/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_2");
		org.slf4j.MDC.put("_subJobPid", "s6cbIA_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_2", false);
		start_Hash.put("tDBClose_2", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_2";
	
	
		int tos_count_tDBClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_2 = new StringBuilder();
                    log4jParamters_tDBClose_2.append("Parameters:");
                            log4jParamters_tDBClose_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBClose_2.append(" | ");
                            log4jParamters_tDBClose_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + (log4jParamters_tDBClose_2) );
                    } 
                } 
            new BytesLimit65535_tDBClose_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_2", "tDBClose_2", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_2 begin ] stop
 */
	
	/**
	 * [tDBClose_2 main ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	



	java.sql.Connection conn_tDBClose_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	if(conn_tDBClose_2 != null && !conn_tDBClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Closing the connection ")  + ("conn_tDBConnection_2")  + (" to the database.") );
        conn_tDBClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Connection ")  + ("conn_tDBConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_2++;

/**
 * [tDBClose_2 main ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_2 end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Done.") );

ok_Hash.put("tDBClose_2", true);
end_Hash.put("tDBClose_2", System.currentTimeMillis());




/**
 * [tDBClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_2 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_2_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String observation;

				public String getObservation () {
					return this.observation;
				}

				public Boolean observationIsNullable(){
				    return true;
				}
				public Boolean observationIsKey(){
				    return false;
				}
				public Integer observationLength(){
				    return 2147483647;
				}
				public Integer observationPrecision(){
				    return 0;
				}
				public String observationDefault(){
				
					return null;
				
				}
				public String observationComment(){
				
				    return "";
				
				}
				public String observationPattern(){
				
					return "";
				
				}
				public String observationOriginalDbColumnName(){
				
					return "observation";
				
				}

				
			    public int question_id;

				public int getQuestion_id () {
					return this.question_id;
				}

				public Boolean question_idIsNullable(){
				    return false;
				}
				public Boolean question_idIsKey(){
				    return false;
				}
				public Integer question_idLength(){
				    return 10;
				}
				public Integer question_idPrecision(){
				    return 0;
				}
				public String question_idDefault(){
				
					return null;
				
				}
				public String question_idComment(){
				
				    return "";
				
				}
				public String question_idPattern(){
				
					return "";
				
				}
				public String question_idOriginalDbColumnName(){
				
					return "question_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String observation_id;

				public String getObservation_id () {
					return this.observation_id;
				}

				public Boolean observation_idIsNullable(){
				    return true;
				}
				public Boolean observation_idIsKey(){
				    return false;
				}
				public Integer observation_idLength(){
				    return 32;
				}
				public Integer observation_idPrecision(){
				    return 0;
				}
				public String observation_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String observation_idComment(){
				
				    return "";
				
				}
				public String observation_idPattern(){
				
					return "";
				
				}
				public String observation_idOriginalDbColumnName(){
				
					return "observation_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.id = this.id;
	            other.observation = this.observation;
	            other.question_id = this.question_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.observation_id = this.observation_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.observation = readString(dis);
					
			        this.question_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.observation_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.observation = readString(dis);
					
			        this.question_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.observation_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.observation,dos);
					
					// int
				
		            	dos.writeInt(this.question_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.observation_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.observation,dos);
					
					// int
				
		            	dos.writeInt(this.question_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.observation_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",observation="+observation);
		sb.append(",question_id="+String.valueOf(question_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",observation_id="+observation_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(observation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation);
            			}
            		
        			sb.append("|");
        		
        				sb.append(question_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(observation_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", "q0OqiA_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tAsyncOut_tDBOutput_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncOut_tDBOutput_10", false);
		start_Hash.put("tAsyncOut_tDBOutput_10", System.currentTimeMillis());
		
	
	currentComponent="tAsyncOut_tDBOutput_10";
	
	
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row1");
			
		int tos_count_tAsyncOut_tDBOutput_10 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncOut_tDBOutput_10", "tAsyncOut_tDBOutput_10", "tAsyncOut");
				talendJobLogProcess(globalMap);
			}
			

	int index_tAsyncOut_tDBOutput_10 = 0;
	int threadIdCounter_tAsyncOut_tDBOutput_10 = 0;
	java.util.List<Object[]> buffers_tAsyncOut_tDBOutput_10 = new java.util.ArrayList<Object[]>();
	int toto_tAsyncOut_tDBOutput_10=0;
	
	final ParallelThreadPool pool_tAsyncOut_tDBOutput_10 = new ParallelThreadPool(8);
	globalMap.put("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_10", pool_tAsyncOut_tDBOutput_10);
	final Object[] lockWrite_tAsyncOut_tDBOutput_10 = new Object[0];
	globalMap.put("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_10", lockWrite_tAsyncOut_tDBOutput_10);
 



/**
 * [tAsyncOut_tDBOutput_10 begin ] stop
 */



	
	/**
	 * [tDBInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_1", false);
		start_Hash.put("tDBInput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mst_observation\"";
		
		int tos_count_tDBInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
                    log4jParamters_tDBInput_1.append("Parameters:");
                            log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"mst_observation\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("QUERY" + " = " + "\"SELECT    `mst_observation`.`id`,    `mst_observation`.`observation`,    `mst_observation`.`question_id`,    `mst_observation`.`created_by`,    `mst_observation`.`created_on`,    `mst_observation`.`updated_by`,    `mst_observation`.`updated_on`,    `mst_observation`.`is_active`,    `mst_observation`.`is_deleted`,    `mst_observation`.`observation_id`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `mst_observation`\"");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("observation")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("question_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("observation_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_1.append(" | ");
                            log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + (log4jParamters_tDBInput_1) );
                    } 
                } 
            new BytesLimit65535_tDBInput_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_1", "\"mst_observation\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
		    calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
		    int nb_line_tDBInput_1 = 0;
		    java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_1 != null) {
					if(conn_tDBInput_1.getMetaData() != null) {
						
							log.debug("tDBInput_1 - Uses an existing connection with username '" + conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();
				if(stmt_tDBInput_1 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_1).enableStreamingResults();
				}else if(stmt_tDBInput_1 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_1).enableStreamingResults();
				}

		    String dbquery_tDBInput_1 = "SELECT \n  `mst_observation`.`id`, \n  `mst_observation`.`observation`, \n  `mst_observation`.`question_id`, \n  `mst_obser"
+"vation`.`created_by`, \n  `mst_observation`.`created_on`, \n  `mst_observation`.`updated_by`, \n  `mst_observation`.`update"
+"d_on`, \n  `mst_observation`.`is_active`, \n  `mst_observation`.`is_deleted`, \n  `mst_observation`.`observation_id`,\n	DAT"
+"E_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `mst_observation`";
		    
	    		log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");
			

            	globalMap.put("tDBInput_1_QUERY",dbquery_tDBInput_1);
		    java.sql.ResultSet rs_tDBInput_1 = null;

		    try {
		    	rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
		    	int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

		    String tmpContent_tDBInput_1 = null;
		    
		    
		    	log.debug("tDBInput_1 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_1.next()) {
		        nb_line_tDBInput_1++;
		        
							if(colQtyInRs_tDBInput_1 < 1) {
								row1.id = 0;
							} else {
		                          
            row1.id = rs_tDBInput_1.getInt(1);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 2) {
								row1.observation = null;
							} else {
	                         		
        	row1.observation = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 3) {
								row1.question_id = 0;
							} else {
		                          
            row1.question_id = rs_tDBInput_1.getInt(3);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 4) {
								row1.created_by = null;
							} else {
		                          
            row1.created_by = rs_tDBInput_1.getInt(4);
            if(rs_tDBInput_1.wasNull()){
                    row1.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 5) {
								row1.created_on = null;
							} else {
										
				if(rs_tDBInput_1.getString(5) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(5);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.created_on = rs_tDBInput_1.getTimestamp(5);
					} else {
						row1.created_on = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 6) {
								row1.updated_by = null;
							} else {
		                          
            row1.updated_by = rs_tDBInput_1.getInt(6);
            if(rs_tDBInput_1.wasNull()){
                    row1.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 7) {
								row1.updated_on = null;
							} else {
										
				if(rs_tDBInput_1.getString(7) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(7);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.updated_on = rs_tDBInput_1.getTimestamp(7);
					} else {
						row1.updated_on = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_1 < 8) {
								row1.is_active = 0;
							} else {
		                          
            row1.is_active = rs_tDBInput_1.getInt(8);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 9) {
								row1.is_deleted = 0;
							} else {
		                          
            row1.is_deleted = rs_tDBInput_1.getInt(9);
            if(rs_tDBInput_1.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_1 < 10) {
								row1.observation_id = null;
							} else {
	                         		
        	row1.observation_id = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
		                    }
							if(colQtyInRs_tDBInput_1 < 11) {
								row1.as_on = null;
							} else {
										
				if(rs_tDBInput_1.getString(11) != null) {
					String dateString_tDBInput_1 = rs_tDBInput_1.getString(11);
					if (!("0000-00-00").equals(dateString_tDBInput_1) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
						row1.as_on = rs_tDBInput_1.getTimestamp(11);
					} else {
						row1.as_on = (java.util.Date) year0_tDBInput_1.clone();
					}
				} else {
					row1.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");
					

 



/**
 * [tDBInput_1 begin ] stop
 */
	
	/**
	 * [tDBInput_1 main ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mst_observation\"";
		

 


	tos_count_tDBInput_1++;

/**
 * [tDBInput_1 main ] stop
 */
	
	/**
	 * [tDBInput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mst_observation\"";
		

 



/**
 * [tDBInput_1 process_data_begin ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_10 main ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_10";
	
	
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row1","tDBInput_1","\"mst_observation\"","tMysqlInput","tAsyncOut_tDBOutput_10","tAsyncOut_tDBOutput_10","tAsyncOut"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		



	Object[] row_tAsyncOut_tDBOutput_10=new Object[]{null,null,null,null,null,null,null,null,null,null,null,};		
	row_tAsyncOut_tDBOutput_10[0] = String.valueOf(row1.id); 
	if(row1.observation != null){
		row_tAsyncOut_tDBOutput_10[1] = row1.observation;                			    
	}
	row_tAsyncOut_tDBOutput_10[2] = String.valueOf(row1.question_id); 
	if(row1.created_by != null){
		row_tAsyncOut_tDBOutput_10[3] = String.valueOf(row1.created_by);                			    
	}
	if(row1.created_on != null){
		row_tAsyncOut_tDBOutput_10[4] = row1.created_on;                			    
	}
	if(row1.updated_by != null){
		row_tAsyncOut_tDBOutput_10[5] = String.valueOf(row1.updated_by);                			    
	}
	if(row1.updated_on != null){
		row_tAsyncOut_tDBOutput_10[6] = row1.updated_on;                			    
	}
	row_tAsyncOut_tDBOutput_10[7] = String.valueOf(row1.is_active); 
	row_tAsyncOut_tDBOutput_10[8] = String.valueOf(row1.is_deleted); 
	if(row1.observation_id != null){
		row_tAsyncOut_tDBOutput_10[9] = row1.observation_id;                			    
	}
	if(row1.as_on != null){
		row_tAsyncOut_tDBOutput_10[10] = row1.as_on;                			    
	}
	if (index_tAsyncOut_tDBOutput_10 >= 25000) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_10", buffers_tAsyncOut_tDBOutput_10);
		/*tAsyncIn_tDBOutput_10Process(globalMap);*/
		tAsyncIn_tDBOutput_10Process(globalMap);
		buffers_tAsyncOut_tDBOutput_10 = new java.util.ArrayList<Object[]>();
		index_tAsyncOut_tDBOutput_10 = 0;
	}
	buffers_tAsyncOut_tDBOutput_10.add(row_tAsyncOut_tDBOutput_10);
	index_tAsyncOut_tDBOutput_10++;
 


	tos_count_tAsyncOut_tDBOutput_10++;

/**
 * [tAsyncOut_tDBOutput_10 main ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_10";
	
	

 



/**
 * [tAsyncOut_tDBOutput_10 process_data_begin ] stop
 */
	
	/**
	 * [tAsyncOut_tDBOutput_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_10";
	
	

 



/**
 * [tAsyncOut_tDBOutput_10 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mst_observation\"";
		

 



/**
 * [tDBInput_1 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_1 end ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mst_observation\"";
		

	}
}finally{
	if (rs_tDBInput_1 != null) {
		rs_tDBInput_1.close();
	}
	if (stmt_tDBInput_1 != null) {
		stmt_tDBInput_1.close();
	}
}

		   globalMap.put("tDBInput_1_NB_LINE",nb_line_tDBInput_1);
		

	    		log.debug("tDBInput_1 - Retrieved records count: "+nb_line_tDBInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_1 - "  + ("Done.") );

ok_Hash.put("tDBInput_1", true);
end_Hash.put("tDBInput_1", System.currentTimeMillis());




/**
 * [tDBInput_1 end ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_10 end ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_10";
	
	


	if (buffers_tAsyncOut_tDBOutput_10.size() > 0) {
		globalMap.put("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_10", buffers_tAsyncOut_tDBOutput_10);
	    tAsyncIn_tDBOutput_10Process(globalMap);
	}
	pool_tAsyncOut_tDBOutput_10.waitForEnd();
	pool_tAsyncOut_tDBOutput_10.setGlobalVariables(globalMap);
			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row1",2,0,
			 			"tDBInput_1","\"mst_observation\"","tMysqlInput","tAsyncOut_tDBOutput_10","tAsyncOut_tDBOutput_10","tAsyncOut","output")) {
						talendJobLogProcess(globalMap);
					}
				
 

ok_Hash.put("tAsyncOut_tDBOutput_10", true);
end_Hash.put("tAsyncOut_tDBOutput_10", System.currentTimeMillis());




/**
 * [tAsyncOut_tDBOutput_10 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_1";
	
	
			cLabel="\"mst_observation\"";
		

 



/**
 * [tDBInput_1 finally ] stop
 */

	
	/**
	 * [tAsyncOut_tDBOutput_10 finally ] start
	 */

	

	
	
	currentComponent="tAsyncOut_tDBOutput_10";
	
	

 



/**
 * [tAsyncOut_tDBOutput_10 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row2Struct implements routines.system.IPersistableRow<pRow_row2Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String option_name;

				public String getOption_name () {
					return this.option_name;
				}

				public Boolean option_nameIsNullable(){
				    return false;
				}
				public Boolean option_nameIsKey(){
				    return false;
				}
				public Integer option_nameLength(){
				    return 50;
				}
				public Integer option_namePrecision(){
				    return 0;
				}
				public String option_nameDefault(){
				
					return null;
				
				}
				public String option_nameComment(){
				
				    return "";
				
				}
				public String option_namePattern(){
				
					return "";
				
				}
				public String option_nameOriginalDbColumnName(){
				
					return "option_name";
				
				}

				
			    public Float option_marks;

				public Float getOption_marks () {
					return this.option_marks;
				}

				public Boolean option_marksIsNullable(){
				    return true;
				}
				public Boolean option_marksIsKey(){
				    return false;
				}
				public Integer option_marksLength(){
				    return 8;
				}
				public Integer option_marksPrecision(){
				    return 8;
				}
				public String option_marksDefault(){
				
					return "'0'::real";
				
				}
				public String option_marksComment(){
				
				    return "";
				
				}
				public String option_marksPattern(){
				
					return "";
				
				}
				public String option_marksOriginalDbColumnName(){
				
					return "option_marks";
				
				}

				
			    public int question_id;

				public int getQuestion_id () {
					return this.question_id;
				}

				public Boolean question_idIsNullable(){
				    return false;
				}
				public Boolean question_idIsKey(){
				    return false;
				}
				public Integer question_idLength(){
				    return 10;
				}
				public Integer question_idPrecision(){
				    return 0;
				}
				public String question_idDefault(){
				
					return null;
				
				}
				public String question_idComment(){
				
				    return "";
				
				}
				public String question_idPattern(){
				
					return "";
				
				}
				public String question_idOriginalDbColumnName(){
				
					return "question_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String option_id;

				public String getOption_id () {
					return this.option_id;
				}

				public Boolean option_idIsNullable(){
				    return true;
				}
				public Boolean option_idIsKey(){
				    return false;
				}
				public Integer option_idLength(){
				    return 32;
				}
				public Integer option_idPrecision(){
				    return 0;
				}
				public String option_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String option_idComment(){
				
				    return "";
				
				}
				public String option_idPattern(){
				
					return "";
				
				}
				public String option_idOriginalDbColumnName(){
				
					return "option_id";
				
				}

				
			    public Integer observation;

				public Integer getObservation () {
					return this.observation;
				}

				public Boolean observationIsNullable(){
				    return true;
				}
				public Boolean observationIsKey(){
				    return false;
				}
				public Integer observationLength(){
				    return 10;
				}
				public Integer observationPrecision(){
				    return 0;
				}
				public String observationDefault(){
				
					return "0";
				
				}
				public String observationComment(){
				
				    return "";
				
				}
				public String observationPattern(){
				
					return "";
				
				}
				public String observationOriginalDbColumnName(){
				
					return "observation";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row2Struct other = (pRow_row2Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row2Struct other) {

		other.id = this.id;
	            other.option_name = this.option_name;
	            other.option_marks = this.option_marks;
	            other.question_id = this.question_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.option_id = this.option_id;
	            other.observation = this.observation;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row2Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.option_marks = null;
           				} else {
           			    	this.option_marks = dis.readFloat();
           				}
					
			        this.question_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_id = readString(dis);
					
						this.observation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.option_marks = null;
           				} else {
           			    	this.option_marks = dis.readFloat();
           				}
					
			        this.question_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_id = readString(dis);
					
						this.observation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.option_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.option_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.question_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_id,dos);
					
					// Integer
				
						writeInteger(this.observation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.option_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.option_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.question_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_id,dos);
					
					// Integer
				
						writeInteger(this.observation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",option_name="+option_name);
		sb.append(",option_marks="+String.valueOf(option_marks));
		sb.append(",question_id="+String.valueOf(question_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",option_id="+option_id);
		sb.append(",observation="+String.valueOf(observation));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(option_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_name);
            			}
            		
        			sb.append("|");
        		
        				if(option_marks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_marks);
            			}
            		
        			sb.append("|");
        		
        				sb.append(question_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(option_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_id);
            			}
            		
        			sb.append("|");
        		
        				if(observation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row2Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_2");
		org.slf4j.MDC.put("_subJobPid", "I7gwUh_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_2");
		class tAsyncIn_tDBOutput_2_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_2_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row2Struct pRow_row2 = new pRow_row2Struct();




	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mst_option_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row2");
			
		int tos_count_tDBOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_2 = new StringBuilder();
                    log4jParamters_tDBOutput_2.append("Parameters:");
                            log4jParamters_tDBOutput_2.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("TABLE" + " = " + "\"mst_option_dw\"");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_2.append(" | ");
                            log4jParamters_tDBOutput_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + (log4jParamters_tDBOutput_2) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_2", "\"mst_option_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_2 = null;
	dbschema_tDBOutput_2 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_2 = null;
if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
	tableName_tDBOutput_2 = ("mst_option_dw");
} else {
	tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "\".\"" + ("mst_option_dw");
}


int nb_line_tDBOutput_2 = 0;
int nb_line_update_tDBOutput_2 = 0;
int nb_line_inserted_tDBOutput_2 = 0;
int nb_line_deleted_tDBOutput_2 = 0;
int nb_line_rejected_tDBOutput_2 = 0;

int deletedCount_tDBOutput_2=0;
int updatedCount_tDBOutput_2=0;
int insertedCount_tDBOutput_2=0;
int rowsToCommitCount_tDBOutput_2=0;
int rejectedCount_tDBOutput_2=0;

boolean whetherReject_tDBOutput_2 = false;

java.sql.Connection conn_tDBOutput_2 = null;
String dbUser_tDBOutput_2 = null;

	conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_2.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_2.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_2 = 10000;
   int batchSizeCounter_tDBOutput_2=0;

int count_tDBOutput_2=0;
        java.lang.StringBuilder sb_tDBOutput_2 = new java.lang.StringBuilder();
        sb_tDBOutput_2.append("INSERT INTO \"").append(tableName_tDBOutput_2).append("\" (\"id\",\"option_name\",\"option_marks\",\"question_id\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"option_id\",\"observation\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_2.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"option_name\" = EXCLUDED.\"option_name\",\"option_marks\" = EXCLUDED.\"option_marks\",\"question_id\" = EXCLUDED.\"question_id\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"option_id\" = EXCLUDED.\"option_id\",\"observation\" = EXCLUDED.\"observation\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_2 = sb_tDBOutput_2.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing '")  + (insert_tDBOutput_2)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
	    resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
	    

 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_2", false);
		start_Hash.put("tAsyncIn_tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	
		int tos_count_tAsyncIn_tDBOutput_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_2", "tAsyncIn_tDBOutput_2", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_2= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_2 = buffers_tAsyncIn_tDBOutput_2.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_2 != null && buffers_tAsyncIn_tDBOutput_2.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_2 : buffers_tAsyncIn_tDBOutput_2) {
    		pRow_row2 = null;						
			pRow_row2 = new pRow_row2Struct();
		
		
			String temp_tAsyncIn_tDBOutput_2_0 = row_tAsyncIn_tDBOutput_2[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[0]);
			if(temp_tAsyncIn_tDBOutput_2_0 != null) {
		
			pRow_row2.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_0);
		} else {						
			pRow_row2.id = 0;
		}
		pRow_row2.option_name = row_tAsyncIn_tDBOutput_2[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[1]);
		
		
			String temp_tAsyncIn_tDBOutput_2_2 = row_tAsyncIn_tDBOutput_2[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[2]);
			if(temp_tAsyncIn_tDBOutput_2_2 != null) {
		
			pRow_row2.option_marks = ParserUtils.parseTo_Float(temp_tAsyncIn_tDBOutput_2_2);
		} else {						
			pRow_row2.option_marks = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_3 = row_tAsyncIn_tDBOutput_2[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[3]);
			if(temp_tAsyncIn_tDBOutput_2_3 != null) {
		
			pRow_row2.question_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_3);
		} else {						
			pRow_row2.question_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_4 = row_tAsyncIn_tDBOutput_2[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[4]);
			if(temp_tAsyncIn_tDBOutput_2_4 != null) {
		
			pRow_row2.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_4);
		} else {						
			pRow_row2.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_5 = row_tAsyncIn_tDBOutput_2[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[5]);
			if(temp_tAsyncIn_tDBOutput_2_5 != null) {
		
			pRow_row2.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_2[5]);
		} else {						
			pRow_row2.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_6 = row_tAsyncIn_tDBOutput_2[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[6]);
			if(temp_tAsyncIn_tDBOutput_2_6 != null) {
		
			pRow_row2.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_6);
		} else {						
			pRow_row2.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_7 = row_tAsyncIn_tDBOutput_2[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[7]);
			if(temp_tAsyncIn_tDBOutput_2_7 != null) {
		
			pRow_row2.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_2[7]);
		} else {						
			pRow_row2.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_8 = row_tAsyncIn_tDBOutput_2[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[8]);
			if(temp_tAsyncIn_tDBOutput_2_8 != null) {
		
			pRow_row2.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_8);
		} else {						
			pRow_row2.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_9 = row_tAsyncIn_tDBOutput_2[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[9]);
			if(temp_tAsyncIn_tDBOutput_2_9 != null) {
		
			pRow_row2.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_2_9);
		} else {						
			pRow_row2.is_deleted = 0;
		}
		pRow_row2.option_id = row_tAsyncIn_tDBOutput_2[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[10]);
		
		
			String temp_tAsyncIn_tDBOutput_2_11 = row_tAsyncIn_tDBOutput_2[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[11]);
			if(temp_tAsyncIn_tDBOutput_2_11 != null) {
		
			pRow_row2.observation = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_2_11);
		} else {						
			pRow_row2.observation = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_2_12 = row_tAsyncIn_tDBOutput_2[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_2[12]);
			if(temp_tAsyncIn_tDBOutput_2_12 != null) {
		
			pRow_row2.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_2[12]);
		} else {						
			pRow_row2.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_2 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 


	tos_count_tAsyncIn_tDBOutput_2++;

/**
 * [tAsyncIn_tDBOutput_2 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 



/**
 * [tAsyncIn_tDBOutput_2 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mst_option_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row2","tAsyncIn_tDBOutput_2","tAsyncIn_tDBOutput_2","tAsyncIn","tDBOutput_2","\"mst_option_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row2 - " + (pRow_row2==null? "": pRow_row2.toLogString()));
    			}
    		



				batchSize_tDBOutput_2 = buffersSize_tAsyncIn_tDBOutput_2;
        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, pRow_row2.id);

                    if(pRow_row2.option_name == null) {
pstmt_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(2, pRow_row2.option_name);
}

                    if(pRow_row2.option_marks == null) {
pstmt_tDBOutput_2.setNull(3, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_2.setFloat(3, pRow_row2.option_marks);
}

                    pstmt_tDBOutput_2.setInt(4, pRow_row2.question_id);

                    if(pRow_row2.created_by == null) {
pstmt_tDBOutput_2.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(5, pRow_row2.created_by);
}

                    if(pRow_row2.created_on != null) {
pstmt_tDBOutput_2.setTimestamp(6, new java.sql.Timestamp(pRow_row2.created_on.getTime()));
} else {
pstmt_tDBOutput_2.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row2.updated_by == null) {
pstmt_tDBOutput_2.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(7, pRow_row2.updated_by);
}

                    if(pRow_row2.updated_on != null) {
pstmt_tDBOutput_2.setTimestamp(8, new java.sql.Timestamp(pRow_row2.updated_on.getTime()));
} else {
pstmt_tDBOutput_2.setNull(8, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_2.setInt(9, pRow_row2.is_active);

                    pstmt_tDBOutput_2.setInt(10, pRow_row2.is_deleted);

                    if(pRow_row2.option_id == null) {
pstmt_tDBOutput_2.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_2.setString(11, pRow_row2.option_id);
}

                    if(pRow_row2.observation == null) {
pstmt_tDBOutput_2.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_2.setInt(12, pRow_row2.observation);
}

                    if(pRow_row2.as_on != null) {
pstmt_tDBOutput_2.setTimestamp(13, new java.sql.Timestamp(pRow_row2.as_on.getTime()));
} else {
pstmt_tDBOutput_2.setNull(13, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_2.addBatch();
    		nb_line_tDBOutput_2++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Adding the record ")  + (nb_line_tDBOutput_2)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_2++;
    		  
    			if ((batchSize_tDBOutput_2 > 0) && (batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2)) {
                try {
						int countSum_tDBOutput_2 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            	    	batchSizeCounter_tDBOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
				    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
				    	String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						}else{
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}
				    	
				    	int countSum_tDBOutput_2 = 0;
						for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
							countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
						}
						rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
				    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
				    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
				    	System.err.println(errormessage_tDBOutput_2);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mst_option_dw\"";
		

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mst_option_dw\"";
		

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 



/**
 * [tAsyncIn_tDBOutput_2 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_2.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_2", true);
end_Hash.put("tAsyncIn_tDBOutput_2", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_2 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mst_option_dw\"";
		



	    try {
				int countSum_tDBOutput_2 = 0;
				if (pstmt_tDBOutput_2 != null && batchSizeCounter_tDBOutput_2 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_2: pstmt_tDBOutput_2.executeBatch()) {
						countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
					}
					rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_2){
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
	    	java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),sqle_tDBOutput_2=null;
	    	String errormessage_tDBOutput_2;
			if (ne_tDBOutput_2 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_2 = new java.sql.SQLException(e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(), ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
				errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
			}else{
				errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
			}
	    	
	    	int countSum_tDBOutput_2 = 0;
			for(int countEach_tDBOutput_2: e_tDBOutput_2.getUpdateCounts()) {
				countSum_tDBOutput_2 += (countEach_tDBOutput_2 < 0 ? 0 : countEach_tDBOutput_2);
			}
			rowsToCommitCount_tDBOutput_2 += countSum_tDBOutput_2;
			
	    		insertedCount_tDBOutput_2 += countSum_tDBOutput_2;
	    	
            log.error("tDBOutput_2 - "  + (errormessage_tDBOutput_2) );
	    	System.err.println(errormessage_tDBOutput_2);
	    	
		}
	    
        if(pstmt_tDBOutput_2 != null) {
        		
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
    	if (globalMap.get("tDBOutput_2_NB_LINE") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE",(Integer)globalMap.get("tDBOutput_2_NB_LINE") + nb_line_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_UPDATED") + nb_line_update_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_2);
        }
        if (globalMap.get("tDBOutput_2_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_2_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_2);
        } else {
        	globalMap.put("tDBOutput_2_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_2_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_2);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row2",2,0,
			 			"tAsyncIn_tDBOutput_2","tAsyncIn_tDBOutput_2","tAsyncIn","tDBOutput_2","\"mst_option_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_2 - "  + ("Done.") );

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_2";
	
	

 



/**
 * [tAsyncIn_tDBOutput_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";
	
	
			cLabel="\"mst_option_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_2");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_2_ParallelThread pt = new tAsyncIn_tDBOutput_2_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_2"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_2_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row3Struct implements routines.system.IPersistableRow<pRow_row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String option_group_name;

				public String getOption_group_name () {
					return this.option_group_name;
				}

				public Boolean option_group_nameIsNullable(){
				    return false;
				}
				public Boolean option_group_nameIsKey(){
				    return false;
				}
				public Integer option_group_nameLength(){
				    return 50;
				}
				public Integer option_group_namePrecision(){
				    return 0;
				}
				public String option_group_nameDefault(){
				
					return null;
				
				}
				public String option_group_nameComment(){
				
				    return "";
				
				}
				public String option_group_namePattern(){
				
					return "";
				
				}
				public String option_group_nameOriginalDbColumnName(){
				
					return "option_group_name";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String option_group_id;

				public String getOption_group_id () {
					return this.option_group_id;
				}

				public Boolean option_group_idIsNullable(){
				    return true;
				}
				public Boolean option_group_idIsKey(){
				    return false;
				}
				public Integer option_group_idLength(){
				    return 32;
				}
				public Integer option_group_idPrecision(){
				    return 0;
				}
				public String option_group_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String option_group_idComment(){
				
				    return "";
				
				}
				public String option_group_idPattern(){
				
					return "";
				
				}
				public String option_group_idOriginalDbColumnName(){
				
					return "option_group_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row3Struct other = (pRow_row3Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row3Struct other) {

		other.id = this.id;
	            other.option_group_name = this.option_group_name;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.option_group_id = this.option_group_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row3Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_group_name = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_group_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_group_name = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_group_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_group_name,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_group_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_group_name,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_group_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",option_group_name="+option_group_name);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",option_group_id="+option_group_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(option_group_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_group_name);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(option_group_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_group_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_3");
		org.slf4j.MDC.put("_subJobPid", "xndyNf_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_3");
		class tAsyncIn_tDBOutput_3_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_3_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row3Struct pRow_row3 = new pRow_row3Struct();




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_option_group_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row3");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"mst_option_group_dw\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "\"mst_option_group_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_3 = null;
	dbschema_tDBOutput_3 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_3 = null;
if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
	tableName_tDBOutput_3 = ("mst_option_group_dw");
} else {
	tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "\".\"" + ("mst_option_group_dw");
}


int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

boolean whetherReject_tDBOutput_3 = false;

java.sql.Connection conn_tDBOutput_3 = null;
String dbUser_tDBOutput_3 = null;

	conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_3 = 10000;
   int batchSizeCounter_tDBOutput_3=0;

int count_tDBOutput_3=0;
        java.lang.StringBuilder sb_tDBOutput_3 = new java.lang.StringBuilder();
        sb_tDBOutput_3.append("INSERT INTO \"").append(tableName_tDBOutput_3).append("\" (\"id\",\"option_group_name\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"option_group_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_3.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"option_group_name\" = EXCLUDED.\"option_group_name\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"option_group_id\" = EXCLUDED.\"option_group_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_3 = sb_tDBOutput_3.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing '")  + (insert_tDBOutput_3)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_3", false);
		start_Hash.put("tAsyncIn_tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	
		int tos_count_tAsyncIn_tDBOutput_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_3", "tAsyncIn_tDBOutput_3", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_3= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_3 = buffers_tAsyncIn_tDBOutput_3.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_3 != null && buffers_tAsyncIn_tDBOutput_3.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_3 : buffers_tAsyncIn_tDBOutput_3) {
    		pRow_row3 = null;						
			pRow_row3 = new pRow_row3Struct();
		
		
			String temp_tAsyncIn_tDBOutput_3_0 = row_tAsyncIn_tDBOutput_3[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[0]);
			if(temp_tAsyncIn_tDBOutput_3_0 != null) {
		
			pRow_row3.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_3_0);
		} else {						
			pRow_row3.id = 0;
		}
		pRow_row3.option_group_name = row_tAsyncIn_tDBOutput_3[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[1]);
		
		
			String temp_tAsyncIn_tDBOutput_3_2 = row_tAsyncIn_tDBOutput_3[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[2]);
			if(temp_tAsyncIn_tDBOutput_3_2 != null) {
		
			pRow_row3.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_3_2);
		} else {						
			pRow_row3.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_3_3 = row_tAsyncIn_tDBOutput_3[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[3]);
			if(temp_tAsyncIn_tDBOutput_3_3 != null) {
		
			pRow_row3.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_3[3]);
		} else {						
			pRow_row3.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_3_4 = row_tAsyncIn_tDBOutput_3[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[4]);
			if(temp_tAsyncIn_tDBOutput_3_4 != null) {
		
			pRow_row3.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_3_4);
		} else {						
			pRow_row3.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_3_5 = row_tAsyncIn_tDBOutput_3[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[5]);
			if(temp_tAsyncIn_tDBOutput_3_5 != null) {
		
			pRow_row3.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_3[5]);
		} else {						
			pRow_row3.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_3_6 = row_tAsyncIn_tDBOutput_3[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[6]);
			if(temp_tAsyncIn_tDBOutput_3_6 != null) {
		
			pRow_row3.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_3_6);
		} else {						
			pRow_row3.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_3_7 = row_tAsyncIn_tDBOutput_3[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[7]);
			if(temp_tAsyncIn_tDBOutput_3_7 != null) {
		
			pRow_row3.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_3_7);
		} else {						
			pRow_row3.is_deleted = 0;
		}
		pRow_row3.option_group_id = row_tAsyncIn_tDBOutput_3[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[8]);
		
		
			String temp_tAsyncIn_tDBOutput_3_9 = row_tAsyncIn_tDBOutput_3[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_3[9]);
			if(temp_tAsyncIn_tDBOutput_3_9 != null) {
		
			pRow_row3.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_3[9]);
		} else {						
			pRow_row3.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_3 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

 


	tos_count_tAsyncIn_tDBOutput_3++;

/**
 * [tAsyncIn_tDBOutput_3 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

 



/**
 * [tAsyncIn_tDBOutput_3 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_option_group_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row3","tAsyncIn_tDBOutput_3","tAsyncIn_tDBOutput_3","tAsyncIn","tDBOutput_3","\"mst_option_group_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row3 - " + (pRow_row3==null? "": pRow_row3.toLogString()));
    			}
    		



				batchSize_tDBOutput_3 = buffersSize_tAsyncIn_tDBOutput_3;
        whetherReject_tDBOutput_3 = false;
                    pstmt_tDBOutput_3.setInt(1, pRow_row3.id);

                    if(pRow_row3.option_group_name == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, pRow_row3.option_group_name);
}

                    if(pRow_row3.created_by == null) {
pstmt_tDBOutput_3.setNull(3, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(3, pRow_row3.created_by);
}

                    if(pRow_row3.created_on != null) {
pstmt_tDBOutput_3.setTimestamp(4, new java.sql.Timestamp(pRow_row3.created_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(4, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row3.updated_by == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(5, pRow_row3.updated_by);
}

                    if(pRow_row3.updated_on != null) {
pstmt_tDBOutput_3.setTimestamp(6, new java.sql.Timestamp(pRow_row3.updated_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_3.setInt(7, pRow_row3.is_active);

                    pstmt_tDBOutput_3.setInt(8, pRow_row3.is_deleted);

                    if(pRow_row3.option_group_id == null) {
pstmt_tDBOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(9, pRow_row3.option_group_id);
}

                    if(pRow_row3.as_on != null) {
pstmt_tDBOutput_3.setTimestamp(10, new java.sql.Timestamp(pRow_row3.as_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(10, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_3.addBatch();
    		nb_line_tDBOutput_3++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Adding the record ")  + (nb_line_tDBOutput_3)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_3++;
    		  
    			if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                try {
						int countSum_tDBOutput_3 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            	    	batchSizeCounter_tDBOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
				    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
				    	String errormessage_tDBOutput_3;
						if (ne_tDBOutput_3 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
							errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
						}else{
							errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
						}
				    	
				    	int countSum_tDBOutput_3 = 0;
						for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
				    	System.err.println(errormessage_tDBOutput_3);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_option_group_dw\"";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_option_group_dw\"";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

 



/**
 * [tAsyncIn_tDBOutput_3 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_3.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_3", true);
end_Hash.put("tAsyncIn_tDBOutput_3", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_3 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_option_group_dw\"";
		



	    try {
				int countSum_tDBOutput_3 = 0;
				if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
	    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
	    	String errormessage_tDBOutput_3;
			if (ne_tDBOutput_3 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
				errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
			}else{
				errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
			}
	    	
	    	int countSum_tDBOutput_3 = 0;
			for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
				countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
			}
			rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
			
	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
	    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
	    	System.err.println(errormessage_tDBOutput_3);
	    	
		}
	    
        if(pstmt_tDBOutput_3 != null) {
        		
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
    	if (globalMap.get("tDBOutput_3_NB_LINE") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE",(Integer)globalMap.get("tDBOutput_3_NB_LINE") + nb_line_tDBOutput_3);
        }
        if (globalMap.get("tDBOutput_3_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_3_NB_LINE_UPDATED") + nb_line_update_tDBOutput_3);
        }
        if (globalMap.get("tDBOutput_3_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_3_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_3);
        }
        if (globalMap.get("tDBOutput_3_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_3_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_3);
        }
        if (globalMap.get("tDBOutput_3_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_3_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_3);
        } else {
        	globalMap.put("tDBOutput_3_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_3_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_3);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row3",2,0,
			 			"tAsyncIn_tDBOutput_3","tAsyncIn_tDBOutput_3","tAsyncIn","tDBOutput_3","\"mst_option_group_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_3";
	
	

 



/**
 * [tAsyncIn_tDBOutput_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="\"mst_option_group_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_3");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_3_ParallelThread pt = new tAsyncIn_tDBOutput_3_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_3"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_3_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row4Struct implements routines.system.IPersistableRow<pRow_row4Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String option_name;

				public String getOption_name () {
					return this.option_name;
				}

				public Boolean option_nameIsNullable(){
				    return false;
				}
				public Boolean option_nameIsKey(){
				    return false;
				}
				public Integer option_nameLength(){
				    return 50;
				}
				public Integer option_namePrecision(){
				    return 0;
				}
				public String option_nameDefault(){
				
					return null;
				
				}
				public String option_nameComment(){
				
				    return "";
				
				}
				public String option_namePattern(){
				
					return "";
				
				}
				public String option_nameOriginalDbColumnName(){
				
					return "option_name";
				
				}

				
			    public Float option_marks;

				public Float getOption_marks () {
					return this.option_marks;
				}

				public Boolean option_marksIsNullable(){
				    return true;
				}
				public Boolean option_marksIsKey(){
				    return false;
				}
				public Integer option_marksLength(){
				    return 8;
				}
				public Integer option_marksPrecision(){
				    return 8;
				}
				public String option_marksDefault(){
				
					return "'0'::real";
				
				}
				public String option_marksComment(){
				
				    return "";
				
				}
				public String option_marksPattern(){
				
					return "";
				
				}
				public String option_marksOriginalDbColumnName(){
				
					return "option_marks";
				
				}

				
			    public int option_group_id;

				public int getOption_group_id () {
					return this.option_group_id;
				}

				public Boolean option_group_idIsNullable(){
				    return false;
				}
				public Boolean option_group_idIsKey(){
				    return false;
				}
				public Integer option_group_idLength(){
				    return 10;
				}
				public Integer option_group_idPrecision(){
				    return 0;
				}
				public String option_group_idDefault(){
				
					return null;
				
				}
				public String option_group_idComment(){
				
				    return "";
				
				}
				public String option_group_idPattern(){
				
					return "";
				
				}
				public String option_group_idOriginalDbColumnName(){
				
					return "option_group_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String option_group_lines_id;

				public String getOption_group_lines_id () {
					return this.option_group_lines_id;
				}

				public Boolean option_group_lines_idIsNullable(){
				    return true;
				}
				public Boolean option_group_lines_idIsKey(){
				    return false;
				}
				public Integer option_group_lines_idLength(){
				    return 32;
				}
				public Integer option_group_lines_idPrecision(){
				    return 0;
				}
				public String option_group_lines_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String option_group_lines_idComment(){
				
				    return "";
				
				}
				public String option_group_lines_idPattern(){
				
					return "";
				
				}
				public String option_group_lines_idOriginalDbColumnName(){
				
					return "option_group_lines_id";
				
				}

				
			    public Integer observation;

				public Integer getObservation () {
					return this.observation;
				}

				public Boolean observationIsNullable(){
				    return true;
				}
				public Boolean observationIsKey(){
				    return false;
				}
				public Integer observationLength(){
				    return 10;
				}
				public Integer observationPrecision(){
				    return 0;
				}
				public String observationDefault(){
				
					return "0";
				
				}
				public String observationComment(){
				
				    return "";
				
				}
				public String observationPattern(){
				
					return "";
				
				}
				public String observationOriginalDbColumnName(){
				
					return "observation";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row4Struct other = (pRow_row4Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row4Struct other) {

		other.id = this.id;
	            other.option_name = this.option_name;
	            other.option_marks = this.option_marks;
	            other.option_group_id = this.option_group_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.option_group_lines_id = this.option_group_lines_id;
	            other.observation = this.observation;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row4Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.option_marks = null;
           				} else {
           			    	this.option_marks = dis.readFloat();
           				}
					
			        this.option_group_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_group_lines_id = readString(dis);
					
						this.observation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.option_marks = null;
           				} else {
           			    	this.option_marks = dis.readFloat();
           				}
					
			        this.option_group_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.option_group_lines_id = readString(dis);
					
						this.observation = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.option_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.option_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.option_group_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_group_lines_id,dos);
					
					// Integer
				
						writeInteger(this.observation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.option_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.option_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.option_group_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.option_group_lines_id,dos);
					
					// Integer
				
						writeInteger(this.observation,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",option_name="+option_name);
		sb.append(",option_marks="+String.valueOf(option_marks));
		sb.append(",option_group_id="+String.valueOf(option_group_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",option_group_lines_id="+option_group_lines_id);
		sb.append(",observation="+String.valueOf(observation));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(option_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_name);
            			}
            		
        			sb.append("|");
        		
        				if(option_marks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_marks);
            			}
            		
        			sb.append("|");
        		
        				sb.append(option_group_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(option_group_lines_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_group_lines_id);
            			}
            		
        			sb.append("|");
        		
        				if(observation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_4");
		org.slf4j.MDC.put("_subJobPid", "Bw9Zrk_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_4");
		class tAsyncIn_tDBOutput_4_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_4_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row4Struct pRow_row4 = new pRow_row4Struct();




	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_option_group_lines_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row4");
			
		int tos_count_tDBOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_4 = new StringBuilder();
                    log4jParamters_tDBOutput_4.append("Parameters:");
                            log4jParamters_tDBOutput_4.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("TABLE" + " = " + "\"mst_option_group_lines_dw\"");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_4.append(" | ");
                            log4jParamters_tDBOutput_4.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + (log4jParamters_tDBOutput_4) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_4", "\"mst_option_group_lines_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_4 = null;
	dbschema_tDBOutput_4 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_4 = null;
if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
	tableName_tDBOutput_4 = ("mst_option_group_lines_dw");
} else {
	tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "\".\"" + ("mst_option_group_lines_dw");
}


int nb_line_tDBOutput_4 = 0;
int nb_line_update_tDBOutput_4 = 0;
int nb_line_inserted_tDBOutput_4 = 0;
int nb_line_deleted_tDBOutput_4 = 0;
int nb_line_rejected_tDBOutput_4 = 0;

int deletedCount_tDBOutput_4=0;
int updatedCount_tDBOutput_4=0;
int insertedCount_tDBOutput_4=0;
int rowsToCommitCount_tDBOutput_4=0;
int rejectedCount_tDBOutput_4=0;

boolean whetherReject_tDBOutput_4 = false;

java.sql.Connection conn_tDBOutput_4 = null;
String dbUser_tDBOutput_4 = null;

	conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_4.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_4.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_4 = 10000;
   int batchSizeCounter_tDBOutput_4=0;

int count_tDBOutput_4=0;
        java.lang.StringBuilder sb_tDBOutput_4 = new java.lang.StringBuilder();
        sb_tDBOutput_4.append("INSERT INTO \"").append(tableName_tDBOutput_4).append("\" (\"id\",\"option_name\",\"option_marks\",\"option_group_id\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"option_group_lines_id\",\"observation\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_4.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"option_name\" = EXCLUDED.\"option_name\",\"option_marks\" = EXCLUDED.\"option_marks\",\"option_group_id\" = EXCLUDED.\"option_group_id\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"option_group_lines_id\" = EXCLUDED.\"option_group_lines_id\",\"observation\" = EXCLUDED.\"observation\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_4 = sb_tDBOutput_4.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing '")  + (insert_tDBOutput_4)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
	    resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
	    

 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_4", false);
		start_Hash.put("tAsyncIn_tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	
		int tos_count_tAsyncIn_tDBOutput_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_4", "tAsyncIn_tDBOutput_4", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_4= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_4 = buffers_tAsyncIn_tDBOutput_4.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_4 != null && buffers_tAsyncIn_tDBOutput_4.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_4 : buffers_tAsyncIn_tDBOutput_4) {
    		pRow_row4 = null;						
			pRow_row4 = new pRow_row4Struct();
		
		
			String temp_tAsyncIn_tDBOutput_4_0 = row_tAsyncIn_tDBOutput_4[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[0]);
			if(temp_tAsyncIn_tDBOutput_4_0 != null) {
		
			pRow_row4.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_4_0);
		} else {						
			pRow_row4.id = 0;
		}
		pRow_row4.option_name = row_tAsyncIn_tDBOutput_4[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[1]);
		
		
			String temp_tAsyncIn_tDBOutput_4_2 = row_tAsyncIn_tDBOutput_4[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[2]);
			if(temp_tAsyncIn_tDBOutput_4_2 != null) {
		
			pRow_row4.option_marks = ParserUtils.parseTo_Float(temp_tAsyncIn_tDBOutput_4_2);
		} else {						
			pRow_row4.option_marks = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_3 = row_tAsyncIn_tDBOutput_4[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[3]);
			if(temp_tAsyncIn_tDBOutput_4_3 != null) {
		
			pRow_row4.option_group_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_4_3);
		} else {						
			pRow_row4.option_group_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_4 = row_tAsyncIn_tDBOutput_4[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[4]);
			if(temp_tAsyncIn_tDBOutput_4_4 != null) {
		
			pRow_row4.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_4_4);
		} else {						
			pRow_row4.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_5 = row_tAsyncIn_tDBOutput_4[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[5]);
			if(temp_tAsyncIn_tDBOutput_4_5 != null) {
		
			pRow_row4.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_4[5]);
		} else {						
			pRow_row4.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_6 = row_tAsyncIn_tDBOutput_4[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[6]);
			if(temp_tAsyncIn_tDBOutput_4_6 != null) {
		
			pRow_row4.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_4_6);
		} else {						
			pRow_row4.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_7 = row_tAsyncIn_tDBOutput_4[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[7]);
			if(temp_tAsyncIn_tDBOutput_4_7 != null) {
		
			pRow_row4.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_4[7]);
		} else {						
			pRow_row4.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_8 = row_tAsyncIn_tDBOutput_4[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[8]);
			if(temp_tAsyncIn_tDBOutput_4_8 != null) {
		
			pRow_row4.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_4_8);
		} else {						
			pRow_row4.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_9 = row_tAsyncIn_tDBOutput_4[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[9]);
			if(temp_tAsyncIn_tDBOutput_4_9 != null) {
		
			pRow_row4.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_4_9);
		} else {						
			pRow_row4.is_deleted = 0;
		}
		pRow_row4.option_group_lines_id = row_tAsyncIn_tDBOutput_4[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[10]);
		
		
			String temp_tAsyncIn_tDBOutput_4_11 = row_tAsyncIn_tDBOutput_4[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[11]);
			if(temp_tAsyncIn_tDBOutput_4_11 != null) {
		
			pRow_row4.observation = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_4_11);
		} else {						
			pRow_row4.observation = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_4_12 = row_tAsyncIn_tDBOutput_4[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_4[12]);
			if(temp_tAsyncIn_tDBOutput_4_12 != null) {
		
			pRow_row4.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_4[12]);
		} else {						
			pRow_row4.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_4 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

 


	tos_count_tAsyncIn_tDBOutput_4++;

/**
 * [tAsyncIn_tDBOutput_4 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

 



/**
 * [tAsyncIn_tDBOutput_4 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_option_group_lines_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row4","tAsyncIn_tDBOutput_4","tAsyncIn_tDBOutput_4","tAsyncIn","tDBOutput_4","\"mst_option_group_lines_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row4 - " + (pRow_row4==null? "": pRow_row4.toLogString()));
    			}
    		



				batchSize_tDBOutput_4 = buffersSize_tAsyncIn_tDBOutput_4;
        whetherReject_tDBOutput_4 = false;
                    pstmt_tDBOutput_4.setInt(1, pRow_row4.id);

                    if(pRow_row4.option_name == null) {
pstmt_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(2, pRow_row4.option_name);
}

                    if(pRow_row4.option_marks == null) {
pstmt_tDBOutput_4.setNull(3, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_4.setFloat(3, pRow_row4.option_marks);
}

                    pstmt_tDBOutput_4.setInt(4, pRow_row4.option_group_id);

                    if(pRow_row4.created_by == null) {
pstmt_tDBOutput_4.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(5, pRow_row4.created_by);
}

                    if(pRow_row4.created_on != null) {
pstmt_tDBOutput_4.setTimestamp(6, new java.sql.Timestamp(pRow_row4.created_on.getTime()));
} else {
pstmt_tDBOutput_4.setNull(6, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row4.updated_by == null) {
pstmt_tDBOutput_4.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(7, pRow_row4.updated_by);
}

                    if(pRow_row4.updated_on != null) {
pstmt_tDBOutput_4.setTimestamp(8, new java.sql.Timestamp(pRow_row4.updated_on.getTime()));
} else {
pstmt_tDBOutput_4.setNull(8, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_4.setInt(9, pRow_row4.is_active);

                    pstmt_tDBOutput_4.setInt(10, pRow_row4.is_deleted);

                    if(pRow_row4.option_group_lines_id == null) {
pstmt_tDBOutput_4.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_4.setString(11, pRow_row4.option_group_lines_id);
}

                    if(pRow_row4.observation == null) {
pstmt_tDBOutput_4.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_4.setInt(12, pRow_row4.observation);
}

                    if(pRow_row4.as_on != null) {
pstmt_tDBOutput_4.setTimestamp(13, new java.sql.Timestamp(pRow_row4.as_on.getTime()));
} else {
pstmt_tDBOutput_4.setNull(13, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_4.addBatch();
    		nb_line_tDBOutput_4++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Adding the record ")  + (nb_line_tDBOutput_4)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_4++;
    		  
    			if ((batchSize_tDBOutput_4 > 0) && (batchSize_tDBOutput_4 <= batchSizeCounter_tDBOutput_4)) {
                try {
						int countSum_tDBOutput_4 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            	    	batchSizeCounter_tDBOutput_4 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
				    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
				    	String errormessage_tDBOutput_4;
						if (ne_tDBOutput_4 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
							errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
						}else{
							errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
						}
				    	
				    	int countSum_tDBOutput_4 = 0;
						for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
							countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
						}
						rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
				    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
				    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
				    	System.err.println(errormessage_tDBOutput_4);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_option_group_lines_dw\"";
		

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_option_group_lines_dw\"";
		

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

 



/**
 * [tAsyncIn_tDBOutput_4 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_4.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_4", true);
end_Hash.put("tAsyncIn_tDBOutput_4", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_4 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_option_group_lines_dw\"";
		



	    try {
				int countSum_tDBOutput_4 = 0;
				if (pstmt_tDBOutput_4 != null && batchSizeCounter_tDBOutput_4 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_4: pstmt_tDBOutput_4.executeBatch()) {
						countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
					}
					rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_4){
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
	    	java.sql.SQLException ne_tDBOutput_4 = e_tDBOutput_4.getNextException(),sqle_tDBOutput_4=null;
	    	String errormessage_tDBOutput_4;
			if (ne_tDBOutput_4 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_4 = new java.sql.SQLException(e_tDBOutput_4.getMessage() + "\ncaused by: " + ne_tDBOutput_4.getMessage(), ne_tDBOutput_4.getSQLState(), ne_tDBOutput_4.getErrorCode(), ne_tDBOutput_4);
				errormessage_tDBOutput_4 = sqle_tDBOutput_4.getMessage();
			}else{
				errormessage_tDBOutput_4 = e_tDBOutput_4.getMessage();
			}
	    	
	    	int countSum_tDBOutput_4 = 0;
			for(int countEach_tDBOutput_4: e_tDBOutput_4.getUpdateCounts()) {
				countSum_tDBOutput_4 += (countEach_tDBOutput_4 < 0 ? 0 : countEach_tDBOutput_4);
			}
			rowsToCommitCount_tDBOutput_4 += countSum_tDBOutput_4;
			
	    		insertedCount_tDBOutput_4 += countSum_tDBOutput_4;
	    	
            log.error("tDBOutput_4 - "  + (errormessage_tDBOutput_4) );
	    	System.err.println(errormessage_tDBOutput_4);
	    	
		}
	    
        if(pstmt_tDBOutput_4 != null) {
        		
            pstmt_tDBOutput_4.close();
            resourceMap.remove("pstmt_tDBOutput_4");
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);

	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
    	if (globalMap.get("tDBOutput_4_NB_LINE") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE",(Integer)globalMap.get("tDBOutput_4_NB_LINE") + nb_line_tDBOutput_4);
        }
        if (globalMap.get("tDBOutput_4_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_4_NB_LINE_UPDATED") + nb_line_update_tDBOutput_4);
        }
        if (globalMap.get("tDBOutput_4_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_4_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_4);
        }
        if (globalMap.get("tDBOutput_4_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_4_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_4);
        }
        if (globalMap.get("tDBOutput_4_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_4_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_4);
        } else {
        	globalMap.put("tDBOutput_4_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_4_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_4);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row4",2,0,
			 			"tAsyncIn_tDBOutput_4","tAsyncIn_tDBOutput_4","tAsyncIn","tDBOutput_4","\"mst_option_group_lines_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_4 - "  + ("Done.") );

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_4";
	
	

 



/**
 * [tAsyncIn_tDBOutput_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";
	
	
			cLabel="\"mst_option_group_lines_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_4");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_4_ParallelThread pt = new tAsyncIn_tDBOutput_4_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_4"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_4_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row5Struct implements routines.system.IPersistableRow<pRow_row5Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String process_name;

				public String getProcess_name () {
					return this.process_name;
				}

				public Boolean process_nameIsNullable(){
				    return false;
				}
				public Boolean process_nameIsKey(){
				    return false;
				}
				public Integer process_nameLength(){
				    return 150;
				}
				public Integer process_namePrecision(){
				    return 0;
				}
				public String process_nameDefault(){
				
					return null;
				
				}
				public String process_nameComment(){
				
				    return "";
				
				}
				public String process_namePattern(){
				
					return "";
				
				}
				public String process_nameOriginalDbColumnName(){
				
					return "process_name";
				
				}

				
			    public Float parent_process;

				public Float getParent_process () {
					return this.parent_process;
				}

				public Boolean parent_processIsNullable(){
				    return true;
				}
				public Boolean parent_processIsKey(){
				    return false;
				}
				public Integer parent_processLength(){
				    return 8;
				}
				public Integer parent_processPrecision(){
				    return 8;
				}
				public String parent_processDefault(){
				
					return null;
				
				}
				public String parent_processComment(){
				
				    return "";
				
				}
				public String parent_processPattern(){
				
					return "";
				
				}
				public String parent_processOriginalDbColumnName(){
				
					return "parent_process";
				
				}

				
			    public String tagging_type;

				public String getTagging_type () {
					return this.tagging_type;
				}

				public Boolean tagging_typeIsNullable(){
				    return true;
				}
				public Boolean tagging_typeIsKey(){
				    return false;
				}
				public Integer tagging_typeLength(){
				    return 2;
				}
				public Integer tagging_typePrecision(){
				    return 0;
				}
				public String tagging_typeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String tagging_typeComment(){
				
				    return "";
				
				}
				public String tagging_typePattern(){
				
					return "";
				
				}
				public String tagging_typeOriginalDbColumnName(){
				
					return "tagging_type";
				
				}

				
			    public Integer process_order;

				public Integer getProcess_order () {
					return this.process_order;
				}

				public Boolean process_orderIsNullable(){
				    return true;
				}
				public Boolean process_orderIsKey(){
				    return false;
				}
				public Integer process_orderLength(){
				    return 10;
				}
				public Integer process_orderPrecision(){
				    return 0;
				}
				public String process_orderDefault(){
				
					return "0";
				
				}
				public String process_orderComment(){
				
				    return "";
				
				}
				public String process_orderPattern(){
				
					return "";
				
				}
				public String process_orderOriginalDbColumnName(){
				
					return "process_order";
				
				}

				
			    public Integer subprocess_order;

				public Integer getSubprocess_order () {
					return this.subprocess_order;
				}

				public Boolean subprocess_orderIsNullable(){
				    return true;
				}
				public Boolean subprocess_orderIsKey(){
				    return false;
				}
				public Integer subprocess_orderLength(){
				    return 10;
				}
				public Integer subprocess_orderPrecision(){
				    return 0;
				}
				public String subprocess_orderDefault(){
				
					return "0";
				
				}
				public String subprocess_orderComment(){
				
				    return "";
				
				}
				public String subprocess_orderPattern(){
				
					return "";
				
				}
				public String subprocess_orderOriginalDbColumnName(){
				
					return "subprocess_order";
				
				}

				
			    public Integer weightage;

				public Integer getWeightage () {
					return this.weightage;
				}

				public Boolean weightageIsNullable(){
				    return true;
				}
				public Boolean weightageIsKey(){
				    return false;
				}
				public Integer weightageLength(){
				    return 10;
				}
				public Integer weightagePrecision(){
				    return 0;
				}
				public String weightageDefault(){
				
					return "0";
				
				}
				public String weightageComment(){
				
				    return "";
				
				}
				public String weightagePattern(){
				
					return "";
				
				}
				public String weightageOriginalDbColumnName(){
				
					return "weightage";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String process_id;

				public String getProcess_id () {
					return this.process_id;
				}

				public Boolean process_idIsNullable(){
				    return true;
				}
				public Boolean process_idIsKey(){
				    return false;
				}
				public Integer process_idLength(){
				    return 32;
				}
				public Integer process_idPrecision(){
				    return 0;
				}
				public String process_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String process_idComment(){
				
				    return "";
				
				}
				public String process_idPattern(){
				
					return "";
				
				}
				public String process_idOriginalDbColumnName(){
				
					return "process_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row5Struct other = (pRow_row5Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row5Struct other) {

		other.id = this.id;
	            other.process_name = this.process_name;
	            other.parent_process = this.parent_process;
	            other.tagging_type = this.tagging_type;
	            other.process_order = this.process_order;
	            other.subprocess_order = this.subprocess_order;
	            other.weightage = this.weightage;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.process_id = this.process_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row5Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.process_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.parent_process = null;
           				} else {
           			    	this.parent_process = dis.readFloat();
           				}
					
					this.tagging_type = readString(dis);
					
						this.process_order = readInteger(dis);
					
						this.subprocess_order = readInteger(dis);
					
						this.weightage = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.process_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.process_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.parent_process = null;
           				} else {
           			    	this.parent_process = dis.readFloat();
           				}
					
					this.tagging_type = readString(dis);
					
						this.process_order = readInteger(dis);
					
						this.subprocess_order = readInteger(dis);
					
						this.weightage = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.process_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.process_name,dos);
					
					// Float
				
						if(this.parent_process == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.parent_process);
		            	}
					
					// String
				
						writeString(this.tagging_type,dos);
					
					// Integer
				
						writeInteger(this.process_order,dos);
					
					// Integer
				
						writeInteger(this.subprocess_order,dos);
					
					// Integer
				
						writeInteger(this.weightage,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.process_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.process_name,dos);
					
					// Float
				
						if(this.parent_process == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.parent_process);
		            	}
					
					// String
				
						writeString(this.tagging_type,dos);
					
					// Integer
				
						writeInteger(this.process_order,dos);
					
					// Integer
				
						writeInteger(this.subprocess_order,dos);
					
					// Integer
				
						writeInteger(this.weightage,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.process_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",process_name="+process_name);
		sb.append(",parent_process="+String.valueOf(parent_process));
		sb.append(",tagging_type="+tagging_type);
		sb.append(",process_order="+String.valueOf(process_order));
		sb.append(",subprocess_order="+String.valueOf(subprocess_order));
		sb.append(",weightage="+String.valueOf(weightage));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",process_id="+process_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(process_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_name);
            			}
            		
        			sb.append("|");
        		
        				if(parent_process == null){
        					sb.append("<null>");
        				}else{
            				sb.append(parent_process);
            			}
            		
        			sb.append("|");
        		
        				if(tagging_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(tagging_type);
            			}
            		
        			sb.append("|");
        		
        				if(process_order == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_order);
            			}
            		
        			sb.append("|");
        		
        				if(subprocess_order == null){
        					sb.append("<null>");
        				}else{
            				sb.append(subprocess_order);
            			}
            		
        			sb.append("|");
        		
        				if(weightage == null){
        					sb.append("<null>");
        				}else{
            				sb.append(weightage);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(process_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_5");
		org.slf4j.MDC.put("_subJobPid", "7YnWHh_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_5");
		class tAsyncIn_tDBOutput_5_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_5_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row5Struct pRow_row5 = new pRow_row5Struct();




	
	/**
	 * [tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_5", false);
		start_Hash.put("tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_process_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row5");
			
		int tos_count_tDBOutput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_5 = new StringBuilder();
                    log4jParamters_tDBOutput_5.append("Parameters:");
                            log4jParamters_tDBOutput_5.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("TABLE" + " = " + "\"mst_process_dw\"");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_5.append(" | ");
                            log4jParamters_tDBOutput_5.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + (log4jParamters_tDBOutput_5) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_5", "\"mst_process_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_5 = null;
	dbschema_tDBOutput_5 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_5 = null;
if(dbschema_tDBOutput_5 == null || dbschema_tDBOutput_5.trim().length() == 0) {
	tableName_tDBOutput_5 = ("mst_process_dw");
} else {
	tableName_tDBOutput_5 = dbschema_tDBOutput_5 + "\".\"" + ("mst_process_dw");
}


int nb_line_tDBOutput_5 = 0;
int nb_line_update_tDBOutput_5 = 0;
int nb_line_inserted_tDBOutput_5 = 0;
int nb_line_deleted_tDBOutput_5 = 0;
int nb_line_rejected_tDBOutput_5 = 0;

int deletedCount_tDBOutput_5=0;
int updatedCount_tDBOutput_5=0;
int insertedCount_tDBOutput_5=0;
int rowsToCommitCount_tDBOutput_5=0;
int rejectedCount_tDBOutput_5=0;

boolean whetherReject_tDBOutput_5 = false;

java.sql.Connection conn_tDBOutput_5 = null;
String dbUser_tDBOutput_5 = null;

	conn_tDBOutput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_5.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_5.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_5.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_5 = 10000;
   int batchSizeCounter_tDBOutput_5=0;

int count_tDBOutput_5=0;
        java.lang.StringBuilder sb_tDBOutput_5 = new java.lang.StringBuilder();
        sb_tDBOutput_5.append("INSERT INTO \"").append(tableName_tDBOutput_5).append("\" (\"id\",\"process_name\",\"parent_process\",\"tagging_type\",\"process_order\",\"subprocess_order\",\"weightage\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"process_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_5.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"process_name\" = EXCLUDED.\"process_name\",\"parent_process\" = EXCLUDED.\"parent_process\",\"tagging_type\" = EXCLUDED.\"tagging_type\",\"process_order\" = EXCLUDED.\"process_order\",\"subprocess_order\" = EXCLUDED.\"subprocess_order\",\"weightage\" = EXCLUDED.\"weightage\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"process_id\" = EXCLUDED.\"process_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_5 = sb_tDBOutput_5.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing '")  + (insert_tDBOutput_5)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
	    resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);
	    

 



/**
 * [tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_5", false);
		start_Hash.put("tAsyncIn_tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	
		int tos_count_tAsyncIn_tDBOutput_5 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_5", "tAsyncIn_tDBOutput_5", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_5= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_5 = buffers_tAsyncIn_tDBOutput_5.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_5 != null && buffers_tAsyncIn_tDBOutput_5.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_5 : buffers_tAsyncIn_tDBOutput_5) {
    		pRow_row5 = null;						
			pRow_row5 = new pRow_row5Struct();
		
		
			String temp_tAsyncIn_tDBOutput_5_0 = row_tAsyncIn_tDBOutput_5[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[0]);
			if(temp_tAsyncIn_tDBOutput_5_0 != null) {
		
			pRow_row5.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_5_0);
		} else {						
			pRow_row5.id = 0;
		}
		pRow_row5.process_name = row_tAsyncIn_tDBOutput_5[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[1]);
		
		
			String temp_tAsyncIn_tDBOutput_5_2 = row_tAsyncIn_tDBOutput_5[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[2]);
			if(temp_tAsyncIn_tDBOutput_5_2 != null) {
		
			pRow_row5.parent_process = ParserUtils.parseTo_Float(temp_tAsyncIn_tDBOutput_5_2);
		} else {						
			pRow_row5.parent_process = null;
		}
		pRow_row5.tagging_type = row_tAsyncIn_tDBOutput_5[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[3]);
		
		
			String temp_tAsyncIn_tDBOutput_5_4 = row_tAsyncIn_tDBOutput_5[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[4]);
			if(temp_tAsyncIn_tDBOutput_5_4 != null) {
		
			pRow_row5.process_order = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_5_4);
		} else {						
			pRow_row5.process_order = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_5 = row_tAsyncIn_tDBOutput_5[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[5]);
			if(temp_tAsyncIn_tDBOutput_5_5 != null) {
		
			pRow_row5.subprocess_order = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_5_5);
		} else {						
			pRow_row5.subprocess_order = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_6 = row_tAsyncIn_tDBOutput_5[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[6]);
			if(temp_tAsyncIn_tDBOutput_5_6 != null) {
		
			pRow_row5.weightage = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_5_6);
		} else {						
			pRow_row5.weightage = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_7 = row_tAsyncIn_tDBOutput_5[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[7]);
			if(temp_tAsyncIn_tDBOutput_5_7 != null) {
		
			pRow_row5.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_5_7);
		} else {						
			pRow_row5.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_8 = row_tAsyncIn_tDBOutput_5[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[8]);
			if(temp_tAsyncIn_tDBOutput_5_8 != null) {
		
			pRow_row5.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_5[8]);
		} else {						
			pRow_row5.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_9 = row_tAsyncIn_tDBOutput_5[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[9]);
			if(temp_tAsyncIn_tDBOutput_5_9 != null) {
		
			pRow_row5.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_5_9);
		} else {						
			pRow_row5.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_10 = row_tAsyncIn_tDBOutput_5[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[10]);
			if(temp_tAsyncIn_tDBOutput_5_10 != null) {
		
			pRow_row5.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_5[10]);
		} else {						
			pRow_row5.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_11 = row_tAsyncIn_tDBOutput_5[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[11]);
			if(temp_tAsyncIn_tDBOutput_5_11 != null) {
		
			pRow_row5.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_5_11);
		} else {						
			pRow_row5.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_5_12 = row_tAsyncIn_tDBOutput_5[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[12]);
			if(temp_tAsyncIn_tDBOutput_5_12 != null) {
		
			pRow_row5.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_5_12);
		} else {						
			pRow_row5.is_deleted = 0;
		}
		pRow_row5.process_id = row_tAsyncIn_tDBOutput_5[13]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[13]);
		
		
			String temp_tAsyncIn_tDBOutput_5_14 = row_tAsyncIn_tDBOutput_5[14]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_5[14]);
			if(temp_tAsyncIn_tDBOutput_5_14 != null) {
		
			pRow_row5.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_5[14]);
		} else {						
			pRow_row5.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_5 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

 


	tos_count_tAsyncIn_tDBOutput_5++;

/**
 * [tAsyncIn_tDBOutput_5 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

 



/**
 * [tAsyncIn_tDBOutput_5 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_process_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row5","tAsyncIn_tDBOutput_5","tAsyncIn_tDBOutput_5","tAsyncIn","tDBOutput_5","\"mst_process_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row5 - " + (pRow_row5==null? "": pRow_row5.toLogString()));
    			}
    		



				batchSize_tDBOutput_5 = buffersSize_tAsyncIn_tDBOutput_5;
        whetherReject_tDBOutput_5 = false;
                    pstmt_tDBOutput_5.setInt(1, pRow_row5.id);

                    if(pRow_row5.process_name == null) {
pstmt_tDBOutput_5.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(2, pRow_row5.process_name);
}

                    if(pRow_row5.parent_process == null) {
pstmt_tDBOutput_5.setNull(3, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_5.setFloat(3, pRow_row5.parent_process);
}

                    if(pRow_row5.tagging_type == null) {
pstmt_tDBOutput_5.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(4, pRow_row5.tagging_type);
}

                    if(pRow_row5.process_order == null) {
pstmt_tDBOutput_5.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(5, pRow_row5.process_order);
}

                    if(pRow_row5.subprocess_order == null) {
pstmt_tDBOutput_5.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(6, pRow_row5.subprocess_order);
}

                    if(pRow_row5.weightage == null) {
pstmt_tDBOutput_5.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(7, pRow_row5.weightage);
}

                    if(pRow_row5.created_by == null) {
pstmt_tDBOutput_5.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(8, pRow_row5.created_by);
}

                    if(pRow_row5.created_on != null) {
pstmt_tDBOutput_5.setTimestamp(9, new java.sql.Timestamp(pRow_row5.created_on.getTime()));
} else {
pstmt_tDBOutput_5.setNull(9, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row5.updated_by == null) {
pstmt_tDBOutput_5.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_5.setInt(10, pRow_row5.updated_by);
}

                    if(pRow_row5.updated_on != null) {
pstmt_tDBOutput_5.setTimestamp(11, new java.sql.Timestamp(pRow_row5.updated_on.getTime()));
} else {
pstmt_tDBOutput_5.setNull(11, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_5.setInt(12, pRow_row5.is_active);

                    pstmt_tDBOutput_5.setInt(13, pRow_row5.is_deleted);

                    if(pRow_row5.process_id == null) {
pstmt_tDBOutput_5.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_5.setString(14, pRow_row5.process_id);
}

                    if(pRow_row5.as_on != null) {
pstmt_tDBOutput_5.setTimestamp(15, new java.sql.Timestamp(pRow_row5.as_on.getTime()));
} else {
pstmt_tDBOutput_5.setNull(15, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_5.addBatch();
    		nb_line_tDBOutput_5++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Adding the record ")  + (nb_line_tDBOutput_5)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_5++;
    		  
    			if ((batchSize_tDBOutput_5 > 0) && (batchSize_tDBOutput_5 <= batchSizeCounter_tDBOutput_5)) {
                try {
						int countSum_tDBOutput_5 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            	    	batchSizeCounter_tDBOutput_5 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
				    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
				    	String errormessage_tDBOutput_5;
						if (ne_tDBOutput_5 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
							errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
						}else{
							errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
						}
				    	
				    	int countSum_tDBOutput_5 = 0;
						for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
							countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
						}
						rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
				    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
				    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
				    	System.err.println(errormessage_tDBOutput_5);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_5++;

/**
 * [tDBOutput_5 main ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_process_dw\"";
		

 



/**
 * [tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_process_dw\"";
		

 



/**
 * [tDBOutput_5 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

 



/**
 * [tAsyncIn_tDBOutput_5 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_5.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_5", true);
end_Hash.put("tAsyncIn_tDBOutput_5", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_5 end ] stop
 */

	
	/**
	 * [tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_process_dw\"";
		



	    try {
				int countSum_tDBOutput_5 = 0;
				if (pstmt_tDBOutput_5 != null && batchSizeCounter_tDBOutput_5 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_5: pstmt_tDBOutput_5.executeBatch()) {
						countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
					}
					rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_5){
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
	    	java.sql.SQLException ne_tDBOutput_5 = e_tDBOutput_5.getNextException(),sqle_tDBOutput_5=null;
	    	String errormessage_tDBOutput_5;
			if (ne_tDBOutput_5 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_5 = new java.sql.SQLException(e_tDBOutput_5.getMessage() + "\ncaused by: " + ne_tDBOutput_5.getMessage(), ne_tDBOutput_5.getSQLState(), ne_tDBOutput_5.getErrorCode(), ne_tDBOutput_5);
				errormessage_tDBOutput_5 = sqle_tDBOutput_5.getMessage();
			}else{
				errormessage_tDBOutput_5 = e_tDBOutput_5.getMessage();
			}
	    	
	    	int countSum_tDBOutput_5 = 0;
			for(int countEach_tDBOutput_5: e_tDBOutput_5.getUpdateCounts()) {
				countSum_tDBOutput_5 += (countEach_tDBOutput_5 < 0 ? 0 : countEach_tDBOutput_5);
			}
			rowsToCommitCount_tDBOutput_5 += countSum_tDBOutput_5;
			
	    		insertedCount_tDBOutput_5 += countSum_tDBOutput_5;
	    	
            log.error("tDBOutput_5 - "  + (errormessage_tDBOutput_5) );
	    	System.err.println(errormessage_tDBOutput_5);
	    	
		}
	    
        if(pstmt_tDBOutput_5 != null) {
        		
            pstmt_tDBOutput_5.close();
            resourceMap.remove("pstmt_tDBOutput_5");
        }
    resourceMap.put("statementClosed_tDBOutput_5", true);

	nb_line_deleted_tDBOutput_5=nb_line_deleted_tDBOutput_5+ deletedCount_tDBOutput_5;
	nb_line_update_tDBOutput_5=nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
	nb_line_inserted_tDBOutput_5=nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
	nb_line_rejected_tDBOutput_5=nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;
	
    	if (globalMap.get("tDBOutput_5_NB_LINE") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE",nb_line_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE",(Integer)globalMap.get("tDBOutput_5_NB_LINE") + nb_line_tDBOutput_5);
        }
        if (globalMap.get("tDBOutput_5_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE_UPDATED",nb_line_update_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_5_NB_LINE_UPDATED") + nb_line_update_tDBOutput_5);
        }
        if (globalMap.get("tDBOutput_5_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_5_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_5);
        }
        if (globalMap.get("tDBOutput_5_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE_DELETED",nb_line_deleted_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_5_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_5);
        }
        if (globalMap.get("tDBOutput_5_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_5_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_5);
        } else {
        	globalMap.put("tDBOutput_5_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_5_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_5);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row5",2,0,
			 			"tAsyncIn_tDBOutput_5","tAsyncIn_tDBOutput_5","tAsyncIn","tDBOutput_5","\"mst_process_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_5 - "  + ("Done.") );

ok_Hash.put("tDBOutput_5", true);
end_Hash.put("tDBOutput_5", System.currentTimeMillis());




/**
 * [tDBOutput_5 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_5";
	
	

 



/**
 * [tAsyncIn_tDBOutput_5 finally ] stop
 */

	
	/**
	 * [tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";
	
	
			cLabel="\"mst_process_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
                if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_5")) != null) {
                    pstmtToClose_tDBOutput_5.close();
                }
    }
 



/**
 * [tDBOutput_5 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_5");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_5_ParallelThread pt = new tAsyncIn_tDBOutput_5_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_5"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_5_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row6Struct implements routines.system.IPersistableRow<pRow_row6Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String question;

				public String getQuestion () {
					return this.question;
				}

				public Boolean questionIsNullable(){
				    return false;
				}
				public Boolean questionIsKey(){
				    return false;
				}
				public Integer questionLength(){
				    return 2147483647;
				}
				public Integer questionPrecision(){
				    return 0;
				}
				public String questionDefault(){
				
					return null;
				
				}
				public String questionComment(){
				
				    return "";
				
				}
				public String questionPattern(){
				
					return "";
				
				}
				public String questionOriginalDbColumnName(){
				
					return "question";
				
				}

				
			    public int option_group_id;

				public int getOption_group_id () {
					return this.option_group_id;
				}

				public Boolean option_group_idIsNullable(){
				    return false;
				}
				public Boolean option_group_idIsKey(){
				    return false;
				}
				public Integer option_group_idLength(){
				    return 10;
				}
				public Integer option_group_idPrecision(){
				    return 0;
				}
				public String option_group_idDefault(){
				
					return null;
				
				}
				public String option_group_idComment(){
				
				    return "";
				
				}
				public String option_group_idPattern(){
				
					return "";
				
				}
				public String option_group_idOriginalDbColumnName(){
				
					return "option_group_id";
				
				}

				
			    public Float min_marks;

				public Float getMin_marks () {
					return this.min_marks;
				}

				public Boolean min_marksIsNullable(){
				    return true;
				}
				public Boolean min_marksIsKey(){
				    return false;
				}
				public Integer min_marksLength(){
				    return 8;
				}
				public Integer min_marksPrecision(){
				    return 8;
				}
				public String min_marksDefault(){
				
					return "'0'::real";
				
				}
				public String min_marksComment(){
				
				    return "";
				
				}
				public String min_marksPattern(){
				
					return "";
				
				}
				public String min_marksOriginalDbColumnName(){
				
					return "min_marks";
				
				}

				
			    public Float max_marks;

				public Float getMax_marks () {
					return this.max_marks;
				}

				public Boolean max_marksIsNullable(){
				    return true;
				}
				public Boolean max_marksIsKey(){
				    return false;
				}
				public Integer max_marksLength(){
				    return 8;
				}
				public Integer max_marksPrecision(){
				    return 8;
				}
				public String max_marksDefault(){
				
					return "'0'::real";
				
				}
				public String max_marksComment(){
				
				    return "";
				
				}
				public String max_marksPattern(){
				
					return "";
				
				}
				public String max_marksOriginalDbColumnName(){
				
					return "max_marks";
				
				}

				
			    public int checklist_id;

				public int getChecklist_id () {
					return this.checklist_id;
				}

				public Boolean checklist_idIsNullable(){
				    return false;
				}
				public Boolean checklist_idIsKey(){
				    return false;
				}
				public Integer checklist_idLength(){
				    return 10;
				}
				public Integer checklist_idPrecision(){
				    return 0;
				}
				public String checklist_idDefault(){
				
					return null;
				
				}
				public String checklist_idComment(){
				
				    return "";
				
				}
				public String checklist_idPattern(){
				
					return "";
				
				}
				public String checklist_idOriginalDbColumnName(){
				
					return "checklist_id";
				
				}

				
			    public int category_id;

				public int getCategory_id () {
					return this.category_id;
				}

				public Boolean category_idIsNullable(){
				    return false;
				}
				public Boolean category_idIsKey(){
				    return false;
				}
				public Integer category_idLength(){
				    return 10;
				}
				public Integer category_idPrecision(){
				    return 0;
				}
				public String category_idDefault(){
				
					return null;
				
				}
				public String category_idComment(){
				
				    return "";
				
				}
				public String category_idPattern(){
				
					return "";
				
				}
				public String category_idOriginalDbColumnName(){
				
					return "category_id";
				
				}

				
			    public Integer process_id;

				public Integer getProcess_id () {
					return this.process_id;
				}

				public Boolean process_idIsNullable(){
				    return true;
				}
				public Boolean process_idIsKey(){
				    return false;
				}
				public Integer process_idLength(){
				    return 10;
				}
				public Integer process_idPrecision(){
				    return 0;
				}
				public String process_idDefault(){
				
					return null;
				
				}
				public String process_idComment(){
				
				    return "";
				
				}
				public String process_idPattern(){
				
					return "";
				
				}
				public String process_idOriginalDbColumnName(){
				
					return "process_id";
				
				}

				
			    public Integer subprocess_id;

				public Integer getSubprocess_id () {
					return this.subprocess_id;
				}

				public Boolean subprocess_idIsNullable(){
				    return true;
				}
				public Boolean subprocess_idIsKey(){
				    return false;
				}
				public Integer subprocess_idLength(){
				    return 10;
				}
				public Integer subprocess_idPrecision(){
				    return 0;
				}
				public String subprocess_idDefault(){
				
					return null;
				
				}
				public String subprocess_idComment(){
				
				    return "";
				
				}
				public String subprocess_idPattern(){
				
					return "";
				
				}
				public String subprocess_idOriginalDbColumnName(){
				
					return "subprocess_id";
				
				}

				
			    public int is_mandatory;

				public int getIs_mandatory () {
					return this.is_mandatory;
				}

				public Boolean is_mandatoryIsNullable(){
				    return false;
				}
				public Boolean is_mandatoryIsKey(){
				    return false;
				}
				public Integer is_mandatoryLength(){
				    return 10;
				}
				public Integer is_mandatoryPrecision(){
				    return 0;
				}
				public String is_mandatoryDefault(){
				
					return "1";
				
				}
				public String is_mandatoryComment(){
				
				    return "";
				
				}
				public String is_mandatoryPattern(){
				
					return "";
				
				}
				public String is_mandatoryOriginalDbColumnName(){
				
					return "is_mandatory";
				
				}

				
			    public Integer question_order;

				public Integer getQuestion_order () {
					return this.question_order;
				}

				public Boolean question_orderIsNullable(){
				    return true;
				}
				public Boolean question_orderIsKey(){
				    return false;
				}
				public Integer question_orderLength(){
				    return 10;
				}
				public Integer question_orderPrecision(){
				    return 0;
				}
				public String question_orderDefault(){
				
					return "0";
				
				}
				public String question_orderComment(){
				
				    return "";
				
				}
				public String question_orderPattern(){
				
					return "";
				
				}
				public String question_orderOriginalDbColumnName(){
				
					return "question_order";
				
				}

				
			    public String risk_type;

				public String getRisk_type () {
					return this.risk_type;
				}

				public Boolean risk_typeIsNullable(){
				    return true;
				}
				public Boolean risk_typeIsKey(){
				    return false;
				}
				public Integer risk_typeLength(){
				    return 45;
				}
				public Integer risk_typePrecision(){
				    return 0;
				}
				public String risk_typeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String risk_typeComment(){
				
				    return "";
				
				}
				public String risk_typePattern(){
				
					return "";
				
				}
				public String risk_typeOriginalDbColumnName(){
				
					return "risk_type";
				
				}

				
			    public Integer is_fraud;

				public Integer getIs_fraud () {
					return this.is_fraud;
				}

				public Boolean is_fraudIsNullable(){
				    return true;
				}
				public Boolean is_fraudIsKey(){
				    return false;
				}
				public Integer is_fraudLength(){
				    return 10;
				}
				public Integer is_fraudPrecision(){
				    return 0;
				}
				public String is_fraudDefault(){
				
					return "0";
				
				}
				public String is_fraudComment(){
				
				    return "";
				
				}
				public String is_fraudPattern(){
				
					return "";
				
				}
				public String is_fraudOriginalDbColumnName(){
				
					return "is_fraud";
				
				}

				
			    public Integer is_linked;

				public Integer getIs_linked () {
					return this.is_linked;
				}

				public Boolean is_linkedIsNullable(){
				    return true;
				}
				public Boolean is_linkedIsKey(){
				    return false;
				}
				public Integer is_linkedLength(){
				    return 10;
				}
				public Integer is_linkedPrecision(){
				    return 0;
				}
				public String is_linkedDefault(){
				
					return "0";
				
				}
				public String is_linkedComment(){
				
				    return "";
				
				}
				public String is_linkedPattern(){
				
					return "";
				
				}
				public String is_linkedOriginalDbColumnName(){
				
					return "is_linked";
				
				}

				
			    public Integer is_primary;

				public Integer getIs_primary () {
					return this.is_primary;
				}

				public Boolean is_primaryIsNullable(){
				    return true;
				}
				public Boolean is_primaryIsKey(){
				    return false;
				}
				public Integer is_primaryLength(){
				    return 10;
				}
				public Integer is_primaryPrecision(){
				    return 0;
				}
				public String is_primaryDefault(){
				
					return "0";
				
				}
				public String is_primaryComment(){
				
				    return "";
				
				}
				public String is_primaryPattern(){
				
					return "";
				
				}
				public String is_primaryOriginalDbColumnName(){
				
					return "is_primary";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String question_id;

				public String getQuestion_id () {
					return this.question_id;
				}

				public Boolean question_idIsNullable(){
				    return true;
				}
				public Boolean question_idIsKey(){
				    return false;
				}
				public Integer question_idLength(){
				    return 32;
				}
				public Integer question_idPrecision(){
				    return 0;
				}
				public String question_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String question_idComment(){
				
				    return "";
				
				}
				public String question_idPattern(){
				
					return "";
				
				}
				public String question_idOriginalDbColumnName(){
				
					return "question_id";
				
				}

				
			    public String linking_id;

				public String getLinking_id () {
					return this.linking_id;
				}

				public Boolean linking_idIsNullable(){
				    return true;
				}
				public Boolean linking_idIsKey(){
				    return false;
				}
				public Integer linking_idLength(){
				    return 32;
				}
				public Integer linking_idPrecision(){
				    return 0;
				}
				public String linking_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String linking_idComment(){
				
				    return "";
				
				}
				public String linking_idPattern(){
				
					return "";
				
				}
				public String linking_idOriginalDbColumnName(){
				
					return "linking_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row6Struct other = (pRow_row6Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row6Struct other) {

		other.id = this.id;
	            other.question = this.question;
	            other.option_group_id = this.option_group_id;
	            other.min_marks = this.min_marks;
	            other.max_marks = this.max_marks;
	            other.checklist_id = this.checklist_id;
	            other.category_id = this.category_id;
	            other.process_id = this.process_id;
	            other.subprocess_id = this.subprocess_id;
	            other.is_mandatory = this.is_mandatory;
	            other.question_order = this.question_order;
	            other.risk_type = this.risk_type;
	            other.is_fraud = this.is_fraud;
	            other.is_linked = this.is_linked;
	            other.is_primary = this.is_primary;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.question_id = this.question_id;
	            other.linking_id = this.linking_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row6Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.question = readString(dis);
					
			        this.option_group_id = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.min_marks = null;
           				} else {
           			    	this.min_marks = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.max_marks = null;
           				} else {
           			    	this.max_marks = dis.readFloat();
           				}
					
			        this.checklist_id = dis.readInt();
					
			        this.category_id = dis.readInt();
					
						this.process_id = readInteger(dis);
					
						this.subprocess_id = readInteger(dis);
					
			        this.is_mandatory = dis.readInt();
					
						this.question_order = readInteger(dis);
					
					this.risk_type = readString(dis);
					
						this.is_fraud = readInteger(dis);
					
						this.is_linked = readInteger(dis);
					
						this.is_primary = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.question_id = readString(dis);
					
					this.linking_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.question = readString(dis);
					
			        this.option_group_id = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.min_marks = null;
           				} else {
           			    	this.min_marks = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.max_marks = null;
           				} else {
           			    	this.max_marks = dis.readFloat();
           				}
					
			        this.checklist_id = dis.readInt();
					
			        this.category_id = dis.readInt();
					
						this.process_id = readInteger(dis);
					
						this.subprocess_id = readInteger(dis);
					
			        this.is_mandatory = dis.readInt();
					
						this.question_order = readInteger(dis);
					
					this.risk_type = readString(dis);
					
						this.is_fraud = readInteger(dis);
					
						this.is_linked = readInteger(dis);
					
						this.is_primary = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.question_id = readString(dis);
					
					this.linking_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.question,dos);
					
					// int
				
		            	dos.writeInt(this.option_group_id);
					
					// Float
				
						if(this.min_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.min_marks);
		            	}
					
					// Float
				
						if(this.max_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.max_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.checklist_id);
					
					// int
				
		            	dos.writeInt(this.category_id);
					
					// Integer
				
						writeInteger(this.process_id,dos);
					
					// Integer
				
						writeInteger(this.subprocess_id,dos);
					
					// int
				
		            	dos.writeInt(this.is_mandatory);
					
					// Integer
				
						writeInteger(this.question_order,dos);
					
					// String
				
						writeString(this.risk_type,dos);
					
					// Integer
				
						writeInteger(this.is_fraud,dos);
					
					// Integer
				
						writeInteger(this.is_linked,dos);
					
					// Integer
				
						writeInteger(this.is_primary,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.question_id,dos);
					
					// String
				
						writeString(this.linking_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.question,dos);
					
					// int
				
		            	dos.writeInt(this.option_group_id);
					
					// Float
				
						if(this.min_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.min_marks);
		            	}
					
					// Float
				
						if(this.max_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.max_marks);
		            	}
					
					// int
				
		            	dos.writeInt(this.checklist_id);
					
					// int
				
		            	dos.writeInt(this.category_id);
					
					// Integer
				
						writeInteger(this.process_id,dos);
					
					// Integer
				
						writeInteger(this.subprocess_id,dos);
					
					// int
				
		            	dos.writeInt(this.is_mandatory);
					
					// Integer
				
						writeInteger(this.question_order,dos);
					
					// String
				
						writeString(this.risk_type,dos);
					
					// Integer
				
						writeInteger(this.is_fraud,dos);
					
					// Integer
				
						writeInteger(this.is_linked,dos);
					
					// Integer
				
						writeInteger(this.is_primary,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.question_id,dos);
					
					// String
				
						writeString(this.linking_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",question="+question);
		sb.append(",option_group_id="+String.valueOf(option_group_id));
		sb.append(",min_marks="+String.valueOf(min_marks));
		sb.append(",max_marks="+String.valueOf(max_marks));
		sb.append(",checklist_id="+String.valueOf(checklist_id));
		sb.append(",category_id="+String.valueOf(category_id));
		sb.append(",process_id="+String.valueOf(process_id));
		sb.append(",subprocess_id="+String.valueOf(subprocess_id));
		sb.append(",is_mandatory="+String.valueOf(is_mandatory));
		sb.append(",question_order="+String.valueOf(question_order));
		sb.append(",risk_type="+risk_type);
		sb.append(",is_fraud="+String.valueOf(is_fraud));
		sb.append(",is_linked="+String.valueOf(is_linked));
		sb.append(",is_primary="+String.valueOf(is_primary));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",question_id="+question_id);
		sb.append(",linking_id="+linking_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(question == null){
        					sb.append("<null>");
        				}else{
            				sb.append(question);
            			}
            		
        			sb.append("|");
        		
        				sb.append(option_group_id);
        			
        			sb.append("|");
        		
        				if(min_marks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(min_marks);
            			}
            		
        			sb.append("|");
        		
        				if(max_marks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(max_marks);
            			}
            		
        			sb.append("|");
        		
        				sb.append(checklist_id);
        			
        			sb.append("|");
        		
        				sb.append(category_id);
        			
        			sb.append("|");
        		
        				if(process_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_id);
            			}
            		
        			sb.append("|");
        		
        				if(subprocess_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(subprocess_id);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_mandatory);
        			
        			sb.append("|");
        		
        				if(question_order == null){
        					sb.append("<null>");
        				}else{
            				sb.append(question_order);
            			}
            		
        			sb.append("|");
        		
        				if(risk_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(risk_type);
            			}
            		
        			sb.append("|");
        		
        				if(is_fraud == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_fraud);
            			}
            		
        			sb.append("|");
        		
        				if(is_linked == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_linked);
            			}
            		
        			sb.append("|");
        		
        				if(is_primary == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_primary);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(question_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(question_id);
            			}
            		
        			sb.append("|");
        		
        				if(linking_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(linking_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row6Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_6");
		org.slf4j.MDC.put("_subJobPid", "5RMlX9_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_6");
		class tAsyncIn_tDBOutput_6_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_6_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row6Struct pRow_row6 = new pRow_row6Struct();




	
	/**
	 * [tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_6", false);
		start_Hash.put("tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_questions_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row6");
			
		int tos_count_tDBOutput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_6 = new StringBuilder();
                    log4jParamters_tDBOutput_6.append("Parameters:");
                            log4jParamters_tDBOutput_6.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("TABLE" + " = " + "\"mst_questions_dw\"");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_6.append(" | ");
                            log4jParamters_tDBOutput_6.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + (log4jParamters_tDBOutput_6) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_6", "\"mst_questions_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_6 = null;
	dbschema_tDBOutput_6 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_6 = null;
if(dbschema_tDBOutput_6 == null || dbschema_tDBOutput_6.trim().length() == 0) {
	tableName_tDBOutput_6 = ("mst_questions_dw");
} else {
	tableName_tDBOutput_6 = dbschema_tDBOutput_6 + "\".\"" + ("mst_questions_dw");
}


int nb_line_tDBOutput_6 = 0;
int nb_line_update_tDBOutput_6 = 0;
int nb_line_inserted_tDBOutput_6 = 0;
int nb_line_deleted_tDBOutput_6 = 0;
int nb_line_rejected_tDBOutput_6 = 0;

int deletedCount_tDBOutput_6=0;
int updatedCount_tDBOutput_6=0;
int insertedCount_tDBOutput_6=0;
int rowsToCommitCount_tDBOutput_6=0;
int rejectedCount_tDBOutput_6=0;

boolean whetherReject_tDBOutput_6 = false;

java.sql.Connection conn_tDBOutput_6 = null;
String dbUser_tDBOutput_6 = null;

	conn_tDBOutput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_6.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_6.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_6.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_6 = 10000;
   int batchSizeCounter_tDBOutput_6=0;

int count_tDBOutput_6=0;
        java.lang.StringBuilder sb_tDBOutput_6 = new java.lang.StringBuilder();
        sb_tDBOutput_6.append("INSERT INTO \"").append(tableName_tDBOutput_6).append("\" (\"id\",\"question\",\"option_group_id\",\"min_marks\",\"max_marks\",\"checklist_id\",\"category_id\",\"process_id\",\"subprocess_id\",\"is_mandatory\",\"question_order\",\"risk_type\",\"is_fraud\",\"is_linked\",\"is_primary\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"question_id\",\"linking_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_6.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"question\" = EXCLUDED.\"question\",\"option_group_id\" = EXCLUDED.\"option_group_id\",\"min_marks\" = EXCLUDED.\"min_marks\",\"max_marks\" = EXCLUDED.\"max_marks\",\"checklist_id\" = EXCLUDED.\"checklist_id\",\"category_id\" = EXCLUDED.\"category_id\",\"process_id\" = EXCLUDED.\"process_id\",\"subprocess_id\" = EXCLUDED.\"subprocess_id\",\"is_mandatory\" = EXCLUDED.\"is_mandatory\",\"question_order\" = EXCLUDED.\"question_order\",\"risk_type\" = EXCLUDED.\"risk_type\",\"is_fraud\" = EXCLUDED.\"is_fraud\",\"is_linked\" = EXCLUDED.\"is_linked\",\"is_primary\" = EXCLUDED.\"is_primary\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"question_id\" = EXCLUDED.\"question_id\",\"linking_id\" = EXCLUDED.\"linking_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_6 = sb_tDBOutput_6.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing '")  + (insert_tDBOutput_6)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
	    resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);
	    

 



/**
 * [tDBOutput_6 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_6", false);
		start_Hash.put("tAsyncIn_tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	
		int tos_count_tAsyncIn_tDBOutput_6 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_6", "tAsyncIn_tDBOutput_6", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_6= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_6 = buffers_tAsyncIn_tDBOutput_6.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_6 != null && buffers_tAsyncIn_tDBOutput_6.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_6 : buffers_tAsyncIn_tDBOutput_6) {
    		pRow_row6 = null;						
			pRow_row6 = new pRow_row6Struct();
		
		
			String temp_tAsyncIn_tDBOutput_6_0 = row_tAsyncIn_tDBOutput_6[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[0]);
			if(temp_tAsyncIn_tDBOutput_6_0 != null) {
		
			pRow_row6.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_0);
		} else {						
			pRow_row6.id = 0;
		}
		pRow_row6.question = row_tAsyncIn_tDBOutput_6[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[1]);
		
		
			String temp_tAsyncIn_tDBOutput_6_2 = row_tAsyncIn_tDBOutput_6[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[2]);
			if(temp_tAsyncIn_tDBOutput_6_2 != null) {
		
			pRow_row6.option_group_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_2);
		} else {						
			pRow_row6.option_group_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_3 = row_tAsyncIn_tDBOutput_6[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[3]);
			if(temp_tAsyncIn_tDBOutput_6_3 != null) {
		
			pRow_row6.min_marks = ParserUtils.parseTo_Float(temp_tAsyncIn_tDBOutput_6_3);
		} else {						
			pRow_row6.min_marks = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_4 = row_tAsyncIn_tDBOutput_6[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[4]);
			if(temp_tAsyncIn_tDBOutput_6_4 != null) {
		
			pRow_row6.max_marks = ParserUtils.parseTo_Float(temp_tAsyncIn_tDBOutput_6_4);
		} else {						
			pRow_row6.max_marks = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_5 = row_tAsyncIn_tDBOutput_6[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[5]);
			if(temp_tAsyncIn_tDBOutput_6_5 != null) {
		
			pRow_row6.checklist_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_5);
		} else {						
			pRow_row6.checklist_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_6 = row_tAsyncIn_tDBOutput_6[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[6]);
			if(temp_tAsyncIn_tDBOutput_6_6 != null) {
		
			pRow_row6.category_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_6);
		} else {						
			pRow_row6.category_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_7 = row_tAsyncIn_tDBOutput_6[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[7]);
			if(temp_tAsyncIn_tDBOutput_6_7 != null) {
		
			pRow_row6.process_id = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_7);
		} else {						
			pRow_row6.process_id = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_8 = row_tAsyncIn_tDBOutput_6[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[8]);
			if(temp_tAsyncIn_tDBOutput_6_8 != null) {
		
			pRow_row6.subprocess_id = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_8);
		} else {						
			pRow_row6.subprocess_id = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_9 = row_tAsyncIn_tDBOutput_6[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[9]);
			if(temp_tAsyncIn_tDBOutput_6_9 != null) {
		
			pRow_row6.is_mandatory = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_9);
		} else {						
			pRow_row6.is_mandatory = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_10 = row_tAsyncIn_tDBOutput_6[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[10]);
			if(temp_tAsyncIn_tDBOutput_6_10 != null) {
		
			pRow_row6.question_order = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_10);
		} else {						
			pRow_row6.question_order = null;
		}
		pRow_row6.risk_type = row_tAsyncIn_tDBOutput_6[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[11]);
		
		
			String temp_tAsyncIn_tDBOutput_6_12 = row_tAsyncIn_tDBOutput_6[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[12]);
			if(temp_tAsyncIn_tDBOutput_6_12 != null) {
		
			pRow_row6.is_fraud = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_12);
		} else {						
			pRow_row6.is_fraud = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_13 = row_tAsyncIn_tDBOutput_6[13]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[13]);
			if(temp_tAsyncIn_tDBOutput_6_13 != null) {
		
			pRow_row6.is_linked = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_13);
		} else {						
			pRow_row6.is_linked = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_14 = row_tAsyncIn_tDBOutput_6[14]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[14]);
			if(temp_tAsyncIn_tDBOutput_6_14 != null) {
		
			pRow_row6.is_primary = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_14);
		} else {						
			pRow_row6.is_primary = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_15 = row_tAsyncIn_tDBOutput_6[15]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[15]);
			if(temp_tAsyncIn_tDBOutput_6_15 != null) {
		
			pRow_row6.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_15);
		} else {						
			pRow_row6.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_16 = row_tAsyncIn_tDBOutput_6[16]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[16]);
			if(temp_tAsyncIn_tDBOutput_6_16 != null) {
		
			pRow_row6.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_6[16]);
		} else {						
			pRow_row6.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_17 = row_tAsyncIn_tDBOutput_6[17]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[17]);
			if(temp_tAsyncIn_tDBOutput_6_17 != null) {
		
			pRow_row6.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_6_17);
		} else {						
			pRow_row6.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_18 = row_tAsyncIn_tDBOutput_6[18]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[18]);
			if(temp_tAsyncIn_tDBOutput_6_18 != null) {
		
			pRow_row6.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_6[18]);
		} else {						
			pRow_row6.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_19 = row_tAsyncIn_tDBOutput_6[19]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[19]);
			if(temp_tAsyncIn_tDBOutput_6_19 != null) {
		
			pRow_row6.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_19);
		} else {						
			pRow_row6.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_6_20 = row_tAsyncIn_tDBOutput_6[20]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[20]);
			if(temp_tAsyncIn_tDBOutput_6_20 != null) {
		
			pRow_row6.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_6_20);
		} else {						
			pRow_row6.is_deleted = 0;
		}
		pRow_row6.question_id = row_tAsyncIn_tDBOutput_6[21]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[21]);
		pRow_row6.linking_id = row_tAsyncIn_tDBOutput_6[22]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[22]);
		
		
			String temp_tAsyncIn_tDBOutput_6_23 = row_tAsyncIn_tDBOutput_6[23]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_6[23]);
			if(temp_tAsyncIn_tDBOutput_6_23 != null) {
		
			pRow_row6.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_6[23]);
		} else {						
			pRow_row6.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_6 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

 


	tos_count_tAsyncIn_tDBOutput_6++;

/**
 * [tAsyncIn_tDBOutput_6 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

 



/**
 * [tAsyncIn_tDBOutput_6 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_questions_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row6","tAsyncIn_tDBOutput_6","tAsyncIn_tDBOutput_6","tAsyncIn","tDBOutput_6","\"mst_questions_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row6 - " + (pRow_row6==null? "": pRow_row6.toLogString()));
    			}
    		



				batchSize_tDBOutput_6 = buffersSize_tAsyncIn_tDBOutput_6;
        whetherReject_tDBOutput_6 = false;
                    pstmt_tDBOutput_6.setInt(1, pRow_row6.id);

                    if(pRow_row6.question == null) {
pstmt_tDBOutput_6.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(2, pRow_row6.question);
}

                    pstmt_tDBOutput_6.setInt(3, pRow_row6.option_group_id);

                    if(pRow_row6.min_marks == null) {
pstmt_tDBOutput_6.setNull(4, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_6.setFloat(4, pRow_row6.min_marks);
}

                    if(pRow_row6.max_marks == null) {
pstmt_tDBOutput_6.setNull(5, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_6.setFloat(5, pRow_row6.max_marks);
}

                    pstmt_tDBOutput_6.setInt(6, pRow_row6.checklist_id);

                    pstmt_tDBOutput_6.setInt(7, pRow_row6.category_id);

                    if(pRow_row6.process_id == null) {
pstmt_tDBOutput_6.setNull(8, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(8, pRow_row6.process_id);
}

                    if(pRow_row6.subprocess_id == null) {
pstmt_tDBOutput_6.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(9, pRow_row6.subprocess_id);
}

                    pstmt_tDBOutput_6.setInt(10, pRow_row6.is_mandatory);

                    if(pRow_row6.question_order == null) {
pstmt_tDBOutput_6.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(11, pRow_row6.question_order);
}

                    if(pRow_row6.risk_type == null) {
pstmt_tDBOutput_6.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(12, pRow_row6.risk_type);
}

                    if(pRow_row6.is_fraud == null) {
pstmt_tDBOutput_6.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(13, pRow_row6.is_fraud);
}

                    if(pRow_row6.is_linked == null) {
pstmt_tDBOutput_6.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(14, pRow_row6.is_linked);
}

                    if(pRow_row6.is_primary == null) {
pstmt_tDBOutput_6.setNull(15, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(15, pRow_row6.is_primary);
}

                    if(pRow_row6.created_by == null) {
pstmt_tDBOutput_6.setNull(16, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(16, pRow_row6.created_by);
}

                    if(pRow_row6.created_on != null) {
pstmt_tDBOutput_6.setTimestamp(17, new java.sql.Timestamp(pRow_row6.created_on.getTime()));
} else {
pstmt_tDBOutput_6.setNull(17, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row6.updated_by == null) {
pstmt_tDBOutput_6.setNull(18, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_6.setInt(18, pRow_row6.updated_by);
}

                    if(pRow_row6.updated_on != null) {
pstmt_tDBOutput_6.setTimestamp(19, new java.sql.Timestamp(pRow_row6.updated_on.getTime()));
} else {
pstmt_tDBOutput_6.setNull(19, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_6.setInt(20, pRow_row6.is_active);

                    pstmt_tDBOutput_6.setInt(21, pRow_row6.is_deleted);

                    if(pRow_row6.question_id == null) {
pstmt_tDBOutput_6.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(22, pRow_row6.question_id);
}

                    if(pRow_row6.linking_id == null) {
pstmt_tDBOutput_6.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_6.setString(23, pRow_row6.linking_id);
}

                    if(pRow_row6.as_on != null) {
pstmt_tDBOutput_6.setTimestamp(24, new java.sql.Timestamp(pRow_row6.as_on.getTime()));
} else {
pstmt_tDBOutput_6.setNull(24, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_6.addBatch();
    		nb_line_tDBOutput_6++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Adding the record ")  + (nb_line_tDBOutput_6)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_6++;
    		  
    			if ((batchSize_tDBOutput_6 > 0) && (batchSize_tDBOutput_6 <= batchSizeCounter_tDBOutput_6)) {
                try {
						int countSum_tDBOutput_6 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            	    	batchSizeCounter_tDBOutput_6 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
				    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
				    	String errormessage_tDBOutput_6;
						if (ne_tDBOutput_6 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
							errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
						}else{
							errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
						}
				    	
				    	int countSum_tDBOutput_6 = 0;
						for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
							countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
						}
						rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
				    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
				    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
				    	System.err.println(errormessage_tDBOutput_6);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_6++;

/**
 * [tDBOutput_6 main ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_questions_dw\"";
		

 



/**
 * [tDBOutput_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_questions_dw\"";
		

 



/**
 * [tDBOutput_6 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

 



/**
 * [tAsyncIn_tDBOutput_6 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_6.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_6", true);
end_Hash.put("tAsyncIn_tDBOutput_6", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_6 end ] stop
 */

	
	/**
	 * [tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_questions_dw\"";
		



	    try {
				int countSum_tDBOutput_6 = 0;
				if (pstmt_tDBOutput_6 != null && batchSizeCounter_tDBOutput_6 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_6: pstmt_tDBOutput_6.executeBatch()) {
						countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
					}
					rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_6){
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
	    	java.sql.SQLException ne_tDBOutput_6 = e_tDBOutput_6.getNextException(),sqle_tDBOutput_6=null;
	    	String errormessage_tDBOutput_6;
			if (ne_tDBOutput_6 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_6 = new java.sql.SQLException(e_tDBOutput_6.getMessage() + "\ncaused by: " + ne_tDBOutput_6.getMessage(), ne_tDBOutput_6.getSQLState(), ne_tDBOutput_6.getErrorCode(), ne_tDBOutput_6);
				errormessage_tDBOutput_6 = sqle_tDBOutput_6.getMessage();
			}else{
				errormessage_tDBOutput_6 = e_tDBOutput_6.getMessage();
			}
	    	
	    	int countSum_tDBOutput_6 = 0;
			for(int countEach_tDBOutput_6: e_tDBOutput_6.getUpdateCounts()) {
				countSum_tDBOutput_6 += (countEach_tDBOutput_6 < 0 ? 0 : countEach_tDBOutput_6);
			}
			rowsToCommitCount_tDBOutput_6 += countSum_tDBOutput_6;
			
	    		insertedCount_tDBOutput_6 += countSum_tDBOutput_6;
	    	
            log.error("tDBOutput_6 - "  + (errormessage_tDBOutput_6) );
	    	System.err.println(errormessage_tDBOutput_6);
	    	
		}
	    
        if(pstmt_tDBOutput_6 != null) {
        		
            pstmt_tDBOutput_6.close();
            resourceMap.remove("pstmt_tDBOutput_6");
        }
    resourceMap.put("statementClosed_tDBOutput_6", true);

	nb_line_deleted_tDBOutput_6=nb_line_deleted_tDBOutput_6+ deletedCount_tDBOutput_6;
	nb_line_update_tDBOutput_6=nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
	nb_line_inserted_tDBOutput_6=nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
	nb_line_rejected_tDBOutput_6=nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;
	
    	if (globalMap.get("tDBOutput_6_NB_LINE") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE",nb_line_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE",(Integer)globalMap.get("tDBOutput_6_NB_LINE") + nb_line_tDBOutput_6);
        }
        if (globalMap.get("tDBOutput_6_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE_UPDATED",nb_line_update_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_6_NB_LINE_UPDATED") + nb_line_update_tDBOutput_6);
        }
        if (globalMap.get("tDBOutput_6_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_6_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_6);
        }
        if (globalMap.get("tDBOutput_6_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE_DELETED",nb_line_deleted_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_6_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_6);
        }
        if (globalMap.get("tDBOutput_6_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_6_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_6);
        } else {
        	globalMap.put("tDBOutput_6_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_6_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_6);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row6",2,0,
			 			"tAsyncIn_tDBOutput_6","tAsyncIn_tDBOutput_6","tAsyncIn","tDBOutput_6","\"mst_questions_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_6 - "  + ("Done.") );

ok_Hash.put("tDBOutput_6", true);
end_Hash.put("tDBOutput_6", System.currentTimeMillis());




/**
 * [tDBOutput_6 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_6";
	
	

 



/**
 * [tAsyncIn_tDBOutput_6 finally ] stop
 */

	
	/**
	 * [tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";
	
	
			cLabel="\"mst_questions_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
                if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_6")) != null) {
                    pstmtToClose_tDBOutput_6.close();
                }
    }
 



/**
 * [tDBOutput_6 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_6");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_6_ParallelThread pt = new tAsyncIn_tDBOutput_6_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_6"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_6_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row7Struct implements routines.system.IPersistableRow<pRow_row7Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String region;

				public String getRegion () {
					return this.region;
				}

				public Boolean regionIsNullable(){
				    return false;
				}
				public Boolean regionIsKey(){
				    return false;
				}
				public Integer regionLength(){
				    return 45;
				}
				public Integer regionPrecision(){
				    return 0;
				}
				public String regionDefault(){
				
					return null;
				
				}
				public String regionComment(){
				
				    return "";
				
				}
				public String regionPattern(){
				
					return "";
				
				}
				public String regionOriginalDbColumnName(){
				
					return "region";
				
				}

				
			    public int division_id;

				public int getDivision_id () {
					return this.division_id;
				}

				public Boolean division_idIsNullable(){
				    return false;
				}
				public Boolean division_idIsKey(){
				    return false;
				}
				public Integer division_idLength(){
				    return 10;
				}
				public Integer division_idPrecision(){
				    return 0;
				}
				public String division_idDefault(){
				
					return null;
				
				}
				public String division_idComment(){
				
				    return "";
				
				}
				public String division_idPattern(){
				
					return "";
				
				}
				public String division_idOriginalDbColumnName(){
				
					return "division_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String region_id;

				public String getRegion_id () {
					return this.region_id;
				}

				public Boolean region_idIsNullable(){
				    return true;
				}
				public Boolean region_idIsKey(){
				    return false;
				}
				public Integer region_idLength(){
				    return 32;
				}
				public Integer region_idPrecision(){
				    return 0;
				}
				public String region_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String region_idComment(){
				
				    return "";
				
				}
				public String region_idPattern(){
				
					return "";
				
				}
				public String region_idOriginalDbColumnName(){
				
					return "region_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row7Struct other = (pRow_row7Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row7Struct other) {

		other.id = this.id;
	            other.region = this.region;
	            other.division_id = this.division_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.region_id = this.region_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row7Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
			        this.division_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.region_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.region = readString(dis);
					
			        this.division_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.region_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// int
				
		            	dos.writeInt(this.division_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.region_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.region,dos);
					
					// int
				
		            	dos.writeInt(this.division_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.region_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",region="+region);
		sb.append(",division_id="+String.valueOf(division_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",region_id="+region_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(region == null){
        					sb.append("<null>");
        				}else{
            				sb.append(region);
            			}
            		
        			sb.append("|");
        		
        				sb.append(division_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(region_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(region_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_7");
		org.slf4j.MDC.put("_subJobPid", "4dunT2_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_7");
		class tAsyncIn_tDBOutput_7_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_7_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row7Struct pRow_row7 = new pRow_row7Struct();




	
	/**
	 * [tDBOutput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_7", false);
		start_Hash.put("tDBOutput_7", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_region_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row7");
			
		int tos_count_tDBOutput_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_7{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_7 = new StringBuilder();
                    log4jParamters_tDBOutput_7.append("Parameters:");
                            log4jParamters_tDBOutput_7.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("TABLE" + " = " + "\"mst_region_dw\"");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_7.append(" | ");
                            log4jParamters_tDBOutput_7.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + (log4jParamters_tDBOutput_7) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_7().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_7", "\"mst_region_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_7 = null;
	dbschema_tDBOutput_7 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_7 = null;
if(dbschema_tDBOutput_7 == null || dbschema_tDBOutput_7.trim().length() == 0) {
	tableName_tDBOutput_7 = ("mst_region_dw");
} else {
	tableName_tDBOutput_7 = dbschema_tDBOutput_7 + "\".\"" + ("mst_region_dw");
}


int nb_line_tDBOutput_7 = 0;
int nb_line_update_tDBOutput_7 = 0;
int nb_line_inserted_tDBOutput_7 = 0;
int nb_line_deleted_tDBOutput_7 = 0;
int nb_line_rejected_tDBOutput_7 = 0;

int deletedCount_tDBOutput_7=0;
int updatedCount_tDBOutput_7=0;
int insertedCount_tDBOutput_7=0;
int rowsToCommitCount_tDBOutput_7=0;
int rejectedCount_tDBOutput_7=0;

boolean whetherReject_tDBOutput_7 = false;

java.sql.Connection conn_tDBOutput_7 = null;
String dbUser_tDBOutput_7 = null;

	conn_tDBOutput_7 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_7.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_7.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_7.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_7 = 10000;
   int batchSizeCounter_tDBOutput_7=0;

int count_tDBOutput_7=0;
        java.lang.StringBuilder sb_tDBOutput_7 = new java.lang.StringBuilder();
        sb_tDBOutput_7.append("INSERT INTO \"").append(tableName_tDBOutput_7).append("\" (\"id\",\"region\",\"division_id\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"region_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_7.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"region\" = EXCLUDED.\"region\",\"division_id\" = EXCLUDED.\"division_id\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"region_id\" = EXCLUDED.\"region_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_7 = sb_tDBOutput_7.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Executing '")  + (insert_tDBOutput_7)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_7 = conn_tDBOutput_7.prepareStatement(insert_tDBOutput_7);
	    resourceMap.put("pstmt_tDBOutput_7", pstmt_tDBOutput_7);
	    

 



/**
 * [tDBOutput_7 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_7", false);
		start_Hash.put("tAsyncIn_tDBOutput_7", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	
		int tos_count_tAsyncIn_tDBOutput_7 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_7", "tAsyncIn_tDBOutput_7", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_7= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_7 = buffers_tAsyncIn_tDBOutput_7.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_7 != null && buffers_tAsyncIn_tDBOutput_7.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_7 : buffers_tAsyncIn_tDBOutput_7) {
    		pRow_row7 = null;						
			pRow_row7 = new pRow_row7Struct();
		
		
			String temp_tAsyncIn_tDBOutput_7_0 = row_tAsyncIn_tDBOutput_7[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[0]);
			if(temp_tAsyncIn_tDBOutput_7_0 != null) {
		
			pRow_row7.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_7_0);
		} else {						
			pRow_row7.id = 0;
		}
		pRow_row7.region = row_tAsyncIn_tDBOutput_7[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[1]);
		
		
			String temp_tAsyncIn_tDBOutput_7_2 = row_tAsyncIn_tDBOutput_7[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[2]);
			if(temp_tAsyncIn_tDBOutput_7_2 != null) {
		
			pRow_row7.division_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_7_2);
		} else {						
			pRow_row7.division_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_3 = row_tAsyncIn_tDBOutput_7[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[3]);
			if(temp_tAsyncIn_tDBOutput_7_3 != null) {
		
			pRow_row7.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_7_3);
		} else {						
			pRow_row7.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_4 = row_tAsyncIn_tDBOutput_7[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[4]);
			if(temp_tAsyncIn_tDBOutput_7_4 != null) {
		
			pRow_row7.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_7[4]);
		} else {						
			pRow_row7.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_5 = row_tAsyncIn_tDBOutput_7[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[5]);
			if(temp_tAsyncIn_tDBOutput_7_5 != null) {
		
			pRow_row7.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_7_5);
		} else {						
			pRow_row7.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_6 = row_tAsyncIn_tDBOutput_7[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[6]);
			if(temp_tAsyncIn_tDBOutput_7_6 != null) {
		
			pRow_row7.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_7[6]);
		} else {						
			pRow_row7.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_7 = row_tAsyncIn_tDBOutput_7[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[7]);
			if(temp_tAsyncIn_tDBOutput_7_7 != null) {
		
			pRow_row7.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_7_7);
		} else {						
			pRow_row7.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_7_8 = row_tAsyncIn_tDBOutput_7[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[8]);
			if(temp_tAsyncIn_tDBOutput_7_8 != null) {
		
			pRow_row7.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_7_8);
		} else {						
			pRow_row7.is_deleted = 0;
		}
		pRow_row7.region_id = row_tAsyncIn_tDBOutput_7[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[9]);
		
		
			String temp_tAsyncIn_tDBOutput_7_10 = row_tAsyncIn_tDBOutput_7[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_7[10]);
			if(temp_tAsyncIn_tDBOutput_7_10 != null) {
		
			pRow_row7.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_7[10]);
		} else {						
			pRow_row7.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_7 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_7 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

 


	tos_count_tAsyncIn_tDBOutput_7++;

/**
 * [tAsyncIn_tDBOutput_7 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

 



/**
 * [tAsyncIn_tDBOutput_7 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_7 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_region_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row7","tAsyncIn_tDBOutput_7","tAsyncIn_tDBOutput_7","tAsyncIn","tDBOutput_7","\"mst_region_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row7 - " + (pRow_row7==null? "": pRow_row7.toLogString()));
    			}
    		



				batchSize_tDBOutput_7 = buffersSize_tAsyncIn_tDBOutput_7;
        whetherReject_tDBOutput_7 = false;
                    pstmt_tDBOutput_7.setInt(1, pRow_row7.id);

                    if(pRow_row7.region == null) {
pstmt_tDBOutput_7.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(2, pRow_row7.region);
}

                    pstmt_tDBOutput_7.setInt(3, pRow_row7.division_id);

                    if(pRow_row7.created_by == null) {
pstmt_tDBOutput_7.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_7.setInt(4, pRow_row7.created_by);
}

                    if(pRow_row7.created_on != null) {
pstmt_tDBOutput_7.setTimestamp(5, new java.sql.Timestamp(pRow_row7.created_on.getTime()));
} else {
pstmt_tDBOutput_7.setNull(5, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row7.updated_by == null) {
pstmt_tDBOutput_7.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_7.setInt(6, pRow_row7.updated_by);
}

                    if(pRow_row7.updated_on != null) {
pstmt_tDBOutput_7.setTimestamp(7, new java.sql.Timestamp(pRow_row7.updated_on.getTime()));
} else {
pstmt_tDBOutput_7.setNull(7, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_7.setInt(8, pRow_row7.is_active);

                    pstmt_tDBOutput_7.setInt(9, pRow_row7.is_deleted);

                    if(pRow_row7.region_id == null) {
pstmt_tDBOutput_7.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_7.setString(10, pRow_row7.region_id);
}

                    if(pRow_row7.as_on != null) {
pstmt_tDBOutput_7.setTimestamp(11, new java.sql.Timestamp(pRow_row7.as_on.getTime()));
} else {
pstmt_tDBOutput_7.setNull(11, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_7.addBatch();
    		nb_line_tDBOutput_7++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Adding the record ")  + (nb_line_tDBOutput_7)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_7++;
    		  
    			if ((batchSize_tDBOutput_7 > 0) && (batchSize_tDBOutput_7 <= batchSizeCounter_tDBOutput_7)) {
                try {
						int countSum_tDBOutput_7 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_7: pstmt_tDBOutput_7.executeBatch()) {
							countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
				    	
				    		insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
				    	
            	    	batchSizeCounter_tDBOutput_7 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_7){
globalMap.put("tDBOutput_7_ERROR_MESSAGE",e_tDBOutput_7.getMessage());
				    	java.sql.SQLException ne_tDBOutput_7 = e_tDBOutput_7.getNextException(),sqle_tDBOutput_7=null;
				    	String errormessage_tDBOutput_7;
						if (ne_tDBOutput_7 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_7 = new java.sql.SQLException(e_tDBOutput_7.getMessage() + "\ncaused by: " + ne_tDBOutput_7.getMessage(), ne_tDBOutput_7.getSQLState(), ne_tDBOutput_7.getErrorCode(), ne_tDBOutput_7);
							errormessage_tDBOutput_7 = sqle_tDBOutput_7.getMessage();
						}else{
							errormessage_tDBOutput_7 = e_tDBOutput_7.getMessage();
						}
				    	
				    	int countSum_tDBOutput_7 = 0;
						for(int countEach_tDBOutput_7: e_tDBOutput_7.getUpdateCounts()) {
							countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
						}
						rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
						
				    		insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
				    	
            log.error("tDBOutput_7 - "  + (errormessage_tDBOutput_7) );
				    	System.err.println(errormessage_tDBOutput_7);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_7++;

/**
 * [tDBOutput_7 main ] stop
 */
	
	/**
	 * [tDBOutput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_region_dw\"";
		

 



/**
 * [tDBOutput_7 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_region_dw\"";
		

 



/**
 * [tDBOutput_7 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

 



/**
 * [tAsyncIn_tDBOutput_7 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_7 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_7.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_7", true);
end_Hash.put("tAsyncIn_tDBOutput_7", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_7 end ] stop
 */

	
	/**
	 * [tDBOutput_7 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_region_dw\"";
		



	    try {
				int countSum_tDBOutput_7 = 0;
				if (pstmt_tDBOutput_7 != null && batchSizeCounter_tDBOutput_7 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_7: pstmt_tDBOutput_7.executeBatch()) {
						countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
					}
					rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_7){
globalMap.put("tDBOutput_7_ERROR_MESSAGE",e_tDBOutput_7.getMessage());
	    	java.sql.SQLException ne_tDBOutput_7 = e_tDBOutput_7.getNextException(),sqle_tDBOutput_7=null;
	    	String errormessage_tDBOutput_7;
			if (ne_tDBOutput_7 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_7 = new java.sql.SQLException(e_tDBOutput_7.getMessage() + "\ncaused by: " + ne_tDBOutput_7.getMessage(), ne_tDBOutput_7.getSQLState(), ne_tDBOutput_7.getErrorCode(), ne_tDBOutput_7);
				errormessage_tDBOutput_7 = sqle_tDBOutput_7.getMessage();
			}else{
				errormessage_tDBOutput_7 = e_tDBOutput_7.getMessage();
			}
	    	
	    	int countSum_tDBOutput_7 = 0;
			for(int countEach_tDBOutput_7: e_tDBOutput_7.getUpdateCounts()) {
				countSum_tDBOutput_7 += (countEach_tDBOutput_7 < 0 ? 0 : countEach_tDBOutput_7);
			}
			rowsToCommitCount_tDBOutput_7 += countSum_tDBOutput_7;
			
	    		insertedCount_tDBOutput_7 += countSum_tDBOutput_7;
	    	
            log.error("tDBOutput_7 - "  + (errormessage_tDBOutput_7) );
	    	System.err.println(errormessage_tDBOutput_7);
	    	
		}
	    
        if(pstmt_tDBOutput_7 != null) {
        		
            pstmt_tDBOutput_7.close();
            resourceMap.remove("pstmt_tDBOutput_7");
        }
    resourceMap.put("statementClosed_tDBOutput_7", true);

	nb_line_deleted_tDBOutput_7=nb_line_deleted_tDBOutput_7+ deletedCount_tDBOutput_7;
	nb_line_update_tDBOutput_7=nb_line_update_tDBOutput_7 + updatedCount_tDBOutput_7;
	nb_line_inserted_tDBOutput_7=nb_line_inserted_tDBOutput_7 + insertedCount_tDBOutput_7;
	nb_line_rejected_tDBOutput_7=nb_line_rejected_tDBOutput_7 + rejectedCount_tDBOutput_7;
	
    	if (globalMap.get("tDBOutput_7_NB_LINE") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE",nb_line_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE",(Integer)globalMap.get("tDBOutput_7_NB_LINE") + nb_line_tDBOutput_7);
        }
        if (globalMap.get("tDBOutput_7_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE_UPDATED",nb_line_update_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_7_NB_LINE_UPDATED") + nb_line_update_tDBOutput_7);
        }
        if (globalMap.get("tDBOutput_7_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_7_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_7);
        }
        if (globalMap.get("tDBOutput_7_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE_DELETED",nb_line_deleted_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_7_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_7);
        }
        if (globalMap.get("tDBOutput_7_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_7_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_7);
        } else {
        	globalMap.put("tDBOutput_7_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_7_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_7);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row7",2,0,
			 			"tAsyncIn_tDBOutput_7","tAsyncIn_tDBOutput_7","tAsyncIn","tDBOutput_7","\"mst_region_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_7 - "  + ("Done.") );

ok_Hash.put("tDBOutput_7", true);
end_Hash.put("tDBOutput_7", System.currentTimeMillis());




/**
 * [tDBOutput_7 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_7 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_7";
	
	

 



/**
 * [tAsyncIn_tDBOutput_7 finally ] stop
 */

	
	/**
	 * [tDBOutput_7 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";
	
	
			cLabel="\"mst_region_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_7") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_7 = null;
                if ((pstmtToClose_tDBOutput_7 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_7")) != null) {
                    pstmtToClose_tDBOutput_7.close();
                }
    }
 



/**
 * [tDBOutput_7 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_7");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_7_ParallelThread pt = new tAsyncIn_tDBOutput_7_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_7"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_7_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row8Struct implements routines.system.IPersistableRow<pRow_row8Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String name;

				public String getName () {
					return this.name;
				}

				public Boolean nameIsNullable(){
				    return false;
				}
				public Boolean nameIsKey(){
				    return false;
				}
				public Integer nameLength(){
				    return 45;
				}
				public Integer namePrecision(){
				    return 0;
				}
				public String nameDefault(){
				
					return null;
				
				}
				public String nameComment(){
				
				    return "";
				
				}
				public String namePattern(){
				
					return "";
				
				}
				public String nameOriginalDbColumnName(){
				
					return "name";
				
				}

				
			    public String description;

				public String getDescription () {
					return this.description;
				}

				public Boolean descriptionIsNullable(){
				    return true;
				}
				public Boolean descriptionIsKey(){
				    return false;
				}
				public Integer descriptionLength(){
				    return 2147483647;
				}
				public Integer descriptionPrecision(){
				    return 0;
				}
				public String descriptionDefault(){
				
					return null;
				
				}
				public String descriptionComment(){
				
				    return "";
				
				}
				public String descriptionPattern(){
				
					return "";
				
				}
				public String descriptionOriginalDbColumnName(){
				
					return "description";
				
				}

				
			    public int user_type;

				public int getUser_type () {
					return this.user_type;
				}

				public Boolean user_typeIsNullable(){
				    return false;
				}
				public Boolean user_typeIsKey(){
				    return false;
				}
				public Integer user_typeLength(){
				    return 10;
				}
				public Integer user_typePrecision(){
				    return 0;
				}
				public String user_typeDefault(){
				
					return "0";
				
				}
				public String user_typeComment(){
				
				    return "";
				
				}
				public String user_typePattern(){
				
					return "";
				
				}
				public String user_typeOriginalDbColumnName(){
				
					return "user_type";
				
				}

				
			    public String access_level;

				public String getAccess_level () {
					return this.access_level;
				}

				public Boolean access_levelIsNullable(){
				    return true;
				}
				public Boolean access_levelIsKey(){
				    return false;
				}
				public Integer access_levelLength(){
				    return 45;
				}
				public Integer access_levelPrecision(){
				    return 0;
				}
				public String access_levelDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String access_levelComment(){
				
				    return "";
				
				}
				public String access_levelPattern(){
				
					return "";
				
				}
				public String access_levelOriginalDbColumnName(){
				
					return "access_level";
				
				}

				
			    public Integer role_code;

				public Integer getRole_code () {
					return this.role_code;
				}

				public Boolean role_codeIsNullable(){
				    return true;
				}
				public Boolean role_codeIsKey(){
				    return false;
				}
				public Integer role_codeLength(){
				    return 10;
				}
				public Integer role_codePrecision(){
				    return 0;
				}
				public String role_codeDefault(){
				
					return null;
				
				}
				public String role_codeComment(){
				
				    return "";
				
				}
				public String role_codePattern(){
				
					return "";
				
				}
				public String role_codeOriginalDbColumnName(){
				
					return "role_code";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'now()'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'now()'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String role_id;

				public String getRole_id () {
					return this.role_id;
				}

				public Boolean role_idIsNullable(){
				    return true;
				}
				public Boolean role_idIsKey(){
				    return false;
				}
				public Integer role_idLength(){
				    return 32;
				}
				public Integer role_idPrecision(){
				    return 0;
				}
				public String role_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String role_idComment(){
				
				    return "";
				
				}
				public String role_idPattern(){
				
					return "";
				
				}
				public String role_idOriginalDbColumnName(){
				
					return "role_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row8Struct other = (pRow_row8Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row8Struct other) {

		other.id = this.id;
	            other.name = this.name;
	            other.description = this.description;
	            other.user_type = this.user_type;
	            other.access_level = this.access_level;
	            other.role_code = this.role_code;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.role_id = this.role_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row8Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.name = readString(dis);
					
					this.description = readString(dis);
					
			        this.user_type = dis.readInt();
					
					this.access_level = readString(dis);
					
						this.role_code = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.role_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.name = readString(dis);
					
					this.description = readString(dis);
					
			        this.user_type = dis.readInt();
					
					this.access_level = readString(dis);
					
						this.role_code = readInteger(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.role_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// int
				
		            	dos.writeInt(this.user_type);
					
					// String
				
						writeString(this.access_level,dos);
					
					// Integer
				
						writeInteger(this.role_code,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.role_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.name,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// int
				
		            	dos.writeInt(this.user_type);
					
					// String
				
						writeString(this.access_level,dos);
					
					// Integer
				
						writeInteger(this.role_code,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.role_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",name="+name);
		sb.append(",description="+description);
		sb.append(",user_type="+String.valueOf(user_type));
		sb.append(",access_level="+access_level);
		sb.append(",role_code="+String.valueOf(role_code));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",role_id="+role_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(name);
            			}
            		
        			sb.append("|");
        		
        				if(description == null){
        					sb.append("<null>");
        				}else{
            				sb.append(description);
            			}
            		
        			sb.append("|");
        		
        				sb.append(user_type);
        			
        			sb.append("|");
        		
        				if(access_level == null){
        					sb.append("<null>");
        				}else{
            				sb.append(access_level);
            			}
            		
        			sb.append("|");
        		
        				if(role_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(role_code);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(role_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(role_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_8");
		org.slf4j.MDC.put("_subJobPid", "jQlHMT_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_8");
		class tAsyncIn_tDBOutput_8_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_8_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row8Struct pRow_row8 = new pRow_row8Struct();




	
	/**
	 * [tDBOutput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_8", false);
		start_Hash.put("tDBOutput_8", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_8";
	
	
			cLabel="\"mst_role_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row8");
			
		int tos_count_tDBOutput_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_8{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_8 = new StringBuilder();
                    log4jParamters_tDBOutput_8.append("Parameters:");
                            log4jParamters_tDBOutput_8.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("TABLE" + " = " + "\"mst_role_dw\"");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_8.append(" | ");
                            log4jParamters_tDBOutput_8.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + (log4jParamters_tDBOutput_8) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_8().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_8", "\"mst_role_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_8 = null;
	dbschema_tDBOutput_8 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_8 = null;
if(dbschema_tDBOutput_8 == null || dbschema_tDBOutput_8.trim().length() == 0) {
	tableName_tDBOutput_8 = ("mst_role_dw");
} else {
	tableName_tDBOutput_8 = dbschema_tDBOutput_8 + "\".\"" + ("mst_role_dw");
}


int nb_line_tDBOutput_8 = 0;
int nb_line_update_tDBOutput_8 = 0;
int nb_line_inserted_tDBOutput_8 = 0;
int nb_line_deleted_tDBOutput_8 = 0;
int nb_line_rejected_tDBOutput_8 = 0;

int deletedCount_tDBOutput_8=0;
int updatedCount_tDBOutput_8=0;
int insertedCount_tDBOutput_8=0;
int rowsToCommitCount_tDBOutput_8=0;
int rejectedCount_tDBOutput_8=0;

boolean whetherReject_tDBOutput_8 = false;

java.sql.Connection conn_tDBOutput_8 = null;
String dbUser_tDBOutput_8 = null;

	conn_tDBOutput_8 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_8.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_8.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_8.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_8 = 10000;
   int batchSizeCounter_tDBOutput_8=0;

int count_tDBOutput_8=0;
        java.lang.StringBuilder sb_tDBOutput_8 = new java.lang.StringBuilder();
        sb_tDBOutput_8.append("INSERT INTO \"").append(tableName_tDBOutput_8).append("\" (\"id\",\"name\",\"description\",\"user_type\",\"access_level\",\"role_code\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"role_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_8.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"name\" = EXCLUDED.\"name\",\"description\" = EXCLUDED.\"description\",\"user_type\" = EXCLUDED.\"user_type\",\"access_level\" = EXCLUDED.\"access_level\",\"role_code\" = EXCLUDED.\"role_code\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"role_id\" = EXCLUDED.\"role_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_8 = sb_tDBOutput_8.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("Executing '")  + (insert_tDBOutput_8)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_8 = conn_tDBOutput_8.prepareStatement(insert_tDBOutput_8);
	    resourceMap.put("pstmt_tDBOutput_8", pstmt_tDBOutput_8);
	    

 



/**
 * [tDBOutput_8 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_8", false);
		start_Hash.put("tAsyncIn_tDBOutput_8", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_8";
	
	
		int tos_count_tAsyncIn_tDBOutput_8 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_8", "tAsyncIn_tDBOutput_8", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_8= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_8 = buffers_tAsyncIn_tDBOutput_8.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_8 != null && buffers_tAsyncIn_tDBOutput_8.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_8 : buffers_tAsyncIn_tDBOutput_8) {
    		pRow_row8 = null;						
			pRow_row8 = new pRow_row8Struct();
		
		
			String temp_tAsyncIn_tDBOutput_8_0 = row_tAsyncIn_tDBOutput_8[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[0]);
			if(temp_tAsyncIn_tDBOutput_8_0 != null) {
		
			pRow_row8.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_8_0);
		} else {						
			pRow_row8.id = 0;
		}
		pRow_row8.name = row_tAsyncIn_tDBOutput_8[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[1]);
		pRow_row8.description = row_tAsyncIn_tDBOutput_8[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[2]);
		
		
			String temp_tAsyncIn_tDBOutput_8_3 = row_tAsyncIn_tDBOutput_8[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[3]);
			if(temp_tAsyncIn_tDBOutput_8_3 != null) {
		
			pRow_row8.user_type = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_8_3);
		} else {						
			pRow_row8.user_type = 0;
		}
		pRow_row8.access_level = row_tAsyncIn_tDBOutput_8[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[4]);
		
		
			String temp_tAsyncIn_tDBOutput_8_5 = row_tAsyncIn_tDBOutput_8[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[5]);
			if(temp_tAsyncIn_tDBOutput_8_5 != null) {
		
			pRow_row8.role_code = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_8_5);
		} else {						
			pRow_row8.role_code = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_8_6 = row_tAsyncIn_tDBOutput_8[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[6]);
			if(temp_tAsyncIn_tDBOutput_8_6 != null) {
		
			pRow_row8.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_8_6);
		} else {						
			pRow_row8.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_8_7 = row_tAsyncIn_tDBOutput_8[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[7]);
			if(temp_tAsyncIn_tDBOutput_8_7 != null) {
		
			pRow_row8.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_8[7]);
		} else {						
			pRow_row8.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_8_8 = row_tAsyncIn_tDBOutput_8[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[8]);
			if(temp_tAsyncIn_tDBOutput_8_8 != null) {
		
			pRow_row8.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_8_8);
		} else {						
			pRow_row8.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_8_9 = row_tAsyncIn_tDBOutput_8[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[9]);
			if(temp_tAsyncIn_tDBOutput_8_9 != null) {
		
			pRow_row8.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_8[9]);
		} else {						
			pRow_row8.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_8_10 = row_tAsyncIn_tDBOutput_8[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[10]);
			if(temp_tAsyncIn_tDBOutput_8_10 != null) {
		
			pRow_row8.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_8_10);
		} else {						
			pRow_row8.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_8_11 = row_tAsyncIn_tDBOutput_8[11]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[11]);
			if(temp_tAsyncIn_tDBOutput_8_11 != null) {
		
			pRow_row8.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_8_11);
		} else {						
			pRow_row8.is_deleted = 0;
		}
		pRow_row8.role_id = row_tAsyncIn_tDBOutput_8[12]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[12]);
		
		
			String temp_tAsyncIn_tDBOutput_8_13 = row_tAsyncIn_tDBOutput_8[13]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_8[13]);
			if(temp_tAsyncIn_tDBOutput_8_13 != null) {
		
			pRow_row8.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_8[13]);
		} else {						
			pRow_row8.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_8 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_8 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_8";
	
	

 


	tos_count_tAsyncIn_tDBOutput_8++;

/**
 * [tAsyncIn_tDBOutput_8 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_8";
	
	

 



/**
 * [tAsyncIn_tDBOutput_8 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_8 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";
	
	
			cLabel="\"mst_role_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row8","tAsyncIn_tDBOutput_8","tAsyncIn_tDBOutput_8","tAsyncIn","tDBOutput_8","\"mst_role_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row8 - " + (pRow_row8==null? "": pRow_row8.toLogString()));
    			}
    		



				batchSize_tDBOutput_8 = buffersSize_tAsyncIn_tDBOutput_8;
        whetherReject_tDBOutput_8 = false;
                    pstmt_tDBOutput_8.setInt(1, pRow_row8.id);

                    if(pRow_row8.name == null) {
pstmt_tDBOutput_8.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_8.setString(2, pRow_row8.name);
}

                    if(pRow_row8.description == null) {
pstmt_tDBOutput_8.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_8.setString(3, pRow_row8.description);
}

                    pstmt_tDBOutput_8.setInt(4, pRow_row8.user_type);

                    if(pRow_row8.access_level == null) {
pstmt_tDBOutput_8.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_8.setString(5, pRow_row8.access_level);
}

                    if(pRow_row8.role_code == null) {
pstmt_tDBOutput_8.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_8.setInt(6, pRow_row8.role_code);
}

                    if(pRow_row8.created_by == null) {
pstmt_tDBOutput_8.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_8.setInt(7, pRow_row8.created_by);
}

                    if(pRow_row8.created_on != null) {
pstmt_tDBOutput_8.setTimestamp(8, new java.sql.Timestamp(pRow_row8.created_on.getTime()));
} else {
pstmt_tDBOutput_8.setNull(8, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row8.updated_by == null) {
pstmt_tDBOutput_8.setNull(9, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_8.setInt(9, pRow_row8.updated_by);
}

                    if(pRow_row8.updated_on != null) {
pstmt_tDBOutput_8.setTimestamp(10, new java.sql.Timestamp(pRow_row8.updated_on.getTime()));
} else {
pstmt_tDBOutput_8.setNull(10, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_8.setInt(11, pRow_row8.is_active);

                    pstmt_tDBOutput_8.setInt(12, pRow_row8.is_deleted);

                    if(pRow_row8.role_id == null) {
pstmt_tDBOutput_8.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_8.setString(13, pRow_row8.role_id);
}

                    if(pRow_row8.as_on != null) {
pstmt_tDBOutput_8.setTimestamp(14, new java.sql.Timestamp(pRow_row8.as_on.getTime()));
} else {
pstmt_tDBOutput_8.setNull(14, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_8.addBatch();
    		nb_line_tDBOutput_8++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("Adding the record ")  + (nb_line_tDBOutput_8)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_8++;
    		  
    			if ((batchSize_tDBOutput_8 > 0) && (batchSize_tDBOutput_8 <= batchSizeCounter_tDBOutput_8)) {
                try {
						int countSum_tDBOutput_8 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_8: pstmt_tDBOutput_8.executeBatch()) {
							countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;
				    	
				    		insertedCount_tDBOutput_8 += countSum_tDBOutput_8;
				    	
            	    	batchSizeCounter_tDBOutput_8 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_8){
globalMap.put("tDBOutput_8_ERROR_MESSAGE",e_tDBOutput_8.getMessage());
				    	java.sql.SQLException ne_tDBOutput_8 = e_tDBOutput_8.getNextException(),sqle_tDBOutput_8=null;
				    	String errormessage_tDBOutput_8;
						if (ne_tDBOutput_8 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_8 = new java.sql.SQLException(e_tDBOutput_8.getMessage() + "\ncaused by: " + ne_tDBOutput_8.getMessage(), ne_tDBOutput_8.getSQLState(), ne_tDBOutput_8.getErrorCode(), ne_tDBOutput_8);
							errormessage_tDBOutput_8 = sqle_tDBOutput_8.getMessage();
						}else{
							errormessage_tDBOutput_8 = e_tDBOutput_8.getMessage();
						}
				    	
				    	int countSum_tDBOutput_8 = 0;
						for(int countEach_tDBOutput_8: e_tDBOutput_8.getUpdateCounts()) {
							countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
						}
						rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;
						
				    		insertedCount_tDBOutput_8 += countSum_tDBOutput_8;
				    	
            log.error("tDBOutput_8 - "  + (errormessage_tDBOutput_8) );
				    	System.err.println(errormessage_tDBOutput_8);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_8++;

/**
 * [tDBOutput_8 main ] stop
 */
	
	/**
	 * [tDBOutput_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";
	
	
			cLabel="\"mst_role_dw\"";
		

 



/**
 * [tDBOutput_8 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";
	
	
			cLabel="\"mst_role_dw\"";
		

 



/**
 * [tDBOutput_8 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_8";
	
	

 



/**
 * [tAsyncIn_tDBOutput_8 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_8 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_8";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_8.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_8", true);
end_Hash.put("tAsyncIn_tDBOutput_8", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_8 end ] stop
 */

	
	/**
	 * [tDBOutput_8 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";
	
	
			cLabel="\"mst_role_dw\"";
		



	    try {
				int countSum_tDBOutput_8 = 0;
				if (pstmt_tDBOutput_8 != null && batchSizeCounter_tDBOutput_8 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_8: pstmt_tDBOutput_8.executeBatch()) {
						countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
					}
					rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_8 += countSum_tDBOutput_8;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_8){
globalMap.put("tDBOutput_8_ERROR_MESSAGE",e_tDBOutput_8.getMessage());
	    	java.sql.SQLException ne_tDBOutput_8 = e_tDBOutput_8.getNextException(),sqle_tDBOutput_8=null;
	    	String errormessage_tDBOutput_8;
			if (ne_tDBOutput_8 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_8 = new java.sql.SQLException(e_tDBOutput_8.getMessage() + "\ncaused by: " + ne_tDBOutput_8.getMessage(), ne_tDBOutput_8.getSQLState(), ne_tDBOutput_8.getErrorCode(), ne_tDBOutput_8);
				errormessage_tDBOutput_8 = sqle_tDBOutput_8.getMessage();
			}else{
				errormessage_tDBOutput_8 = e_tDBOutput_8.getMessage();
			}
	    	
	    	int countSum_tDBOutput_8 = 0;
			for(int countEach_tDBOutput_8: e_tDBOutput_8.getUpdateCounts()) {
				countSum_tDBOutput_8 += (countEach_tDBOutput_8 < 0 ? 0 : countEach_tDBOutput_8);
			}
			rowsToCommitCount_tDBOutput_8 += countSum_tDBOutput_8;
			
	    		insertedCount_tDBOutput_8 += countSum_tDBOutput_8;
	    	
            log.error("tDBOutput_8 - "  + (errormessage_tDBOutput_8) );
	    	System.err.println(errormessage_tDBOutput_8);
	    	
		}
	    
        if(pstmt_tDBOutput_8 != null) {
        		
            pstmt_tDBOutput_8.close();
            resourceMap.remove("pstmt_tDBOutput_8");
        }
    resourceMap.put("statementClosed_tDBOutput_8", true);

	nb_line_deleted_tDBOutput_8=nb_line_deleted_tDBOutput_8+ deletedCount_tDBOutput_8;
	nb_line_update_tDBOutput_8=nb_line_update_tDBOutput_8 + updatedCount_tDBOutput_8;
	nb_line_inserted_tDBOutput_8=nb_line_inserted_tDBOutput_8 + insertedCount_tDBOutput_8;
	nb_line_rejected_tDBOutput_8=nb_line_rejected_tDBOutput_8 + rejectedCount_tDBOutput_8;
	
    	if (globalMap.get("tDBOutput_8_NB_LINE") == null) {
        	globalMap.put("tDBOutput_8_NB_LINE",nb_line_tDBOutput_8);
        } else {
        	globalMap.put("tDBOutput_8_NB_LINE",(Integer)globalMap.get("tDBOutput_8_NB_LINE") + nb_line_tDBOutput_8);
        }
        if (globalMap.get("tDBOutput_8_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_8_NB_LINE_UPDATED",nb_line_update_tDBOutput_8);
        } else {
        	globalMap.put("tDBOutput_8_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_8_NB_LINE_UPDATED") + nb_line_update_tDBOutput_8);
        }
        if (globalMap.get("tDBOutput_8_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_8_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_8);
        } else {
        	globalMap.put("tDBOutput_8_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_8_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_8);
        }
        if (globalMap.get("tDBOutput_8_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_8_NB_LINE_DELETED",nb_line_deleted_tDBOutput_8);
        } else {
        	globalMap.put("tDBOutput_8_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_8_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_8);
        }
        if (globalMap.get("tDBOutput_8_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_8_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_8);
        } else {
        	globalMap.put("tDBOutput_8_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_8_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_8);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row8",2,0,
			 			"tAsyncIn_tDBOutput_8","tAsyncIn_tDBOutput_8","tAsyncIn","tDBOutput_8","\"mst_role_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_8 - "  + ("Done.") );

ok_Hash.put("tDBOutput_8", true);
end_Hash.put("tDBOutput_8", System.currentTimeMillis());




/**
 * [tDBOutput_8 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_8 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_8";
	
	

 



/**
 * [tAsyncIn_tDBOutput_8 finally ] stop
 */

	
	/**
	 * [tDBOutput_8 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";
	
	
			cLabel="\"mst_role_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_8") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_8 = null;
                if ((pstmtToClose_tDBOutput_8 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_8")) != null) {
                    pstmtToClose_tDBOutput_8.close();
                }
    }
 



/**
 * [tDBOutput_8 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_8");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_8_ParallelThread pt = new tAsyncIn_tDBOutput_8_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_8"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_8_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row9Struct implements routines.system.IPersistableRow<pRow_row9Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String sbu;

				public String getSbu () {
					return this.sbu;
				}

				public Boolean sbuIsNullable(){
				    return false;
				}
				public Boolean sbuIsKey(){
				    return false;
				}
				public Integer sbuLength(){
				    return 45;
				}
				public Integer sbuPrecision(){
				    return 0;
				}
				public String sbuDefault(){
				
					return null;
				
				}
				public String sbuComment(){
				
				    return "";
				
				}
				public String sbuPattern(){
				
					return "";
				
				}
				public String sbuOriginalDbColumnName(){
				
					return "sbu";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String sbu_id;

				public String getSbu_id () {
					return this.sbu_id;
				}

				public Boolean sbu_idIsNullable(){
				    return true;
				}
				public Boolean sbu_idIsKey(){
				    return false;
				}
				public Integer sbu_idLength(){
				    return 32;
				}
				public Integer sbu_idPrecision(){
				    return 0;
				}
				public String sbu_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String sbu_idComment(){
				
				    return "";
				
				}
				public String sbu_idPattern(){
				
					return "";
				
				}
				public String sbu_idOriginalDbColumnName(){
				
					return "sbu_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy_MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row9Struct other = (pRow_row9Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row9Struct other) {

		other.id = this.id;
	            other.sbu = this.sbu;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.sbu_id = this.sbu_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row9Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.sbu = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.sbu_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.sbu = readString(dis);
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.sbu_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.sbu,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.sbu_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.sbu,dos);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.sbu_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",sbu="+sbu);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",sbu_id="+sbu_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(sbu == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbu);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(sbu_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbu_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row9Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_9");
		org.slf4j.MDC.put("_subJobPid", "IsGdKn_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_9");
		class tAsyncIn_tDBOutput_9_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_9_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row9Struct pRow_row9 = new pRow_row9Struct();




	
	/**
	 * [tDBOutput_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_9", false);
		start_Hash.put("tDBOutput_9", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_9";
	
	
			cLabel="\"mst_sbu_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row9");
			
		int tos_count_tDBOutput_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_9{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_9 = new StringBuilder();
                    log4jParamters_tDBOutput_9.append("Parameters:");
                            log4jParamters_tDBOutput_9.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("TABLE" + " = " + "\"mst_sbu_dw\"");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_9.append(" | ");
                            log4jParamters_tDBOutput_9.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + (log4jParamters_tDBOutput_9) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_9().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_9", "\"mst_sbu_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_9 = null;
	dbschema_tDBOutput_9 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_9 = null;
if(dbschema_tDBOutput_9 == null || dbschema_tDBOutput_9.trim().length() == 0) {
	tableName_tDBOutput_9 = ("mst_sbu_dw");
} else {
	tableName_tDBOutput_9 = dbschema_tDBOutput_9 + "\".\"" + ("mst_sbu_dw");
}


int nb_line_tDBOutput_9 = 0;
int nb_line_update_tDBOutput_9 = 0;
int nb_line_inserted_tDBOutput_9 = 0;
int nb_line_deleted_tDBOutput_9 = 0;
int nb_line_rejected_tDBOutput_9 = 0;

int deletedCount_tDBOutput_9=0;
int updatedCount_tDBOutput_9=0;
int insertedCount_tDBOutput_9=0;
int rowsToCommitCount_tDBOutput_9=0;
int rejectedCount_tDBOutput_9=0;

boolean whetherReject_tDBOutput_9 = false;

java.sql.Connection conn_tDBOutput_9 = null;
String dbUser_tDBOutput_9 = null;

	conn_tDBOutput_9 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_9.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_9.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_9.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_9 = 10000;
   int batchSizeCounter_tDBOutput_9=0;

int count_tDBOutput_9=0;
        java.lang.StringBuilder sb_tDBOutput_9 = new java.lang.StringBuilder();
        sb_tDBOutput_9.append("INSERT INTO \"").append(tableName_tDBOutput_9).append("\" (\"id\",\"sbu\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"sbu_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_9.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"sbu\" = EXCLUDED.\"sbu\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"sbu_id\" = EXCLUDED.\"sbu_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_9 = sb_tDBOutput_9.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("Executing '")  + (insert_tDBOutput_9)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_9 = conn_tDBOutput_9.prepareStatement(insert_tDBOutput_9);
	    resourceMap.put("pstmt_tDBOutput_9", pstmt_tDBOutput_9);
	    

 



/**
 * [tDBOutput_9 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_9", false);
		start_Hash.put("tAsyncIn_tDBOutput_9", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_9";
	
	
		int tos_count_tAsyncIn_tDBOutput_9 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_9", "tAsyncIn_tDBOutput_9", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_9= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_9 = buffers_tAsyncIn_tDBOutput_9.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_9 != null && buffers_tAsyncIn_tDBOutput_9.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_9 : buffers_tAsyncIn_tDBOutput_9) {
    		pRow_row9 = null;						
			pRow_row9 = new pRow_row9Struct();
		
		
			String temp_tAsyncIn_tDBOutput_9_0 = row_tAsyncIn_tDBOutput_9[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[0]);
			if(temp_tAsyncIn_tDBOutput_9_0 != null) {
		
			pRow_row9.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_9_0);
		} else {						
			pRow_row9.id = 0;
		}
		pRow_row9.sbu = row_tAsyncIn_tDBOutput_9[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[1]);
		
		
			String temp_tAsyncIn_tDBOutput_9_2 = row_tAsyncIn_tDBOutput_9[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[2]);
			if(temp_tAsyncIn_tDBOutput_9_2 != null) {
		
			pRow_row9.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_9_2);
		} else {						
			pRow_row9.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_9_3 = row_tAsyncIn_tDBOutput_9[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[3]);
			if(temp_tAsyncIn_tDBOutput_9_3 != null) {
		
			pRow_row9.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_9[3]);
		} else {						
			pRow_row9.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_9_4 = row_tAsyncIn_tDBOutput_9[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[4]);
			if(temp_tAsyncIn_tDBOutput_9_4 != null) {
		
			pRow_row9.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_9_4);
		} else {						
			pRow_row9.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_9_5 = row_tAsyncIn_tDBOutput_9[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[5]);
			if(temp_tAsyncIn_tDBOutput_9_5 != null) {
		
			pRow_row9.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_9[5]);
		} else {						
			pRow_row9.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_9_6 = row_tAsyncIn_tDBOutput_9[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[6]);
			if(temp_tAsyncIn_tDBOutput_9_6 != null) {
		
			pRow_row9.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_9_6);
		} else {						
			pRow_row9.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_9_7 = row_tAsyncIn_tDBOutput_9[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[7]);
			if(temp_tAsyncIn_tDBOutput_9_7 != null) {
		
			pRow_row9.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_9_7);
		} else {						
			pRow_row9.is_deleted = 0;
		}
		pRow_row9.sbu_id = row_tAsyncIn_tDBOutput_9[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[8]);
		
		
			String temp_tAsyncIn_tDBOutput_9_9 = row_tAsyncIn_tDBOutput_9[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_9[9]);
			if(temp_tAsyncIn_tDBOutput_9_9 != null) {
		
			pRow_row9.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_9[9]);
		} else {						
			pRow_row9.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_9 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_9 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_9";
	
	

 


	tos_count_tAsyncIn_tDBOutput_9++;

/**
 * [tAsyncIn_tDBOutput_9 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_9";
	
	

 



/**
 * [tAsyncIn_tDBOutput_9 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_9 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";
	
	
			cLabel="\"mst_sbu_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row9","tAsyncIn_tDBOutput_9","tAsyncIn_tDBOutput_9","tAsyncIn","tDBOutput_9","\"mst_sbu_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row9 - " + (pRow_row9==null? "": pRow_row9.toLogString()));
    			}
    		



				batchSize_tDBOutput_9 = buffersSize_tAsyncIn_tDBOutput_9;
        whetherReject_tDBOutput_9 = false;
                    pstmt_tDBOutput_9.setInt(1, pRow_row9.id);

                    if(pRow_row9.sbu == null) {
pstmt_tDBOutput_9.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_9.setString(2, pRow_row9.sbu);
}

                    if(pRow_row9.created_by == null) {
pstmt_tDBOutput_9.setNull(3, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_9.setInt(3, pRow_row9.created_by);
}

                    if(pRow_row9.created_on != null) {
pstmt_tDBOutput_9.setTimestamp(4, new java.sql.Timestamp(pRow_row9.created_on.getTime()));
} else {
pstmt_tDBOutput_9.setNull(4, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row9.updated_by == null) {
pstmt_tDBOutput_9.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_9.setInt(5, pRow_row9.updated_by);
}

                    if(pRow_row9.updated_on != null) {
pstmt_tDBOutput_9.setTimestamp(6, new java.sql.Timestamp(pRow_row9.updated_on.getTime()));
} else {
pstmt_tDBOutput_9.setNull(6, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_9.setInt(7, pRow_row9.is_active);

                    pstmt_tDBOutput_9.setInt(8, pRow_row9.is_deleted);

                    if(pRow_row9.sbu_id == null) {
pstmt_tDBOutput_9.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_9.setString(9, pRow_row9.sbu_id);
}

                    if(pRow_row9.as_on != null) {
pstmt_tDBOutput_9.setTimestamp(10, new java.sql.Timestamp(pRow_row9.as_on.getTime()));
} else {
pstmt_tDBOutput_9.setNull(10, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_9.addBatch();
    		nb_line_tDBOutput_9++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("Adding the record ")  + (nb_line_tDBOutput_9)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_9++;
    		  
    			if ((batchSize_tDBOutput_9 > 0) && (batchSize_tDBOutput_9 <= batchSizeCounter_tDBOutput_9)) {
                try {
						int countSum_tDBOutput_9 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_9: pstmt_tDBOutput_9.executeBatch()) {
							countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;
				    	
				    		insertedCount_tDBOutput_9 += countSum_tDBOutput_9;
				    	
            	    	batchSizeCounter_tDBOutput_9 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_9){
globalMap.put("tDBOutput_9_ERROR_MESSAGE",e_tDBOutput_9.getMessage());
				    	java.sql.SQLException ne_tDBOutput_9 = e_tDBOutput_9.getNextException(),sqle_tDBOutput_9=null;
				    	String errormessage_tDBOutput_9;
						if (ne_tDBOutput_9 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_9 = new java.sql.SQLException(e_tDBOutput_9.getMessage() + "\ncaused by: " + ne_tDBOutput_9.getMessage(), ne_tDBOutput_9.getSQLState(), ne_tDBOutput_9.getErrorCode(), ne_tDBOutput_9);
							errormessage_tDBOutput_9 = sqle_tDBOutput_9.getMessage();
						}else{
							errormessage_tDBOutput_9 = e_tDBOutput_9.getMessage();
						}
				    	
				    	int countSum_tDBOutput_9 = 0;
						for(int countEach_tDBOutput_9: e_tDBOutput_9.getUpdateCounts()) {
							countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
						}
						rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;
						
				    		insertedCount_tDBOutput_9 += countSum_tDBOutput_9;
				    	
            log.error("tDBOutput_9 - "  + (errormessage_tDBOutput_9) );
				    	System.err.println(errormessage_tDBOutput_9);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_9++;

/**
 * [tDBOutput_9 main ] stop
 */
	
	/**
	 * [tDBOutput_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";
	
	
			cLabel="\"mst_sbu_dw\"";
		

 



/**
 * [tDBOutput_9 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";
	
	
			cLabel="\"mst_sbu_dw\"";
		

 



/**
 * [tDBOutput_9 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_9";
	
	

 



/**
 * [tAsyncIn_tDBOutput_9 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_9 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_9";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_9.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_9", true);
end_Hash.put("tAsyncIn_tDBOutput_9", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_9 end ] stop
 */

	
	/**
	 * [tDBOutput_9 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";
	
	
			cLabel="\"mst_sbu_dw\"";
		



	    try {
				int countSum_tDBOutput_9 = 0;
				if (pstmt_tDBOutput_9 != null && batchSizeCounter_tDBOutput_9 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_9: pstmt_tDBOutput_9.executeBatch()) {
						countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
					}
					rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_9 += countSum_tDBOutput_9;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_9){
globalMap.put("tDBOutput_9_ERROR_MESSAGE",e_tDBOutput_9.getMessage());
	    	java.sql.SQLException ne_tDBOutput_9 = e_tDBOutput_9.getNextException(),sqle_tDBOutput_9=null;
	    	String errormessage_tDBOutput_9;
			if (ne_tDBOutput_9 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_9 = new java.sql.SQLException(e_tDBOutput_9.getMessage() + "\ncaused by: " + ne_tDBOutput_9.getMessage(), ne_tDBOutput_9.getSQLState(), ne_tDBOutput_9.getErrorCode(), ne_tDBOutput_9);
				errormessage_tDBOutput_9 = sqle_tDBOutput_9.getMessage();
			}else{
				errormessage_tDBOutput_9 = e_tDBOutput_9.getMessage();
			}
	    	
	    	int countSum_tDBOutput_9 = 0;
			for(int countEach_tDBOutput_9: e_tDBOutput_9.getUpdateCounts()) {
				countSum_tDBOutput_9 += (countEach_tDBOutput_9 < 0 ? 0 : countEach_tDBOutput_9);
			}
			rowsToCommitCount_tDBOutput_9 += countSum_tDBOutput_9;
			
	    		insertedCount_tDBOutput_9 += countSum_tDBOutput_9;
	    	
            log.error("tDBOutput_9 - "  + (errormessage_tDBOutput_9) );
	    	System.err.println(errormessage_tDBOutput_9);
	    	
		}
	    
        if(pstmt_tDBOutput_9 != null) {
        		
            pstmt_tDBOutput_9.close();
            resourceMap.remove("pstmt_tDBOutput_9");
        }
    resourceMap.put("statementClosed_tDBOutput_9", true);

	nb_line_deleted_tDBOutput_9=nb_line_deleted_tDBOutput_9+ deletedCount_tDBOutput_9;
	nb_line_update_tDBOutput_9=nb_line_update_tDBOutput_9 + updatedCount_tDBOutput_9;
	nb_line_inserted_tDBOutput_9=nb_line_inserted_tDBOutput_9 + insertedCount_tDBOutput_9;
	nb_line_rejected_tDBOutput_9=nb_line_rejected_tDBOutput_9 + rejectedCount_tDBOutput_9;
	
    	if (globalMap.get("tDBOutput_9_NB_LINE") == null) {
        	globalMap.put("tDBOutput_9_NB_LINE",nb_line_tDBOutput_9);
        } else {
        	globalMap.put("tDBOutput_9_NB_LINE",(Integer)globalMap.get("tDBOutput_9_NB_LINE") + nb_line_tDBOutput_9);
        }
        if (globalMap.get("tDBOutput_9_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_9_NB_LINE_UPDATED",nb_line_update_tDBOutput_9);
        } else {
        	globalMap.put("tDBOutput_9_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_9_NB_LINE_UPDATED") + nb_line_update_tDBOutput_9);
        }
        if (globalMap.get("tDBOutput_9_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_9_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_9);
        } else {
        	globalMap.put("tDBOutput_9_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_9_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_9);
        }
        if (globalMap.get("tDBOutput_9_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_9_NB_LINE_DELETED",nb_line_deleted_tDBOutput_9);
        } else {
        	globalMap.put("tDBOutput_9_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_9_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_9);
        }
        if (globalMap.get("tDBOutput_9_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_9_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_9);
        } else {
        	globalMap.put("tDBOutput_9_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_9_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_9);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row9",2,0,
			 			"tAsyncIn_tDBOutput_9","tAsyncIn_tDBOutput_9","tAsyncIn","tDBOutput_9","\"mst_sbu_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_9 - "  + ("Done.") );

ok_Hash.put("tDBOutput_9", true);
end_Hash.put("tDBOutput_9", System.currentTimeMillis());




/**
 * [tDBOutput_9 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_9 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_9";
	
	

 



/**
 * [tAsyncIn_tDBOutput_9 finally ] stop
 */

	
	/**
	 * [tDBOutput_9 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";
	
	
			cLabel="\"mst_sbu_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_9") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_9 = null;
                if ((pstmtToClose_tDBOutput_9 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_9")) != null) {
                    pstmtToClose_tDBOutput_9.close();
                }
    }
 



/**
 * [tDBOutput_9 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_9");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_9_ParallelThread pt = new tAsyncIn_tDBOutput_9_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_9"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_9_SUBPROCESS_STATE", 1);
	}
	


public static class pRow_row1Struct implements routines.system.IPersistableRow<pRow_row1Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String observation;

				public String getObservation () {
					return this.observation;
				}

				public Boolean observationIsNullable(){
				    return true;
				}
				public Boolean observationIsKey(){
				    return false;
				}
				public Integer observationLength(){
				    return 2147483647;
				}
				public Integer observationPrecision(){
				    return 0;
				}
				public String observationDefault(){
				
					return null;
				
				}
				public String observationComment(){
				
				    return "";
				
				}
				public String observationPattern(){
				
					return "";
				
				}
				public String observationOriginalDbColumnName(){
				
					return "observation";
				
				}

				
			    public int question_id;

				public int getQuestion_id () {
					return this.question_id;
				}

				public Boolean question_idIsNullable(){
				    return false;
				}
				public Boolean question_idIsKey(){
				    return false;
				}
				public Integer question_idLength(){
				    return 10;
				}
				public Integer question_idPrecision(){
				    return 0;
				}
				public String question_idDefault(){
				
					return null;
				
				}
				public String question_idComment(){
				
				    return "";
				
				}
				public String question_idPattern(){
				
					return "";
				
				}
				public String question_idOriginalDbColumnName(){
				
					return "question_id";
				
				}

				
			    public Integer created_by;

				public Integer getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 10;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String observation_id;

				public String getObservation_id () {
					return this.observation_id;
				}

				public Boolean observation_idIsNullable(){
				    return true;
				}
				public Boolean observation_idIsKey(){
				    return false;
				}
				public Integer observation_idLength(){
				    return 32;
				}
				public Integer observation_idPrecision(){
				    return 0;
				}
				public String observation_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String observation_idComment(){
				
				    return "";
				
				}
				public String observation_idPattern(){
				
					return "";
				
				}
				public String observation_idOriginalDbColumnName(){
				
					return "observation_id";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final pRow_row1Struct other = (pRow_row1Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(pRow_row1Struct other) {

		other.id = this.id;
	            other.observation = this.observation;
	            other.question_id = this.question_id;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.observation_id = this.observation_id;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(pRow_row1Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4 = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_7_tables_4, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.observation = readString(dis);
					
			        this.question_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.observation_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_7_tables_4) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.observation = readString(dis);
					
			        this.question_id = dis.readInt();
					
						this.created_by = readInteger(dis);
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.observation_id = readString(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.observation,dos);
					
					// int
				
		            	dos.writeInt(this.question_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.observation_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.observation,dos);
					
					// int
				
		            	dos.writeInt(this.question_id);
					
					// Integer
				
						writeInteger(this.created_by,dos);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.observation_id,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",observation="+observation);
		sb.append(",question_id="+String.valueOf(question_id));
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",observation_id="+observation_id);
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(observation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation);
            			}
            		
        			sb.append("|");
        		
        				sb.append(question_id);
        			
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(observation_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation_id);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(pRow_row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tAsyncIn_tDBOutput_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAsyncIn_tDBOutput_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tAsyncIn_tDBOutput_10");
		org.slf4j.MDC.put("_subJobPid", "D6qaAH_" + subJobPidCounter.getAndIncrement());
	


	try {
		final ParallelThreadPool pool = (ParallelThreadPool) globalMap
				.get("PARALLEL_FLOW_POOL_tAsyncOut_tDBOutput_10");
		class tAsyncIn_tDBOutput_10_ParallelThread extends ParallelThread {

			public tAsyncIn_tDBOutput_10_ParallelThread(
					java.util.Map<String, Object> globalMap,
					Object[] lockWrite) {
				super(globalMap, lockWrite);
			}
			boolean isRunning = false;
			String iterateId = "";
			

			public void run() {
				java.util.Map threadRunResultMap = new java.util.HashMap();
				threadRunResultMap.put("errorCode", null);
				threadRunResultMap.put("status", "");
				threadLocal.set(threadRunResultMap);

				this.isRunning = true;
				String currentComponent = "";
				String cLabel = null;
				
				java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
				try{


		pRow_row1Struct pRow_row1 = new pRow_row1Struct();




	
	/**
	 * [tDBOutput_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_10", false);
		start_Hash.put("tDBOutput_10", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_10";
	
	
			cLabel="\"mst_observation_dw\"";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"pRow_row1");
			
		int tos_count_tDBOutput_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_10{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_10 = new StringBuilder();
                    log4jParamters_tDBOutput_10.append("Parameters:");
                            log4jParamters_tDBOutput_10.append("PARALLELIZE_NUMBER" + " = " + "8");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("TABLE" + " = " + "\"mst_observation_dw\"");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_10.append(" | ");
                            log4jParamters_tDBOutput_10.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + (log4jParamters_tDBOutput_10) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_10().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_10", "\"mst_observation_dw\"", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_10 = null;
	dbschema_tDBOutput_10 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_10 = null;
if(dbschema_tDBOutput_10 == null || dbschema_tDBOutput_10.trim().length() == 0) {
	tableName_tDBOutput_10 = ("mst_observation_dw");
} else {
	tableName_tDBOutput_10 = dbschema_tDBOutput_10 + "\".\"" + ("mst_observation_dw");
}


int nb_line_tDBOutput_10 = 0;
int nb_line_update_tDBOutput_10 = 0;
int nb_line_inserted_tDBOutput_10 = 0;
int nb_line_deleted_tDBOutput_10 = 0;
int nb_line_rejected_tDBOutput_10 = 0;

int deletedCount_tDBOutput_10=0;
int updatedCount_tDBOutput_10=0;
int insertedCount_tDBOutput_10=0;
int rowsToCommitCount_tDBOutput_10=0;
int rejectedCount_tDBOutput_10=0;

boolean whetherReject_tDBOutput_10 = false;

java.sql.Connection conn_tDBOutput_10 = null;
String dbUser_tDBOutput_10 = null;

	conn_tDBOutput_10 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_10.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_10.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_10.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_10 = 10000;
   int batchSizeCounter_tDBOutput_10=0;

int count_tDBOutput_10=0;
        java.lang.StringBuilder sb_tDBOutput_10 = new java.lang.StringBuilder();
        sb_tDBOutput_10.append("INSERT INTO \"").append(tableName_tDBOutput_10).append("\" (\"id\",\"observation\",\"question_id\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"is_active\",\"is_deleted\",\"observation_id\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_10.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"observation\" = EXCLUDED.\"observation\",\"question_id\" = EXCLUDED.\"question_id\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"observation_id\" = EXCLUDED.\"observation_id\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_10 = sb_tDBOutput_10.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("Executing '")  + (insert_tDBOutput_10)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_10 = conn_tDBOutput_10.prepareStatement(insert_tDBOutput_10);
	    resourceMap.put("pstmt_tDBOutput_10", pstmt_tDBOutput_10);
	    

 



/**
 * [tDBOutput_10 begin ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tAsyncIn_tDBOutput_10", false);
		start_Hash.put("tAsyncIn_tDBOutput_10", System.currentTimeMillis());
		
	
	currentComponent="tAsyncIn_tDBOutput_10";
	
	
		int tos_count_tAsyncIn_tDBOutput_10 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tAsyncIn_tDBOutput_10", "tAsyncIn_tDBOutput_10", "tAsyncIn");
				talendJobLogProcess(globalMap);
			}
			

	while (!this.isFinish()) {
		java.util.List<Object[]> buffers_tAsyncIn_tDBOutput_10= (java.util.List<Object[]>) this.pollBuffer();// wait
		int buffersSize_tAsyncIn_tDBOutput_10 = buffers_tAsyncIn_tDBOutput_10.size();// bug0014422
		this.setFree(false);
		if (buffers_tAsyncIn_tDBOutput_10 != null && buffers_tAsyncIn_tDBOutput_10.size() > 0) {
			for (Object[] row_tAsyncIn_tDBOutput_10 : buffers_tAsyncIn_tDBOutput_10) {
    		pRow_row1 = null;						
			pRow_row1 = new pRow_row1Struct();
		
		
			String temp_tAsyncIn_tDBOutput_10_0 = row_tAsyncIn_tDBOutput_10[0]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[0]);
			if(temp_tAsyncIn_tDBOutput_10_0 != null) {
		
			pRow_row1.id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_10_0);
		} else {						
			pRow_row1.id = 0;
		}
		pRow_row1.observation = row_tAsyncIn_tDBOutput_10[1]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[1]);
		
		
			String temp_tAsyncIn_tDBOutput_10_2 = row_tAsyncIn_tDBOutput_10[2]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[2]);
			if(temp_tAsyncIn_tDBOutput_10_2 != null) {
		
			pRow_row1.question_id = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_10_2);
		} else {						
			pRow_row1.question_id = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_10_3 = row_tAsyncIn_tDBOutput_10[3]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[3]);
			if(temp_tAsyncIn_tDBOutput_10_3 != null) {
		
			pRow_row1.created_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_10_3);
		} else {						
			pRow_row1.created_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_10_4 = row_tAsyncIn_tDBOutput_10[4]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[4]);
			if(temp_tAsyncIn_tDBOutput_10_4 != null) {
		
			pRow_row1.created_on = (java.util.Date)(row_tAsyncIn_tDBOutput_10[4]);
		} else {						
			pRow_row1.created_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_10_5 = row_tAsyncIn_tDBOutput_10[5]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[5]);
			if(temp_tAsyncIn_tDBOutput_10_5 != null) {
		
			pRow_row1.updated_by = ParserUtils.parseTo_Integer(temp_tAsyncIn_tDBOutput_10_5);
		} else {						
			pRow_row1.updated_by = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_10_6 = row_tAsyncIn_tDBOutput_10[6]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[6]);
			if(temp_tAsyncIn_tDBOutput_10_6 != null) {
		
			pRow_row1.updated_on = (java.util.Date)(row_tAsyncIn_tDBOutput_10[6]);
		} else {						
			pRow_row1.updated_on = null;
		}
		
		
			String temp_tAsyncIn_tDBOutput_10_7 = row_tAsyncIn_tDBOutput_10[7]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[7]);
			if(temp_tAsyncIn_tDBOutput_10_7 != null) {
		
			pRow_row1.is_active = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_10_7);
		} else {						
			pRow_row1.is_active = 0;
		}
		
		
			String temp_tAsyncIn_tDBOutput_10_8 = row_tAsyncIn_tDBOutput_10[8]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[8]);
			if(temp_tAsyncIn_tDBOutput_10_8 != null) {
		
			pRow_row1.is_deleted = ParserUtils.parseTo_int(temp_tAsyncIn_tDBOutput_10_8);
		} else {						
			pRow_row1.is_deleted = 0;
		}
		pRow_row1.observation_id = row_tAsyncIn_tDBOutput_10[9]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[9]);
		
		
			String temp_tAsyncIn_tDBOutput_10_10 = row_tAsyncIn_tDBOutput_10[10]==null?null:String.valueOf(row_tAsyncIn_tDBOutput_10[10]);
			if(temp_tAsyncIn_tDBOutput_10_10 != null) {
		
			pRow_row1.as_on = (java.util.Date)(row_tAsyncIn_tDBOutput_10[10]);
		} else {						
			pRow_row1.as_on = null;
		}
 



/**
 * [tAsyncIn_tDBOutput_10 begin ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_10 main ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_10";
	
	

 


	tos_count_tAsyncIn_tDBOutput_10++;

/**
 * [tAsyncIn_tDBOutput_10 main ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_10";
	
	

 



/**
 * [tAsyncIn_tDBOutput_10 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_10 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";
	
	
			cLabel="\"mst_observation_dw\"";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"pRow_row1","tAsyncIn_tDBOutput_10","tAsyncIn_tDBOutput_10","tAsyncIn","tDBOutput_10","\"mst_observation_dw\"","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("pRow_row1 - " + (pRow_row1==null? "": pRow_row1.toLogString()));
    			}
    		



				batchSize_tDBOutput_10 = buffersSize_tAsyncIn_tDBOutput_10;
        whetherReject_tDBOutput_10 = false;
                    pstmt_tDBOutput_10.setInt(1, pRow_row1.id);

                    if(pRow_row1.observation == null) {
pstmt_tDBOutput_10.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_10.setString(2, pRow_row1.observation);
}

                    pstmt_tDBOutput_10.setInt(3, pRow_row1.question_id);

                    if(pRow_row1.created_by == null) {
pstmt_tDBOutput_10.setNull(4, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_10.setInt(4, pRow_row1.created_by);
}

                    if(pRow_row1.created_on != null) {
pstmt_tDBOutput_10.setTimestamp(5, new java.sql.Timestamp(pRow_row1.created_on.getTime()));
} else {
pstmt_tDBOutput_10.setNull(5, java.sql.Types.TIMESTAMP);
}

                    if(pRow_row1.updated_by == null) {
pstmt_tDBOutput_10.setNull(6, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_10.setInt(6, pRow_row1.updated_by);
}

                    if(pRow_row1.updated_on != null) {
pstmt_tDBOutput_10.setTimestamp(7, new java.sql.Timestamp(pRow_row1.updated_on.getTime()));
} else {
pstmt_tDBOutput_10.setNull(7, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_10.setInt(8, pRow_row1.is_active);

                    pstmt_tDBOutput_10.setInt(9, pRow_row1.is_deleted);

                    if(pRow_row1.observation_id == null) {
pstmt_tDBOutput_10.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_10.setString(10, pRow_row1.observation_id);
}

                    if(pRow_row1.as_on != null) {
pstmt_tDBOutput_10.setTimestamp(11, new java.sql.Timestamp(pRow_row1.as_on.getTime()));
} else {
pstmt_tDBOutput_10.setNull(11, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_10.addBatch();
    		nb_line_tDBOutput_10++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("Adding the record ")  + (nb_line_tDBOutput_10)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_10++;
    		  
    			if ((batchSize_tDBOutput_10 > 0) && (batchSize_tDBOutput_10 <= batchSizeCounter_tDBOutput_10)) {
                try {
						int countSum_tDBOutput_10 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_10: pstmt_tDBOutput_10.executeBatch()) {
							countSum_tDBOutput_10 += (countEach_tDBOutput_10 < 0 ? 0 : countEach_tDBOutput_10);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_10 += countSum_tDBOutput_10;
				    	
				    		insertedCount_tDBOutput_10 += countSum_tDBOutput_10;
				    	
            	    	batchSizeCounter_tDBOutput_10 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_10){
globalMap.put("tDBOutput_10_ERROR_MESSAGE",e_tDBOutput_10.getMessage());
				    	java.sql.SQLException ne_tDBOutput_10 = e_tDBOutput_10.getNextException(),sqle_tDBOutput_10=null;
				    	String errormessage_tDBOutput_10;
						if (ne_tDBOutput_10 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_10 = new java.sql.SQLException(e_tDBOutput_10.getMessage() + "\ncaused by: " + ne_tDBOutput_10.getMessage(), ne_tDBOutput_10.getSQLState(), ne_tDBOutput_10.getErrorCode(), ne_tDBOutput_10);
							errormessage_tDBOutput_10 = sqle_tDBOutput_10.getMessage();
						}else{
							errormessage_tDBOutput_10 = e_tDBOutput_10.getMessage();
						}
				    	
				    	int countSum_tDBOutput_10 = 0;
						for(int countEach_tDBOutput_10: e_tDBOutput_10.getUpdateCounts()) {
							countSum_tDBOutput_10 += (countEach_tDBOutput_10 < 0 ? 0 : countEach_tDBOutput_10);
						}
						rowsToCommitCount_tDBOutput_10 += countSum_tDBOutput_10;
						
				    		insertedCount_tDBOutput_10 += countSum_tDBOutput_10;
				    	
            log.error("tDBOutput_10 - "  + (errormessage_tDBOutput_10) );
				    	System.err.println(errormessage_tDBOutput_10);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_10++;

/**
 * [tDBOutput_10 main ] stop
 */
	
	/**
	 * [tDBOutput_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";
	
	
			cLabel="\"mst_observation_dw\"";
		

 



/**
 * [tDBOutput_10 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";
	
	
			cLabel="\"mst_observation_dw\"";
		

 



/**
 * [tDBOutput_10 process_data_end ] stop
 */



	
	/**
	 * [tAsyncIn_tDBOutput_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_10";
	
	

 



/**
 * [tAsyncIn_tDBOutput_10 process_data_end ] stop
 */
	
	/**
	 * [tAsyncIn_tDBOutput_10 end ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_10";
	
	

			}
			 buffers_tAsyncIn_tDBOutput_10.clear();
		}
		this.setFree(true);
	}
 

ok_Hash.put("tAsyncIn_tDBOutput_10", true);
end_Hash.put("tAsyncIn_tDBOutput_10", System.currentTimeMillis());




/**
 * [tAsyncIn_tDBOutput_10 end ] stop
 */

	
	/**
	 * [tDBOutput_10 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";
	
	
			cLabel="\"mst_observation_dw\"";
		



	    try {
				int countSum_tDBOutput_10 = 0;
				if (pstmt_tDBOutput_10 != null && batchSizeCounter_tDBOutput_10 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_10: pstmt_tDBOutput_10.executeBatch()) {
						countSum_tDBOutput_10 += (countEach_tDBOutput_10 < 0 ? 0 : countEach_tDBOutput_10);
					}
					rowsToCommitCount_tDBOutput_10 += countSum_tDBOutput_10;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_10 += countSum_tDBOutput_10;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_10){
globalMap.put("tDBOutput_10_ERROR_MESSAGE",e_tDBOutput_10.getMessage());
	    	java.sql.SQLException ne_tDBOutput_10 = e_tDBOutput_10.getNextException(),sqle_tDBOutput_10=null;
	    	String errormessage_tDBOutput_10;
			if (ne_tDBOutput_10 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_10 = new java.sql.SQLException(e_tDBOutput_10.getMessage() + "\ncaused by: " + ne_tDBOutput_10.getMessage(), ne_tDBOutput_10.getSQLState(), ne_tDBOutput_10.getErrorCode(), ne_tDBOutput_10);
				errormessage_tDBOutput_10 = sqle_tDBOutput_10.getMessage();
			}else{
				errormessage_tDBOutput_10 = e_tDBOutput_10.getMessage();
			}
	    	
	    	int countSum_tDBOutput_10 = 0;
			for(int countEach_tDBOutput_10: e_tDBOutput_10.getUpdateCounts()) {
				countSum_tDBOutput_10 += (countEach_tDBOutput_10 < 0 ? 0 : countEach_tDBOutput_10);
			}
			rowsToCommitCount_tDBOutput_10 += countSum_tDBOutput_10;
			
	    		insertedCount_tDBOutput_10 += countSum_tDBOutput_10;
	    	
            log.error("tDBOutput_10 - "  + (errormessage_tDBOutput_10) );
	    	System.err.println(errormessage_tDBOutput_10);
	    	
		}
	    
        if(pstmt_tDBOutput_10 != null) {
        		
            pstmt_tDBOutput_10.close();
            resourceMap.remove("pstmt_tDBOutput_10");
        }
    resourceMap.put("statementClosed_tDBOutput_10", true);

	nb_line_deleted_tDBOutput_10=nb_line_deleted_tDBOutput_10+ deletedCount_tDBOutput_10;
	nb_line_update_tDBOutput_10=nb_line_update_tDBOutput_10 + updatedCount_tDBOutput_10;
	nb_line_inserted_tDBOutput_10=nb_line_inserted_tDBOutput_10 + insertedCount_tDBOutput_10;
	nb_line_rejected_tDBOutput_10=nb_line_rejected_tDBOutput_10 + rejectedCount_tDBOutput_10;
	
    	if (globalMap.get("tDBOutput_10_NB_LINE") == null) {
        	globalMap.put("tDBOutput_10_NB_LINE",nb_line_tDBOutput_10);
        } else {
        	globalMap.put("tDBOutput_10_NB_LINE",(Integer)globalMap.get("tDBOutput_10_NB_LINE") + nb_line_tDBOutput_10);
        }
        if (globalMap.get("tDBOutput_10_NB_LINE_UPDATED") == null) {
        	globalMap.put("tDBOutput_10_NB_LINE_UPDATED",nb_line_update_tDBOutput_10);
        } else {
        	globalMap.put("tDBOutput_10_NB_LINE_UPDATED",(Integer)globalMap.get("tDBOutput_10_NB_LINE_UPDATED") + nb_line_update_tDBOutput_10);
        }
        if (globalMap.get("tDBOutput_10_NB_LINE_INSERTED") == null) {
        	globalMap.put("tDBOutput_10_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_10);
        } else {
        	globalMap.put("tDBOutput_10_NB_LINE_INSERTED",(Integer)globalMap.get("tDBOutput_10_NB_LINE_INSERTED") + nb_line_inserted_tDBOutput_10);
        }
        if (globalMap.get("tDBOutput_10_NB_LINE_DELETED") == null) {
        	globalMap.put("tDBOutput_10_NB_LINE_DELETED",nb_line_deleted_tDBOutput_10);
        } else {
        	globalMap.put("tDBOutput_10_NB_LINE_DELETED",(Integer)globalMap.get("tDBOutput_10_NB_LINE_DELETED") + nb_line_deleted_tDBOutput_10);
        }
        if (globalMap.get("tDBOutput_10_NB_LINE_REJECTED") == null) {
        	globalMap.put("tDBOutput_10_NB_LINE_REJECTED",nb_line_rejected_tDBOutput_10);
        } else {
        	globalMap.put("tDBOutput_10_NB_LINE_REJECTED",(Integer)globalMap.get("tDBOutput_10_NB_LINE_REJECTED") + nb_line_rejected_tDBOutput_10);
        }
	

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"pRow_row1",2,0,
			 			"tAsyncIn_tDBOutput_10","tAsyncIn_tDBOutput_10","tAsyncIn","tDBOutput_10","\"mst_observation_dw\"","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_10 - "  + ("Done.") );

ok_Hash.put("tDBOutput_10", true);
end_Hash.put("tDBOutput_10", System.currentTimeMillis());




/**
 * [tDBOutput_10 end ] stop
 */



					} catch (java.lang.Exception e) {
						this.status = "failure";
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						}					
			            pool.setErrorThread(this, new TalendException(e, currentComponent, cLabel, globalMap));
			            //pool.setErrorThread(this,e);
			            pool.stopAllThreads();
					}finally{
						try{
							
	
	/**
	 * [tAsyncIn_tDBOutput_10 finally ] start
	 */

	

	
	
	currentComponent="tAsyncIn_tDBOutput_10";
	
	

 



/**
 * [tAsyncIn_tDBOutput_10 finally ] stop
 */

	
	/**
	 * [tDBOutput_10 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";
	
	
			cLabel="\"mst_observation_dw\"";
		



    if (resourceMap.get("statementClosed_tDBOutput_10") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_10 = null;
                if ((pstmtToClose_tDBOutput_10 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_10")) != null) {
                    pstmtToClose_tDBOutput_10.close();
                }
    }
 



/**
 * [tDBOutput_10 finally ] stop
 */



						}catch(java.lang.Exception e){	
							//ignore
						}catch(java.lang.Error error){
							//ignore
						}
						resourceMap = null;
					}
					this.isRunning = false;
					
					Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
					String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
					if (localErrorCode != null) {
						if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
							this.errorCode = localErrorCode;
						}
					} 
					if (!this.status.equals("failure")) {
						this.status = localStatus;
					}
			
					pool.getTalendThreadResult().setErrorCode(this.errorCode);
					pool.getTalendThreadResult().setStatus(this.status);	
				}//Run method
			}//ParallelThread class

			List<String[]> buffer = (List<String[]>) globalMap
					.get("PARALLEL_FLOW_BUFFER_tAsyncOut_tDBOutput_10");

			if (pool.isFull()) {
				ParallelThread pt = pool.getFreeThread();// wait for Free Thread
				if (pt!= null) {
					pt.putBuffer(buffer);// notify the ParallelThread
				}
			} else {
				// Start a new thread
				tAsyncIn_tDBOutput_10_ParallelThread pt = new tAsyncIn_tDBOutput_10_ParallelThread(
						globalMap, (Object[]) globalMap
								.get("PARALLEL_FLOW_LOCK_tAsyncOut_tDBOutput_10"));
				pt.putBuffer(buffer);
				pool.execThread(pt);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (java.lang.Exception te) {
			throw new TalendException(te, currentComponent, cLabel, globalMap);
		}
	

		globalMap.put("tAsyncIn_tDBOutput_10_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "Zy3TW9_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final Audit_incremental_7_tables_4 Audit_incremental_7_tables_4Class = new Audit_incremental_7_tables_4();

        int exitCode = Audit_incremental_7_tables_4Class.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'Audit_incremental_7_tables_4' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230612_1054-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'Audit_incremental_7_tables_4' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_InvzwNnaEe2k6LMINsbvIw");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-08-02T11:50:31.146918300Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = Audit_incremental_7_tables_4.class.getClassLoader().getResourceAsStream("talend_tac2_repo/audit_incremental_7_tables_4_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = Audit_incremental_7_tables_4.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'Audit_incremental_7_tables_4' - Started.");
            mdcInfo.putAll(org.slf4j.MDC.getCopyOfContextMap());

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_2) {
globalMap.put("tDBInput_2_SUBPROCESS_STATE", -1);

e_tDBInput_2.printStackTrace();

}
try {
errorCode = null;tDBInput_3Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_3) {
globalMap.put("tDBInput_3_SUBPROCESS_STATE", -1);

e_tDBInput_3.printStackTrace();

}
try {
errorCode = null;tDBInput_4Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_4) {
globalMap.put("tDBInput_4_SUBPROCESS_STATE", -1);

e_tDBInput_4.printStackTrace();

}
try {
errorCode = null;tDBInput_5Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_5) {
globalMap.put("tDBInput_5_SUBPROCESS_STATE", -1);

e_tDBInput_5.printStackTrace();

}
try {
errorCode = null;tDBInput_6Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_6) {
globalMap.put("tDBInput_6_SUBPROCESS_STATE", -1);

e_tDBInput_6.printStackTrace();

}
try {
errorCode = null;tDBInput_7Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_7) {
globalMap.put("tDBInput_7_SUBPROCESS_STATE", -1);

e_tDBInput_7.printStackTrace();

}
try {
errorCode = null;tDBInput_8Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_8) {
globalMap.put("tDBInput_8_SUBPROCESS_STATE", -1);

e_tDBInput_8.printStackTrace();

}
try {
errorCode = null;tDBInput_9Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_9) {
globalMap.put("tDBInput_9_SUBPROCESS_STATE", -1);

e_tDBInput_9.printStackTrace();

}
try {
errorCode = null;tDBInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_1) {
globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

e_tDBInput_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : Audit_incremental_7_tables_4");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'Audit_incremental_7_tables_4' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     977176 characters generated by Talend Data Integration 
 *     on the August 2, 2023 at 5:20:31 PM IST
 ************************************************************************************************/