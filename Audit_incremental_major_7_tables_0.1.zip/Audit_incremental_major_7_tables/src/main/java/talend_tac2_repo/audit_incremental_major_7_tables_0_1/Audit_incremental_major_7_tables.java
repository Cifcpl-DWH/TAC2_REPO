
package talend_tac2_repo.audit_incremental_major_7_tables_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: Audit_incremental_major_7_tables Purpose: <br>
 * Description:  <br>
 * @author chaitanya, admin
 * @version 8.0.1.20230612_1054-patch
 * @status 
 */
public class Audit_incremental_major_7_tables implements TalendJob {
	static {System.setProperty("TalendJob.log", "Audit_incremental_major_7_tables.log");}

	

	
	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(Audit_incremental_major_7_tables.class);
	

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	

	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
		

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}
			
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "Audit_incremental_major_7_tables";
	private final String projectName = "TALEND_TAC2_REPO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
	private String cLabel =  null;
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_8p5JcNkPEe2cDNax3wxz5A", "0.1");
private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	
	private String currentComponent = null;
	private String cLabel =  null;
	
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}
	
	private TalendException(Exception e, String errorComponent, String errorComponentLabel, final java.util.Map<String, Object> globalMap) {
		this(e, errorComponent, globalMap);
		this.cLabel = errorComponentLabel;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				Audit_incremental_major_7_tables.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(Audit_incremental_major_7_tables.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
		if(enableLogStash) {
			talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
			talendJobLogProcess(globalMap);
		}
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBInput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBInput_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	



public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPrejob_1");
		org.slf4j.MDC.put("_subJobPid", "e7bDhN_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";
	
	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPrejob_1", "tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBConnection_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";
	
	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "HtslBa_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MYSQL_8");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"115.124.105.62\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"3306\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"chaitanya_audit\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "\"chaitanya_auditprd\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:hFaa1l6z9Fxp0hTwxvMODdFB90Q033wafHuPcNGYtSNtBR3N").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_1", "Audit_source", "tMysqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
        String properties_tDBConnection_1 = "noDatetimeStringSync=true&enabledTLSProtocols=TLSv1.2,TLSv1.1,TLSv1";
        if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
            properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
        }else {
            if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
                properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
            }

            if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
                properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
            }
        }

        String url_tDBConnection_1 = "jdbc:mysql://" + "115.124.105.62" + ":" + "3306" + "/" + "chaitanya_audit" + "?" + properties_tDBConnection_1;
	String dbUser_tDBConnection_1 = "chaitanya_auditprd";
	
	
		 
	final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:UGxOcvvcC+t2KoSRnbT3UWJewzznV11k2ikLhrnLSCaLatWz");
		String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
	
	
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "com.mysql.cj.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
			globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
			conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_1.setAutoCommit(true);
	}

	globalMap.put("db_tDBConnection_1","chaitanya_audit");
 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tDBConnection_2Process(globalMap);



/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";
	
	
			cLabel="Audit_source";
		

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_2");
		org.slf4j.MDC.put("_subJobPid", "cBJAfB_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DB_VERSION" + " = " + "V9_X");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "\"10.40.26.201\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "\"5432\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "\"audit_dwh\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "\"audit_user\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf("enc:routine.encryption.key.v1:FWGD8yU6HuzeyVtK6CZ6zcSwuBH9btWm4fZ6zgCZcDVjPjzD/MRx").substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBConnection_2", "Audit_target", "tPostgresqlConnection");
				talendJobLogProcess(globalMap);
			}
			


	
            String dbProperties_tDBConnection_2 = "";
            String url_tDBConnection_2 = "jdbc:postgresql://"+"10.40.26.201"+":"+"5432"+"/"+"audit_dwh";
            
            if(dbProperties_tDBConnection_2 != null && !"".equals(dbProperties_tDBConnection_2.trim())) {
                url_tDBConnection_2 = url_tDBConnection_2 + "?" + dbProperties_tDBConnection_2;
            }
	String dbUser_tDBConnection_2 = "audit_user";
	
	
		 
	final String decryptedPassword_tDBConnection_2 = routines.system.PasswordEncryptUtil.decryptPassword("enc:routine.encryption.key.v1:eLrW1TPWNr+J7vlvsXIdCY4o3luYcNoOCPU1261wCREXioSXBBy3");
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
        java.util.Enumeration<java.sql.Driver> drivers_tDBConnection_2 =  java.sql.DriverManager.getDrivers();
        java.util.Set<String> redShiftDriverNames_tDBConnection_2 = new java.util.HashSet<String>(java.util.Arrays
                .asList("com.amazon.redshift.jdbc.Driver","com.amazon.redshift.jdbc41.Driver","com.amazon.redshift.jdbc42.Driver"));
    while (drivers_tDBConnection_2.hasMoreElements()) {
        java.sql.Driver d_tDBConnection_2 = drivers_tDBConnection_2.nextElement();
        if (redShiftDriverNames_tDBConnection_2.contains(d_tDBConnection_2.getClass().getName())) {
            try {
                java.sql.DriverManager.deregisterDriver(d_tDBConnection_2);
                java.sql.DriverManager.registerDriver(d_tDBConnection_2);
            } catch (java.lang.Exception e_tDBConnection_2) {
globalMap.put("tDBConnection_2_ERROR_MESSAGE",e_tDBConnection_2.getMessage());
                    //do nothing
            }
        }
    }
					String driverClass_tDBConnection_2 = "org.postgresql.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tDBConnection_2","");

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_major_7_tables = new byte[0];
    static byte[] commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int id;

				public int getId () {
					return this.id;
				}

				public Boolean idIsNullable(){
				    return false;
				}
				public Boolean idIsKey(){
				    return true;
				}
				public Integer idLength(){
				    return 10;
				}
				public Integer idPrecision(){
				    return 0;
				}
				public String idDefault(){
				
					return null;
				
				}
				public String idComment(){
				
				    return "";
				
				}
				public String idPattern(){
				
					return "";
				
				}
				public String idOriginalDbColumnName(){
				
					return "id";
				
				}

				
			    public String m_Id;

				public String getM_Id () {
					return this.m_Id;
				}

				public Boolean m_IdIsNullable(){
				    return true;
				}
				public Boolean m_IdIsKey(){
				    return false;
				}
				public Integer m_IdLength(){
				    return 45;
				}
				public Integer m_IdPrecision(){
				    return 0;
				}
				public String m_IdDefault(){
				
					return "'NULL::character varying'::character varying'";
				
				}
				public String m_IdComment(){
				
				    return "";
				
				}
				public String m_IdPattern(){
				
					return "";
				
				}
				public String m_IdOriginalDbColumnName(){
				
					return "m_Id";
				
				}

				
			    public BigDecimal process_audit_details_id;

				public BigDecimal getProcess_audit_details_id () {
					return this.process_audit_details_id;
				}

				public Boolean process_audit_details_idIsNullable(){
				    return false;
				}
				public Boolean process_audit_details_idIsKey(){
				    return false;
				}
				public Integer process_audit_details_idLength(){
				    return 16;
				}
				public Integer process_audit_details_idPrecision(){
				    return 0;
				}
				public String process_audit_details_idDefault(){
				
					return null;
				
				}
				public String process_audit_details_idComment(){
				
				    return "";
				
				}
				public String process_audit_details_idPattern(){
				
					return "";
				
				}
				public String process_audit_details_idOriginalDbColumnName(){
				
					return "process_audit_details_id";
				
				}

				
			    public BigDecimal audit_plan_id;

				public BigDecimal getAudit_plan_id () {
					return this.audit_plan_id;
				}

				public Boolean audit_plan_idIsNullable(){
				    return false;
				}
				public Boolean audit_plan_idIsKey(){
				    return false;
				}
				public Integer audit_plan_idLength(){
				    return 16;
				}
				public Integer audit_plan_idPrecision(){
				    return 0;
				}
				public String audit_plan_idDefault(){
				
					return null;
				
				}
				public String audit_plan_idComment(){
				
				    return "";
				
				}
				public String audit_plan_idPattern(){
				
					return "";
				
				}
				public String audit_plan_idOriginalDbColumnName(){
				
					return "audit_plan_id";
				
				}

				
			    public String process_name;

				public String getProcess_name () {
					return this.process_name;
				}

				public Boolean process_nameIsNullable(){
				    return false;
				}
				public Boolean process_nameIsKey(){
				    return false;
				}
				public Integer process_nameLength(){
				    return 150;
				}
				public Integer process_namePrecision(){
				    return 0;
				}
				public String process_nameDefault(){
				
					return null;
				
				}
				public String process_nameComment(){
				
				    return "";
				
				}
				public String process_namePattern(){
				
					return "";
				
				}
				public String process_nameOriginalDbColumnName(){
				
					return "process_name";
				
				}

				
			    public String subprocess_name;

				public String getSubprocess_name () {
					return this.subprocess_name;
				}

				public Boolean subprocess_nameIsNullable(){
				    return false;
				}
				public Boolean subprocess_nameIsKey(){
				    return false;
				}
				public Integer subprocess_nameLength(){
				    return 150;
				}
				public Integer subprocess_namePrecision(){
				    return 0;
				}
				public String subprocess_nameDefault(){
				
					return null;
				
				}
				public String subprocess_nameComment(){
				
				    return "";
				
				}
				public String subprocess_namePattern(){
				
					return "";
				
				}
				public String subprocess_nameOriginalDbColumnName(){
				
					return "subprocess_name";
				
				}

				
			    public String question;

				public String getQuestion () {
					return this.question;
				}

				public Boolean questionIsNullable(){
				    return false;
				}
				public Boolean questionIsKey(){
				    return false;
				}
				public Integer questionLength(){
				    return 2147483647;
				}
				public Integer questionPrecision(){
				    return 0;
				}
				public String questionDefault(){
				
					return null;
				
				}
				public String questionComment(){
				
				    return "";
				
				}
				public String questionPattern(){
				
					return "";
				
				}
				public String questionOriginalDbColumnName(){
				
					return "question";
				
				}

				
			    public String option_name;

				public String getOption_name () {
					return this.option_name;
				}

				public Boolean option_nameIsNullable(){
				    return false;
				}
				public Boolean option_nameIsKey(){
				    return false;
				}
				public Integer option_nameLength(){
				    return 150;
				}
				public Integer option_namePrecision(){
				    return 0;
				}
				public String option_nameDefault(){
				
					return null;
				
				}
				public String option_nameComment(){
				
				    return "";
				
				}
				public String option_namePattern(){
				
					return "";
				
				}
				public String option_nameOriginalDbColumnName(){
				
					return "option_name";
				
				}

				
			    public Float max_marks;

				public Float getMax_marks () {
					return this.max_marks;
				}

				public Boolean max_marksIsNullable(){
				    return true;
				}
				public Boolean max_marksIsKey(){
				    return false;
				}
				public Integer max_marksLength(){
				    return 8;
				}
				public Integer max_marksPrecision(){
				    return 8;
				}
				public String max_marksDefault(){
				
					return "'0'::real";
				
				}
				public String max_marksComment(){
				
				    return "";
				
				}
				public String max_marksPattern(){
				
					return "";
				
				}
				public String max_marksOriginalDbColumnName(){
				
					return "max_marks";
				
				}

				
			    public Float score;

				public Float getScore () {
					return this.score;
				}

				public Boolean scoreIsNullable(){
				    return true;
				}
				public Boolean scoreIsKey(){
				    return false;
				}
				public Integer scoreLength(){
				    return 8;
				}
				public Integer scorePrecision(){
				    return 8;
				}
				public String scoreDefault(){
				
					return "'0'::real";
				
				}
				public String scoreComment(){
				
				    return "";
				
				}
				public String scorePattern(){
				
					return "";
				
				}
				public String scoreOriginalDbColumnName(){
				
					return "score";
				
				}

				
			    public String observation;

				public String getObservation () {
					return this.observation;
				}

				public Boolean observationIsNullable(){
				    return true;
				}
				public Boolean observationIsKey(){
				    return false;
				}
				public Integer observationLength(){
				    return 2147483647;
				}
				public Integer observationPrecision(){
				    return 0;
				}
				public String observationDefault(){
				
					return null;
				
				}
				public String observationComment(){
				
				    return "";
				
				}
				public String observationPattern(){
				
					return "";
				
				}
				public String observationOriginalDbColumnName(){
				
					return "observation";
				
				}

				
			    public String other_observation;

				public String getOther_observation () {
					return this.other_observation;
				}

				public Boolean other_observationIsNullable(){
				    return true;
				}
				public Boolean other_observationIsKey(){
				    return false;
				}
				public Integer other_observationLength(){
				    return 2147483647;
				}
				public Integer other_observationPrecision(){
				    return 0;
				}
				public String other_observationDefault(){
				
					return null;
				
				}
				public String other_observationComment(){
				
				    return "";
				
				}
				public String other_observationPattern(){
				
					return "";
				
				}
				public String other_observationOriginalDbColumnName(){
				
					return "other_observation";
				
				}

				
			    public String risk_type;

				public String getRisk_type () {
					return this.risk_type;
				}

				public Boolean risk_typeIsNullable(){
				    return true;
				}
				public Boolean risk_typeIsKey(){
				    return false;
				}
				public Integer risk_typeLength(){
				    return 45;
				}
				public Integer risk_typePrecision(){
				    return 0;
				}
				public String risk_typeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String risk_typeComment(){
				
				    return "";
				
				}
				public String risk_typePattern(){
				
					return "";
				
				}
				public String risk_typeOriginalDbColumnName(){
				
					return "risk_type";
				
				}

				
			    public String attachement;

				public String getAttachement () {
					return this.attachement;
				}

				public Boolean attachementIsNullable(){
				    return true;
				}
				public Boolean attachementIsKey(){
				    return false;
				}
				public Integer attachementLength(){
				    return 2147483647;
				}
				public Integer attachementPrecision(){
				    return 0;
				}
				public String attachementDefault(){
				
					return null;
				
				}
				public String attachementComment(){
				
				    return "";
				
				}
				public String attachementPattern(){
				
					return "";
				
				}
				public String attachementOriginalDbColumnName(){
				
					return "attachement";
				
				}

				
			    public String attachement_type;

				public String getAttachement_type () {
					return this.attachement_type;
				}

				public Boolean attachement_typeIsNullable(){
				    return true;
				}
				public Boolean attachement_typeIsKey(){
				    return false;
				}
				public Integer attachement_typeLength(){
				    return 10;
				}
				public Integer attachement_typePrecision(){
				    return 0;
				}
				public String attachement_typeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String attachement_typeComment(){
				
				    return "";
				
				}
				public String attachement_typePattern(){
				
					return "";
				
				}
				public String attachement_typeOriginalDbColumnName(){
				
					return "attachement_type";
				
				}

				
			    public String resloved_attachment;

				public String getResloved_attachment () {
					return this.resloved_attachment;
				}

				public Boolean resloved_attachmentIsNullable(){
				    return true;
				}
				public Boolean resloved_attachmentIsKey(){
				    return false;
				}
				public Integer resloved_attachmentLength(){
				    return 2147483647;
				}
				public Integer resloved_attachmentPrecision(){
				    return 0;
				}
				public String resloved_attachmentDefault(){
				
					return null;
				
				}
				public String resloved_attachmentComment(){
				
				    return "";
				
				}
				public String resloved_attachmentPattern(){
				
					return "";
				
				}
				public String resloved_attachmentOriginalDbColumnName(){
				
					return "resloved_attachment";
				
				}

				
			    public BigDecimal is_nc;

				public BigDecimal getIs_nc () {
					return this.is_nc;
				}

				public Boolean is_ncIsNullable(){
				    return false;
				}
				public Boolean is_ncIsKey(){
				    return false;
				}
				public Integer is_ncLength(){
				    return 16;
				}
				public Integer is_ncPrecision(){
				    return 0;
				}
				public String is_ncDefault(){
				
					return null;
				
				}
				public String is_ncComment(){
				
				    return "";
				
				}
				public String is_ncPattern(){
				
					return "";
				
				}
				public String is_ncOriginalDbColumnName(){
				
					return "is_nc";
				
				}

				
			    public BigDecimal nc_status;

				public BigDecimal getNc_status () {
					return this.nc_status;
				}

				public Boolean nc_statusIsNullable(){
				    return true;
				}
				public Boolean nc_statusIsKey(){
				    return false;
				}
				public Integer nc_statusLength(){
				    return 16;
				}
				public Integer nc_statusPrecision(){
				    return 0;
				}
				public String nc_statusDefault(){
				
					return null;
				
				}
				public String nc_statusComment(){
				
				    return "";
				
				}
				public String nc_statusPattern(){
				
					return "";
				
				}
				public String nc_statusOriginalDbColumnName(){
				
					return "nc_status";
				
				}

				
			    public BigDecimal assigned_to;

				public BigDecimal getAssigned_to () {
					return this.assigned_to;
				}

				public Boolean assigned_toIsNullable(){
				    return true;
				}
				public Boolean assigned_toIsKey(){
				    return false;
				}
				public Integer assigned_toLength(){
				    return 16;
				}
				public Integer assigned_toPrecision(){
				    return 0;
				}
				public String assigned_toDefault(){
				
					return null;
				
				}
				public String assigned_toComment(){
				
				    return "";
				
				}
				public String assigned_toPattern(){
				
					return "";
				
				}
				public String assigned_toOriginalDbColumnName(){
				
					return "assigned_to";
				
				}

				
			    public BigDecimal role_code;

				public BigDecimal getRole_code () {
					return this.role_code;
				}

				public Boolean role_codeIsNullable(){
				    return true;
				}
				public Boolean role_codeIsKey(){
				    return false;
				}
				public Integer role_codeLength(){
				    return 16;
				}
				public Integer role_codePrecision(){
				    return 0;
				}
				public String role_codeDefault(){
				
					return null;
				
				}
				public String role_codeComment(){
				
				    return "";
				
				}
				public String role_codePattern(){
				
					return "";
				
				}
				public String role_codeOriginalDbColumnName(){
				
					return "role_code";
				
				}

				
			    public String nc_remarks;

				public String getNc_remarks () {
					return this.nc_remarks;
				}

				public Boolean nc_remarksIsNullable(){
				    return true;
				}
				public Boolean nc_remarksIsKey(){
				    return false;
				}
				public Integer nc_remarksLength(){
				    return 2147483647;
				}
				public Integer nc_remarksPrecision(){
				    return 0;
				}
				public String nc_remarksDefault(){
				
					return null;
				
				}
				public String nc_remarksComment(){
				
				    return "";
				
				}
				public String nc_remarksPattern(){
				
					return "";
				
				}
				public String nc_remarksOriginalDbColumnName(){
				
					return "nc_remarks";
				
				}

				
			    public BigDecimal is_major_nc;

				public BigDecimal getIs_major_nc () {
					return this.is_major_nc;
				}

				public Boolean is_major_ncIsNullable(){
				    return true;
				}
				public Boolean is_major_ncIsKey(){
				    return false;
				}
				public Integer is_major_ncLength(){
				    return 16;
				}
				public Integer is_major_ncPrecision(){
				    return 0;
				}
				public String is_major_ncDefault(){
				
					return null;
				
				}
				public String is_major_ncComment(){
				
				    return "";
				
				}
				public String is_major_ncPattern(){
				
					return "";
				
				}
				public String is_major_ncOriginalDbColumnName(){
				
					return "is_major_nc";
				
				}

				
			    public BigDecimal category_id;

				public BigDecimal getCategory_id () {
					return this.category_id;
				}

				public Boolean category_idIsNullable(){
				    return true;
				}
				public Boolean category_idIsKey(){
				    return false;
				}
				public Integer category_idLength(){
				    return 16;
				}
				public Integer category_idPrecision(){
				    return 0;
				}
				public String category_idDefault(){
				
					return null;
				
				}
				public String category_idComment(){
				
				    return "";
				
				}
				public String category_idPattern(){
				
					return "";
				
				}
				public String category_idOriginalDbColumnName(){
				
					return "category_id";
				
				}

				
			    public String category_name;

				public String getCategory_name () {
					return this.category_name;
				}

				public Boolean category_nameIsNullable(){
				    return true;
				}
				public Boolean category_nameIsKey(){
				    return false;
				}
				public Integer category_nameLength(){
				    return 40;
				}
				public Integer category_namePrecision(){
				    return 0;
				}
				public String category_nameDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String category_nameComment(){
				
				    return "";
				
				}
				public String category_namePattern(){
				
					return "";
				
				}
				public String category_nameOriginalDbColumnName(){
				
					return "category_name";
				
				}

				
			    public BigDecimal created_by;

				public BigDecimal getCreated_by () {
					return this.created_by;
				}

				public Boolean created_byIsNullable(){
				    return true;
				}
				public Boolean created_byIsKey(){
				    return false;
				}
				public Integer created_byLength(){
				    return 16;
				}
				public Integer created_byPrecision(){
				    return 0;
				}
				public String created_byDefault(){
				
					return null;
				
				}
				public String created_byComment(){
				
				    return "";
				
				}
				public String created_byPattern(){
				
					return "";
				
				}
				public String created_byOriginalDbColumnName(){
				
					return "created_by";
				
				}

				
			    public java.util.Date created_on;

				public java.util.Date getCreated_on () {
					return this.created_on;
				}

				public Boolean created_onIsNullable(){
				    return false;
				}
				public Boolean created_onIsKey(){
				    return false;
				}
				public Integer created_onLength(){
				    return 29;
				}
				public Integer created_onPrecision(){
				    return 6;
				}
				public String created_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String created_onComment(){
				
				    return "";
				
				}
				public String created_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String created_onOriginalDbColumnName(){
				
					return "created_on";
				
				}

				
			    public Integer updated_by;

				public Integer getUpdated_by () {
					return this.updated_by;
				}

				public Boolean updated_byIsNullable(){
				    return true;
				}
				public Boolean updated_byIsKey(){
				    return false;
				}
				public Integer updated_byLength(){
				    return 10;
				}
				public Integer updated_byPrecision(){
				    return 0;
				}
				public String updated_byDefault(){
				
					return null;
				
				}
				public String updated_byComment(){
				
				    return "";
				
				}
				public String updated_byPattern(){
				
					return "";
				
				}
				public String updated_byOriginalDbColumnName(){
				
					return "updated_by";
				
				}

				
			    public java.util.Date updated_on;

				public java.util.Date getUpdated_on () {
					return this.updated_on;
				}

				public Boolean updated_onIsNullable(){
				    return false;
				}
				public Boolean updated_onIsKey(){
				    return false;
				}
				public Integer updated_onLength(){
				    return 29;
				}
				public Integer updated_onPrecision(){
				    return 6;
				}
				public String updated_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String updated_onComment(){
				
				    return "";
				
				}
				public String updated_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String updated_onOriginalDbColumnName(){
				
					return "updated_on";
				
				}

				
			    public Integer closed_by;

				public Integer getClosed_by () {
					return this.closed_by;
				}

				public Boolean closed_byIsNullable(){
				    return true;
				}
				public Boolean closed_byIsKey(){
				    return false;
				}
				public Integer closed_byLength(){
				    return 10;
				}
				public Integer closed_byPrecision(){
				    return 0;
				}
				public String closed_byDefault(){
				
					return null;
				
				}
				public String closed_byComment(){
				
				    return "";
				
				}
				public String closed_byPattern(){
				
					return "";
				
				}
				public String closed_byOriginalDbColumnName(){
				
					return "closed_by";
				
				}

				
			    public java.util.Date closed_on;

				public java.util.Date getClosed_on () {
					return this.closed_on;
				}

				public Boolean closed_onIsNullable(){
				    return true;
				}
				public Boolean closed_onIsKey(){
				    return false;
				}
				public Integer closed_onLength(){
				    return 29;
				}
				public Integer closed_onPrecision(){
				    return 6;
				}
				public String closed_onDefault(){
				
					return null;
				
				}
				public String closed_onComment(){
				
				    return "";
				
				}
				public String closed_onPattern(){
				
					return "dd-MM-yyyy";
				
				}
				public String closed_onOriginalDbColumnName(){
				
					return "closed_on";
				
				}

				
			    public int is_active;

				public int getIs_active () {
					return this.is_active;
				}

				public Boolean is_activeIsNullable(){
				    return false;
				}
				public Boolean is_activeIsKey(){
				    return false;
				}
				public Integer is_activeLength(){
				    return 10;
				}
				public Integer is_activePrecision(){
				    return 0;
				}
				public String is_activeDefault(){
				
					return "1";
				
				}
				public String is_activeComment(){
				
				    return "";
				
				}
				public String is_activePattern(){
				
					return "";
				
				}
				public String is_activeOriginalDbColumnName(){
				
					return "is_active";
				
				}

				
			    public int is_deleted;

				public int getIs_deleted () {
					return this.is_deleted;
				}

				public Boolean is_deletedIsNullable(){
				    return false;
				}
				public Boolean is_deletedIsKey(){
				    return false;
				}
				public Integer is_deletedLength(){
				    return 10;
				}
				public Integer is_deletedPrecision(){
				    return 0;
				}
				public String is_deletedDefault(){
				
					return "0";
				
				}
				public String is_deletedComment(){
				
				    return "";
				
				}
				public String is_deletedPattern(){
				
					return "";
				
				}
				public String is_deletedOriginalDbColumnName(){
				
					return "is_deleted";
				
				}

				
			    public String audited_questions_id;

				public String getAudited_questions_id () {
					return this.audited_questions_id;
				}

				public Boolean audited_questions_idIsNullable(){
				    return true;
				}
				public Boolean audited_questions_idIsKey(){
				    return false;
				}
				public Integer audited_questions_idLength(){
				    return 32;
				}
				public Integer audited_questions_idPrecision(){
				    return 0;
				}
				public String audited_questions_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String audited_questions_idComment(){
				
				    return "";
				
				}
				public String audited_questions_idPattern(){
				
					return "";
				
				}
				public String audited_questions_idOriginalDbColumnName(){
				
					return "audited_questions_id";
				
				}

				
			    public String linking_id;

				public String getLinking_id () {
					return this.linking_id;
				}

				public Boolean linking_idIsNullable(){
				    return true;
				}
				public Boolean linking_idIsKey(){
				    return false;
				}
				public Integer linking_idLength(){
				    return 32;
				}
				public Integer linking_idPrecision(){
				    return 0;
				}
				public String linking_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String linking_idComment(){
				
				    return "";
				
				}
				public String linking_idPattern(){
				
					return "";
				
				}
				public String linking_idOriginalDbColumnName(){
				
					return "linking_id";
				
				}

				
			    public String option_id;

				public String getOption_id () {
					return this.option_id;
				}

				public Boolean option_idIsNullable(){
				    return true;
				}
				public Boolean option_idIsKey(){
				    return false;
				}
				public Integer option_idLength(){
				    return 45;
				}
				public Integer option_idPrecision(){
				    return 0;
				}
				public String option_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String option_idComment(){
				
				    return "";
				
				}
				public String option_idPattern(){
				
					return "";
				
				}
				public String option_idOriginalDbColumnName(){
				
					return "option_id";
				
				}

				
			    public Integer question_order;

				public Integer getQuestion_order () {
					return this.question_order;
				}

				public Boolean question_orderIsNullable(){
				    return true;
				}
				public Boolean question_orderIsKey(){
				    return false;
				}
				public Integer question_orderLength(){
				    return 10;
				}
				public Integer question_orderPrecision(){
				    return 0;
				}
				public String question_orderDefault(){
				
					return null;
				
				}
				public String question_orderComment(){
				
				    return "";
				
				}
				public String question_orderPattern(){
				
					return "";
				
				}
				public String question_orderOriginalDbColumnName(){
				
					return "question_order";
				
				}

				
			    public String observation_id;

				public String getObservation_id () {
					return this.observation_id;
				}

				public Boolean observation_idIsNullable(){
				    return true;
				}
				public Boolean observation_idIsKey(){
				    return false;
				}
				public Integer observation_idLength(){
				    return 45;
				}
				public Integer observation_idPrecision(){
				    return 0;
				}
				public String observation_idDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String observation_idComment(){
				
				    return "";
				
				}
				public String observation_idPattern(){
				
					return "";
				
				}
				public String observation_idOriginalDbColumnName(){
				
					return "observation_id";
				
				}

				
			    public Integer observation_mandatory;

				public Integer getObservation_mandatory () {
					return this.observation_mandatory;
				}

				public Boolean observation_mandatoryIsNullable(){
				    return true;
				}
				public Boolean observation_mandatoryIsKey(){
				    return false;
				}
				public Integer observation_mandatoryLength(){
				    return 10;
				}
				public Integer observation_mandatoryPrecision(){
				    return 0;
				}
				public String observation_mandatoryDefault(){
				
					return "0";
				
				}
				public String observation_mandatoryComment(){
				
				    return "";
				
				}
				public String observation_mandatoryPattern(){
				
					return "";
				
				}
				public String observation_mandatoryOriginalDbColumnName(){
				
					return "observation_mandatory";
				
				}

				
			    public Integer mandatory;

				public Integer getMandatory () {
					return this.mandatory;
				}

				public Boolean mandatoryIsNullable(){
				    return true;
				}
				public Boolean mandatoryIsKey(){
				    return false;
				}
				public Integer mandatoryLength(){
				    return 10;
				}
				public Integer mandatoryPrecision(){
				    return 0;
				}
				public String mandatoryDefault(){
				
					return "0";
				
				}
				public String mandatoryComment(){
				
				    return "";
				
				}
				public String mandatoryPattern(){
				
					return "";
				
				}
				public String mandatoryOriginalDbColumnName(){
				
					return "mandatory";
				
				}

				
			    public Integer is_other_observation;

				public Integer getIs_other_observation () {
					return this.is_other_observation;
				}

				public Boolean is_other_observationIsNullable(){
				    return true;
				}
				public Boolean is_other_observationIsKey(){
				    return false;
				}
				public Integer is_other_observationLength(){
				    return 10;
				}
				public Integer is_other_observationPrecision(){
				    return 0;
				}
				public String is_other_observationDefault(){
				
					return "0";
				
				}
				public String is_other_observationComment(){
				
				    return "";
				
				}
				public String is_other_observationPattern(){
				
					return "";
				
				}
				public String is_other_observationOriginalDbColumnName(){
				
					return "is_other_observation";
				
				}

				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}

				public Boolean file_nameIsNullable(){
				    return true;
				}
				public Boolean file_nameIsKey(){
				    return false;
				}
				public Integer file_nameLength(){
				    return 300;
				}
				public Integer file_namePrecision(){
				    return 0;
				}
				public String file_nameDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String file_nameComment(){
				
				    return "";
				
				}
				public String file_namePattern(){
				
					return "";
				
				}
				public String file_nameOriginalDbColumnName(){
				
					return "file_name";
				
				}

				
			    public String file_type;

				public String getFile_type () {
					return this.file_type;
				}

				public Boolean file_typeIsNullable(){
				    return true;
				}
				public Boolean file_typeIsKey(){
				    return false;
				}
				public Integer file_typeLength(){
				    return 300;
				}
				public Integer file_typePrecision(){
				    return 0;
				}
				public String file_typeDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String file_typeComment(){
				
				    return "";
				
				}
				public String file_typePattern(){
				
					return "";
				
				}
				public String file_typeOriginalDbColumnName(){
				
					return "file_type";
				
				}

				
			    public String file_path;

				public String getFile_path () {
					return this.file_path;
				}

				public Boolean file_pathIsNullable(){
				    return true;
				}
				public Boolean file_pathIsKey(){
				    return false;
				}
				public Integer file_pathLength(){
				    return 300;
				}
				public Integer file_pathPrecision(){
				    return 0;
				}
				public String file_pathDefault(){
				
					return "'NULL::character varying'";
				
				}
				public String file_pathComment(){
				
				    return "";
				
				}
				public String file_pathPattern(){
				
					return "";
				
				}
				public String file_pathOriginalDbColumnName(){
				
					return "file_path";
				
				}

				
			    public Integer is_attached;

				public Integer getIs_attached () {
					return this.is_attached;
				}

				public Boolean is_attachedIsNullable(){
				    return true;
				}
				public Boolean is_attachedIsKey(){
				    return false;
				}
				public Integer is_attachedLength(){
				    return 10;
				}
				public Integer is_attachedPrecision(){
				    return 0;
				}
				public String is_attachedDefault(){
				
					return "0";
				
				}
				public String is_attachedComment(){
				
				    return "";
				
				}
				public String is_attachedPattern(){
				
					return "";
				
				}
				public String is_attachedOriginalDbColumnName(){
				
					return "is_attached";
				
				}

				
			    public Integer is_linked;

				public Integer getIs_linked () {
					return this.is_linked;
				}

				public Boolean is_linkedIsNullable(){
				    return true;
				}
				public Boolean is_linkedIsKey(){
				    return false;
				}
				public Integer is_linkedLength(){
				    return 10;
				}
				public Integer is_linkedPrecision(){
				    return 0;
				}
				public String is_linkedDefault(){
				
					return "0";
				
				}
				public String is_linkedComment(){
				
				    return "";
				
				}
				public String is_linkedPattern(){
				
					return "";
				
				}
				public String is_linkedOriginalDbColumnName(){
				
					return "is_linked";
				
				}

				
			    public Integer is_primary;

				public Integer getIs_primary () {
					return this.is_primary;
				}

				public Boolean is_primaryIsNullable(){
				    return true;
				}
				public Boolean is_primaryIsKey(){
				    return false;
				}
				public Integer is_primaryLength(){
				    return 10;
				}
				public Integer is_primaryPrecision(){
				    return 0;
				}
				public String is_primaryDefault(){
				
					return "0";
				
				}
				public String is_primaryComment(){
				
				    return "";
				
				}
				public String is_primaryPattern(){
				
					return "";
				
				}
				public String is_primaryOriginalDbColumnName(){
				
					return "is_primary";
				
				}

				
			    public Integer temp_process;

				public Integer getTemp_process () {
					return this.temp_process;
				}

				public Boolean temp_processIsNullable(){
				    return true;
				}
				public Boolean temp_processIsKey(){
				    return false;
				}
				public Integer temp_processLength(){
				    return 10;
				}
				public Integer temp_processPrecision(){
				    return 0;
				}
				public String temp_processDefault(){
				
					return "0";
				
				}
				public String temp_processComment(){
				
				    return "";
				
				}
				public String temp_processPattern(){
				
					return "";
				
				}
				public String temp_processOriginalDbColumnName(){
				
					return "temp_process";
				
				}

				
			    public String transaction_question_Id;

				public String getTransaction_question_Id () {
					return this.transaction_question_Id;
				}

				public Boolean transaction_question_IdIsNullable(){
				    return true;
				}
				public Boolean transaction_question_IdIsKey(){
				    return false;
				}
				public Integer transaction_question_IdLength(){
				    return 45;
				}
				public Integer transaction_question_IdPrecision(){
				    return 0;
				}
				public String transaction_question_IdDefault(){
				
					return "'NULL::character varying'::character varying'";
				
				}
				public String transaction_question_IdComment(){
				
				    return "";
				
				}
				public String transaction_question_IdPattern(){
				
					return "";
				
				}
				public String transaction_question_IdOriginalDbColumnName(){
				
					return "transaction_question_Id";
				
				}

				
			    public Integer is_first_linked;

				public Integer getIs_first_linked () {
					return this.is_first_linked;
				}

				public Boolean is_first_linkedIsNullable(){
				    return true;
				}
				public Boolean is_first_linkedIsKey(){
				    return false;
				}
				public Integer is_first_linkedLength(){
				    return 10;
				}
				public Integer is_first_linkedPrecision(){
				    return 0;
				}
				public String is_first_linkedDefault(){
				
					return "0";
				
				}
				public String is_first_linkedComment(){
				
				    return "";
				
				}
				public String is_first_linkedPattern(){
				
					return "";
				
				}
				public String is_first_linkedOriginalDbColumnName(){
				
					return "is_first_linked";
				
				}

				
			    public Integer is_fraud;

				public Integer getIs_fraud () {
					return this.is_fraud;
				}

				public Boolean is_fraudIsNullable(){
				    return true;
				}
				public Boolean is_fraudIsKey(){
				    return false;
				}
				public Integer is_fraudLength(){
				    return 10;
				}
				public Integer is_fraudPrecision(){
				    return 0;
				}
				public String is_fraudDefault(){
				
					return "0";
				
				}
				public String is_fraudComment(){
				
				    return "";
				
				}
				public String is_fraudPattern(){
				
					return "";
				
				}
				public String is_fraudOriginalDbColumnName(){
				
					return "is_fraud";
				
				}

				
			    public Integer is_converted;

				public Integer getIs_converted () {
					return this.is_converted;
				}

				public Boolean is_convertedIsNullable(){
				    return true;
				}
				public Boolean is_convertedIsKey(){
				    return false;
				}
				public Integer is_convertedLength(){
				    return 10;
				}
				public Integer is_convertedPrecision(){
				    return 0;
				}
				public String is_convertedDefault(){
				
					return "0";
				
				}
				public String is_convertedComment(){
				
				    return "";
				
				}
				public String is_convertedPattern(){
				
					return "";
				
				}
				public String is_convertedOriginalDbColumnName(){
				
					return "is_converted";
				
				}

				
			    public java.util.Date as_on;

				public java.util.Date getAs_on () {
					return this.as_on;
				}

				public Boolean as_onIsNullable(){
				    return true;
				}
				public Boolean as_onIsKey(){
				    return false;
				}
				public Integer as_onLength(){
				    return 0;
				}
				public Integer as_onPrecision(){
				    return 0;
				}
				public String as_onDefault(){
				
					return "'CURRENT_TIMESTAMP'";
				
				}
				public String as_onComment(){
				
				    return "";
				
				}
				public String as_onPattern(){
				
					return "yyyy-MM-dd";
				
				}
				public String as_onOriginalDbColumnName(){
				
					return "as_on";
				
				}

				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.id;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row3Struct other = (row3Struct) obj;
		
						if (this.id != other.id)
							return false;
					

		return true;
    }

	public void copyDataTo(row3Struct other) {

		other.id = this.id;
	            other.m_Id = this.m_Id;
	            other.process_audit_details_id = this.process_audit_details_id;
	            other.audit_plan_id = this.audit_plan_id;
	            other.process_name = this.process_name;
	            other.subprocess_name = this.subprocess_name;
	            other.question = this.question;
	            other.option_name = this.option_name;
	            other.max_marks = this.max_marks;
	            other.score = this.score;
	            other.observation = this.observation;
	            other.other_observation = this.other_observation;
	            other.risk_type = this.risk_type;
	            other.attachement = this.attachement;
	            other.attachement_type = this.attachement_type;
	            other.resloved_attachment = this.resloved_attachment;
	            other.is_nc = this.is_nc;
	            other.nc_status = this.nc_status;
	            other.assigned_to = this.assigned_to;
	            other.role_code = this.role_code;
	            other.nc_remarks = this.nc_remarks;
	            other.is_major_nc = this.is_major_nc;
	            other.category_id = this.category_id;
	            other.category_name = this.category_name;
	            other.created_by = this.created_by;
	            other.created_on = this.created_on;
	            other.updated_by = this.updated_by;
	            other.updated_on = this.updated_on;
	            other.closed_by = this.closed_by;
	            other.closed_on = this.closed_on;
	            other.is_active = this.is_active;
	            other.is_deleted = this.is_deleted;
	            other.audited_questions_id = this.audited_questions_id;
	            other.linking_id = this.linking_id;
	            other.option_id = this.option_id;
	            other.question_order = this.question_order;
	            other.observation_id = this.observation_id;
	            other.observation_mandatory = this.observation_mandatory;
	            other.mandatory = this.mandatory;
	            other.is_other_observation = this.is_other_observation;
	            other.file_name = this.file_name;
	            other.file_type = this.file_type;
	            other.file_path = this.file_path;
	            other.is_attached = this.is_attached;
	            other.is_linked = this.is_linked;
	            other.is_primary = this.is_primary;
	            other.temp_process = this.temp_process;
	            other.transaction_question_Id = this.transaction_question_Id;
	            other.is_first_linked = this.is_first_linked;
	            other.is_fraud = this.is_fraud;
	            other.is_converted = this.is_converted;
	            other.as_on = this.as_on;
	            
	}

	public void copyKeysDataTo(row3Struct other) {

		other.id = this.id;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables.length) {
				if(length < 1024 && commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables.length == 0) {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables = new byte[1024];
				} else {
   					commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables, 0, length);
			strReturn = new String(commonByteArray_TALEND_TAC2_REPO_Audit_incremental_major_7_tables, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_major_7_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.m_Id = readString(dis);
					
						this.process_audit_details_id = (BigDecimal) dis.readObject();
					
						this.audit_plan_id = (BigDecimal) dis.readObject();
					
					this.process_name = readString(dis);
					
					this.subprocess_name = readString(dis);
					
					this.question = readString(dis);
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.max_marks = null;
           				} else {
           			    	this.max_marks = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.score = null;
           				} else {
           			    	this.score = dis.readFloat();
           				}
					
					this.observation = readString(dis);
					
					this.other_observation = readString(dis);
					
					this.risk_type = readString(dis);
					
					this.attachement = readString(dis);
					
					this.attachement_type = readString(dis);
					
					this.resloved_attachment = readString(dis);
					
						this.is_nc = (BigDecimal) dis.readObject();
					
						this.nc_status = (BigDecimal) dis.readObject();
					
						this.assigned_to = (BigDecimal) dis.readObject();
					
						this.role_code = (BigDecimal) dis.readObject();
					
					this.nc_remarks = readString(dis);
					
						this.is_major_nc = (BigDecimal) dis.readObject();
					
						this.category_id = (BigDecimal) dis.readObject();
					
					this.category_name = readString(dis);
					
						this.created_by = (BigDecimal) dis.readObject();
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
						this.closed_by = readInteger(dis);
					
					this.closed_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.audited_questions_id = readString(dis);
					
					this.linking_id = readString(dis);
					
					this.option_id = readString(dis);
					
						this.question_order = readInteger(dis);
					
					this.observation_id = readString(dis);
					
						this.observation_mandatory = readInteger(dis);
					
						this.mandatory = readInteger(dis);
					
						this.is_other_observation = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.file_type = readString(dis);
					
					this.file_path = readString(dis);
					
						this.is_attached = readInteger(dis);
					
						this.is_linked = readInteger(dis);
					
						this.is_primary = readInteger(dis);
					
						this.temp_process = readInteger(dis);
					
					this.transaction_question_Id = readString(dis);
					
						this.is_first_linked = readInteger(dis);
					
						this.is_fraud = readInteger(dis);
					
						this.is_converted = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_TALEND_TAC2_REPO_Audit_incremental_major_7_tables) {

        	try {

        		int length = 0;
		
			        this.id = dis.readInt();
					
					this.m_Id = readString(dis);
					
						this.process_audit_details_id = (BigDecimal) dis.readObject();
					
						this.audit_plan_id = (BigDecimal) dis.readObject();
					
					this.process_name = readString(dis);
					
					this.subprocess_name = readString(dis);
					
					this.question = readString(dis);
					
					this.option_name = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.max_marks = null;
           				} else {
           			    	this.max_marks = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.score = null;
           				} else {
           			    	this.score = dis.readFloat();
           				}
					
					this.observation = readString(dis);
					
					this.other_observation = readString(dis);
					
					this.risk_type = readString(dis);
					
					this.attachement = readString(dis);
					
					this.attachement_type = readString(dis);
					
					this.resloved_attachment = readString(dis);
					
						this.is_nc = (BigDecimal) dis.readObject();
					
						this.nc_status = (BigDecimal) dis.readObject();
					
						this.assigned_to = (BigDecimal) dis.readObject();
					
						this.role_code = (BigDecimal) dis.readObject();
					
					this.nc_remarks = readString(dis);
					
						this.is_major_nc = (BigDecimal) dis.readObject();
					
						this.category_id = (BigDecimal) dis.readObject();
					
					this.category_name = readString(dis);
					
						this.created_by = (BigDecimal) dis.readObject();
					
					this.created_on = readDate(dis);
					
						this.updated_by = readInteger(dis);
					
					this.updated_on = readDate(dis);
					
						this.closed_by = readInteger(dis);
					
					this.closed_on = readDate(dis);
					
			        this.is_active = dis.readInt();
					
			        this.is_deleted = dis.readInt();
					
					this.audited_questions_id = readString(dis);
					
					this.linking_id = readString(dis);
					
					this.option_id = readString(dis);
					
						this.question_order = readInteger(dis);
					
					this.observation_id = readString(dis);
					
						this.observation_mandatory = readInteger(dis);
					
						this.mandatory = readInteger(dis);
					
						this.is_other_observation = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.file_type = readString(dis);
					
					this.file_path = readString(dis);
					
						this.is_attached = readInteger(dis);
					
						this.is_linked = readInteger(dis);
					
						this.is_primary = readInteger(dis);
					
						this.temp_process = readInteger(dis);
					
					this.transaction_question_Id = readString(dis);
					
						this.is_first_linked = readInteger(dis);
					
						this.is_fraud = readInteger(dis);
					
						this.is_converted = readInteger(dis);
					
					this.as_on = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.m_Id,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.process_audit_details_id);
					
					// BigDecimal
				
       			    	dos.writeObject(this.audit_plan_id);
					
					// String
				
						writeString(this.process_name,dos);
					
					// String
				
						writeString(this.subprocess_name,dos);
					
					// String
				
						writeString(this.question,dos);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.max_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.max_marks);
		            	}
					
					// Float
				
						if(this.score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.score);
		            	}
					
					// String
				
						writeString(this.observation,dos);
					
					// String
				
						writeString(this.other_observation,dos);
					
					// String
				
						writeString(this.risk_type,dos);
					
					// String
				
						writeString(this.attachement,dos);
					
					// String
				
						writeString(this.attachement_type,dos);
					
					// String
				
						writeString(this.resloved_attachment,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.is_nc);
					
					// BigDecimal
				
       			    	dos.writeObject(this.nc_status);
					
					// BigDecimal
				
       			    	dos.writeObject(this.assigned_to);
					
					// BigDecimal
				
       			    	dos.writeObject(this.role_code);
					
					// String
				
						writeString(this.nc_remarks,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.is_major_nc);
					
					// BigDecimal
				
       			    	dos.writeObject(this.category_id);
					
					// String
				
						writeString(this.category_name,dos);
					
					// BigDecimal
				
       			    	dos.writeObject(this.created_by);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// Integer
				
						writeInteger(this.closed_by,dos);
					
					// java.util.Date
				
						writeDate(this.closed_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.audited_questions_id,dos);
					
					// String
				
						writeString(this.linking_id,dos);
					
					// String
				
						writeString(this.option_id,dos);
					
					// Integer
				
						writeInteger(this.question_order,dos);
					
					// String
				
						writeString(this.observation_id,dos);
					
					// Integer
				
						writeInteger(this.observation_mandatory,dos);
					
					// Integer
				
						writeInteger(this.mandatory,dos);
					
					// Integer
				
						writeInteger(this.is_other_observation,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// String
				
						writeString(this.file_type,dos);
					
					// String
				
						writeString(this.file_path,dos);
					
					// Integer
				
						writeInteger(this.is_attached,dos);
					
					// Integer
				
						writeInteger(this.is_linked,dos);
					
					// Integer
				
						writeInteger(this.is_primary,dos);
					
					// Integer
				
						writeInteger(this.temp_process,dos);
					
					// String
				
						writeString(this.transaction_question_Id,dos);
					
					// Integer
				
						writeInteger(this.is_first_linked,dos);
					
					// Integer
				
						writeInteger(this.is_fraud,dos);
					
					// Integer
				
						writeInteger(this.is_converted,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.id);
					
					// String
				
						writeString(this.m_Id,dos);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.process_audit_details_id);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.audit_plan_id);
					
					// String
				
						writeString(this.process_name,dos);
					
					// String
				
						writeString(this.subprocess_name,dos);
					
					// String
				
						writeString(this.question,dos);
					
					// String
				
						writeString(this.option_name,dos);
					
					// Float
				
						if(this.max_marks == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.max_marks);
		            	}
					
					// Float
				
						if(this.score == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.score);
		            	}
					
					// String
				
						writeString(this.observation,dos);
					
					// String
				
						writeString(this.other_observation,dos);
					
					// String
				
						writeString(this.risk_type,dos);
					
					// String
				
						writeString(this.attachement,dos);
					
					// String
				
						writeString(this.attachement_type,dos);
					
					// String
				
						writeString(this.resloved_attachment,dos);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.is_nc);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.nc_status);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.assigned_to);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.role_code);
					
					// String
				
						writeString(this.nc_remarks,dos);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.is_major_nc);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.category_id);
					
					// String
				
						writeString(this.category_name,dos);
					
					// BigDecimal
				
						dos.clearInstanceCache();
						dos.writeObject(this.created_by);
					
					// java.util.Date
				
						writeDate(this.created_on,dos);
					
					// Integer
				
						writeInteger(this.updated_by,dos);
					
					// java.util.Date
				
						writeDate(this.updated_on,dos);
					
					// Integer
				
						writeInteger(this.closed_by,dos);
					
					// java.util.Date
				
						writeDate(this.closed_on,dos);
					
					// int
				
		            	dos.writeInt(this.is_active);
					
					// int
				
		            	dos.writeInt(this.is_deleted);
					
					// String
				
						writeString(this.audited_questions_id,dos);
					
					// String
				
						writeString(this.linking_id,dos);
					
					// String
				
						writeString(this.option_id,dos);
					
					// Integer
				
						writeInteger(this.question_order,dos);
					
					// String
				
						writeString(this.observation_id,dos);
					
					// Integer
				
						writeInteger(this.observation_mandatory,dos);
					
					// Integer
				
						writeInteger(this.mandatory,dos);
					
					// Integer
				
						writeInteger(this.is_other_observation,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// String
				
						writeString(this.file_type,dos);
					
					// String
				
						writeString(this.file_path,dos);
					
					// Integer
				
						writeInteger(this.is_attached,dos);
					
					// Integer
				
						writeInteger(this.is_linked,dos);
					
					// Integer
				
						writeInteger(this.is_primary,dos);
					
					// Integer
				
						writeInteger(this.temp_process,dos);
					
					// String
				
						writeString(this.transaction_question_Id,dos);
					
					// Integer
				
						writeInteger(this.is_first_linked,dos);
					
					// Integer
				
						writeInteger(this.is_fraud,dos);
					
					// Integer
				
						writeInteger(this.is_converted,dos);
					
					// java.util.Date
				
						writeDate(this.as_on,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",m_Id="+m_Id);
		sb.append(",process_audit_details_id="+String.valueOf(process_audit_details_id));
		sb.append(",audit_plan_id="+String.valueOf(audit_plan_id));
		sb.append(",process_name="+process_name);
		sb.append(",subprocess_name="+subprocess_name);
		sb.append(",question="+question);
		sb.append(",option_name="+option_name);
		sb.append(",max_marks="+String.valueOf(max_marks));
		sb.append(",score="+String.valueOf(score));
		sb.append(",observation="+observation);
		sb.append(",other_observation="+other_observation);
		sb.append(",risk_type="+risk_type);
		sb.append(",attachement="+attachement);
		sb.append(",attachement_type="+attachement_type);
		sb.append(",resloved_attachment="+resloved_attachment);
		sb.append(",is_nc="+String.valueOf(is_nc));
		sb.append(",nc_status="+String.valueOf(nc_status));
		sb.append(",assigned_to="+String.valueOf(assigned_to));
		sb.append(",role_code="+String.valueOf(role_code));
		sb.append(",nc_remarks="+nc_remarks);
		sb.append(",is_major_nc="+String.valueOf(is_major_nc));
		sb.append(",category_id="+String.valueOf(category_id));
		sb.append(",category_name="+category_name);
		sb.append(",created_by="+String.valueOf(created_by));
		sb.append(",created_on="+String.valueOf(created_on));
		sb.append(",updated_by="+String.valueOf(updated_by));
		sb.append(",updated_on="+String.valueOf(updated_on));
		sb.append(",closed_by="+String.valueOf(closed_by));
		sb.append(",closed_on="+String.valueOf(closed_on));
		sb.append(",is_active="+String.valueOf(is_active));
		sb.append(",is_deleted="+String.valueOf(is_deleted));
		sb.append(",audited_questions_id="+audited_questions_id);
		sb.append(",linking_id="+linking_id);
		sb.append(",option_id="+option_id);
		sb.append(",question_order="+String.valueOf(question_order));
		sb.append(",observation_id="+observation_id);
		sb.append(",observation_mandatory="+String.valueOf(observation_mandatory));
		sb.append(",mandatory="+String.valueOf(mandatory));
		sb.append(",is_other_observation="+String.valueOf(is_other_observation));
		sb.append(",file_name="+file_name);
		sb.append(",file_type="+file_type);
		sb.append(",file_path="+file_path);
		sb.append(",is_attached="+String.valueOf(is_attached));
		sb.append(",is_linked="+String.valueOf(is_linked));
		sb.append(",is_primary="+String.valueOf(is_primary));
		sb.append(",temp_process="+String.valueOf(temp_process));
		sb.append(",transaction_question_Id="+transaction_question_Id);
		sb.append(",is_first_linked="+String.valueOf(is_first_linked));
		sb.append(",is_fraud="+String.valueOf(is_fraud));
		sb.append(",is_converted="+String.valueOf(is_converted));
		sb.append(",as_on="+String.valueOf(as_on));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				sb.append(id);
        			
        			sb.append("|");
        		
        				if(m_Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(m_Id);
            			}
            		
        			sb.append("|");
        		
        				if(process_audit_details_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_audit_details_id);
            			}
            		
        			sb.append("|");
        		
        				if(audit_plan_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audit_plan_id);
            			}
            		
        			sb.append("|");
        		
        				if(process_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_name);
            			}
            		
        			sb.append("|");
        		
        				if(subprocess_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(subprocess_name);
            			}
            		
        			sb.append("|");
        		
        				if(question == null){
        					sb.append("<null>");
        				}else{
            				sb.append(question);
            			}
            		
        			sb.append("|");
        		
        				if(option_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_name);
            			}
            		
        			sb.append("|");
        		
        				if(max_marks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(max_marks);
            			}
            		
        			sb.append("|");
        		
        				if(score == null){
        					sb.append("<null>");
        				}else{
            				sb.append(score);
            			}
            		
        			sb.append("|");
        		
        				if(observation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation);
            			}
            		
        			sb.append("|");
        		
        				if(other_observation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(other_observation);
            			}
            		
        			sb.append("|");
        		
        				if(risk_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(risk_type);
            			}
            		
        			sb.append("|");
        		
        				if(attachement == null){
        					sb.append("<null>");
        				}else{
            				sb.append(attachement);
            			}
            		
        			sb.append("|");
        		
        				if(attachement_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(attachement_type);
            			}
            		
        			sb.append("|");
        		
        				if(resloved_attachment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(resloved_attachment);
            			}
            		
        			sb.append("|");
        		
        				if(is_nc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_nc);
            			}
            		
        			sb.append("|");
        		
        				if(nc_status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(nc_status);
            			}
            		
        			sb.append("|");
        		
        				if(assigned_to == null){
        					sb.append("<null>");
        				}else{
            				sb.append(assigned_to);
            			}
            		
        			sb.append("|");
        		
        				if(role_code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(role_code);
            			}
            		
        			sb.append("|");
        		
        				if(nc_remarks == null){
        					sb.append("<null>");
        				}else{
            				sb.append(nc_remarks);
            			}
            		
        			sb.append("|");
        		
        				if(is_major_nc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_major_nc);
            			}
            		
        			sb.append("|");
        		
        				if(category_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(category_id);
            			}
            		
        			sb.append("|");
        		
        				if(category_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(category_name);
            			}
            		
        			sb.append("|");
        		
        				if(created_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_by);
            			}
            		
        			sb.append("|");
        		
        				if(created_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(created_on);
            			}
            		
        			sb.append("|");
        		
        				if(updated_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_by);
            			}
            		
        			sb.append("|");
        		
        				if(updated_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updated_on);
            			}
            		
        			sb.append("|");
        		
        				if(closed_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(closed_by);
            			}
            		
        			sb.append("|");
        		
        				if(closed_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(closed_on);
            			}
            		
        			sb.append("|");
        		
        				sb.append(is_active);
        			
        			sb.append("|");
        		
        				sb.append(is_deleted);
        			
        			sb.append("|");
        		
        				if(audited_questions_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(audited_questions_id);
            			}
            		
        			sb.append("|");
        		
        				if(linking_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(linking_id);
            			}
            		
        			sb.append("|");
        		
        				if(option_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(option_id);
            			}
            		
        			sb.append("|");
        		
        				if(question_order == null){
        					sb.append("<null>");
        				}else{
            				sb.append(question_order);
            			}
            		
        			sb.append("|");
        		
        				if(observation_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation_id);
            			}
            		
        			sb.append("|");
        		
        				if(observation_mandatory == null){
        					sb.append("<null>");
        				}else{
            				sb.append(observation_mandatory);
            			}
            		
        			sb.append("|");
        		
        				if(mandatory == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mandatory);
            			}
            		
        			sb.append("|");
        		
        				if(is_other_observation == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_other_observation);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(file_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_type);
            			}
            		
        			sb.append("|");
        		
        				if(file_path == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_path);
            			}
            		
        			sb.append("|");
        		
        				if(is_attached == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_attached);
            			}
            		
        			sb.append("|");
        		
        				if(is_linked == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_linked);
            			}
            		
        			sb.append("|");
        		
        				if(is_primary == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_primary);
            			}
            		
        			sb.append("|");
        		
        				if(temp_process == null){
        					sb.append("<null>");
        				}else{
            				sb.append(temp_process);
            			}
            		
        			sb.append("|");
        		
        				if(transaction_question_Id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(transaction_question_Id);
            			}
            		
        			sb.append("|");
        		
        				if(is_first_linked == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_first_linked);
            			}
            		
        			sb.append("|");
        		
        				if(is_fraud == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_fraud);
            			}
            		
        			sb.append("|");
        		
        				if(is_converted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_converted);
            			}
            		
        			sb.append("|");
        		
        				if(as_on == null){
        					sb.append("<null>");
        				}else{
            				sb.append(as_on);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id, other.id);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public void tDBInput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBInput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_7");
		org.slf4j.MDC.put("_subJobPid", "0dtKni_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="Audit_target";
		
			runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,0,0,"row3");
			
		int tos_count_tDBOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBOutput_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBOutput_3 = new StringBuilder();
                    log4jParamters_tDBOutput_3.append("Parameters:");
                            log4jParamters_tDBOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE" + " = " + "\"tbl_audited_questions\"");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("TABLE_ACTION" + " = " + "CREATE");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DATA_ACTION" + " = " + "UPSERT");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_SPATIAL_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_ALTERNATE_SCHEMA" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ADD_COLS" + " = " + "[]");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("CONVERT_COLUMN_TABLE_TO_LOWERCASE" + " = " + "false");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("BATCH_SIZE" + " = " + "10000");
                        log4jParamters_tDBOutput_3.append(" | ");
                            log4jParamters_tDBOutput_3.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlOutput");
                        log4jParamters_tDBOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + (log4jParamters_tDBOutput_3) );
                    } 
                } 
            new BytesLimit65535_tDBOutput_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBOutput_3", "Audit_target", "tPostgresqlOutput");
				talendJobLogProcess(globalMap);
			}
			





String dbschema_tDBOutput_3 = null;
	dbschema_tDBOutput_3 = (String)globalMap.get("schema_" + "tDBConnection_2");
	

String tableName_tDBOutput_3 = null;
if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
	tableName_tDBOutput_3 = ("tbl_audited_questions");
} else {
	tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "\".\"" + ("tbl_audited_questions");
}


int nb_line_tDBOutput_3 = 0;
int nb_line_update_tDBOutput_3 = 0;
int nb_line_inserted_tDBOutput_3 = 0;
int nb_line_deleted_tDBOutput_3 = 0;
int nb_line_rejected_tDBOutput_3 = 0;

int deletedCount_tDBOutput_3=0;
int updatedCount_tDBOutput_3=0;
int insertedCount_tDBOutput_3=0;
int rowsToCommitCount_tDBOutput_3=0;
int rejectedCount_tDBOutput_3=0;

boolean whetherReject_tDBOutput_3 = false;

java.sql.Connection conn_tDBOutput_3 = null;
String dbUser_tDBOutput_3 = null;

	conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tDBOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tDBOutput_3.getMetaData().getURL())  + (".") );
	
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tDBOutput_3.getAutoCommit())  + ("'.") );


   int batchSize_tDBOutput_3 = 10000;
   int batchSizeCounter_tDBOutput_3=0;

int count_tDBOutput_3=0;
            try (java.sql.Statement stmtCreate_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Creating")  + (" table '")  + ("\"" +tableName_tDBOutput_3+ "\"")  + ("'.") );
                stmtCreate_tDBOutput_3.execute("CREATE TABLE \"" + tableName_tDBOutput_3 + "\"(\"id\" INT4  not null ,\"m_Id\" VARCHAR(45)  default null ,\"process_audit_details_id\" NUMERIC(16,0)   not null ,\"audit_plan_id\" NUMERIC(16,0)   not null ,\"process_name\" VARCHAR(150)   not null ,\"subprocess_name\" VARCHAR(150)   not null ,\"question\" TEXT  not null ,\"option_name\" VARCHAR(150)   not null ,\"max_marks\" FLOAT4 default '0'::real ,\"score\" FLOAT4 default '0'::real ,\"observation\" TEXT ,\"other_observation\" TEXT ,\"risk_type\" VARCHAR(45)  default 'NULL::character varying' ,\"attachement\" TEXT ,\"attachement_type\" VARCHAR(10)  default 'NULL::character varying' ,\"resloved_attachment\" TEXT ,\"is_nc\" NUMERIC(16,0)   not null ,\"nc_status\" NUMERIC(16,0)  ,\"assigned_to\" NUMERIC(16,0)  ,\"role_code\" NUMERIC(16,0)  ,\"nc_remarks\" TEXT ,\"is_major_nc\" NUMERIC(16,0)  ,\"category_id\" NUMERIC(16,0)  ,\"category_name\" VARCHAR(40)  default 'NULL::character varying' ,\"created_by\" NUMERIC(16,0)  ,\"created_on\" TIMESTAMP(29)  default 'CURRENT_TIMESTAMP'  not null ,\"updated_by\" INT4 ,\"updated_on\" TIMESTAMP(29)  default 'CURRENT_TIMESTAMP'  not null ,\"closed_by\" INT4 ,\"closed_on\" TIMESTAMP(29)  ,\"is_active\" INT4 default 1  not null ,\"is_deleted\" INT4 default 0  not null ,\"audited_questions_id\" VARCHAR(32)  default 'NULL::character varying' ,\"linking_id\" VARCHAR(32)  default 'NULL::character varying' ,\"option_id\" VARCHAR(45)  default 'NULL::character varying' ,\"question_order\" INT4 ,\"observation_id\" VARCHAR(45)  default 'NULL::character varying' ,\"observation_mandatory\" INT4 default 0 ,\"mandatory\" INT4 default 0 ,\"is_other_observation\" INT4 default 0 ,\"file_name\" VARCHAR(300)  default 'NULL::character varying' ,\"file_type\" VARCHAR(300)  default 'NULL::character varying' ,\"file_path\" VARCHAR(300)  default 'NULL::character varying' ,\"is_attached\" INT4 default 0 ,\"is_linked\" INT4 default 0 ,\"is_primary\" INT4 default 0 ,\"temp_process\" INT4 default 0 ,\"transaction_question_Id\" VARCHAR(45)  default 'NULL::character varying'::character varying' ,\"is_first_linked\" INT4 default 0 ,\"is_fraud\" INT4 default 0 ,\"is_converted\" INT4 default 0 ,\"as_on\" DATE default 'CURRENT_TIMESTAMP' ,primary key(\"id\"))");
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Create")  + (" table '")  + ("\"" +tableName_tDBOutput_3+ "\"")  + ("' has succeeded.") );
            }
        java.lang.StringBuilder sb_tDBOutput_3 = new java.lang.StringBuilder();
        sb_tDBOutput_3.append("INSERT INTO \"").append(tableName_tDBOutput_3).append("\" (\"id\",\"m_Id\",\"process_audit_details_id\",\"audit_plan_id\",\"process_name\",\"subprocess_name\",\"question\",\"option_name\",\"max_marks\",\"score\",\"observation\",\"other_observation\",\"risk_type\",\"attachement\",\"attachement_type\",\"resloved_attachment\",\"is_nc\",\"nc_status\",\"assigned_to\",\"role_code\",\"nc_remarks\",\"is_major_nc\",\"category_id\",\"category_name\",\"created_by\",\"created_on\",\"updated_by\",\"updated_on\",\"closed_by\",\"closed_on\",\"is_active\",\"is_deleted\",\"audited_questions_id\",\"linking_id\",\"option_id\",\"question_order\",\"observation_id\",\"observation_mandatory\",\"mandatory\",\"is_other_observation\",\"file_name\",\"file_type\",\"file_path\",\"is_attached\",\"is_linked\",\"is_primary\",\"temp_process\",\"transaction_question_Id\",\"is_first_linked\",\"is_fraud\",\"is_converted\",\"as_on\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            sb_tDBOutput_3.append(" ON CONFLICT (").append("\"id\"").append(")").append(" DO UPDATE SET ").append("\"m_Id\" = EXCLUDED.\"m_Id\",\"process_audit_details_id\" = EXCLUDED.\"process_audit_details_id\",\"audit_plan_id\" = EXCLUDED.\"audit_plan_id\",\"process_name\" = EXCLUDED.\"process_name\",\"subprocess_name\" = EXCLUDED.\"subprocess_name\",\"question\" = EXCLUDED.\"question\",\"option_name\" = EXCLUDED.\"option_name\",\"max_marks\" = EXCLUDED.\"max_marks\",\"score\" = EXCLUDED.\"score\",\"observation\" = EXCLUDED.\"observation\",\"other_observation\" = EXCLUDED.\"other_observation\",\"risk_type\" = EXCLUDED.\"risk_type\",\"attachement\" = EXCLUDED.\"attachement\",\"attachement_type\" = EXCLUDED.\"attachement_type\",\"resloved_attachment\" = EXCLUDED.\"resloved_attachment\",\"is_nc\" = EXCLUDED.\"is_nc\",\"nc_status\" = EXCLUDED.\"nc_status\",\"assigned_to\" = EXCLUDED.\"assigned_to\",\"role_code\" = EXCLUDED.\"role_code\",\"nc_remarks\" = EXCLUDED.\"nc_remarks\",\"is_major_nc\" = EXCLUDED.\"is_major_nc\",\"category_id\" = EXCLUDED.\"category_id\",\"category_name\" = EXCLUDED.\"category_name\",\"created_by\" = EXCLUDED.\"created_by\",\"created_on\" = EXCLUDED.\"created_on\",\"updated_by\" = EXCLUDED.\"updated_by\",\"updated_on\" = EXCLUDED.\"updated_on\",\"closed_by\" = EXCLUDED.\"closed_by\",\"closed_on\" = EXCLUDED.\"closed_on\",\"is_active\" = EXCLUDED.\"is_active\",\"is_deleted\" = EXCLUDED.\"is_deleted\",\"audited_questions_id\" = EXCLUDED.\"audited_questions_id\",\"linking_id\" = EXCLUDED.\"linking_id\",\"option_id\" = EXCLUDED.\"option_id\",\"question_order\" = EXCLUDED.\"question_order\",\"observation_id\" = EXCLUDED.\"observation_id\",\"observation_mandatory\" = EXCLUDED.\"observation_mandatory\",\"mandatory\" = EXCLUDED.\"mandatory\",\"is_other_observation\" = EXCLUDED.\"is_other_observation\",\"file_name\" = EXCLUDED.\"file_name\",\"file_type\" = EXCLUDED.\"file_type\",\"file_path\" = EXCLUDED.\"file_path\",\"is_attached\" = EXCLUDED.\"is_attached\",\"is_linked\" = EXCLUDED.\"is_linked\",\"is_primary\" = EXCLUDED.\"is_primary\",\"temp_process\" = EXCLUDED.\"temp_process\",\"transaction_question_Id\" = EXCLUDED.\"transaction_question_Id\",\"is_first_linked\" = EXCLUDED.\"is_first_linked\",\"is_fraud\" = EXCLUDED.\"is_fraud\",\"is_converted\" = EXCLUDED.\"is_converted\",\"as_on\" = EXCLUDED.\"as_on\"");

        String insert_tDBOutput_3 = sb_tDBOutput_3.toString();
        
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing '")  + (insert_tDBOutput_3)  + ("'.") );
        
	    
	    java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
	    resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
	    

 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tDBInput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBInput_7", false);
		start_Hash.put("tDBInput_7", System.currentTimeMillis());
		
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"tbl_audited_questions\"";
		
		int tos_count_tDBInput_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBInput_7 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBInput_7{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBInput_7 = new StringBuilder();
                    log4jParamters_tDBInput_7.append("Parameters:");
                            log4jParamters_tDBInput_7.append("USE_EXISTING_CONNECTION" + " = " + "true");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("TABLE" + " = " + "\"tbl_audited_questions\"");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("QUERYSTORE" + " = " + "\"\"");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("QUERY" + " = " + "\"SELECT    `tbl_audited_questions`.`id`,    `tbl_audited_questions`.`m_Id`,    `tbl_audited_questions`.`process_audit_details_id`,    `tbl_audited_questions`.`audit_plan_id`,    `tbl_audited_questions`.`process_name`,    `tbl_audited_questions`.`subprocess_name`,    `tbl_audited_questions`.`question`,    `tbl_audited_questions`.`option_name`,    `tbl_audited_questions`.`max_marks`,    `tbl_audited_questions`.`score`,    `tbl_audited_questions`.`observation`,    `tbl_audited_questions`.`other_observation`,    `tbl_audited_questions`.`risk_type`,    `tbl_audited_questions`.`attachement`,    `tbl_audited_questions`.`attachement_type`,    `tbl_audited_questions`.`resloved_attachment`,    `tbl_audited_questions`.`is_nc`,    `tbl_audited_questions`.`nc_status`,    `tbl_audited_questions`.`assigned_to`,    `tbl_audited_questions`.`role_code`,    `tbl_audited_questions`.`nc_remarks`,    `tbl_audited_questions`.`is_major_nc`,    `tbl_audited_questions`.`category_id`,    `tbl_audited_questions`.`category_name`,    `tbl_audited_questions`.`created_by`,    `tbl_audited_questions`.`created_on`,    `tbl_audited_questions`.`updated_by`,    `tbl_audited_questions`.`updated_on`,    `tbl_audited_questions`.`closed_by`,    `tbl_audited_questions`.`closed_on`,    `tbl_audited_questions`.`is_active`,    `tbl_audited_questions`.`is_deleted`,    `tbl_audited_questions`.`audited_questions_id`,    `tbl_audited_questions`.`linking_id`,    `tbl_audited_questions`.`option_id`,    `tbl_audited_questions`.`question_order`,    `tbl_audited_questions`.`observation_id`,    `tbl_audited_questions`.`observation_mandatory`,    `tbl_audited_questions`.`mandatory`,    `tbl_audited_questions`.`is_other_observation`,    `tbl_audited_questions`.`file_name`,    `tbl_audited_questions`.`file_type`,    `tbl_audited_questions`.`file_path`,    `tbl_audited_questions`.`is_attached`,    `tbl_audited_questions`.`is_linked`,    `tbl_audited_questions`.`is_primary`,    `tbl_audited_questions`.`temp_process`,    `tbl_audited_questions`.`transaction_question_Id`,    `tbl_audited_questions`.`is_first_linked`,    `tbl_audited_questions`.`is_fraud`,    `tbl_audited_questions`.`is_converted`,  	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on` FROM `tbl_audited_questions`\"");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("ENABLE_STREAM" + " = " + "true");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("TRIM_ALL_COLUMN" + " = " + "false");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("m_Id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("process_audit_details_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audit_plan_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("process_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("subprocess_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("question")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("max_marks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("score")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("observation")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("other_observation")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("risk_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("attachement")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("attachement_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("resloved_attachment")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_nc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("nc_status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("assigned_to")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("role_code")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("nc_remarks")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_major_nc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("category_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("category_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("created_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("updated_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("closed_by")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("closed_on")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_active")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_deleted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("audited_questions_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("linking_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("option_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("question_order")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("observation_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("observation_mandatory")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("mandatory")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_other_observation")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("file_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("file_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("file_path")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_attached")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_linked")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_primary")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("temp_process")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("transaction_question_Id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_first_linked")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_fraud")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("is_converted")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("as_on")+"}]");
                        log4jParamters_tDBInput_7.append(" | ");
                            log4jParamters_tDBInput_7.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
                        log4jParamters_tDBInput_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBInput_7 - "  + (log4jParamters_tDBInput_7) );
                    } 
                } 
            new BytesLimit65535_tDBInput_7().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBInput_7", "\"tbl_audited_questions\"", "tMysqlInput");
				talendJobLogProcess(globalMap);
			}
			
	
	
		    java.util.Calendar calendar_tDBInput_7 = java.util.Calendar.getInstance();
		    calendar_tDBInput_7.set(0, 0, 0, 0, 0, 0);
		    java.util.Date year0_tDBInput_7 = calendar_tDBInput_7.getTime();
		    int nb_line_tDBInput_7 = 0;
		    java.sql.Connection conn_tDBInput_7 = null;
				conn_tDBInput_7 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");
				
				if(conn_tDBInput_7 != null) {
					if(conn_tDBInput_7.getMetaData() != null) {
						
							log.debug("tDBInput_7 - Uses an existing connection with username '" + conn_tDBInput_7.getMetaData().getUserName() + "'. Connection URL: " + conn_tDBInput_7.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tDBInput_7 = conn_tDBInput_7.createStatement();
				if(stmt_tDBInput_7 instanceof com.mysql.cj.jdbc.StatementImpl){
				    ((com.mysql.cj.jdbc.StatementImpl)stmt_tDBInput_7).enableStreamingResults();
				}else if(stmt_tDBInput_7 instanceof com.mysql.cj.jdbc.StatementWrapper){
				    ((com.mysql.cj.jdbc.StatementWrapper)stmt_tDBInput_7).enableStreamingResults();
				}

		    String dbquery_tDBInput_7 = "SELECT \n  `tbl_audited_questions`.`id`, \n  `tbl_audited_questions`.`m_Id`, \n  `tbl_audited_questions`.`process_audit_de"
+"tails_id`, \n  `tbl_audited_questions`.`audit_plan_id`, \n  `tbl_audited_questions`.`process_name`, \n  `tbl_audited_questi"
+"ons`.`subprocess_name`, \n  `tbl_audited_questions`.`question`, \n  `tbl_audited_questions`.`option_name`, \n  `tbl_audited"
+"_questions`.`max_marks`, \n  `tbl_audited_questions`.`score`, \n  `tbl_audited_questions`.`observation`, \n  `tbl_audited_q"
+"uestions`.`other_observation`, \n  `tbl_audited_questions`.`risk_type`, \n  `tbl_audited_questions`.`attachement`, \n  `tbl"
+"_audited_questions`.`attachement_type`, \n  `tbl_audited_questions`.`resloved_attachment`, \n  `tbl_audited_questions`.`is"
+"_nc`, \n  `tbl_audited_questions`.`nc_status`, \n  `tbl_audited_questions`.`assigned_to`, \n  `tbl_audited_questions`.`role"
+"_code`, \n  `tbl_audited_questions`.`nc_remarks`, \n  `tbl_audited_questions`.`is_major_nc`, \n  `tbl_audited_questions`.`c"
+"ategory_id`, \n  `tbl_audited_questions`.`category_name`, \n  `tbl_audited_questions`.`created_by`, \n  `tbl_audited_questi"
+"ons`.`created_on`, \n  `tbl_audited_questions`.`updated_by`, \n  `tbl_audited_questions`.`updated_on`, \n  `tbl_audited_que"
+"stions`.`closed_by`, \n  `tbl_audited_questions`.`closed_on`, \n  `tbl_audited_questions`.`is_active`, \n  `tbl_audited_que"
+"stions`.`is_deleted`, \n  `tbl_audited_questions`.`audited_questions_id`, \n  `tbl_audited_questions`.`linking_id`, \n  `tb"
+"l_audited_questions`.`option_id`, \n  `tbl_audited_questions`.`question_order`, \n  `tbl_audited_questions`.`observation_i"
+"d`, \n  `tbl_audited_questions`.`observation_mandatory`, \n  `tbl_audited_questions`.`mandatory`, \n  `tbl_audited_question"
+"s`.`is_other_observation`, \n  `tbl_audited_questions`.`file_name`, \n  `tbl_audited_questions`.`file_type`, \n  `tbl_audit"
+"ed_questions`.`file_path`, \n  `tbl_audited_questions`.`is_attached`, \n  `tbl_audited_questions`.`is_linked`, \n  `tbl_aud"
+"ited_questions`.`is_primary`, \n  `tbl_audited_questions`.`temp_process`, \n  `tbl_audited_questions`.`transaction_questio"
+"n_Id`, \n  `tbl_audited_questions`.`is_first_linked`, \n  `tbl_audited_questions`.`is_fraud`, \n  `tbl_audited_questions`.`"
+"is_converted`,\n	DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 DAY) AS `as_on`\nFROM `tbl_audited_questions`";
		    
	    		log.debug("tDBInput_7 - Executing the query: '" + dbquery_tDBInput_7 + "'.");
			

            	globalMap.put("tDBInput_7_QUERY",dbquery_tDBInput_7);
		    java.sql.ResultSet rs_tDBInput_7 = null;

		    try {
		    	rs_tDBInput_7 = stmt_tDBInput_7.executeQuery(dbquery_tDBInput_7);
		    	java.sql.ResultSetMetaData rsmd_tDBInput_7 = rs_tDBInput_7.getMetaData();
		    	int colQtyInRs_tDBInput_7 = rsmd_tDBInput_7.getColumnCount();

		    String tmpContent_tDBInput_7 = null;
		    
		    
		    	log.debug("tDBInput_7 - Retrieving records from the database.");
		    
		    while (rs_tDBInput_7.next()) {
		        nb_line_tDBInput_7++;
		        
							if(colQtyInRs_tDBInput_7 < 1) {
								row3.id = 0;
							} else {
		                          
            row3.id = rs_tDBInput_7.getInt(1);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 2) {
								row3.m_Id = null;
							} else {
	                         		
        	row3.m_Id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 2, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 3) {
								row3.process_audit_details_id = null;
							} else {
		                          
            row3.process_audit_details_id = rs_tDBInput_7.getBigDecimal(3);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 4) {
								row3.audit_plan_id = null;
							} else {
		                          
            row3.audit_plan_id = rs_tDBInput_7.getBigDecimal(4);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 5) {
								row3.process_name = null;
							} else {
	                         		
        	row3.process_name = routines.system.JDBCUtil.getString(rs_tDBInput_7, 5, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 6) {
								row3.subprocess_name = null;
							} else {
	                         		
        	row3.subprocess_name = routines.system.JDBCUtil.getString(rs_tDBInput_7, 6, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 7) {
								row3.question = null;
							} else {
	                         		
        	row3.question = routines.system.JDBCUtil.getString(rs_tDBInput_7, 7, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 8) {
								row3.option_name = null;
							} else {
	                         		
        	row3.option_name = routines.system.JDBCUtil.getString(rs_tDBInput_7, 8, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 9) {
								row3.max_marks = null;
							} else {
		                          
            row3.max_marks = rs_tDBInput_7.getFloat(9);
            if(rs_tDBInput_7.wasNull()){
                    row3.max_marks = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 10) {
								row3.score = null;
							} else {
		                          
            row3.score = rs_tDBInput_7.getFloat(10);
            if(rs_tDBInput_7.wasNull()){
                    row3.score = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 11) {
								row3.observation = null;
							} else {
	                         		
        	row3.observation = routines.system.JDBCUtil.getString(rs_tDBInput_7, 11, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 12) {
								row3.other_observation = null;
							} else {
	                         		
        	row3.other_observation = routines.system.JDBCUtil.getString(rs_tDBInput_7, 12, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 13) {
								row3.risk_type = null;
							} else {
	                         		
        	row3.risk_type = routines.system.JDBCUtil.getString(rs_tDBInput_7, 13, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 14) {
								row3.attachement = null;
							} else {
	                         		
        	row3.attachement = routines.system.JDBCUtil.getString(rs_tDBInput_7, 14, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 15) {
								row3.attachement_type = null;
							} else {
	                         		
        	row3.attachement_type = routines.system.JDBCUtil.getString(rs_tDBInput_7, 15, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 16) {
								row3.resloved_attachment = null;
							} else {
	                         		
        	row3.resloved_attachment = routines.system.JDBCUtil.getString(rs_tDBInput_7, 16, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 17) {
								row3.is_nc = null;
							} else {
		                          
            row3.is_nc = rs_tDBInput_7.getBigDecimal(17);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 18) {
								row3.nc_status = null;
							} else {
		                          
            row3.nc_status = rs_tDBInput_7.getBigDecimal(18);
            if(rs_tDBInput_7.wasNull()){
                    row3.nc_status = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 19) {
								row3.assigned_to = null;
							} else {
		                          
            row3.assigned_to = rs_tDBInput_7.getBigDecimal(19);
            if(rs_tDBInput_7.wasNull()){
                    row3.assigned_to = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 20) {
								row3.role_code = null;
							} else {
		                          
            row3.role_code = rs_tDBInput_7.getBigDecimal(20);
            if(rs_tDBInput_7.wasNull()){
                    row3.role_code = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 21) {
								row3.nc_remarks = null;
							} else {
	                         		
        	row3.nc_remarks = routines.system.JDBCUtil.getString(rs_tDBInput_7, 21, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 22) {
								row3.is_major_nc = null;
							} else {
		                          
            row3.is_major_nc = rs_tDBInput_7.getBigDecimal(22);
            if(rs_tDBInput_7.wasNull()){
                    row3.is_major_nc = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 23) {
								row3.category_id = null;
							} else {
		                          
            row3.category_id = rs_tDBInput_7.getBigDecimal(23);
            if(rs_tDBInput_7.wasNull()){
                    row3.category_id = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 24) {
								row3.category_name = null;
							} else {
	                         		
        	row3.category_name = routines.system.JDBCUtil.getString(rs_tDBInput_7, 24, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 25) {
								row3.created_by = null;
							} else {
		                          
            row3.created_by = rs_tDBInput_7.getBigDecimal(25);
            if(rs_tDBInput_7.wasNull()){
                    row3.created_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 26) {
								row3.created_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(26) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(26);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row3.created_on = rs_tDBInput_7.getTimestamp(26);
					} else {
						row3.created_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row3.created_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_7 < 27) {
								row3.updated_by = null;
							} else {
		                          
            row3.updated_by = rs_tDBInput_7.getInt(27);
            if(rs_tDBInput_7.wasNull()){
                    row3.updated_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 28) {
								row3.updated_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(28) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(28);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row3.updated_on = rs_tDBInput_7.getTimestamp(28);
					} else {
						row3.updated_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row3.updated_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_7 < 29) {
								row3.closed_by = null;
							} else {
		                          
            row3.closed_by = rs_tDBInput_7.getInt(29);
            if(rs_tDBInput_7.wasNull()){
                    row3.closed_by = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 30) {
								row3.closed_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(30) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(30);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row3.closed_on = rs_tDBInput_7.getTimestamp(30);
					} else {
						row3.closed_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row3.closed_on =  null;
				}
		                    }
							if(colQtyInRs_tDBInput_7 < 31) {
								row3.is_active = 0;
							} else {
		                          
            row3.is_active = rs_tDBInput_7.getInt(31);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 32) {
								row3.is_deleted = 0;
							} else {
		                          
            row3.is_deleted = rs_tDBInput_7.getInt(32);
            if(rs_tDBInput_7.wasNull()){
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 33) {
								row3.audited_questions_id = null;
							} else {
	                         		
        	row3.audited_questions_id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 33, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 34) {
								row3.linking_id = null;
							} else {
	                         		
        	row3.linking_id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 34, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 35) {
								row3.option_id = null;
							} else {
	                         		
        	row3.option_id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 35, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 36) {
								row3.question_order = null;
							} else {
		                          
            row3.question_order = rs_tDBInput_7.getInt(36);
            if(rs_tDBInput_7.wasNull()){
                    row3.question_order = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 37) {
								row3.observation_id = null;
							} else {
	                         		
        	row3.observation_id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 37, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 38) {
								row3.observation_mandatory = null;
							} else {
		                          
            row3.observation_mandatory = rs_tDBInput_7.getInt(38);
            if(rs_tDBInput_7.wasNull()){
                    row3.observation_mandatory = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 39) {
								row3.mandatory = null;
							} else {
		                          
            row3.mandatory = rs_tDBInput_7.getInt(39);
            if(rs_tDBInput_7.wasNull()){
                    row3.mandatory = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 40) {
								row3.is_other_observation = null;
							} else {
		                          
            row3.is_other_observation = rs_tDBInput_7.getInt(40);
            if(rs_tDBInput_7.wasNull()){
                    row3.is_other_observation = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 41) {
								row3.file_name = null;
							} else {
	                         		
        	row3.file_name = routines.system.JDBCUtil.getString(rs_tDBInput_7, 41, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 42) {
								row3.file_type = null;
							} else {
	                         		
        	row3.file_type = routines.system.JDBCUtil.getString(rs_tDBInput_7, 42, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 43) {
								row3.file_path = null;
							} else {
	                         		
        	row3.file_path = routines.system.JDBCUtil.getString(rs_tDBInput_7, 43, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 44) {
								row3.is_attached = null;
							} else {
		                          
            row3.is_attached = rs_tDBInput_7.getInt(44);
            if(rs_tDBInput_7.wasNull()){
                    row3.is_attached = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 45) {
								row3.is_linked = null;
							} else {
		                          
            row3.is_linked = rs_tDBInput_7.getInt(45);
            if(rs_tDBInput_7.wasNull()){
                    row3.is_linked = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 46) {
								row3.is_primary = null;
							} else {
		                          
            row3.is_primary = rs_tDBInput_7.getInt(46);
            if(rs_tDBInput_7.wasNull()){
                    row3.is_primary = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 47) {
								row3.temp_process = null;
							} else {
		                          
            row3.temp_process = rs_tDBInput_7.getInt(47);
            if(rs_tDBInput_7.wasNull()){
                    row3.temp_process = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 48) {
								row3.transaction_question_Id = null;
							} else {
	                         		
        	row3.transaction_question_Id = routines.system.JDBCUtil.getString(rs_tDBInput_7, 48, false);
		                    }
							if(colQtyInRs_tDBInput_7 < 49) {
								row3.is_first_linked = null;
							} else {
		                          
            row3.is_first_linked = rs_tDBInput_7.getInt(49);
            if(rs_tDBInput_7.wasNull()){
                    row3.is_first_linked = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 50) {
								row3.is_fraud = null;
							} else {
		                          
            row3.is_fraud = rs_tDBInput_7.getInt(50);
            if(rs_tDBInput_7.wasNull()){
                    row3.is_fraud = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 51) {
								row3.is_converted = null;
							} else {
		                          
            row3.is_converted = rs_tDBInput_7.getInt(51);
            if(rs_tDBInput_7.wasNull()){
                    row3.is_converted = null;
            }
		                    }
							if(colQtyInRs_tDBInput_7 < 52) {
								row3.as_on = null;
							} else {
										
				if(rs_tDBInput_7.getString(52) != null) {
					String dateString_tDBInput_7 = rs_tDBInput_7.getString(52);
					if (!("0000-00-00").equals(dateString_tDBInput_7) && !("0000-00-00 00:00:00").equals(dateString_tDBInput_7)) {
						row3.as_on = rs_tDBInput_7.getTimestamp(52);
					} else {
						row3.as_on = (java.util.Date) year0_tDBInput_7.clone();
					}
				} else {
					row3.as_on =  null;
				}
		                    }
					
						log.debug("tDBInput_7 - Retrieving the record " + nb_line_tDBInput_7 + ".");
					

 



/**
 * [tDBInput_7 begin ] stop
 */
	
	/**
	 * [tDBInput_7 main ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"tbl_audited_questions\"";
		

 


	tos_count_tDBInput_7++;

/**
 * [tDBInput_7 main ] stop
 */
	
	/**
	 * [tDBInput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"tbl_audited_questions\"";
		

 



/**
 * [tDBInput_7 process_data_begin ] stop
 */

	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="Audit_target";
		
			if(runStat.update(execStat,enableLogStash,iterateId,1,1
				
					,"row3","tDBInput_7","\"tbl_audited_questions\"","tMysqlInput","tDBOutput_3","Audit_target","tPostgresqlOutput"
				
			)) {
				talendJobLogProcess(globalMap);
			}
			
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



        whetherReject_tDBOutput_3 = false;
                    pstmt_tDBOutput_3.setInt(1, row3.id);

                    if(row3.m_Id == null) {
pstmt_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(2, row3.m_Id);
}

                    pstmt_tDBOutput_3.setBigDecimal(3, row3.process_audit_details_id);

                    pstmt_tDBOutput_3.setBigDecimal(4, row3.audit_plan_id);

                    if(row3.process_name == null) {
pstmt_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(5, row3.process_name);
}

                    if(row3.subprocess_name == null) {
pstmt_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(6, row3.subprocess_name);
}

                    if(row3.question == null) {
pstmt_tDBOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(7, row3.question);
}

                    if(row3.option_name == null) {
pstmt_tDBOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(8, row3.option_name);
}

                    if(row3.max_marks == null) {
pstmt_tDBOutput_3.setNull(9, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_3.setFloat(9, row3.max_marks);
}

                    if(row3.score == null) {
pstmt_tDBOutput_3.setNull(10, java.sql.Types.FLOAT);
} else {pstmt_tDBOutput_3.setFloat(10, row3.score);
}

                    if(row3.observation == null) {
pstmt_tDBOutput_3.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(11, row3.observation);
}

                    if(row3.other_observation == null) {
pstmt_tDBOutput_3.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(12, row3.other_observation);
}

                    if(row3.risk_type == null) {
pstmt_tDBOutput_3.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(13, row3.risk_type);
}

                    if(row3.attachement == null) {
pstmt_tDBOutput_3.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(14, row3.attachement);
}

                    if(row3.attachement_type == null) {
pstmt_tDBOutput_3.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(15, row3.attachement_type);
}

                    if(row3.resloved_attachment == null) {
pstmt_tDBOutput_3.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(16, row3.resloved_attachment);
}

                    pstmt_tDBOutput_3.setBigDecimal(17, row3.is_nc);

                    pstmt_tDBOutput_3.setBigDecimal(18, row3.nc_status);

                    pstmt_tDBOutput_3.setBigDecimal(19, row3.assigned_to);

                    pstmt_tDBOutput_3.setBigDecimal(20, row3.role_code);

                    if(row3.nc_remarks == null) {
pstmt_tDBOutput_3.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(21, row3.nc_remarks);
}

                    pstmt_tDBOutput_3.setBigDecimal(22, row3.is_major_nc);

                    pstmt_tDBOutput_3.setBigDecimal(23, row3.category_id);

                    if(row3.category_name == null) {
pstmt_tDBOutput_3.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(24, row3.category_name);
}

                    pstmt_tDBOutput_3.setBigDecimal(25, row3.created_by);

                    if(row3.created_on != null) {
pstmt_tDBOutput_3.setTimestamp(26, new java.sql.Timestamp(row3.created_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(26, java.sql.Types.TIMESTAMP);
}

                    if(row3.updated_by == null) {
pstmt_tDBOutput_3.setNull(27, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(27, row3.updated_by);
}

                    if(row3.updated_on != null) {
pstmt_tDBOutput_3.setTimestamp(28, new java.sql.Timestamp(row3.updated_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(28, java.sql.Types.TIMESTAMP);
}

                    if(row3.closed_by == null) {
pstmt_tDBOutput_3.setNull(29, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(29, row3.closed_by);
}

                    if(row3.closed_on != null) {
pstmt_tDBOutput_3.setTimestamp(30, new java.sql.Timestamp(row3.closed_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(30, java.sql.Types.TIMESTAMP);
}

                    pstmt_tDBOutput_3.setInt(31, row3.is_active);

                    pstmt_tDBOutput_3.setInt(32, row3.is_deleted);

                    if(row3.audited_questions_id == null) {
pstmt_tDBOutput_3.setNull(33, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(33, row3.audited_questions_id);
}

                    if(row3.linking_id == null) {
pstmt_tDBOutput_3.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(34, row3.linking_id);
}

                    if(row3.option_id == null) {
pstmt_tDBOutput_3.setNull(35, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(35, row3.option_id);
}

                    if(row3.question_order == null) {
pstmt_tDBOutput_3.setNull(36, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(36, row3.question_order);
}

                    if(row3.observation_id == null) {
pstmt_tDBOutput_3.setNull(37, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(37, row3.observation_id);
}

                    if(row3.observation_mandatory == null) {
pstmt_tDBOutput_3.setNull(38, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(38, row3.observation_mandatory);
}

                    if(row3.mandatory == null) {
pstmt_tDBOutput_3.setNull(39, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(39, row3.mandatory);
}

                    if(row3.is_other_observation == null) {
pstmt_tDBOutput_3.setNull(40, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(40, row3.is_other_observation);
}

                    if(row3.file_name == null) {
pstmt_tDBOutput_3.setNull(41, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(41, row3.file_name);
}

                    if(row3.file_type == null) {
pstmt_tDBOutput_3.setNull(42, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(42, row3.file_type);
}

                    if(row3.file_path == null) {
pstmt_tDBOutput_3.setNull(43, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(43, row3.file_path);
}

                    if(row3.is_attached == null) {
pstmt_tDBOutput_3.setNull(44, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(44, row3.is_attached);
}

                    if(row3.is_linked == null) {
pstmt_tDBOutput_3.setNull(45, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(45, row3.is_linked);
}

                    if(row3.is_primary == null) {
pstmt_tDBOutput_3.setNull(46, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(46, row3.is_primary);
}

                    if(row3.temp_process == null) {
pstmt_tDBOutput_3.setNull(47, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(47, row3.temp_process);
}

                    if(row3.transaction_question_Id == null) {
pstmt_tDBOutput_3.setNull(48, java.sql.Types.VARCHAR);
} else {pstmt_tDBOutput_3.setString(48, row3.transaction_question_Id);
}

                    if(row3.is_first_linked == null) {
pstmt_tDBOutput_3.setNull(49, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(49, row3.is_first_linked);
}

                    if(row3.is_fraud == null) {
pstmt_tDBOutput_3.setNull(50, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(50, row3.is_fraud);
}

                    if(row3.is_converted == null) {
pstmt_tDBOutput_3.setNull(51, java.sql.Types.INTEGER);
} else {pstmt_tDBOutput_3.setInt(51, row3.is_converted);
}

                    if(row3.as_on != null) {
pstmt_tDBOutput_3.setTimestamp(52, new java.sql.Timestamp(row3.as_on.getTime()));
} else {
pstmt_tDBOutput_3.setNull(52, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tDBOutput_3.addBatch();
    		nb_line_tDBOutput_3++;
    		  
    		  
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Adding the record ")  + (nb_line_tDBOutput_3)  + (" to the ")  + ("UPSERT")  + (" batch.") );
    		  batchSizeCounter_tDBOutput_3++;
    		  
    			if ((batchSize_tDBOutput_3 > 0) && (batchSize_tDBOutput_3 <= batchSizeCounter_tDBOutput_3)) {
                try {
						int countSum_tDBOutput_3 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
						for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				    	rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            	    	batchSizeCounter_tDBOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
				    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
				    	String errormessage_tDBOutput_3;
						if (ne_tDBOutput_3 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
							errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
						}else{
							errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
						}
				    	
				    	int countSum_tDBOutput_3 = 0;
						for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
							countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
						}
						rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
				    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
				    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
				    	System.err.println(errormessage_tDBOutput_3);
				    	
					}
    			}
    		

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="Audit_target";
		

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */



	
	/**
	 * [tDBInput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"tbl_audited_questions\"";
		

 



/**
 * [tDBInput_7 process_data_end ] stop
 */
	
	/**
	 * [tDBInput_7 end ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"tbl_audited_questions\"";
		

	}
}finally{
	if (rs_tDBInput_7 != null) {
		rs_tDBInput_7.close();
	}
	if (stmt_tDBInput_7 != null) {
		stmt_tDBInput_7.close();
	}
}

		   globalMap.put("tDBInput_7_NB_LINE",nb_line_tDBInput_7);
		

	    		log.debug("tDBInput_7 - Retrieved records count: "+nb_line_tDBInput_7 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tDBInput_7 - "  + ("Done.") );

ok_Hash.put("tDBInput_7", true);
end_Hash.put("tDBInput_7", System.currentTimeMillis());




/**
 * [tDBInput_7 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="Audit_target";
		



	    try {
				int countSum_tDBOutput_3 = 0;
				if (pstmt_tDBOutput_3 != null && batchSizeCounter_tDBOutput_3 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Executing the ")  + ("UPSERT")  + (" batch.") );
					for(int countEach_tDBOutput_3: pstmt_tDBOutput_3.executeBatch()) {
						countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
					}
					rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
						
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("The ")  + ("UPSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e_tDBOutput_3){
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
	    	java.sql.SQLException ne_tDBOutput_3 = e_tDBOutput_3.getNextException(),sqle_tDBOutput_3=null;
	    	String errormessage_tDBOutput_3;
			if (ne_tDBOutput_3 != null) {
				// build new exception to provide the original cause
				sqle_tDBOutput_3 = new java.sql.SQLException(e_tDBOutput_3.getMessage() + "\ncaused by: " + ne_tDBOutput_3.getMessage(), ne_tDBOutput_3.getSQLState(), ne_tDBOutput_3.getErrorCode(), ne_tDBOutput_3);
				errormessage_tDBOutput_3 = sqle_tDBOutput_3.getMessage();
			}else{
				errormessage_tDBOutput_3 = e_tDBOutput_3.getMessage();
			}
	    	
	    	int countSum_tDBOutput_3 = 0;
			for(int countEach_tDBOutput_3: e_tDBOutput_3.getUpdateCounts()) {
				countSum_tDBOutput_3 += (countEach_tDBOutput_3 < 0 ? 0 : countEach_tDBOutput_3);
			}
			rowsToCommitCount_tDBOutput_3 += countSum_tDBOutput_3;
			
	    		insertedCount_tDBOutput_3 += countSum_tDBOutput_3;
	    	
            log.error("tDBOutput_3 - "  + (errormessage_tDBOutput_3) );
	    	System.err.println(errormessage_tDBOutput_3);
	    	
		}
	    
        if(pstmt_tDBOutput_3 != null) {
        		
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	


			 		if(runStat.updateStatAndLog(execStat,enableLogStash,resourceMap,iterateId,"row3",2,0,
			 			"tDBInput_7","\"tbl_audited_questions\"","tMysqlInput","tDBOutput_3","Audit_target","tPostgresqlOutput","output")) {
						talendJobLogProcess(globalMap);
					}
				
 
                if(log.isDebugEnabled())
            log.debug("tDBOutput_3 - "  + ("Done.") );

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBInput_7 finally ] start
	 */

	

	
	
	currentComponent="tDBInput_7";
	
	
			cLabel="\"tbl_audited_questions\"";
		

 



/**
 * [tDBInput_7 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";
	
	
			cLabel="Audit_target";
		



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBInput_7_SUBPROCESS_STATE", 1);
	}
	


public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "4xeQhn_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";
	
	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addCM("tPostjob_1", "tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tDBClose_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";
	
	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", "uRW3kp_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_1", false);
		start_Hash.put("tDBClose_1", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_1";
	
	
		int tos_count_tDBClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
                    log4jParamters_tDBClose_1.append("Parameters:");
                            log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
                        log4jParamters_tDBClose_1.append(" | ");
                            log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlClose");
                        log4jParamters_tDBClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + (log4jParamters_tDBClose_1) );
                    } 
                } 
            new BytesLimit65535_tDBClose_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMysqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_1 begin ] stop
 */
	
	/**
	 * [tDBClose_1 main ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

	java.sql.Connection conn_tDBClose_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_1");

	if(conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed())
	{
		
	    		log.debug("tDBClose_1 - Closing the connection 'tDBConnection_1' to the database.");
			
			conn_tDBClose_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_1"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	    		log.debug("tDBClose_1 - Connection 'tDBConnection_1' to the database closed.");
			
	}

 


	tos_count_tDBClose_1++;

/**
 * [tDBClose_1 main ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_1 end ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_1 - "  + ("Done.") );

ok_Hash.put("tDBClose_1", true);
end_Hash.put("tDBClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tDBClose_2Process(globalMap);



/**
 * [tDBClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_1 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_1";
	
	

 



/**
 * [tDBClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}
	


public void tDBClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_2");
		org.slf4j.MDC.put("_subJobPid", "TzJJqY_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBClose_2", false);
		start_Hash.put("tDBClose_2", System.currentTimeMillis());
		
	
	currentComponent="tDBClose_2";
	
	
		int tos_count_tDBClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBClose_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBClose_2 = new StringBuilder();
                    log4jParamters_tDBClose_2.append("Parameters:");
                            log4jParamters_tDBClose_2.append("CONNECTION" + " = " + "tDBConnection_2");
                        log4jParamters_tDBClose_2.append(" | ");
                            log4jParamters_tDBClose_2.append("UNIFIED_COMPONENTS" + " = " + "tPostgresqlClose");
                        log4jParamters_tDBClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + (log4jParamters_tDBClose_2) );
                    } 
                } 
            new BytesLimit65535_tDBClose_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addCM("tDBClose_2", "tDBClose_2", "tPostgresqlClose");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tDBClose_2 begin ] stop
 */
	
	/**
	 * [tDBClose_2 main ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	



	java.sql.Connection conn_tDBClose_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
	if(conn_tDBClose_2 != null && !conn_tDBClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Closing the connection ")  + ("conn_tDBConnection_2")  + (" to the database.") );
        conn_tDBClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Connection ")  + ("conn_tDBConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tDBClose_2++;

/**
 * [tDBClose_2 main ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBClose_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 process_data_end ] stop
 */
	
	/**
	 * [tDBClose_2 end ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 
                if(log.isDebugEnabled())
            log.debug("tDBClose_2 - "  + ("Done.") );

ok_Hash.put("tDBClose_2", true);
end_Hash.put("tDBClose_2", System.currentTimeMillis());




/**
 * [tDBClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBClose_2 finally ] start
	 */

	

	
	
	currentComponent="tDBClose_2";
	
	

 



/**
 * [tDBClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBClose_2_SUBPROCESS_STATE", 1);
	}
	


public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "EpIQ29_" + subJobPidCounter.getAndIncrement());
	

	
		String iterateId = "";
	
	
	String currentComponent = "";
	String cLabel =  null;
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";
	
	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
			.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid).custom("father_pid", fatherPid).custom("root_pid", rootPid);
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		
		
		if(jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE){
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.sourceId(jcm.sourceId).sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
				.targetId(jcm.targetId).targetLabel(jcm.targetLabel).targetConnectorType(jcm.targetComponentName)
				.connectionName(jcm.current_connector).rows(jcm.row_count).duration(duration).build();
			auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
			auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
		
			log_context_talendJobLog = builder_talendJobLog
				.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
			auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
			log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {//log current component input line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {//log current component output/reject line
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.valueOf(timeMS);
			
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_name).connectorId(jcm.component_id).connectorLabel(jcm.component_label)
				.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
				.rows(jcm.total_row_number).duration(duration).build();
			auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
		} else if(jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
			java.lang.Exception e_talendJobLog = jcm.exception;
			if(e_talendJobLog!=null) {
				try(java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
					e_talendJobLog.printStackTrace(pw_talendJobLog);
					builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
				}
			}

			if(jcm.extra_info!=null) {
				builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
			}
				
			log_context_talendJobLog = builder_talendJobLog
				.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
				.connectorId(jcm.component_id)
				.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label).build();

			auditLogger_talendJobLog.exception(log_context_talendJobLog);
		}
		
		
		
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";
	
	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    
    
    private final static java.util.Properties jobInfo = new java.util.Properties();
    private final static java.util.Map<String,String> mdcInfo = new java.util.HashMap<>();
    private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();


    public static void main(String[] args){
        final Audit_incremental_major_7_tables Audit_incremental_major_7_tablesClass = new Audit_incremental_major_7_tables();

        int exitCode = Audit_incremental_major_7_tablesClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'Audit_incremental_major_7_tables' - Done.");
	        }

        System.exit(exitCode);
    }
	

	
	
	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if(path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
			readJobInfo(new java.io.File(BUILD_PATH));
	}

    private void readJobInfo(java.io.File jobInfoFile){
	
        if(jobInfoFile.exists()) {
            try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
            	jobInfo.load(is);
            } catch (IOException e) {
            	 
                log.debug("Read jobInfo.properties file fail: " + e.getMessage());
                
            }
        }
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s",
				projectName,jobName,jobInfo.getProperty("gitCommitId"), "8.0.1.20230612_1054-patch"));
		
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

	        if(!"".equals(log4jLevel)){
	        	
				
				
				if("trace".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(), org.apache.logging.log4j.Level.OFF);
				}
				org.apache.logging.log4j.core.config.Configurator.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());
				
			}

	        getjobInfo();
			log.info("TalendJob: 'Audit_incremental_major_7_tables' - Start.");
		

                java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
                for(Object jobInfoKey: jobInfoKeys) {
                    org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
                }
                org.slf4j.MDC.put("_pid", pid);
                org.slf4j.MDC.put("_rootPid", rootPid);
                org.slf4j.MDC.put("_fatherPid", fatherPid);
                org.slf4j.MDC.put("_projectName", projectName);
                org.slf4j.MDC.put("_startTimestamp",java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC ).format( java.time.format.DateTimeFormatter.ISO_INSTANT ));
                org.slf4j.MDC.put("_jobRepositoryId","_8p5JcNkPEe2cDNax3wxz5A");
                org.slf4j.MDC.put("_compiledAtTimestamp","2023-08-02T11:51:19.020120900Z");

                java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
                String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
                if (mxNameTable.length == 2) {
                    org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
                } else {
                    org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
                }

		
		
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");

				System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()), System.getProperty(key)));

				
				
				
				org.apache.logging.log4j.core.config.Configurator.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

            org.slf4j.MDC.put("_pid", pid);

        if (rootPid==null) {
            rootPid = pid;
        }

            org.slf4j.MDC.put("_rootPid", rootPid);

        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }
            org.slf4j.MDC.put("_fatherPid", fatherPid);

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        try {
            java.util.Dictionary<String, Object> jobProperties = null;
            if (inOSGi) {
                jobProperties = routines.system.BundleUtils.getJobProperties(jobName);
    
                if (jobProperties != null && jobProperties.get("context") != null) {
                    contextStr = (String)jobProperties.get("context");
                }
            }
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = Audit_incremental_major_7_tables.class.getClassLoader().getResourceAsStream("talend_tac2_repo/audit_incremental_major_7_tables_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = Audit_incremental_major_7_tables.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
    	                defaultProps.load(inContext);
    	                if (inOSGi && jobProperties != null) {
                             java.util.Enumeration<String> keys = jobProperties.keys();
                             while (keys.hasMoreElements()) {
                                 String propKey = keys.nextElement();
                                 if (defaultProps.containsKey(propKey)) {
                                     defaultProps.put(propKey, (String) jobProperties.get(propKey));
                                 }
                             }
    	                }
    	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,ContextProperties.class,parametersToEncrypt));

            org.slf4j.MDC.put("_context", contextStr);
            log.info("TalendJob: 'Audit_incremental_major_7_tables' - Started.");
            mdcInfo.putAll(org.slf4j.MDC.getCopyOfContextMap());

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBInput_7Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBInput_7) {
globalMap.put("tDBInput_7_SUBPROCESS_STATE", -1);

e_tDBInput_7.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : Audit_incremental_major_7_tables");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");
    resumeUtil.flush();


        org.slf4j.MDC.remove("_subJobName");
        org.slf4j.MDC.remove("_subJobPid");
        org.slf4j.MDC.remove("_systemPid");
        log.info("TalendJob: 'Audit_incremental_major_7_tables' - Finished - status: " + status + " returnCode: " + returnCode );

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     216871 characters generated by Talend Data Integration 
 *     on the August 2, 2023 at 5:21:19 PM IST
 ************************************************************************************************/